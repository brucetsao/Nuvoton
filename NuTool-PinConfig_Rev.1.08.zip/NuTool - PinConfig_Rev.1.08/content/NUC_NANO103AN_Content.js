// chip content
NUTOOL_PIN.g_cfg_chips = [
//NANO100AN
{ name: "NANO100ZC2AN", pkg: "QFN33" },
{ name: "NANO100ZD2AN", pkg: "QFN33" },
{ name: "NANO100ZD3AN", pkg: "QFN33" },
{ name: "NANO100LC2AN", pkg: "LQFP48" },
{ name: "NANO100LD2AN", pkg: "LQFP48" },
{ name: "NANO100LD3AN", pkg: "LQFP48" },
{ name: "NANO100SC2AN", pkg: "LQFP64" },
{ name: "NANO100SD2AN", pkg: "LQFP64" },
{ name: "NANO100SD3AN", pkg: "LQFP64" },
{ name: "NANO100VD2AN", pkg: "LQFP100" },
{ name: "NANO100VD3AN", pkg: "LQFP100" },

{ name: "NANO120ZC2AN", pkg: "QFN33" },
{ name: "NANO120ZD2AN", pkg: "QFN33" },
{ name: "NANO120ZD3AN", pkg: "QFN33" },
{ name: "NANO120LC2AN", pkg: "LQFP48" },
{ name: "NANO120LD2AN", pkg: "LQFP48" },
{ name: "NANO120LD3AN", pkg: "LQFP48" },
{ name: "NANO120SC2AN", pkg: "LQFP64" },
{ name: "NANO120SD2AN", pkg: "LQFP64" },
{ name: "NANO120SD3AN", pkg: "LQFP64" },
{ name: "NANO120VD2AN", pkg: "LQFP100" },
{ name: "NANO120VD3AN", pkg: "LQFP100" },
//NANO100BN
{ name: "NANO100NC2BN", pkg: "QFN48" },
{ name: "NANO100ND2BN", pkg: "QFN48" },
{ name: "NANO100ND3BN", pkg: "QFN48" },
{ name: "NANO100NE3BN", pkg: "QFN48" },
{ name: "NANO100LC2BN", pkg: "LQFP48" },
{ name: "NANO100LD2BN", pkg: "LQFP48" },
{ name: "NANO100LD3BN", pkg: "LQFP48" },
{ name: "NANO100LE3BN", pkg: "LQFP48" },
{ name: "NANO100SC2BN", pkg: "LQFP64" },
{ name: "NANO100SD2BN", pkg: "LQFP64" },
{ name: "NANO100SD3BN", pkg: "LQFP64" },
{ name: "NANO100SE3BN", pkg: "LQFP64" },
{ name: "NANO100KD3BN", pkg: "LQFP128" },
{ name: "NANO100KC2BN", pkg: "LQFP128" },
{ name: "NANO100KD2BN", pkg: "LQFP128" },
{ name: "NANO100KC3BN", pkg: "LQFP128" },
{ name: "NANO100KE3BN", pkg: "LQFP128" },

{ name: "NANO110SC2BN", pkg: "LQFP64" },
{ name: "NANO110SD2BN", pkg: "LQFP64" },
{ name: "NANO110SD3BN", pkg: "LQFP64" },
{ name: "NANO110SE3BN", pkg: "LQFP64" },
{ name: "NANO110RC2BN", pkg: "LQFP64" },
{ name: "NANO110RD2BN", pkg: "LQFP64" },
{ name: "NANO110RD3BN", pkg: "LQFP64" },
{ name: "NANO110RE3BN", pkg: "LQFP64" },
{ name: "NANO110KC2BN", pkg: "LQFP128" },
{ name: "NANO110KD2BN", pkg: "LQFP128" },
{ name: "NANO110KD3BN", pkg: "LQFP128" },
{ name: "NANO110KE3BN", pkg: "LQFP128" },

{ name: "NANO120LC2BN", pkg: "LQFP48" },
{ name: "NANO120LD2BN", pkg: "LQFP48" },
{ name: "NANO120LD3BN", pkg: "LQFP48" },
{ name: "NANO120LE3BN", pkg: "LQFP48" },
{ name: "NANO120SC2BN", pkg: "LQFP64" },
{ name: "NANO120SD2BN", pkg: "LQFP64" },
{ name: "NANO120SD3BN", pkg: "LQFP64" },
{ name: "NANO120SE3BN", pkg: "LQFP64" },
{ name: "NANO120KC2BN", pkg: "LQFP128" },
{ name: "NANO120KD2BN", pkg: "LQFP128" },
{ name: "NANO120KD3BN", pkg: "LQFP128" },
{ name: "NANO120KE3BN", pkg: "LQFP128" },

{ name: "NANO130SC2BN", pkg: "LQFP64" },
{ name: "NANO130SD2BN", pkg: "LQFP64" },
{ name: "NANO130SD3BN", pkg: "LQFP64" },
{ name: "NANO130SE3BN", pkg: "LQFP64" },
{ name: "NANO130KC2BN", pkg: "LQFP128" },
{ name: "NANO130KD2BN", pkg: "LQFP128" },
{ name: "NANO130KD3BN", pkg: "LQFP128" },
{ name: "NANO130KE3BN", pkg: "LQFP128" },
//NANO103
{ name: "NANO103SC2AN", pkg: "LQFP64" },
{ name: "NANO103SD2AN", pkg: "LQFP64" },
{ name: "NANO103SD3AN", pkg: "LQFP64" },

{ name: "NANO103LC2AN", pkg: "LQFP48" },
{ name: "NANO103LD2AN", pkg: "LQFP48" },
{ name: "NANO103LD3AN", pkg: "LQFP48" },

{ name: "NANO103ZC2AN", pkg: "QFN33" },
{ name: "NANO103ZD2AN", pkg: "QFN33" },
{ name: "NANO103ZD3AN", pkg: "QFN33" },
//NANO112
{ name: "NANO112VC2AN", pkg: "LQFP100" },
{ name: "NANO112RC2AN", pkg: "LQFP64" },
{ name: "NANO112RB1AN", pkg: "LQFP64" },
{ name: "NANO112SC2AN", pkg: "LQFP64" },
{ name: "NANO112SB1AN", pkg: "LQFP64" },
{ name: "NANO102SC2AN", pkg: "LQFP64" },
{ name: "NANO112LC2AN", pkg: "LQFP48" },
{ name: "NANO112LB1AN", pkg: "LQFP48" },
{ name: "NANO102LC2AN", pkg: "LQFP48" },
{ name: "NANO102LB1AN", pkg: "LQFP48" },
{ name: "NANO102ZB1AN", pkg: "QFN33" },
{ name: "NANO102ZC2AN", pkg: "QFN33" }
];

NUTOOL_PIN.g_cfg_pkgs = {
	"LQFP64": [
	'PB.14', 'PB.13', 'VBAT', 'PF.6', 'PF.7', 'PA.11', 'PA.10', 'PA.9', 'PA.8', 'PB.4',
	'PB.5', 'PB.6', 'PB.7', 'LDO_CAP', 'VDD', 'VSS',
	'PB.0', 'PB.1', 'PB.2', 'PB.3', 'PD.6', 'PD.7', 'PD.14', 'PD.15', 'PC.3', 'PC.2',
	'PC.1', 'PC.0', 'PE.5', 'PB.11', 'PB.10', 'PB.9',
	'PC.11', 'PC.10', 'PC.9', 'PC.8', 'PA.15', 'PA.14', 'PA.13', 'PA.12', 'PF.0', 'PF.1',
	'AVSS', 'PA.0', 'PA.1', 'PA.2', 'PA.3', 'PA.4',
	'PA.5', 'PA.6', 'VREF', 'AVDD', 'PC.7', 'PC.6', 'PC.15', 'PC.14', 'PB.15', 'PF.3',
	'PF.2', 'nRESET', 'VSS', 'VDD', 'PVSS', 'PB.8'
	],
	"LQFP48": [
	'VBAT', 'PF.6', 'PF.7', 'PA.11', 'PA.10', 'PA.9', 'PA.8', 'PB.4', 'PB.5', 'LDO_CAP',
	'VDD', 'VSS',
	'PB.0', 'PB.1', 'PB.2', 'PB.3', 'PC.3', 'PC.2', 'PC.1', 'PC.0', 'PE.5', 'PB.11',
	'PB.10', 'PB.9',
	'PA.15', 'PA.14', 'PA.13', 'PA.12', 'PF.0', 'PF.1', 'AVSS', 'PA.0', 'PA.1', 'PA.2',
	'PA.3', 'PA.4',
	'PA.5', 'PA.6', 'VREF', 'AVDD', 'PC.7', 'PC.6', 'PB.15', 'PF.3', 'PF.2', 'nRESET',
	'PVSS', 'PB.8'
	],
	"QFN33": [
	'PF.7', 'PA.9', 'PA.8', 'PB.4', 'PB.5', 'LDO_CAP', 'VDD', 'VSS',
	'PB.0', 'PB.1', 'PB.2', 'PB.3', 'PC.3', 'PC.2', 'PC.1', 'PC.0',
	'PA.15', 'PA.14', 'PF.0', 'PF.1', 'PA.0', 'PA.2', 'PA.3', 'PA.4',
	'PA.5', 'PA.6', 'AVDD', 'PF.3', 'PF.2', 'nRESET', 'VBAT', 'PF.6'
	]
};

NUTOOL_PIN.g_cfg_gpios = [
{ f: ['PA.0:0', 'AD0:1', 'CMP1_P:2', 'TM2_CAP_IN:3', 'PWM0_CH2:5', 'SPI3_MOSI1:6'] },
{ f: ['PA.1:0', 'AD1:1', 'CMP1_N:2', 'SPI3_MISO1:6'] },
{ f: ['PA.2:0', 'AD2:1', 'UART1_RXD:5'] },
{ f: ['PA.3:0', 'AD3:1', 'UART1_TXD:5', 'SPI3_MOSI0:6'] },
{ f: ['PA.4:0', 'AD4:1', 'I2C0_SDA:5', 'SPI3_MISO0:6'] },
{ f: ['PA.5:0', 'AD5:1', 'I2C0_SCL:5', 'SPI3_SCLK:6'] },
{ f: ['PA.6:0', 'AD6:1', 'CMP1_OUT:2', 'TM3_CAP_IN:3', 'TM3_ECNT_IN:4', 'PWM0_CH3:5', 'SPI3_SS0:6', 'TM3_TOG_OUT:7'] },
{ f: ['PA.7:0'] },
{ f: ['PA.8:0', 'I2C0_SDA:1', 'TM0_ECNT_IN:2', 'SC0_CLK:3', 'SPI2_SS0:4', 'TM0_TOG_OUT:5', 'UART1_CTSn:6'] },
{ f: ['PA.9:0', 'I2C0_SCL:1', 'TM1_ECNT_IN:2', 'SC0_DAT:3', 'SPI2_SCLK:4', 'TM1_TOG_OUT:5', 'UART1_RTSn:6', 'SNOOPER:7'] },
{ f: ['PA.10:0', 'I2C1_SDA:1', 'TM2_ECNT_IN:2', 'SC0_PWR:3', 'SPI2_MISO0:4', 'TM2_TOG_OUT:5'] },
{ f: ['PA.11:0', 'I2C1_SCL:1', 'TM3_ECNT_IN:2', 'SC0_RST:3', 'SPI2_MOSI0:4', 'TM3_TOG_OUT:5'] },
{ f: ['PA.12:0', 'PWM0_CH0:1', 'TM0_CAP_IN:3', 'I2C0_SDA:5'] },
{ f: ['PA.13:0', 'PWM0_CH1:1', 'TM1_CAP_IN:3', 'I2C0_SCL:5'] },
{ f: ['PA.14:0', 'PWM0_CH2:1', 'I2C1_SDA:2', 'TM2_CAP_IN:3', 'TM2_ECNT_IN:5', 'UART0_RXD:6', 'TM2_TOG_OUT:7'] },
{ f: ['PA.15:0', 'PWM0_CH3:1', 'I2C1_SCL:2', 'TM3_CAP_IN:3', 'SC0_PWR:4', 'TM3_ECNT_IN:5', 'UART0_TXD:6', 'TM3_TOG_OUT:7'] },

{ f: ['PB.0:0', 'UART0_RXD:1', 'SPI1_MOSI0:3'] },
{ f: ['PB.1:0', 'UART0_TXD:1', 'SPI1_MISO0:3'] },
{ f: ['PB.2:0', 'UART0_RTSn:1', 'SPI1_SCLK:3', 'FCLKO:4'] },
{ f: ['PB.3:0', 'UART0_CTSn:1', 'SPI1_SS0:3', 'SC1_CD:4'] },
{ f: ['PB.4:0', 'UART1_RXD:1', 'SC0_CD:3', 'SPI2_SS0:4', 'RTC_HZ_OUT:6'] },
{ f: ['PB.5:0', 'UART1_TXD:1', 'SC0_RST:3', 'SPI2_SCLK:4'] },
{ f: ['PB.6:0', 'UART1_RSTn:1', 'SPI2_MISO0:4'] },
{ f: ['PB.7:0', 'UART1_CTSn:1', 'SPI2_MOSI0:4'] },
{ f: ['PB.8:0', 'STADC:1', 'TM0_ECNT_IN:2', 'INT0:3', 'TM0_TOG_OUT:4', 'SNOOPER:7'] },
{ f: ['PB.9:0', 'SPI1_SS1:1', 'TM1_ECNT_IN:2', 'TM1_TOG_OUT:4', 'INT0:5'] },
{ f: ['PB.10:0', 'SPI0_MOSI0:1', 'TM2_ECNT_IN:2', 'TM2_TOG_OUT:4', 'SPI0_SS1:5'] },
{ f: ['PB.11:0', 'PWM0_CH4:1', 'TM3_ECNT_IN:2', 'TM3_TOG_OUT:4', 'SPI0_MISO0:5'] },
{ f: ['PB.12:0'] },
{ f: ['PB.13:0', 'SPI2_MISO1:3', 'SNOOPER:7'] },
{ f: ['PB.14:0', 'INT0:1', 'SPI2_MOSI1:3', 'SPI2_SS1:4'] },
{ f: ['PB.15:0', 'INT1:1', 'SNOOPER:3', 'SC1_CD:4'] },

{ f: ['PC.0:0', 'SPI0_SS0:1', 'SC1_CLK:4', 'PWM0_BKP1_P1:5'] },
{ f: ['PC.1:0', 'SPI0_SCLK:1', 'SC1_DAT:4', 'PWM0_BKP1_P0:5'] },
{ f: ['PC.2:0', 'SPI0_MISO0:1', 'SC1_PWR:4', 'PWM0_BKP0_P1:5'] },
{ f: ['PC.3:0', 'SPI0_MOSI0:1', 'SC1_RST:4', 'PWM0_BKP0_P0:5'] },
{ f: ['PC.4:0'] },
{ f: ['PC.5:0'] },
{ f: ['PC.6:0', 'UART1_RXD:1', 'TM0_CAP_IN:3', 'SC1_CD:4', 'PWM0_CH0:5'] },
{ f: ['PC.7:0', 'UART1_TXD:1', 'AD7:2', 'TM1_CAP_IN:3', 'PWM0_CH1:5'] },
{ f: ['PC.8:0', 'SPI1_SS0:1', 'I2C1_SDA:5'] },
{ f: ['PC.9:0', 'SPI1_SCLK:1', 'I2C1_SCL:5'] },
{ f: ['PC.10:0', 'SPI1_MISO0:1', 'UART1_RXD:5'] },
{ f: ['PC.11:0', 'SPI1_MOSI0:1', 'UART1_TXD:5'] },
{ f: ['PC.12:0'] },
{ f: ['PC.13:0'] },
{ f: ['PC.14:0', 'UART1_CTSn:1'] },
{ f: ['PC.15:0', 'UART1_RTSn:1', 'TM0_CAP_IN:3'] },

{ f: ['PD.0:0'] },
{ f: ['PD.1:0'] },
{ f: ['PD.2:0'] },
{ f: ['PD.3:0'] },
{ f: ['PD.4:0'] },
{ f: ['PD.5:0'] },
{ f: ['PD.6:0', 'SPI1_MOSI1:3', 'SC1_RST:4'] },
{ f: ['PD.7:0', 'SPI1_MISO1:3', 'SC1_PWR:4'] },
{ f: ['PD.8:0'] },
{ f: ['PD.9:0'] },
{ f: ['PD.10:0'] },
{ f: ['PD.11:0'] },
{ f: ['PD.12:0'] },
{ f: ['PD.13:0'] },
{ f: ['PD.14:0', 'SPI0_MOSI1:1', 'SC1_DAT:4'] },
{ f: ['PD.15:0', 'SPI0_MISO1:1', 'SC1_CLK:4'] },

{ f: ['PE.0:0'] },
{ f: ['PE.1:0'] },
{ f: ['PE.2:0'] },
{ f: ['PE.3:0'] },
{ f: ['PE.4:0'] },
{ f: ['PE.5:0', 'PWM0_CH5:1', 'RTC_HZ_OUT:6'] },
{ f: ['PE.6:0'] },
{ f: ['PE.7:0'] },
{ f: ['PE.8:0'] },
{ f: ['PE.9:0'] },
{ f: ['PE.10:0'] },
{ f: ['PE.11:0'] },
{ f: ['PE.12:0'] },
{ f: ['PE.13:0'] },
{ f: ['PE.14:0'] },
{ f: ['PE.15:0'] },

{ f: ['PF.0:0', 'INT0:5', 'ICE_DAT:7'] },
{ f: ['PF.1:0', 'FCLKO:4', 'INT1:5', 'ICE_CLK:7'] },
{ f: ['PF.2:0', 'XT1_OUT:7'] },
{ f: ['PF.3:0', 'XT1_IN:7'] },
{ f: ['PF.4:0'] },
{ f: ['PF.5:0'] },
{ f: ['PF.6:0', 'I2C1_SDA:1', 'X32O:7'] },
{ f: ['PF.7:0', 'I2C1_SCL:1', 'SC0_CD:3', 'X32I:7'] }
];

NUTOOL_PIN.g_cfg_gpiosDefines = [];
NUTOOL_PIN.g_cfg_gpiosDescriptions = [
'AD0:ADC analog input0.',
'AD1:ADC analog input1.',
'AD2:ADC analog input2.',
'AD3:ADC analog input3.',
'AD4:ADC analog input4.',
'AD5:ADC analog input5.',
'AD6:ADC analog input6.',
'AD7:ADC analog input7.',

'AVDD:Power supply for internal analog circuit.',
'AVSS:Ground pin for analog circuit.',

'CMP1_N:Comparator1 N-end input.',
'CMP1_OUT:Comparator1 output.',
'CMP1_P:Comparator1 P-end input.',

'INT0:External interrupt0 input pin.',

'FCLKO:Frequency Divider output pin.',

'I2C0_SCL:I2C0 clock pin.',
'I2C0_SDA:I2C0 data input/output pin.',
'I2C1_SCL:I2C1 clock pin.',
'I2C1_SDA:I2C1 data input/output pin.',

'ICE_CLK:Serial wired debugger clock pin.',
'ICE_DAT:Serial wired debugger data pin.',

'INT0:External interrupt0 input pin.',
'INT1:External interrupt1 input pin.',
'LDO_CAP:LDO output pin.',
'nRESET:External reset input: active LOW, with an internal pull-up. Set this pin low reset to initial state.',

'PWM0_BKP0_P0:PWM0 break0 input 0.',
'PWM0_BKP0_P1:PWM0 break0 input 1.',
'PWM0_BKP1_P0:PWM0 break1 input 0.',
'PWM0_BKP1_P1:PWM0 break1 input 1.',
'PWM0_CH0:PWM0 channel0 output/capture input.',
'PWM0_CH1:PWM0 channel1 output/capture input.',
'PWM0_CH2:PWM0 channel2 output/capture input.',
'PWM0_CH3:PWM0 channel3 output/capture input.',
'PWM0_CH4:PWM0 channel4 output/capture input.',
'PWM0_CH5:PWM0 channel5 output/capture input.',

'RTC_HZ_OUT:RTC 1Hz output.',

'SC0_CD:SmartCard0 card detect pin.',
'SC0_CLK:SmartCard0 clock pin.',
'SC0_DAT:SmartCard0 data pin.',
'SC0_PWR:SmartCard0 power pin.',
'SC0_RST:SmartCard0 reset pin.',
'SC1_CD:SmartCard1 card detect pin.',
'SC1_CLK:SmartCard1 clock pin.',
'SC1_DAT:SmartCard1 data pin.',
'SC1_PWR:SmartCard1 power pin.',
'SC1_RST:SmartCard1 reset pin.',

'SNOOPER:Snooper pin.',

'SPI0_MISO0:SPI0 1st MISO (Master In, Slave Out) pin.',
'SPI0_MISO1:SPI0 2nd MISO (Master In, Slave Out) pin.',
'SPI0_MOSI0:SPI0 1st MOSI (Master Out, Slave In) pin.',
'SPI0_MOSI1:SPI0 2nd MOSI (Master Out, Slave In) pin.',
'SPI0_SCLK:SPI0 serial clock pin.',
'SPI0_SS0:SPI0 slave select pin.',
'SPI0_SS1:SPI0 slave select pin.',
'SPI1_MISO0:SPI1 1st MISO (Master In, Slave Out) pin.',
'SPI1_MISO1:SPI1 2nd MISO (Master In, Slave Out) pin.',
'SPI1_MOSI0:SPI1 1st MOSI (Master Out, Slave In) pin.',
'SPI1_MOSI1:SPI1 2nd MOSI (Master Out, Slave In) pin.',
'SPI1_SCLK:SPI1 serial clock pin.',
'SPI1_SS0:SPI1 slave select pin.',
'SPI1_SS1:SPI1 slave select pin.',
'SPI2_MISO0:SPI2 1st MISO (Master In, Slave Out) pin.',
'SPI2_MISO1:SPI2 2nd MISO (Master In, Slave Out) pin.',
'SPI2_MOSI0:SPI2 1st MOSI (Master Out, Slave In) pin.',
'SPI2_MOSI1:SPI2 2nd MOSI (Master Out, Slave In) pin.',
'SPI2_SCLK:SPI2 serial clock pin.',
'SPI2_SS0:SPI2 slave select pin.',
'SPI2_SS1:SPI2 slave select pin.',
'SPI3_MISO0:SPI3 1st MISO (Master In, Slave Out) pin.',
'SPI3_MISO1:SPI3 2nd MISO (Master In, Slave Out) pin.',
'SPI3_MOSI0:SPI3 1st MOSI (Master Out, Slave In) pin.',
'SPI3_MOSI1:SPI3 2nd MOSI (Master Out, Slave In) pin.',
'SPI3_SCLK:SPI3 serial clock pin.',
'SPI3_SS0:SPI3 slave select pin.',

'STADC:ADC external trigger input.',

'TM0_CAP_IN:Timer0 capture input.',
'TM0_ECNT_IN:Timer0 external counter input.',
'TM0_TOG_OUT:Timer0 toggle output.',
'TM1_CAP_IN:Timer1 capture input.',
'TM1_ECNT_IN:Timer1 external counter input.',
'TM1_TOG_OUT:Timer1 toggle output.',
'TM2_CAP_IN:Timer2 capture input.',
'TM2_ECNT_IN:Timer2 external counter input.',
'TM2_TOG_OUT:Timer2 toggle output.',
'TM3_CAP_IN:Timer3 capture input.',
'TM3_ECNT_IN:Timer3 external counter input.',
'TM3_TOG_OUT:Timer3 toggle output.',

'UART0_CTSn:UART0 Clear to Send input pin.',
'UART0_RTSn:UART0 Request to Send output pin.',
'UART0_RXD:Data receiver input pin for UART0.',
'UART0_TXD:Data transmitter output pin for UART0.',
'UART1_CTSn:UART1 Clear to Send input pin.',
'UART1_RSTn:UART1 Request to Send output pin.',
'UART1_RTSn:UART1 Request to Send output pin.',
'UART1_RXD:Data receiver input pin for UART1.',
'UART1_TXD:Data transmitter output pin for UART1.',

'VBAT:Power supply for I/O ports and LDO source for internal PLL and digital function.',
'VDD:Power supply for I/O ports and LDO source for internal PLL and digital function.',
'VREF:Voltage reference input for ADC.',
'VSS:Ground pin for digital circuit.',

'X32I:External 32.768 kHz crystal input pin(default).',
'X32O:External 32.768 kHz crystal output pin(default).',
'XT1_IN:External 4~36 MHz (high speed) crystal input pin.',
'XT1_OUT:External 4~36 MHz (high speed) crystal output pin.'
];

NUTOOL_PIN.g_cfg_gpioMatrix = [];
NUTOOL_PIN.g_cfg_shareBits = [];
NUTOOL_PIN.g_cfg_addGPIO = {};
NUTOOL_PIN.g_cfg_unusedGPIO = {};

NUTOOL_PIN.decidepackageNumber = function (given_partNumber_package) {
	var partNumber_package;

	if (typeof given_partNumber_package === 'undefined') {
		partNumber_package = NUTOOL_PIN.getg_partNumber_package();
	}
	else {
		partNumber_package = given_partNumber_package;
	}

	NUTOOL_PIN.g_packageNumber = partNumber_package.substring(partNumber_package.indexOf('(') + 1);
	NUTOOL_PIN.g_packageNumber = NUTOOL_PIN.g_packageNumber.substring(0, NUTOOL_PIN.g_packageNumber.indexOf(')'));
	NUTOOL_PIN.g_packageNumberIndex = NUTOOL_PIN.g_packageNumber;

	partNumber_package = null;
};
