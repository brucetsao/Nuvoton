package com.nuvoton.slidetab.TID;

/**
 * Created by SLMeng on 2016/1/14.
 */
public class DEVICE_DESCRIPTOR {
    int DevDesc_leng;        //Report descriptor length
    int RptDesc_leng;        //Report descriptor length
    int InRptLeng;          //input report length
    int OutRptLeng;          //output report length
    int GetFeatLeng;        //get feature length
    int SetFeatLeng;        //set feature length
    int CID;                //Company ID
    int DID;                //Device ID
    int PID;                //product ID
    int UID;                //product ID
    int UCID;              //product ID
    int reserve1;              //product ID
    int reserve2;              //product ID
}
