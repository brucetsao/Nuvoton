package com.nuvoton.slidetab.TID;

public class TID_FEATURE {
    TID_DATA Data1 = new TID_DATA();              //Class data1
    TID_DATA Data2 = new TID_DATA();              //Class data2
    TID_DATA Data3 = new TID_DATA();              //Class data3
    TID_DATA Data4 = new TID_DATA();              //Class data4
    TID_DATA Data5 = new TID_DATA();              //Class data5
    TID_DATA Data6 = new TID_DATA();              //Class data6
    TID_DATA Data7 = new TID_DATA();              //Class data7
    TID_DATA Data8 = new TID_DATA();              //Class data8
    TID_DATA Data9 = new TID_DATA();              //Class data9
    TID_DATA Data10 = new TID_DATA();             //Class data10
    short[] arg = new short[10];
    short[] datalen = new short[10];
}




