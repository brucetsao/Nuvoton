package com.nuvoton.slidetab.TID;

/**
 * Created by SLMeng on 2016/1/14.
 */
public class TID_DATA {
    int value;
    int minimum;
    int maximum;
}
;