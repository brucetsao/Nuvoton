package com.nuvoton.slidetab.TID;

public class DEVICE_TO_DEVICE {
    short dZERO;
    short dONE;
    short dTWO;
    short dTHR;
    short dFOUR;
    short dFIVE;
    short dSIX;
    short dSEV;
    short dEIG;
    short dNINE;
    short dTEN;
}
