package com.nuvoton.slidetab.TID;

public class TID_OUTPUT {
    TID_DATA Data1 = new TID_DATA();              //Class data1
    TID_DATA Data2 = new TID_DATA();              //Class data2
    TID_DATA Data3 = new TID_DATA();              //Class data3
    TID_DATA Data4 = new TID_DATA();              //Class data4
    TID_DATA Data5 = new TID_DATA();              //Class data5
    short[] arg = new short[5];
    short[] datalen = new short[5];
}
