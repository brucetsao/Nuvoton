package com.nuvoton.slidetab.TID;

/**
 * Created by SLMeng on 2016/1/14.
 */
public class TID_Device {
    DEVICE_DESCRIPTOR DevDesc = new DEVICE_DESCRIPTOR();
    TID_FEATURE Feature = new TID_FEATURE();
    TID_INPUT   Input = new TID_INPUT();
    TID_OUTPUT  Output = new TID_OUTPUT();
    DEVICE_TO_DEVICE dTod = new DEVICE_TO_DEVICE();
}
