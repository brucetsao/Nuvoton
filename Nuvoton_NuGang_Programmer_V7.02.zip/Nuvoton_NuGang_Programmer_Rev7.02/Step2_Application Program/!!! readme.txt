Note:
    Doubly click the setup file to install this application program in PC.
