/*=============================================================*
 *  _  _             ___              _              _         *
 * | \| |   _  _    | _ )     _ _    (_)     __     | |__      *
 * | .` |  | +| |   | _ \    | '_|   | |    / _|    | / /      *
 * |_|\_|   \_,_|   |___/   _|_|_   _|_|_   \__|_   |_\_\      *
 *_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|     *
 *"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'     *
 *                                                             *
 * NuBrick IoT applications firmware                           *
 *                                                             *
 * Written by MB40 for Nuvoton Technology.                     *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                   *
 * HCHEISH@nuvoton.com                                          *
 *=============================================================*
 */
#ifndef LED_H_
#define LED_H_

#include <stdio.h>
#include <stdlib.h>
#include "tid.h"
#include "freq_note.h"

#define LEDPIN_R 2
#define LEDPIN_G 3
#define LEDPIN_B 4

extern void Led_Init(void);
extern void Led_Blink_Start(void);
extern void Led_Stop(void);
extern void Led_Blink_Check(void);

extern unsigned long LedLatency;                                    //single buzzer cycle Time out flag

#endif //LED_H_

