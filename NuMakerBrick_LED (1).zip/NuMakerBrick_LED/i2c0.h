/*=============================================================*
 *  _  _             ___              _              _         *
 * | \| |   _  _    | _ )     _ _    (_)     __     | |__      *
 * | .` |  | +| |   | _ \    | '_|   | |    / _|    | / /      *
 * |_|\_|   \_,_|   |___/   _|_|_   _|_|_   \__|_   |_\_\      *
 *_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|     *
 *"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'     *
 *                                                             *
 * NuBrick IoT applications firmware                           *
 *                                                             *
 * Written by MB40 for Nuvoton Technology.                     *
 * tlshen@nuvoton.com/tzulan611126@gmail.com                   *
 * HCHEISH@nuvoton.com                                          *
 *=============================================================*
 */
#ifndef I2C0_H_
#define I2C0_H_

#include <stdio.h>
#include <stdlib.h>
#include "tid.h"
#include <Wire.h>

#define TID_CHANGE_STATE_FLAG 1
#define TID_FEATURE_FLAG 1
#define TID_INPUT_FLAG 2
#define TID_OUTPUT_FLAG 3
#define TID_REG_MIN 8
#define TID_REG_MAX 12
#define TID_REG_ONE 5
#define TID_REG_TWO 17
#define TID_REG_THR 29
#define TID_REG_FOUR 41
#define TID_REG_FIVE 53
#define TID_REG_SIX 65
#define TID_REG_SEV 77
#define TID_REG_EIG 89
#define TID_REG_NINE 101
#define TID_REG_TEN 113

#endif //LED_H_

