#define  C4   262  // C4      =  261.63Hz
#define  C4u  277  // C4#/D4b =  277.18Hz
#define  D4b  277
#define  D4   294  // D4      =  293.66Hz
#define  D4u  311  // D4#/E4b =  311.13Hz
#define  E4b  311
#define  E4   330  // E4      =  329.63Hz
#define  F4   349  // F4      =  349.23Hz
#define  F4u  370  // F4#/G4b =  369.99Hz
#define  G4b  370
#define  G4   392  // G4      =  392.00Hz
#define  G4u  415  // G4#/A4b =  415.30Hz
#define  A4b  415
#define  A4   440  // A4      =  440.00Hz
#define  A4u  466  // A4#/B4b =  466.16Hz
#define  B4b  466
#define  B4   494  // B4      =  493.88Hz
#define  C5   523  // C5      =  523.25Hz
#define  C5u  554  // C5#/D5b =  554.37Hz
#define  D5b  554
#define  D5   587  // D5      =  587.33Hz
#define  D5u  622  // D5#/E5b =  622.25Hz
#define  E5b  622
#define  E5   659  // E5      =  659.26Hz
#define  F5   698  // F5      =  698.46Hz
#define  F5u  740  // F5#/G5b =  739.99Hz
#define  G5b  740
#define  G5   784  // G5      =  783.99Hz
#define  G5u  831  // G5#/A5b =  830.61Hz
#define  A5b  831
#define  A5   880  // A5      =  880.00Hz
#define  A5u  932  // A5#/B5b =  932.33Hz
#define  B5b  932
#define  B5   988  // B5      =  987.77Hz
#define  C6   1047 // C6      = 1046.50Hz
#define  C6u  1109 // C6#/D6b = 1108.73Hz
#define  D6b  1109
#define  D6   1175 // D6      = 1174.66Hz
#define  D6u  1245 // D6#/E6b = 1244.51Hz
#define  E6b  1245
#define  E6   1319 // E6      = 1318.51Hz
#define  F6   1397 // F6      = 1396.91Hz
#define  F6u  1480 // F6#/G6b = 1479.98Hz
#define  G6   1568 // G6      = 1567.98Hz
#define  G6u  1661 // G6#/A6b = 1661.22Hz
#define  A6b  1661
#define  A6   1760 // A6      = 1760.00Hz
#define  A6u  1865 // A6#/B6b = 1864.66Hz
#define  B6b  1865
#define  B6   1976 // B6      = 1975.53Hz
#define  C7   2093 // C7      = 2093.00Hz
#define  C7u  2217 // C7#/D7b = 2217.46Hz
#define  D7b  2217
#define  D7   2349 // D7      = 2349.32Hz
#define  D7u  2489 // D7#/E7b = 2489.02Hz
#define  E7b  2489
#define  E7   2637 // E7      = 2637.02Hz
#define  F7   2794 // F7      = 2793.83Hz
#define  F7u  2960 // F7#/G7b = 2959.96Hz
#define  G7b  2960
#define  G7   3136 // G7      = 3135.96Hz
#define  G7u  3322 // G7#/A7b = 3322.44Hz
#define  A7b  3322
#define  A7   3520 // A7      = 3520.00Hz
#define  A7u  3729 // A7#/B7b = 3729.31Hz
#define  B7b  3729
#define  B7   3951 // B7      = 3951.07Hz
#define  C8   4186 // C8      = 4186.01Hz
#define  C8u  4435 // C8#/D8b = 4434.92Hz
#define  D8b  4435
#define  D8   4699 // D8      = 4698.64Hz
#define  D8u  4978 // D8#/E8b = 4978.03Hz
#define  E8b  4978


