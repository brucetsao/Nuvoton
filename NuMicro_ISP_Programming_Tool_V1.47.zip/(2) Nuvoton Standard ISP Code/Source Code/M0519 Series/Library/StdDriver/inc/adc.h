/**************************************************************************//**
 * @file     adc.h
 * @version  V3.00
 * $Revision: 13 $
 * $Date: 15/03/09 4:59p $
 * @brief    ADC Driver Header File
 *
 * @note
 * Copyright (C) 2014 Nuvoton Technology Corp. All rights reserved.
 *
 ******************************************************************************/
#ifndef __ADC_H__
#define __ADC_H__


#ifdef __cplusplus
extern "C"
{
#endif


/** @addtogroup Device_Driver Device Driver
  @{
*/

/** @addtogroup ADC_Driver ADC Driver
  @{
*/

/** @addtogroup ADC_EXPORTED_CONSTANTS ADC Exported Constants
  @{
*/
/*---------------------------------------------------------------------------------------------------------*/
/* ADC Sample Module Constant Definitions                                                                  */
/*---------------------------------------------------------------------------------------------------------*/
#define ADC_SMPA0                  (0)    /*!< SAMPLE A0 */
#define ADC_SMPA1                  (1)    /*!< SAMPLE A1 */
#define ADC_SMPA2                  (2)    /*!< SAMPLE A2 */
#define ADC_SMPA3                  (3)    /*!< SAMPLE A3 */
#define ADC_SMPA4                  (4)    /*!< SAMPLE A4 */
#define ADC_SMPA5                  (5)    /*!< SAMPLE A5 */
#define ADC_SMPA6                  (6)    /*!< SAMPLE A6 */
#define ADC_SMPA7                  (7)    /*!< SAMPLE A7 */
#define ADC_SMPB0                  (8)    /*!< SAMPLE B0 */
#define ADC_SMPB1                  (9)    /*!< SAMPLE B1 */
#define ADC_SMPB2                  (10)   /*!< SAMPLE B2 */
#define ADC_SMPB3                  (11)   /*!< SAMPLE B3 */
#define ADC_SMPB4                  (12)   /*!< SAMPLE B4 */
#define ADC_SMPB5                  (13)   /*!< SAMPLE B5 */
#define ADC_SMPB6                  (14)   /*!< SAMPLE B6 */
#define ADC_SMPB7                  (15)   /*!< SAMPLE B7 */

/*---------------------------------------------------------------------------------------------------------*/
/* ADC_ADSPCRA/ADC_ADSPCRB Constant Definitions                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
#define ADC_ADSPCR_CHSEL(x)                ((x) << ADC_ADSPCR_CHSEL_Pos)       /*!< A/D sample module channel selection */
#define ADC_ADSPCR_TRGDLYDIV(x)            ((x) << ADC_ADSPCR_TRGDLYDIV_Pos)   /*!< A/D sample module start of conversion trigger delay clock divider selection */
#define ADC_ADSPCR_TRGDLYCNT(x)            ((x) << ADC_ADSPCR_TRGDLYCNT_Pos)   /*!< A/D sample module start of conversion trigger delay time */

#define ADC_SOFTWARE_TRIGGER               (0)                                                     /*!< Software trigger(Disable hardware trigger) */
#define ADC_FALLING_EDGE_TRIGGER           (ADC_ADSPCR_EXTFEN_Msk | (1UL<<ADC_ADSPCR_TRGSEL_Pos))  /*!< STADC pin falling edge trigger */
#define ADC_RISING_EDGE_TRIGGER            (ADC_ADSPCR_EXTREN_Msk | (1UL<<ADC_ADSPCR_TRGSEL_Pos))  /*!< STADC pin rising edge trigger */
#define ADC_FALLING_RISING_EDGE_TRIGGER    (ADC_ADSPCR_EXTFEN_Msk | ADC_ADSPCR_EXTREN_Msk | (1UL<<ADC_ADSPCR_TRGSEL_Pos)) /*!< STADC pin both falling and rising edge trigger */
#define ADC_ADINT0_TRIGGER                 (2UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< ADC ADINT0 interrupt EOC pulse trigger */
#define ADC_ADINT1_TRIGGER                 (3UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< ADC ADINT1 interrupt EOC pulse trigger */
#define ADC_TIMER0_TRIGGER                 (4UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< Timer0 overflow pulse trigger */
#define ADC_TIMER1_TRIGGER                 (5UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< Timer1 overflow pulse trigger */
#define ADC_TIMER2_TRIGGER                 (6UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< Timer2 overflow pulse trigger */
#define ADC_TIMER3_TRIGGER                 (7UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< Timer3 overflow pulse trigger */
#define ADC_PWM00_TRIGGER                  (8UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< PWM00 trigger */
#define ADC_PWM02_TRIGGER                  (9UL<<ADC_ADSPCR_TRGSEL_Pos)       /*!< PWM02 trigger */
#define ADC_PWM04_TRIGGER                  (0xAUL<<ADC_ADSPCR_TRGSEL_Pos)     /*!< PWM04 trigger */
#define ADC_PWM10_TRIGGER                  (0xBUL<<ADC_ADSPCR_TRGSEL_Pos)     /*!< PWM10 trigger */
#define ADC_PWM12_TRIGGER                  (0xCUL<<ADC_ADSPCR_TRGSEL_Pos)     /*!< PWM12 trigger */
#define ADC_PWM14_TRIGGER                  (0xDUL<<ADC_ADSPCR_TRGSEL_Pos)     /*!< PWM14 trigger */
#define ADC_PWM20_TRIGGER                  (0xEUL<<ADC_ADSPCR_TRGSEL_Pos)     /*!< PWM20 trigger */
#define ADC_PWM21_TRIGGER                  (0xFUL<<ADC_ADSPCR_TRGSEL_Pos)     /*!< PWM21 trigger */

#define ADC_ADSPCR_TRGDLYDIV_1             (0)                                /*!< Trigger delay clock frequency is ADC_CLK/1 */
#define ADC_ADSPCR_TRGDLYDIV_2             (0x1UL<<ADC_ADSPCR_TRGDLYDIV_Pos)  /*!< Trigger delay clock frequency is ADC_CLK/2 */
#define ADC_ADSPCR_TRGDLYDIV_4             (0x2UL<<ADC_ADSPCR_TRGDLYDIV_Pos)  /*!< Trigger delay clock frequency is ADC_CLK/4 */
#define ADC_ADSPCR_TRGDLYDIV_16            (0x3UL<<ADC_ADSPCR_TRGDLYDIV_Pos)  /*!< Trigger delay clock frequency is ADC_CLK/16 */

/*---------------------------------------------------------------------------------------------------------*/
/* ADC_ADCMPR Constant Definitions                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
#define ADC_ADCMPR_CMPCOND_LESS_THAN           (0UL<<ADC_ADCMPR_CMPCOND_Pos)   /*!< The compare condition is "less than" */
#define ADC_ADCMPR_CMPCOND_GREATER_OR_EQUAL    (1UL<<ADC_ADCMPR_CMPCOND_Pos)   /*!< The compare condition is "greater than or equal to" */

#define ADC_CMPSMPL_A0                         (0)    /*!< SAMPLE A0 is selected to be compare */
#define ADC_CMPSMPL_A1                         (1)    /*!< SAMPLE A1 is selected to be compare */
#define ADC_CMPSMPL_A2                         (2)    /*!< SAMPLE A2 is selected to be compare */
#define ADC_CMPSMPL_A3                         (3)    /*!< SAMPLE A3 is selected to be compare */
#define ADC_CMPSMPL_B0                         (4)    /*!< SAMPLE B0 is selected to be compare */
#define ADC_CMPSMPL_B1                         (5)    /*!< SAMPLE B1 is selected to be compare */
#define ADC_CMPSMPL_B2                         (6)    /*!< SAMPLE B2 is selected to be compare */
#define ADC_CMPSMPL_B3                         (7)    /*!< SAMPLE B3 is selected to be compare */

/*---------------------------------------------------------------------------------------------------------*/
/* ADC_ADTCR Constant Definitions                                                                          */
/*---------------------------------------------------------------------------------------------------------*/
#define ADC_ADTCR_SMPA                   (ADC_ADTCR_ADAEST_Pos)    /*!< Extend sampling time for all SAMPLE A */
#define ADC_ADTCR_SMPB                   (ADC_ADTCR_ADBEST_Pos)    /*!< Extend sampling time for all SAMPLE B */

/*---------------------------------------------------------------------------------------------------------*/
/* ADC_SMPTRGA/ADC_SMPTRGB Constant Definitions                                                        */
/*---------------------------------------------------------------------------------------------------------*/
#define ADC_SMPTRG_A0                    (0)    /*!< A/D trigger enable for SAMPLEA0 */
#define ADC_SMPTRG_A1                    (1)    /*!< A/D trigger enable for SAMPLEA1 */
#define ADC_SMPTRG_A2                    (2)    /*!< A/D trigger enable for SAMPLEA2 */
#define ADC_SMPTRG_A3                    (3)    /*!< A/D trigger enable for SAMPLEA3 */
#define ADC_SMPTRG_B0                    (4)    /*!< A/D trigger enable for SAMPLEB0 */
#define ADC_SMPTRG_B1                    (5)    /*!< A/D trigger enable for SAMPLEB1 */
#define ADC_SMPTRG_B2                    (6)    /*!< A/D trigger enable for SAMPLEB2 */
#define ADC_SMPTRG_B3                    (7)    /*!< A/D trigger enable for SAMPLEB3 */

#define ADC_SMPTRG_PWM00                 (ADC_SMPTRG_PWM00REN_Msk)     /*!< PWM00 trigger */
#define ADC_SMPTRG_PWM02                 (ADC_SMPTRG_PWM02REN_Msk)     /*!< PWM02 trigger */
#define ADC_SMPTRG_PWM04                 (ADC_SMPTRG_PWM04REN_Msk)     /*!< PWM04 trigger */
#define ADC_SMPTRG_PWM10                 (ADC_SMPTRG_PWM10REN_Msk)     /*!< PWM10 trigger */
#define ADC_SMPTRG_PWM12                 (ADC_SMPTRG_PWM12REN_Msk)     /*!< PWM12 trigger */
#define ADC_SMPTRG_PWM14                 (ADC_SMPTRG_PWM14REN_Msk)     /*!< PWM14 trigger */
#define ADC_SMPTRG_PWM20                 (ADC_SMPTRG_PWM20REN_Msk)     /*!< PWM20 trigger */
#define ADC_SMPTRG_PWM21                 (ADC_SMPTRG_PWM21REN_Msk)     /*!< PWM21 trigger */

#define ADC_TRGCOND_RISING_EDGE          (0)    /*!< PWM rising edge trigger enable  */
#define ADC_TRGCOND_FALLING_EDGE         (1)    /*!< PWM falling edge trigger enable */
#define ADC_TRGCOND_PERIOD               (2)    /*!< PWM period trigger enable */
#define ADC_TRGCOND_CENTER               (3)    /*!< PWM center trigger enable */

/*---------------------------------------------------------------------------------------------------------*/
/* Constant Definitions of ADC Channel 7 of Sample A Input Source                                          */
/*---------------------------------------------------------------------------------------------------------*/
#define ADC_CH7_EXT_INPUT_SIGNAL         (0)  /*!< External input signal       */
#define ADC_CH7_INT_BANDGAP              (1)  /*!< Internal band-gap voltage   */
#define ADC_CH7_INT_TEMPERATURE_SENSOR   (2)  /*!< Internal temperature sensor */


/*@}*/ /* end of group ADC_EXPORTED_CONSTANTS */

/** @addtogroup ADC_EXPORTED_FUNCTIONS ADC Exported Functions
  @{
*/

/**
  * @brief A/D Converter Control Circuits Reset.
  * @param[in] adc The pointer of the specified ADC module.
  * @return None
  * @details ADRESET bit (ADC_ADCR[1]) remains 1 during ADC reset, when ADC reset end, the ADRESET bit is automatically cleared to 0.
  *          The ADC control circuits will be reset to initial state, but the ADC register values will not be changed.
  */
#define ADC_CONV_RESET(adc) ((adc)->ADCR |= ADC_ADCR_ADRESET_Msk)

/**
  * @brief Enable double buffer mode.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPA0
  *                          - \ref ADC_SMPA1
  *                          - \ref ADC_SMPA2
  *                          - \ref ADC_SMPA3
  *                          - \ref ADC_SMPB0
  *                          - \ref ADC_SMPB1
  *                          - \ref ADC_SMPB2
  *                          - \ref ADC_SMPB3
  * @return None.
  * @details The ADC controller supports a double buffer mode in sample module A/B 0~3.
  *         If user enable DBMAn(ADC_ADDBM[n], n=0~3) or ADC_DBMBn(ADDBM[m], m=8~11), the double buffer mode will enable.
  */
#define ADC_ENABLE_DOUBLE_BUFFER(adc, u32ModuleNum) ((adc)->ADDBM |= (1 << (u32ModuleNum)))

/**
  * @brief Disable double buffer mode.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPA0
  *                          - \ref ADC_SMPA1
  *                          - \ref ADC_SMPA2
  *                          - \ref ADC_SMPA3
  *                          - \ref ADC_SMPB0
  *                          - \ref ADC_SMPB1
  *                          - \ref ADC_SMPB2
  *                          - \ref ADC_SMPB3
  * @return None.
  * @details Sample has one sample result register.
  */
#define ADC_DISABLE_DOUBLE_BUFFER(adc, u32ModuleNum) ((adc)->ADDBM &= ~(1 << (u32ModuleNum)))

/**
  * @brief Enable the interrupt.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32Mask Decides the combination of interrupt enable bits. Each bit corresponds to a interrupt.
  *                    This parameter decides which interrupts will be enabled. Bit 0 is ADIE0, bit 1 is ADIE1..., bit 3 is ADIE3.
  * @return None.
  * @details The A/D converter generates a conversion end ADFn (ADSR1[n]) upon the end of specific sample module A/D conversion.
  *         If ADIEn bit (ADCR[n+2]) is set, the conversion end interrupt request ADINTn is generated (n=0~3).
  */
#define ADC_ENABLE_INT(adc, u32Mask) ((adc)->ADCR |= ((u32Mask) << ADC_ADCR_ADIE0_Pos))

/**
  * @brief Disable the interrupt.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32Mask Decides the combination of interrupt enable bits. Each bit corresponds to a interrupt.
  *                    This parameter decides which interrupts will be disabled. Bit 0 is ADIE0, bit 1 is ADIE1..., bit 3 is ADIE3.
  * @return None.
  * @details Specific sample module A/D ADINTn(n=0~3) interrupt function Disabled.
  */
#define ADC_DISABLE_INT(adc, u32Mask) ((adc)->ADCR &= ~((u32Mask) << ADC_ADCR_ADIE0_Pos))

/**
  * @brief Enable the sample module interrupt.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32IntSel Decides which interrupt source will be used, valid value are from 0 to 3.
  * @param[in] u32ModuleMask the combination of sample module interrupt status bits. Each bit corresponds to a sample module interrupt status.
  *                          This parameter decides which sample module interrupts will be enabled, valid range are between 1~0xFFFF.
  * @return None.
  * @details There are 4 ADC interrupts ADINT0~3, and each of these interrupts has its own interrupt vector address.
  */
#define ADC_ENABLE_SAMPLE_MODULE_INT(adc, u32IntSel, u32ModuleMask) ((adc)->ADINTSRCTL[(u32IntSel)] |= (u32ModuleMask))

/**
  * @brief Disable the sample module interrupt.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32IntSel Decides which interrupt source will be used, valid value are from 0 to 3.
  * @param[in] u32ModuleMask the combination of sample module interrupt status bits. Each bit corresponds to a sample module interrupt status.
  *                          This parameter decides which sample module interrupts will be disabled, valid range are between 1~0xFFFF.
  *                          Bit 0 is sample module A0, bit 1 is sample module A1..., bit 15 is sample module B7.
  * @return None.
  * @details There are 4 ADC interrupts ADINT0~3, and each of these interrupts has its own interrupt vector address.
  */
#define ADC_DISABLE_SAMPLE_MODULE_INT(adc, u32IntSel, u32ModuleMask) ((adc)->ADINTSRCTL[(u32IntSel)] &= ~(u32ModuleMask))

/**
  * @brief Start the A/D conversion.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleMask The combination of sample module. Each bit corresponds to a sample module.
  *                          This parameter decides which sample module will be conversion, valid range are between 1~0xFFFF.
  *                          Bit 0 is sample module A0, bit 1 is sample module A1, ..., bit 15 is sample module B7.
  * @return None.
  * @details After write ADC_ADSSTR register to start ADC conversion, the ADC_ADSTPFR register will show which SAMPLE will conversion.
  */
#define ADC_START_CONV(adc, u32ModuleMask) ((adc)->ADSSTR = (u32ModuleMask))

/**
  * @brief Get the conversion pending flag.
  * @param[in] adc The pointer of the specified ADC module.
  * @return Return the conversion pending sample module.
  * @details This STPFn(ADC_ADSTPFR[15:0]) bit remains 1 during pending state, when the respective ADC conversion is end,
  *          the STPFn (n=0~15) bit is automatically cleared to 0.
  */
#define ADC_GET_PENDING_CONV(adc) ((adc)->ADSTPFR)

/**
  * @brief Get the conversion data of the user-specified sample module.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPA0
  *                          - \ref ADC_SMPA1
  *                          - \ref ADC_SMPA2
  *                          - \ref ADC_SMPA3
  *                          - \ref ADC_SMPA4
  *                          - \ref ADC_SMPA5
  *                          - \ref ADC_SMPA6
  *                          - \ref ADC_SMPA7
  *                          - \ref ADC_SMPB0
  *                          - \ref ADC_SMPB1
  *                          - \ref ADC_SMPB2
  *                          - \ref ADC_SMPB3
  *                          - \ref ADC_SMPB4
  *                          - \ref ADC_SMPB5
  *                          - \ref ADC_SMPB6
  *                          - \ref ADC_SMPB7
  * @return Return the conversion data of the user-specified sample module.
  * @details This macro is used to read RSLT bit (ADC_ADDRAn[11:0] and ADC_ADDRBn[11:0], n=0~7) field to get conversion data.
  */
#define ADC_GET_CONV_DATA(adc, u32ModuleNum) (*(__IO uint32_t *) (&((adc)->ADDRA[0]) + (u32ModuleNum)) & ADC_ADDR_RSLT_Msk)

/**
  * @brief Get the data overrun flag of the user-specified sample module.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleMask The combination of data overrun status bits. Each bit corresponds to a data overrun status, valid range are between 1~0xFFFF.
  * @return Return the data overrun flag of the user-specified sample module.
  * @details This macro is used to read OVERRUN bit (ADC_ADSR0[31:16]) field to get data overrun status.
  */
#define ADC_GET_DATA_OVERRUN_FLAG(adc, u32ModuleMask) (((adc)->ADSR0 >> ADC_ADSR0_OVERRUN_Pos) & (u32ModuleMask))

/**
  * @brief Get the data valid flag of the user-specified sample module.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleMask The combination of data valid status bits. Each bit corresponds to a data valid status, valid range are between 1~0xFFFF.
  * @return Return the data valid flag of the user-specified sample module.
  * @details This macro is used to read VALID bit (ADC_ADSR0[15:0]) field to get data valid flag.
  */
#define ADC_GET_DATA_VALID_FLAG(adc, u32ModuleMask) (((adc)->ADSR0 & ADC_ADSR0_VALID_Msk) & (u32ModuleMask))

/**
  * @brief Get the double data of the user-specified sample module.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPA0
  *                          - \ref ADC_SMPA1
  *                          - \ref ADC_SMPA2
  *                          - \ref ADC_SMPA3
  *                          - \ref ADC_SMPB0
  *                          - \ref ADC_SMPB1
  *                          - \ref ADC_SMPB2
  *                          - \ref ADC_SMPB3
  * @return Return the double data of the user-specified sample module.
  * @details This macro is used to read RSLT bit (ADC_ADDRDBAn[11:0] and ADC_ADDRDBBn[11:0], n=0~3) field to get conversion data.
  */
#define ADC_GET_DOUBLE_DATA(adc, u32ModuleNum) (*(__IO uint32_t *) (&((adc)->ADDRDBA[0]) + ((u32ModuleNum) & 3) + ((u32ModuleNum) & 8)) & (ADC_ADDRDB_RSLT_Msk))

/**
  * @brief Get the user-specified interrupt flags.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32Mask The combination of interrupt status bits. Each bit corresponds to a interrupt status.
  *                    Bit 0 is ADF0, bit 1 is ADF1..., bit 3 is ADF3.
  *                    Bit 6 is ADCMPF0, bit 7 is ADCMPF1.
  * @return Return the user-specified interrupt flags.
  * @details This macro is used to get the user-specified interrupt flags.
  */
#define ADC_GET_INT_FLAG(adc, u32Mask) ((adc)->ADSR1 & (u32Mask))

/**
  * @brief Get the user-specified sample module overrun flags.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleMask The combination of sample module overrun status bits.
  *                          Each bit corresponds to a sample module overrun status, valid range are between 1~0xFFFF.
  * @return Return the user-specified sample module overrun flags.
  * @details This macro is used to get the user-specified sample module overrun flags.
  */
#define ADC_GET_SAMPLE_MODULE_OV_FLAG(adc, u32ModuleMask) ((adc)->ADSPOVFR & (u32ModuleMask))

/**
  * @brief Clear the selected interrupt status bits.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32Mask The combination of compare interrupt status bits. Each bit corresponds to a compare interrupt status.
  *                    Bit 0 is ADIF0, bit 1 is ADIF1..., bit 3 is ADIF3.
  *                    Bit 6 is ADCMPF0, bit 7 is ADCMPF1.
  * @return None.
  * @details This macro is used to clear clear the selected interrupt status bits.
  */
#define ADC_CLR_INT_FLAG(adc, u32Mask) ((adc)->ADSR1 = (u32Mask))

/**
  * @brief Clear the selected sample module overrun status bits.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleMask The combination of sample module overrun status bits.
  *                          Each bit corresponds to a sample module overrun status.
  *                          Bit 0 is SPOVF0, bit 1 is SPOVF1..., bit 15 is SPOVF15.
  * @return None.
  * @details This macro is used to clear the selected sample module overrun status bits.
  */
#define ADC_CLR_SAMPLE_MODULE_OV_FLAG(adc, u32ModuleMask) ((adc)->ADSPOVFR = (u32ModuleMask))

/**
  * @brief Check all sample module A/D result data register overrun flags.
  * @param[in] adc The pointer of the specified ADC module.
  * @retval 0 None of sample module data register overrun flag is set to 1.
  * @retval 1 Any one of sample module data register overrun flag is set to 1.
  * @details The AOVERRUN bit (ADC_ADSR1[27]) will keep 1 when any one of sample module data register\n
  *          overrun flag OVERRUN (ADC_ADDRAn[16] or ADC_ADDRBn[16], n=0~7) is set to 1.
  */
#define ADC_IS_DATA_OV(adc) (((adc)->ADSR1 & ADC_ADSR1_AOVERRUN_Msk) >> ADC_ADSR1_AOVERRUN_Pos)

/**
  * @brief Check all sample module A/D result data register valid flags.
  * @param[in] adc The pointer of the specified ADC module.
  * @retval 0 None of sample module data register valid flag is set to 1.
  * @retval 1 Any one of sample module data register valid flag is set to 1.
  * @details The AVALID bit (ADC_ADSR1[26]) will keep 1 when any one of sample module data register\n
  *          valid flag VALID (ADC_ADDRAn[17] or ADC_ADDRBn[17], n=0~7) is set to 1.
  */
#define ADC_IS_DATA_VALID(adc) (((adc)->ADSR1 & ADC_ADSR1_AVALID_Msk) >> ADC_ADSR1_AVALID_Pos)

/**
  * @brief Check all A/D sample module start of conversion overrun flags.
  * @param[in] adc The pointer of the specified ADC module.
  * @retval 0 None of sample module event overrun flag is set to 1.
  * @retval 1 Any one of sample module event overrun flag is set to 1.
  * @details The ASPOVF bit (ADC_ADSR1[25]) will keep 1 when any one of sample module event overrun flag SPOVF (ADC_ADSPOVFR[n], n=0~15) is set to 1.
  */
#define ADC_IS_SAMPLE_MODULE_OV(adc) (((adc)->ADSR1 & ADC_ADSR1_ASPOVF_Msk) >> ADC_ADSR1_ASPOVF_Pos)

/**
  * @brief Check all A/D interrupt flag overrun bits.
  * @param[in] adc The pointer of the specified ADC module.
  * @retval 0 None of ADINT interrupt flag is overwritten to 1.
  * @retval 1 Any one of ADINT interrupt flag is overwritten to 1.
  * @details The AADFOV bit (ADC_ADSR1[24]) will keep 1 when any one of ADINT interrupt flag ADFOV (ADC_ADIFOVR[3:0], n=0~3) is overwritten to 1.
  */
#define ADC_IS_INT_FLAG_OV(adc) (((adc)->ADSR1 & ADC_ADSR1_AADFOV_Msk) >> ADC_ADSR1_AADFOV_Pos)

/**
  * @brief Get the busy state of ADC.
  * @param[in] adc The pointer of the specified ADC module.
  * @retval 0 Both A/D converter A and B are in idle state.
  * @retval 1 A/D converter A is in busy state.
  * @retval 2 A/D converter B is in busy state.
  * @retval 3 Both A/D converter A and B are in busy state.
  * @details This macro is used to read BUSYA/BUSYB bit (ADC_ADSR1[8]/ADC_ADSR1[16]) to get busy state.
  */
#define ADC_IS_BUSY(adc) ((((adc)->ADSR1 & ADC_ADSR1_BUSYA_Msk) >> ADC_ADSR1_BUSYA_Pos) | (((adc)->ADSR1 & ADC_ADSR1_BUSYB_Msk) >> (ADC_ADSR1_BUSYB_Pos - 1)))

/**
  * @brief Configure the comparator 0 and enable it.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Specifies the compare sample module, valid value are:
  *                          - \ref ADC_CMPSMPL_A0
  *                          - \ref ADC_CMPSMPL_A1
  *                          - \ref ADC_CMPSMPL_A2
  *                          - \ref ADC_CMPSMPL_A3
  *                          - \ref ADC_CMPSMPL_B0
  *                          - \ref ADC_CMPSMPL_B1
  *                          - \ref ADC_CMPSMPL_B2
  *                          - \ref ADC_CMPSMPL_B3
  * @param[in] u32Condition Specifies the compare condition. Valid values are:
  *                          - \ref ADC_ADCMPR_CMPCOND_LESS_THAN            :The compare condition is "less than the compare value"
  *                          - \ref ADC_ADCMPR_CMPCOND_GREATER_OR_EQUAL     :The compare condition is "greater than or equal to the compare value
  * @param[in] u16CMPData Specifies the compare value, valid range are between 0~0xFFF.
  * @param[in] u32MatchCount Specifies the match count setting, valid range are between 0~0xF.
  * @return None.
  * @details For example, ADC_ENABLE_CMP0(ADC, ADC_CMPSMPL_A1, ADC_ADCMPR_CMPCOND_GREATER_OR_EQUAL, 0x800, 10);
  *          Means ADC will assert comparator 0 flag if sample module A1 conversion result is greater or
  *          equal to 0x800 for 10 times continuously, and a compare interrupt request is generated.
  */
#define ADC_ENABLE_CMP0(adc,\
                        u32ModuleNum,\
                        u32Condition,\
                        u16CMPData,\
                        u32MatchCount) ((adc)->ADCMPR[0] |= (((u32ModuleNum) << ADC_ADCMPR_CMPSMPL_Pos)|\
                                                            (u32Condition) |\
                                                            ((u16CMPData) << ADC_ADCMPR_CMPD_Pos)| \
                                                            (((u32MatchCount) - 1) << ADC_ADCMPR_CMPMATCNT_Pos)|\
                                                            ADC_ADCMPR_ADCMP_EN_Msk))

/**
  * @brief Configure the comparator 1 and enable it.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Specifies the compare sample module, valid value are:
  *                          - \ref ADC_CMPSMPL_A0
  *                          - \ref ADC_CMPSMPL_A1
  *                          - \ref ADC_CMPSMPL_A2
  *                          - \ref ADC_CMPSMPL_A3
  *                          - \ref ADC_CMPSMPL_B0
  *                          - \ref ADC_CMPSMPL_B1
  *                          - \ref ADC_CMPSMPL_B2
  *                          - \ref ADC_CMPSMPL_B3
  * @param[in] u32Condition Specifies the compare condition. Valid values are:
  *                          - \ref ADC_ADCMPR_CMPCOND_LESS_THAN            :The compare condition is "less than the compare value"
  *                          - \ref ADC_ADCMPR_CMPCOND_GREATER_OR_EQUAL     :The compare condition is "greater than or equal to the compare value
  * @param[in] u16CMPData Specifies the compare value, valid range are between 0~0xFFF.
  * @param[in] u32MatchCount Specifies the match count setting, valid range are between 0~0xF.
  * @return None.
  * @details For example, ADC_ENABLE_CMP1(ADC, ADC_CMPSMPL_A1, ADC_ADCMPR_CMPCOND_GREATER_OR_EQUAL, 0x800, 10);
  *          Means ADC will assert comparator 0 flag if sample module A1 conversion result is greater or
  *          equal to 0x800 for 10 times continuously, and a compare interrupt request is generated.
  */
#define ADC_ENABLE_CMP1(adc,\
                        u32ModuleNum,\
                        u32Condition,\
                        u16CMPData,\
                        u32MatchCount) ((adc)->ADCMPR[1] |= (((u32ModuleNum) << ADC_ADCMPR_CMPSMPL_Pos)|\
                                                            (u32Condition) |\
                                                            ((u16CMPData) << ADC_ADCMPR_CMPD_Pos)| \
                                                            (((u32MatchCount) - 1) << ADC_ADCMPR_CMPMATCNT_Pos)|\
                                                            ADC_ADCMPR_ADCMP_EN_Msk))

/**
  * @brief Enable the compare interrupt.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32CMP Specifies the compare register, valid value are from 0 to 1.
  * @return None
  * @details If the compare function is enabled and the compare condition matches the setting of CMPCOND (ADC_ADCMPRn[2], n=0~1)
  *         and CMPMATCNT (ADC_ADCMPRn[11:8], n=0~1), ADCMPFn (ADC_ADSR1[7:6], n=0~1) will be asserted, in the meanwhile,
  *         if ADCMPIE is set to 1, a compare interrupt request is generated.
  */
#define ADC_ENABLE_CMP_INT(adc, u32CMP) ((adc)->ADCMPR[(u32CMP)] |= ADC_ADCMPR_ADCMPIE_Msk)

/**
  * @brief Disable the compare interrupt.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32CMP Specifies the compare register, valid value are from 0 to 1.
  * @return None.
  * @details This macro is used to disable the compare interrupt.
  */
#define ADC_DISABLE_CMP_INT(adc, u32CMP) ((adc)->ADCMPR[(u32CMP)] &= ~ADC_ADCMPR_ADCMPIE_Msk)

/**
  * @brief Disable comparator 0.
  * @param[in] adc The pointer of the specified ADC module.
  * @return None.
  * @details This macro is used to disable comparator 0.
  */
#define ADC_DISABLE_CMP0(adc) ((adc)->ADCMPR[0] = 0)

/**
  * @brief Disable comparator 1.
  * @param[in] adc The pointer of the specified ADC module.
  * @return None.
  * @details This macro is used to disable comparator 1.
  */
#define ADC_DISABLE_CMP1(adc) ((adc)->ADCMPR[1] = 0)

/**
  * @brief Configure the analog input source of channel 7 for sample A.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32Source Decides the analog input source of channel 7. Valid values are:
  *                       - \ref ADC_CH7_EXT_INPUT_SIGNAL        : External analog input.
  *                       - \ref ADC_CH7_INT_BANDGAP             : Internal bandgap voltage.
  *                       - \ref ADC_CH7_INT_TEMPERATURE_SENSOR  : Output of internal temperature sensor.
  * @return None.
  * @details Channel 7 of sample A supports 3 input sources: External analog voltage, internal Band-gap voltage, and internal temperature sensor output.
  * @note Channal 7 of sample B doesn't support this function.
  */
#define ADC_CONFIG_CH7(adc, u32Source) ((adc)->ADCHISELR = ((adc)->ADCHISELR & ~ADC_ADCHISELR_PRESEL_Msk) | ((u32Source) << ADC_ADCHISELR_PRESEL_Pos))

/*---------------------------------------------------------------------------------------------------------*/
/* Define ADC functions prototype                                                                          */
/*---------------------------------------------------------------------------------------------------------*/
void ADC_Open(ADC_T *adc, uint32_t u32InputMode);
void ADC_Close(ADC_T *adc);
void ADC_ConfigSampleModule(ADC_T *adc, uint32_t u32ModuleNum, uint32_t u32TriggerSource, uint32_t u32Channel);
void ADC_SetTriggerDelayTime(ADC_T *adc, uint32_t u32ModuleNum, uint32_t u32TriggerDelayTime, uint32_t u32DelayClockDivider);
void ADC_SetExtendSampleTime(ADC_T *adc, uint32_t u32ModuleNum, uint32_t u32ExtendSampleTime);
void ADC_EnableHWTrigger(ADC_T *adc, uint32_t u32ModuleNum, uint32_t u32Source, uint32_t u32Param);
void ADC_DisableHWTrigger(ADC_T *adc, uint32_t u32ModuleNum);

/*@}*/ /* end of group ADC_EXPORTED_FUNCTIONS */

/*@}*/ /* end of group ADC_Driver */

/*@}*/ /* end of group Device_Driver */

#ifdef __cplusplus
}
#endif

#endif //__ADC_H__

/*** (C) COPYRIGHT 2014 Nuvoton Technology Corp. ***/
