/**************************************************************************//**
 * @file     adc.c
 * @version  V3.00
 * $Revision: 11 $
 * $Date: 15/03/09 5:00p $
 * @brief    ADC driver source file
 *
 * @note
 * Copyright (C) 2014 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#include "M0519.h"

/** @addtogroup Device_Driver Device Driver
  @{
*/

/** @addtogroup ADC_Driver ADC Driver
  @{
*/

/** @addtogroup ADC_EXPORTED_FUNCTIONS ADC Exported Functions
  @{
*/

/**
  * @brief This function make ADC_module be ready to convert.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32InputMode Decides the input mode. This parameter is not used.
  * @return None.
  * @details This function is used to set analog input mode and enable A/D Converter.
  *          Before starting A/D conversion function, AD_EN bit (ADC_ADCR[0]) should be set to 1.
  * @note
  */
void ADC_Open(ADC_T *adc, uint32_t u32InputMode)
{
    adc->ADCR |= ADC_ADCR_AD_EN_Msk;
}

/**
  * @brief Disable ADC_module.
  * @param[in] adc The pointer of the specified ADC module..
  * @return None.
  * @details Clear AD_EN bit (ADC_ADCR[0]) to disable A/D converter analog circuit power consumption.
  */
void ADC_Close(ADC_T *adc)
{
    adc->ADCR &= ~ADC_ADCR_AD_EN_Msk;
}

/**
  * @brief Configure the sample control logic module.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPA0
  *                          - \ref ADC_SMPA1
  *                          - \ref ADC_SMPA2
  *                          - \ref ADC_SMPA3
  *                          - \ref ADC_SMPA4
  *                          - \ref ADC_SMPA5
  *                          - \ref ADC_SMPA6
  *                          - \ref ADC_SMPA7
  *                          - \ref ADC_SMPB0
  *                          - \ref ADC_SMPB1
  *                          - \ref ADC_SMPB2
  *                          - \ref ADC_SMPB3
  *                          - \ref ADC_SMPB4
  *                          - \ref ADC_SMPB5
  *                          - \ref ADC_SMPB6
  *                          - \ref ADC_SMPB7
  * @param[in] u32TriggerSrc Decides the trigger source. Valid values are:
  *                           - \ref ADC_SOFTWARE_TRIGGER              : Disable hardware trigger
  *                           - \ref ADC_FALLING_EDGE_TRIGGER          : STADC pin falling edge trigger
  *                           - \ref ADC_RISING_EDGE_TRIGGER           : STADC pin rising edge trigger
  *                           - \ref ADC_FALLING_RISING_EDGE_TRIGGER   : STADC pin both falling and rising edge trigger
  *                           - \ref ADC_ADINT0_TRIGGER                : ADC ADINT0 interrupt EOC pulse trigger
  *                           - \ref ADC_ADINT1_TRIGGER                : ADC ADINT1 interrupt EOC pulse trigger
  *                           - \ref ADC_TIMER0_TRIGGER                : Timer0 overflow pulse trigger
  *                           - \ref ADC_TIMER1_TRIGGER                : Timer1 overflow pulse trigger
  *                           - \ref ADC_TIMER2_TRIGGER                : Timer2 overflow pulse trigger
  *                           - \ref ADC_TIMER3_TRIGGER                : Timer3 overflow pulse trigger
  *                           - \ref ADC_PWM00_TRIGGER                 : PWM00 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM02_TRIGGER                 : PWM02 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM04_TRIGGER                 : PWM04 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM10_TRIGGER                 : PWM10 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM12_TRIGGER                 : PWM12 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM14_TRIGGER                 : PWM14 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM20_TRIGGER                 : PWM20 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  *                           - \ref ADC_PWM21_TRIGGER                 : PWM21 trigger (ADC_SMPAn and ADC_SMPBn, n=4~7 aren't support this configuration)
  * @param[in] u32Channel Specifies the sample module channel, valid value are from 0 to 7.
  * @return None.
  * @details Each of ADC control logic modules A0~7 which is configurable for ADC converter channel ADC0_CH0~7 and trigger source.
  *          And each of ADC control logic modules B0~7 which is configurable for ADC converter channel ADC1_CH0~7 and trigger source.
  */
void ADC_ConfigSampleModule(ADC_T *adc, \
                            uint32_t u32ModuleNum, \
                            uint32_t u32TriggerSrc, \
                            uint32_t u32Channel)
{
    *(__IO uint32_t *) (&((adc)->ADSPCRA[0]) + (u32ModuleNum)) &= ~(ADC_ADSPCR_EXTFEN_Msk | ADC_ADSPCR_EXTREN_Msk | ADC_ADSPCR_TRGSEL_Msk | ADC_ADSPCR_CHSEL_Msk);
    *(__IO uint32_t *) (&((adc)->ADSPCRA[0]) + (u32ModuleNum)) |= (u32TriggerSrc | u32Channel);
}

/**
  * @brief Set trigger delay time.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPA0
  *                          - \ref ADC_SMPA1
  *                          - \ref ADC_SMPA2
  *                          - \ref ADC_SMPA3
  *                          - \ref ADC_SMPB0
  *                          - \ref ADC_SMPB1
  *                          - \ref ADC_SMPB2
  *                          - \ref ADC_SMPB3
  * @param[in] u32TriggerDelayTime Decides the trigger delay time, valid range are between 0~0xFF.
  * @param[in] u32DelayClockDivider Decides the trigger delay clock divider. Valid values are:
  *                                  - \ref ADC_TRGDLYDIV_1    : Trigger delay clock frequency is ADC_CLK/1
  *                                  - \ref ADC_TRGDLYDIV_2    : Trigger delay clock frequency is ADC_CLK/2
  *                                  - \ref ADC_TRGDLYDIV_4    : Trigger delay clock frequency is ADC_CLK/4
  *                                  - \ref ADC_TRGDLYDIV_16   : Trigger delay clock frequency is ADC_CLK/16
  * @return None.
  * @details User can configure the trigger delay time by setting TRGDLYCNT (ADSPCRAn[15:8] and ADSPCRBn[15:8], n=0~3)\n
  *          and TRGDLYDIV (ADSPCRAn[7:6] and ADSPCRBn[7:6], n=0~3).
  *          Trigger delay time = (u32TriggerDelayTime) x Trigger delay clock period.
  */
void ADC_SetTriggerDelayTime(ADC_T *adc, \
                             uint32_t u32ModuleNum, \
                             uint32_t u32TriggerDelayTime, \
                             uint32_t u32DelayClockDivider)
{
    *(__IO uint32_t *) (&((adc)->ADSPCRA[0]) + (u32ModuleNum)) &= ~(ADC_ADSPCR_TRGDLYDIV_Msk | ADC_ADSPCR_TRGDLYCNT_Msk);
    *(__IO uint32_t *) (&((adc)->ADSPCRA[0]) + (u32ModuleNum)) |= ((u32TriggerDelayTime << ADC_ADSPCR_TRGDLYCNT_Pos) | u32DelayClockDivider);
}

/**
  * @brief Set ADC extend sample time.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_ADTCR_SMPA
  *                          - \ref ADC_ADTCR_SMPB
  * @param[in] u32ExtendSampleTime Decides the extend sampling time, the range is from 0~255 ADC clock. Valid value are from 0 to 0xFF.
  * @return None.
  * @details When A/D converting at high conversion rate, the sampling time of analog input voltage may not enough if input channel loading is heavy,
  *          user can extend A/D sampling time after trigger source is coming to get enough sampling time.
  * @note Sample module A0~7 share the same configuration in ADAEST(ADTCR[7:0]) and Sample module B0~7 share the same configuration in ADBEST(ADTCR[23:16]).
  */
void ADC_SetExtendSampleTime(ADC_T *adc, uint32_t u32ModuleNum, uint32_t u32ExtendSampleTime)
{
    adc->ADTCR &= ~(ADC_ADTCR_ADAEST_Msk << (u32ModuleNum));
    adc->ADTCR |= u32ExtendSampleTime << (u32ModuleNum);
}

/**
  * @brief Configure the hardware trigger condition and enable hardware trigger.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPTRG_A0
  *                          - \ref ADC_SMPTRG_A1
  *                          - \ref ADC_SMPTRG_A2
  *                          - \ref ADC_SMPTRG_A3
  *                          - \ref ADC_SMPTRG_B0
  *                          - \ref ADC_SMPTRG_B1
  *                          - \ref ADC_SMPTRG_B2
  *                          - \ref ADC_SMPTRG_B3
  * @param[in] u32Source Decides the hardware trigger source. Valid values are:
  *                       - \ref ADC_SMPTRG_PWM00           :A/D conversion is started by PWM00.
  *                       - \ref ADC_SMPTRG_PWM02           :A/D conversion is started by PWM02.
  *                       - \ref ADC_SMPTRG_PWM04           :A/D conversion is started by PWM04.
  *                       - \ref ADC_SMPTRG_PWM10           :A/D conversion is started by PWM10.
  *                       - \ref ADC_SMPTRG_PWM12           :A/D conversion is started by PWM12.
  *                       - \ref ADC_SMPTRG_PWM14           :A/D conversion is started by PWM14.
  *                       - \ref ADC_SMPTRG_PWM20           :A/D conversion is started by PWM20.
  *                       - \ref ADC_SMPTRG_PWM21           :A/D conversion is started by PWM21.
  * @param[in] u32Param ADC trigger by external pin, this parameter is used to set trigger condition. Valid values are:
  *                      - \ref ADC_TRGCOND_RISING_EDGE     :PWM Rising edge active.
  *                      - \ref ADC_TRGCOND_FALLING_EDGE    :PWM Falling edge active.
  *                      - \ref ADC_TRGCOND_PERIOD          :PWM Period active.
  *                      - \ref ADC_TRGCOND_CENTER          :PWM Center active.
  * @return None
  * @details User can configure the hardware trigger condition of sample module An and Bn(n=0~3) by PWM rising edge, falling edge, period and center point.
  * @note Sample module is triggerred by PWM center point that is only when PWM in Center-aligned mode.
  */
void ADC_EnableHWTrigger(ADC_T *adc,
                         uint32_t u32ModuleNum,
                         uint32_t u32Source,
                         uint32_t u32Param)
{
    *(__IO uint32_t *) (&((adc)->SMPTRGA[0]) + (u32ModuleNum)) |= ((u32Source) << (u32Param));
}

/**
  * @brief Disable hardware trigger ADC function.
  * @param[in] adc The pointer of the specified ADC module.
  * @param[in] u32ModuleNum Decides the sample module number, valid value are:
  *                          - \ref ADC_SMPTRG_A0
  *                          - \ref ADC_SMPTRG_A1
  *                          - \ref ADC_SMPTRG_A2
  *                          - \ref ADC_SMPTRG_A3
  *                          - \ref ADC_SMPTRG_B0
  *                          - \ref ADC_SMPTRG_B1
  *                          - \ref ADC_SMPTRG_B2
  *                          - \ref ADC_SMPTRG_B3
  * @return None
  * @details  Disable triggering of A/D conversion by hardware (PWM trigger).
  */
void ADC_DisableHWTrigger(ADC_T *adc, uint32_t u32ModuleNum)
{
    *(__IO uint32_t *) (&((adc)->SMPTRGA[0]) + (u32ModuleNum)) = 0;
}

/*@}*/ /* end of group ADC_EXPORTED_FUNCTIONS */

/*@}*/ /* end of group ADC_Driver */

/*@}*/ /* end of group Device_Driver */

/*** (C) COPYRIGHT 2014 Nuvoton Technology Corp. ***/
