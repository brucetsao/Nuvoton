/******************************************************************************
 * @file     M451Series.h
 * @version  V0.10
 * $Revision: 1 $
 * $Date: 14/09/09 4:38p $ 
 * @brief    CMSIS Cortex-M4 Core Peripheral Access Layer Header File for M451 Series MCU
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/


#ifndef __M451SERIES_H__    
#define __M451SERIES_H__

#ifdef __cplusplus
 extern "C" {
#endif 

/** @addtogroup M451_Definitions M451 Definitions
  This file defines all structures and symbols for M451:
    - registers and bitfields
    - peripheral base address
    - peripheral ID
    - Peripheral definitions
  @{
*/


/******************************************************************************/
/*                Processor and Core Peripherals                              */
/******************************************************************************/
/** @addtogroup M451_CMSIS Device CMSIS Definitions
  Configuration of the Cortex-M4 Processor and Core Peripherals
  @{
*/

/*
 * ==========================================================================
 * ---------- Interrupt Number Definition -----------------------------------
 * ==========================================================================
 */

typedef enum IRQn
{
/******  Cortex-M4 Processor Exceptions Numbers ***************************************************/
  NonMaskableInt_IRQn           = -14,      /*!<  2 Non Maskable Interrupt                        */
  MemoryManagement_IRQn         = -12,      /*!<  4 Memory Management Interrupt                   */
  BusFault_IRQn                 = -11,      /*!<  5 Bus Fault Interrupt                           */
  UsageFault_IRQn               = -10,      /*!<  6 Usage Fault Interrupt                         */
  SVCall_IRQn                   = -5,       /*!< 11 SV Call Interrupt                             */
  DebugMonitor_IRQn             = -4,       /*!< 12 Debug Monitor Interrupt                       */
  PendSV_IRQn                   = -2,       /*!< 14 Pend SV Interrupt                             */
  SysTick_IRQn                  = -1,       /*!< 15 System Tick Interrupt                         */

/******  M451 Specific Interrupt Numbers ********************************************************/

  BOD_IRQn                      = 0,        /*!< Brown Out detection Interrupt                    */
  IRC_IRQn                      = 1,        /*!< Internal RC Interrupt                            */
  PWRWU_IRQn                    = 2,        /*!< Power Down Wake Up Interrupt                     */
  RAMPE_IRQn                    = 3,        /*!< SRAM parity check failed Interrupt               */
  CKFAIL_IRQn                   = 4,        
  RTC_IRQn                      = 6,        /*!< Real Time Clock Interrupt                        */
  TAMPER_IRQn                   = 7,        /*!< Tamper detection Interrupt                       */
  WDT_IRQn                      = 8,
  WWDT_IRQn                     = 9,
  EINT0_IRQn                    = 10,       /*!< External Input 0 Interrupt                       */
  EINT1_IRQn                    = 11,       /*!< External Input 1 Interrupt                       */
  EINT2_IRQn                    = 12,       /*!< External Input 2 Interrupt                       */
  EINT3_IRQn                    = 13,       /*!< External Input 3 Interrupt                       */
  EINT4_IRQn                    = 14,       /*!< External Input 4 Interrupt                       */
  EINT5_IRQn                    = 15,       /*!< External Input 5 Interrupt                       */
  GPA_IRQn                      = 16,       /*!< GPIO Port A Interrupt                            */
  GPB_IRQn                      = 17,       /*!< GPIO Port B Interrupt                            */
  GPC_IRQn                      = 18,       /*!< GPIO Port C Interrupt                            */
  GPD_IRQn                      = 19,       /*!< GPIO Port D Interrupt                            */
  GPE_IRQn                      = 20,       /*!< GPIO Port E Interrupt                            */
  GPF_IRQn                      = 21,       /*!< GPIO Port F Interrupt                            */
  SPI0_IRQn                     = 22,       /*!< SPI0 Interrupt                                   */
  SPI1_IRQn                     = 23,       /*!< SPI1 Interrupt                                   */
  BRAKE0_IRQn                   = 24,       /*!< BRAKE0 Interrupt                                 */
  PWM0P0_IRQn                   = 25,       /*!< PWM0P0 Interrupt                                 */
  PWM0P1_IRQn                   = 26,       /*!< PWM0P1 Interrupt                                 */
  PWM0P2_IRQn                   = 27,       /*!< PWM0P2 Interrupt                                 */
  BRAKE1_IRQn                   = 28,       /*!< BRAKE1 Interrupt                                 */
  PWM1P0_IRQn                   = 29,       /*!< PWM1P0 Interrupt                                 */
  PWM1P1_IRQn                   = 30,       /*!< PWM1P1 Interrupt                                 */
  PWM1P2_IRQn                   = 31,       /*!< PWM1P2 Interrupt                                 */
  TMR0_IRQn                     = 32,       /*!< Timer 0 Interrupt                                */
  TMR1_IRQn                     = 33,       /*!< Timer 1 Interrupt                                */
  TMR2_IRQn                     = 34,       /*!< Timer 2 Interrupt                                */
  TMR3_IRQn                     = 35,       /*!< Timer 3 Interrupt                                */
  UART0_IRQn                    = 36,       /*!< UART 0 Interrupt                                 */
  UART1_IRQn                    = 37,       /*!< UART 1 Interrupt                                 */
  I2C0_IRQn                     = 38,       /*!< I2C 0 Interrupt                                  */
  I2C1_IRQn                     = 39,       /*!< I2C 1 Interrupt                                  */
  PDMA_IRQn                     = 40,       /*!< Peripheral DMA Interrupt                         */
  DAC_IRQn                      = 41,       /*!< DAC Interrupt                                    */
  ADC00_IRQn                    = 42,       /*!< ADC0 Source 0 Interrupt                          */
  ADC01_IRQn                    = 43,       /*!< ADC0 Source 1 Interrupt                          */
  ACMP01_IRQn                   = 44,       /*!< Analog Comparator 0 and 1 Interrupt              */
  ADC02_IRQn                    = 46,       /*!< ADC0 Source 2 Interrupt                          */
  ADC03_IRQn                    = 47,       /*!< ADC0 Source 3 Interrupt                          */
  UART2_IRQn                    = 48,       
  UART3_IRQn                    = 49,
  SPI2_IRQn                     = 51,
  USBD_IRQn                     = 53,       /*!< USB device Interrupt                             */
  USBH_IRQn                     = 54,       /*!< USB host Interrupt                               */
  USBOTG_IRQn                   = 55,       /*!< USB OTG Interrupt                                */
  CAN0_IRQn                     = 56,       /*!< CAN0 Interrupt                                   */
  SC0_IRQn                      = 58,       /*!< Smart Card 0 Interrupt                           */
  TOUCHKEY_IRQn                 = 63
} IRQn_Type;


/*
 * ==========================================================================
 * ----------- Processor and Core Peripheral Section ------------------------
 * ==========================================================================
 */

/* Configuration of the Cortex-M# Processor and Core Peripherals */
#define __CM4_REV                 0x0201    /*!< Core Revision r2p1                               */
#define __NVIC_PRIO_BITS          4         /*!< Number of Bits used for Priority Levels          */
#define __Vendor_SysTickConfig    0         /*!< Set to 1 if different SysTick Config is used     */
#define __MPU_PRESENT             1         /*!< MPU present or not                               */
#define __FPU_PRESENT             1         /*!< FPU present or not                               */

/*@}*/ /* end of group M451_CMSIS */

#include "core_cm4.h"                       /* Cortex-M4 processor and core peripherals           */
#include "system_M451Series.h"              /* M451 System include file                           */
#include <stdint.h>



/******************************************************************************/
/*                Device Specific Peripheral registers structures             */
/******************************************************************************/

/** @addtogroup REGISTER Control Register

  @{

*/


/*---------------------- Analog Comparator Controller -------------------------*/
/**
    @addtogroup ACMP Analog Comparator Controller(ACMP)
    Memory Mapped Structure for ACMP Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL[2];                /*!< [0x0000] Analog Comparator Control Registers of ACMP0 and ACMP1           */
    __IO uint32_t STATUS;                /*!< [0x0008] Analog Comparator Status Register                                */
    __IO uint32_t VREF;                  /*!< [0x000c] Analog Comparator Reference Voltage Control Register             */

} ACMP_T;

/**
    @addtogroup ACMP_CONST ACMP Bit Field Definition
    Constant Definitions for ACMP Controller
@{ */

#define ACMP_CTL_ACMPEN_Pos              (0)
#define ACMP_CTL_ACMPEN_Msk              (0x1ul << ACMP_CTL_ACMPEN_Pos)

#define ACMP_CTL_ACMPIE_Pos              (1)
#define ACMP_CTL_ACMPIE_Msk              (0x1ul << ACMP_CTL_ACMPIE_Pos)

#define ACMP_CTL_HYSEN_Pos               (2)
#define ACMP_CTL_HYSEN_Msk               (0x1ul << ACMP_CTL_HYSEN_Pos)

#define ACMP_CTL_ACMPOINV_Pos            (3)
#define ACMP_CTL_ACMPOINV_Msk            (0x1ul << ACMP_CTL_ACMPOINV_Pos)

#define ACMP_CTL_NEGSEL_Pos              (4)
#define ACMP_CTL_NEGSEL_Msk              (0x3ul << ACMP_CTL_NEGSEL_Pos)

#define ACMP_CTL_POSSEL_Pos              (6)
#define ACMP_CTL_POSSEL_Msk              (0x3ul << ACMP_CTL_POSSEL_Pos)

#define ACMP_CTL_INTPOL_Pos              (8)
#define ACMP_CTL_INTPOL_Msk              (0x3ul << ACMP_CTL_INTPOL_Pos)

#define ACMP_CTL_OUTSEL_Pos              (12)
#define ACMP_CTL_OUTSEL_Msk              (0x1ul << ACMP_CTL_OUTSEL_Pos)

#define ACMP_CTL_FILTSEL_Pos             (13)
#define ACMP_CTL_FILTSEL_Msk             (0x7ul << ACMP_CTL_FILTSEL_Pos)

#define ACMP_CTL_WKEN_Pos                (16)
#define ACMP_CTL_WKEN_Msk                (0x1ul << ACMP_CTL_WKEN_Pos)

#define ACMP_STATUS_ACMPIF0_Pos          (0)
#define ACMP_STATUS_ACMPIF0_Msk          (0x1ul << ACMP_STATUS_ACMPIF0_Pos)

#define ACMP_STATUS_ACMPIF1_Pos          (1)
#define ACMP_STATUS_ACMPIF1_Msk          (0x1ul << ACMP_STATUS_ACMPIF1_Pos)

#define ACMP_STATUS_ACMPO0_Pos           (4)
#define ACMP_STATUS_ACMPO0_Msk           (0x1ul << ACMP_STATUS_ACMPO0_Pos)

#define ACMP_STATUS_ACMPO1_Pos           (5)
#define ACMP_STATUS_ACMPO1_Msk           (0x1ul << ACMP_STATUS_ACMPO1_Pos)

#define ACMP_STATUS_ACMPWKF0_Pos         (8)
#define ACMP_STATUS_ACMPWKF0_Msk         (0x1ul << ACMP_STATUS_ACMPWKF0_Pos)

#define ACMP_STATUS_ACMPWKF1_Pos         (9)
#define ACMP_STATUS_ACMPWKF1_Msk         (0x1ul << ACMP_STATUS_ACMPWKF1_Pos)

#define ACMP_VREF_CRVCTL_Pos             (0)
#define ACMP_VREF_CRVCTL_Msk             (0xful << ACMP_VREF_CRVCTL_Pos)

#define ACMP_VREF_CRVSSEL_Pos            (6)
#define ACMP_VREF_CRVSSEL_Msk            (0x1ul << ACMP_VREF_CRVSSEL_Pos)

/**@}*/ /* ACMP_CONST */
/**@}*/ /* end of ACMP register group */


/*---------------------- Enhanced Analog to Digital Converter -------------------------*/
/**
    @addtogroup Enhanced Analog to Digital Converter(EADC)
    Memory Mapped Structure for EADC Controller
@{ */
 
typedef struct
{

    __I  uint32_t DAT[19];               /*!< [0x0000~0x0048] A/D Data Register n for SAMPLEn, n=0~18                   */
    __I  uint32_t CURDAT;                /*!< [0x004c] ADC0 PDMA Current Transfer Data Register                         */
    __IO uint32_t CTL;                   /*!< [0x0050] A/D Control Register                                             */
    __O  uint32_t SWTRG;                 /*!< [0x0054] A/D SAMPLE Software Start Register                               */
    __IO uint32_t PENDSTS;               /*!< [0x0058] A/D Start of Conversion Pending Flag Register                    */
    __IO uint32_t OVSTS;                 /*!< [0x005c] A/D SAMPLE Start of Conversion Overrun Flag Register             */
         uint32_t RESERVE0[7];

    __IO uint32_t SELFTCTL;              /*!< [0x007c] A/D Self Test Control Register                                   */
    __IO uint32_t SCTL[19];              /*!< [0x0080~0x00BC] A/D SAMPLEn Control Register, n=0~18                      */
         uint32_t RESERVE1[1];

    __IO uint32_t INTSRC[4];             /*!< [0x00d0~0x00dc] ADC interrupt n Source Enable Control Register, n=0~3     */
    __IO uint32_t CMP[4];                /*!< [0x00e0~0x00ec] A/D Result Compare Register n, n=0~3                      */
    __I  uint32_t STATUS0;               /*!< [0x00f0] A/D Status Register 0                                            */
    __I  uint32_t STATUS1;               /*!< [0x00f4] A/D Status Register 1                                            */
    __IO uint32_t STATUS2;               /*!< [0x00f8] A/D Status Register 2                                            */
    __I  uint32_t STATUS3;               /*!< [0x00fc] A/D Status Register 3                                            */
    __I  uint32_t DDAT[4];               /*!< [0x0100~0x010c] A/D Double Data Register n for SAMPLEn, n=0~3             */

} EADC_T;

/**
    @addtogroup EADC_CONST EADC Bit Field Definition
    Constant Definitions for EADC Controller
@{ */
#define EADC_DAT_RESULT_Pos               (0)
#define EADC_DAT_RESULT_Msk               (0xfffful << EADC_DAT_RESULT_Pos)

#define EADC_DAT_OV_Pos                   (16)
#define EADC_DAT_OV_Msk                   (0x1ul << EADC_DAT_OV_Pos)

#define EADC_DAT_VALID_Pos                (17)
#define EADC_DAT_VALID_Msk                (0x1ul << EADC_DAT_VALID_Pos)

#define EADC_CURDAT_CURDAT_Pos            (0)
#define EADC_CURDAT_CURDAT_Msk            (0x3fffful << EADC_CURDAT_CURDAT_Pos)

#define EADC_CTL_ADCEN_Pos                (0)
#define EADC_CTL_ADCEN_Msk                (0x1ul << EADC_CTL_ADCEN_Pos)

#define EADC_CTL_ADRST_Pos                (1)
#define EADC_CTL_ADRST_Msk                (0x1ul << EADC_CTL_ADRST_Pos)

#define EADC_CTL_ADCIEN0_Pos              (2)
#define EADC_CTL_ADCIEN0_Msk              (0x1ul << EADC_CTL_ADCIEN0_Pos)

#define EADC_CTL_ADCIEN1_Pos              (3)
#define EADC_CTL_ADCIEN1_Msk              (0x1ul << EADC_CTL_ADCIEN1_Pos)

#define EADC_CTL_ADCIEN2_Pos              (4)
#define EADC_CTL_ADCIEN2_Msk              (0x1ul << EADC_CTL_ADCIEN2_Pos)

#define EADC_CTL_ADCIEN3_Pos              (5)
#define EADC_CTL_ADCIEN3_Msk              (0x1ul << EADC_CTL_ADCIEN3_Pos)

#define EADC_CTL_DIFFEN_Pos               (8)
#define EADC_CTL_DIFFEN_Msk               (0x1ul << EADC_CTL_DIFFEN_Pos)

#define EADC_CTL_DMOF_Pos                 (9)
#define EADC_CTL_DMOF_Msk                 (0x1ul << EADC_CTL_DMOF_Pos)

#define EADC_CTL_PDMAEN_Pos               (11)
#define EADC_CTL_PDMAEN_Msk               (0x1ul << EADC_CTL_PDMAEN_Pos)

#define EADC_CTL_SMPTSEL_Pos              (16)
#define EADC_CTL_SMPTSEL_Msk              (0x7ul << EADC_CTL_SMPTSEL_Pos)

#define EADC_SWTRG_SWTRG_Pos              (0)
#define EADC_SWTRG_SWTRG_Msk              (0x7fffful << EADC_SWTRG_SWTRG_Pos)

#define EADC_PENDSTS_STPF_Pos             (0)
#define EADC_PENDSTS_STPF_Msk             (0x7fffful << EADC_PENDSTS_STPF_Pos)

#define EADC_OVSTS_SPOVF_Pos              (0)
#define EADC_OVSTS_SPOVF_Msk              (0x7fffful << EADC_OVSTS_SPOVF_Pos)

#define EADC_SELFTCTL_SELFTEN_Pos         (0)
#define EADC_SELFTCTL_SELFTEN_Msk         (0x1ul << EADC_SELFTCTL_SELFTEN_Pos)

#define EADC_SCTL_CHSEL_Pos               (0)
#define EADC_SCTL_CHSEL_Msk               (0xful << EADC_SCTL_CHSEL_Pos)

#define EADC_SCTL_EXTREN_Pos              (4)
#define EADC_SCTL_EXTREN_Msk              (0x1ul << EADC_SCTL_EXTREN_Pos)

#define EADC_SCTL_EXTFEN_Pos              (5)
#define EADC_SCTL_EXTFEN_Msk              (0x1ul << EADC_SCTL_EXTFEN_Pos)

#define EADC_SCTL_TRGDLYDIV_Pos           (6)
#define EADC_SCTL_TRGDLYDIV_Msk           (0x3ul << EADC_SCTL_TRGDLYDIV_Pos)

#define EADC_SCTL_TRGDLYCNT_Pos          (8)
#define EADC_SCTL_TRGDLYCNT_Msk          (0xfful << EADC_SCTL_TRGDLYCNT_Pos)

#define EADC_SCTL_TRGSEL_Pos             (16)
#define EADC_SCTL_TRGSEL_Msk             (0x1ful << EADC_SCTL_TRGSEL_Pos)

#define EADC_SCTL_INTPOS_Pos             (22)
#define EADC_SCTL_INTPOS_Msk             (0x1ul << EADC_SCTL_INTPOS_Pos)

#define EADC_SCTL_DBMEN_Pos              (23)
#define EADC_SCTL_DBMEN_Msk              (0x1ul << EADC_SCTL_DBMEN_Pos)

#define EADC_SCTL_SPLTEXT_Pos            (24)
#define EADC_SCTL_SPLTEXT_Msk            (0xfful << EADC_SCTL_SPLTEXT_Pos)

#define EADC_INTSRC_SPLIE_Pos            (0)
#define EADC_INTSRC_SPLIE_Msk            (0x7FFFFul << EADC_INTSRC_SPLIE_Pos)

#define EADC_CMP_ADCMPEN_Pos             (0)
#define EADC_CMP_ADCMPEN_Msk             (0x1ul << EADC_CMP_ADCMPEN_Pos)

#define EADC_CMP_ADCMPIE_Pos             (1)
#define EADC_CMP_ADCMPIE_Msk             (0x1ul << EADC_CMP_ADCMPIE_Pos)

#define EADC_CMP_CMPCOND_Pos             (2)
#define EADC_CMP_CMPCOND_Msk             (0x1ul << EADC_CMP_CMPCOND_Pos)

#define EADC_CMP_CMPSPL_Pos              (3)
#define EADC_CMP_CMPSPL_Msk              (0x1ful << EADC_CMP_CMPSPL_Pos)

#define EADC_CMP_CMPMCNT_Pos             (8)
#define EADC_CMP_CMPMCNT_Msk             (0xful << EADC_CMP_CMPMCNT_Pos)

#define EADC_CMP_CMPWEN_Pos              (15)
#define EADC_CMP_CMPWEN_Msk              (0x1ul << EADC_CMP_CMPWEN_Pos)

#define EADC_CMP_CMPDAT_Pos              (16)
#define EADC_CMP_CMPDAT_Msk              (0xffful << EADC_CMP_CMPDAT_Pos)

#define EADC_STATUS0_VALID_Pos            (0)
#define EADC_STATUS0_VALID_Msk            (0xfffful << EADC_STATUS0_VALID_Pos)

#define EADC_STATUS0_OV_Pos               (16)
#define EADC_STATUS0_OV_Msk               (0xfffful << EADC_STATUS0_OV_Pos)

#define EADC_STATUS1_VALID_Pos            (0)
#define EADC_STATUS1_VALID_Msk            (0x7ul << EADC_STATUS1_VALID_Pos)

#define EADC_STATUS1_OV_Pos               (16)
#define EADC_STATUS1_OV_Msk               (0x7ul << EADC_STATUS1_OV_Pos)

#define EADC_STATUS2_ADIF0_Pos            (0)
#define EADC_STATUS2_ADIF0_Msk            (0x1ul << EADC_STATUS2_ADIF0_Pos)

#define EADC_STATUS2_ADIF1_Pos            (1)
#define EADC_STATUS2_ADIF1_Msk            (0x1ul << EADC_STATUS2_ADIF1_Pos)

#define EADC_STATUS2_ADIF2_Pos            (2)
#define EADC_STATUS2_ADIF2_Msk            (0x1ul << EADC_STATUS2_ADIF2_Pos)

#define EADC_STATUS2_ADIF3_Pos            (3)
#define EADC_STATUS2_ADIF3_Msk            (0x1ul << EADC_STATUS2_ADIF3_Pos)

#define EADC_STATUS2_ADCMPF0_Pos          (4)
#define EADC_STATUS2_ADCMPF0_Msk          (0x1ul << EADC_STATUS2_ADCMPF0_Pos)

#define EADC_STATUS2_ADCMPF1_Pos          (5)
#define EADC_STATUS2_ADCMPF1_Msk          (0x1ul << EADC_STATUS2_ADCMPF1_Pos)

#define EADC_STATUS2_ADCMPF2_Pos          (6)
#define EADC_STATUS2_ADCMPF2_Msk          (0x1ul << EADC_STATUS2_ADCMPF2_Pos)

#define EADC_STATUS2_ADCMPF3_Pos          (7)
#define EADC_STATUS2_ADCMPF3_Msk          (0x1ul << EADC_STATUS2_ADCMPF3_Pos)

#define EADC_STATUS2_ADOVIF0_Pos          (8)
#define EADC_STATUS2_ADOVIF0_Msk          (0x1ul << EADC_STATUS2_ADOVIF0_Pos)

#define EADC_STATUS2_ADOVIF1_Pos          (9)
#define EADC_STATUS2_ADOVIF1_Msk          (0x1ul << EADC_STATUS2_ADOVIF1_Pos)

#define EADC_STATUS2_ADOVIF2_Pos          (10)
#define EADC_STATUS2_ADOVIF2_Msk          (0x1ul << EADC_STATUS2_ADOVIF2_Pos)

#define EADC_STATUS2_ADOVIF3_Pos          (11)
#define EADC_STATUS2_ADOVIF3_Msk          (0x1ul << EADC_STATUS2_ADOVIF3_Pos)

#define EADC_STATUS2_ADCMPO0_Pos          (12)
#define EADC_STATUS2_ADCMPO0_Msk          (0x1ul << EADC_STATUS2_ADCMPO0_Pos)

#define EADC_STATUS2_ADCMPO1_Pos          (13)
#define EADC_STATUS2_ADCMPO1_Msk          (0x1ul << EADC_STATUS2_ADCMPO1_Pos)

#define EADC_STATUS2_ADCMPO2_Pos          (14)
#define EADC_STATUS2_ADCMPO2_Msk          (0x1ul << EADC_STATUS2_ADCMPO2_Pos)

#define EADC_STATUS2_ADCMPO3_Pos          (15)
#define EADC_STATUS2_ADCMPO3_Msk          (0x1ul << EADC_STATUS2_ADCMPO3_Pos)

#define EADC_STATUS2_CHANNEL_Pos          (16)
#define EADC_STATUS2_CHANNEL_Msk          (0x1ful << EADC_STATUS2_CHANNEL_Pos)

#define EADC_STATUS2_BUSY_Pos             (23)
#define EADC_STATUS2_BUSY_Msk             (0x1ul << EADC_STATUS2_BUSY_Pos)

#define EADC_STATUS2_ADOVIF_Pos           (24)
#define EADC_STATUS2_ADOVIF_Msk           (0x1ul << EADC_STATUS2_ADOVIF_Pos)

#define EADC_STATUS2_STOVF_Pos            (25)
#define EADC_STATUS2_STOVF_Msk            (0x1ul << EADC_STATUS2_STOVF_Pos)

#define EADC_STATUS2_AVALID_Pos           (26)
#define EADC_STATUS2_AVALID_Msk           (0x1ul << EADC_STATUS2_AVALID_Pos)

#define EADC_STATUS2_AOV_Pos              (27)
#define EADC_STATUS2_AOV_Msk              (0x1ul << EADC_STATUS2_AOV_Pos)

#define EADC_STATUS3_CURSPL_Pos           (0)
#define EADC_STATUS3_CURSPL_Msk           (0x1ful << EADC_STATUS3_CURSPL_Pos)

#define EADC_DDAT_RESULT_Pos             (0)
#define EADC_DDAT_RESULT_Msk             (0xffful << EADC_DDAT_RESULT_Pos)

#define EADC_DDAT_OV_Pos                 (16)
#define EADC_DDAT_OV_Msk                 (0x1ul << EADC_DDAT_OV_Pos)

#define EADC_DDAT_VALID_Pos              (17)
#define EADC_DDAT_VALID_Msk              (0x1ul << EADC_DDAT_VALID_Pos)


/**@}*/ /* EADC_CONST */
/**@}*/ /* end of EADC register group */


/*---------------------- Controller Area Network Controller -------------------------*/
/**
    @addtogroup CAN Controller Area Network Controller(CAN)
    Memory Mapped Structure for CAN Controller
@{ */

typedef struct
{
    __IO uint32_t CREQ;              /*!< IFn (Register Map Note 2) CMD Request Registers                  */
    __IO uint32_t CMASK;             /*!< IFn CMD Mask Registers                                           */
    __IO uint32_t MASK1;             /*!< IFn Mask 1 Registers                                             */
    __IO uint32_t MASK2;             /*!< IFn Mask 2 Registers                                             */
    __IO uint32_t ARB1;              /*!< IFn Arbitration 1 Registers                                      */
    __IO uint32_t ARB2;              /*!< IFn Arbitration 2 Registers                                      */	
    __IO uint32_t MCON;              /*!< IFn Message Control Registers                                    */			
    __IO uint32_t DAT_A1;            /*!< IFn Data A1 Registers (Register Map Note 3)                      */			
    __IO uint32_t DAT_A2;            /*!< IFn Data A2 Registers (Register Map Note 3)                      */		
    __IO uint32_t DAT_B1;            /*!< IFn Data B1 Registers (Register Map Note 3)                      */
    __IO uint32_t DAT_B2;            /*!< IFn Data B2 Registers (Register Map Note 3)                      */		
    __I uint32_t RESERVE0[13];        
                                    
} CAN_IF_T;
 
typedef struct
{

    __IO uint32_t CON;                   /*!< [0x0000] Control Register                                                 */
    __IO uint32_t STATUS;                /*!< [0x0004] Status Register                                                  */
    __I  uint32_t ERR;                   /*!< [0x0008] Error Counter Register                                           */
    __IO uint32_t BTIME;                 /*!< [0x000c] Bit Timing Register                                              */
    __I  uint32_t IIDR;                  /*!< [0x0010] Interrupt Identifier Register                                    */
    __IO uint32_t TEST;                  /*!< [0x0014] Test Register (Register Map Note 1)                              */
    __IO uint32_t BRPE;                  /*!< [0x0018] Baud Rate Prescaler Extension Register                           */
         uint32_t RESERVE0[1];
		 
	__IO CAN_IF_T   IF[2];             
	__I uint32_t   	RESERVE1[8];		 

    __I  uint32_t TXREQ1;                /*!< [0x0100] Transmission Request Register 1                                  */
    __I  uint32_t TXREQ2;                /*!< [0x0104] Transmission Request Register 2                                  */
         uint32_t RESERVE3[6];

    __I  uint32_t NDAT1;                 /*!< [0x0120] New Data Register 1                                              */
    __I  uint32_t NDAT2;                 /*!< [0x0124] New Data Register 2                                              */
         uint32_t RESERVE4[6];

    __I  uint32_t IPND1;                 /*!< [0x0140] Interrupt Pending Register 1                                     */
    __I  uint32_t IPND2;                 /*!< [0x0144] Interrupt Pending Register 2                                     */
         uint32_t RESERVE5[6];

    __I  uint32_t MVLD1;                 /*!< [0x0160] Message Valid Register 1                                         */
    __I  uint32_t MVLD2;                 /*!< [0x0164] Message Valid Register 2                                         */
    __IO uint32_t WU_EN;                 /*!< [0x0168] Wake-up Enable Control Register                                  */
    __IO uint32_t WU_STATUS;             /*!< [0x016c] Wake-up Status Register                                          */

} CAN_T;

/**
    @addtogroup CAN_CONST CAN Bit Field Definition
    Constant Definitions for CAN Controller
@{ */
/* CAN CON Bit Field Definitions */
#define CAN_CON_TEST_Pos           7                                    /*!< CAN CON: TEST Position */  
#define CAN_CON_TEST_Msk           (0x1ul << CAN_CON_TEST_Pos)          /*!< CAN CON: TEST Mask     */  

#define CAN_CON_CCE_Pos            6                                    /*!< CAN CON: CCE Position  */  
#define CAN_CON_CCE_Msk            (0x1ul << CAN_CON_CCE_Pos)           /*!< CAN CON: CCE Mask      */  

#define CAN_CON_DAR_Pos            5                                    /*!< CAN CON: DAR Position  */  
#define CAN_CON_DAR_Msk            (0x1ul << CAN_CON_DAR_Pos)           /*!< CAN CON: DAR Mask      */  

#define CAN_CON_EIE_Pos            3                                    /*!< CAN CON: EIE Position  */  
#define CAN_CON_EIE_Msk            (0x1ul << CAN_CON_EIE_Pos)           /*!< CAN CON: EIE Mask      */  

#define CAN_CON_SIE_Pos            2                                    /*!< CAN CON: SIE Position  */  
#define CAN_CON_SIE_Msk            (0x1ul << CAN_CON_SIE_Pos)           /*!< CAN CON: SIE Mask      */  

#define CAN_CON_IE_Pos             1                                    /*!< CAN CON: IE Position   */  
#define CAN_CON_IE_Msk             (0x1ul << CAN_CON_IE_Pos)            /*!< CAN CON: IE Mask       */  

#define CAN_CON_INIT_Pos           0                                    /*!< CAN CON: INIT Position */  
#define CAN_CON_INIT_Msk           (0x1ul << CAN_CON_INIT_Pos)          /*!< CAN CON: INIT Mask     */  

/* CAN STATUS Bit Field Definitions */
#define CAN_STATUS_BOFF_Pos        7                                    /*!< CAN STATUS: BOFF Position  */
#define CAN_STATUS_BOFF_Msk        (0x1ul << CAN_STATUS_BOFF_Pos)       /*!< CAN STATUS: BOFF Mask      */

#define CAN_STATUS_EWARN_Pos       6                                    /*!< CAN STATUS: EWARN Position */
#define CAN_STATUS_EWARN_Msk       (0x1ul << CAN_STATUS_EWARN_Pos)      /*!< CAN STATUS: EWARN Mask     */

#define CAN_STATUS_EPASS_Pos       5                                    /*!< CAN STATUS: EPASS Position */
#define CAN_STATUS_EPASS_Msk       (0x1ul << CAN_STATUS_EPASS_Pos)      /*!< CAN STATUS: EPASS Mask     */

#define CAN_STATUS_RXOK_Pos        4                                    /*!< CAN STATUS: RXOK Position  */
#define CAN_STATUS_RXOK_Msk        (0x1ul << CAN_STATUS_RXOK_Pos)       /*!< CAN STATUS: RXOK Mask      */

#define CAN_STATUS_TXOK_Pos        3                                    /*!< CAN STATUS: TXOK Position  */
#define CAN_STATUS_TXOK_Msk        (0x1ul << CAN_STATUS_TXOK_Pos)       /*!< CAN STATUS: TXOK Mask      */

#define CAN_STATUS_LEC_Pos         0                                    /*!< CAN STATUS: LEC Position   */
#define CAN_STATUS_LEC_Msk         (0x3ul << CAN_STATUS_LEC_Pos)        /*!< CAN STATUS: LEC Mask       */

/* CAN ERR Bit Field Definitions */
#define CAN_ERR_RP_Pos             15                                   /*!< CAN ERR: RP Position       */
#define CAN_ERR_RP_Msk             (0x1ul << CAN_ERR_RP_Pos)            /*!< CAN ERR: RP Mask           */

#define CAN_ERR_REC_Pos            8                                    /*!< CAN ERR: REC Position      */
#define CAN_ERR_REC_Msk            (0x7Ful << CAN_ERR_REC_Pos)          /*!< CAN ERR: REC Mask          */

#define CAN_ERR_TEC_Pos            0                                    /*!< CAN ERR: TEC Position      */
#define CAN_ERR_TEC_Msk            (0xFFul << CAN_ERR_TEC_Pos)          /*!< CAN ERR: TEC Mask          */

/* CAN BTIME Bit Field Definitions */   
#define CAN_BTIME_TSEG2_Pos        12                                   /*!< CAN BTIME: TSEG2 Position  */
#define CAN_BTIME_TSEG2_Msk        (0x7ul << CAN_BTIME_TSEG2_Pos)       /*!< CAN BTIME: TSEG2 Mask      */

#define CAN_BTIME_TSEG1_Pos        8                                    /*!< CAN BTIME: TSEG1 Position  */
#define CAN_BTIME_TSEG1_Msk        (0xFul << CAN_BTIME_TSEG1_Pos)       /*!< CAN BTIME: TSEG1 Mask      */

#define CAN_BTIME_SJW_Pos          6                                    /*!< CAN BTIME: SJW Position    */
#define CAN_BTIME_SJW_Msk          (0x3ul << CAN_BTIME_SJW_Pos)         /*!< CAN BTIME: SJW Mask        */

#define CAN_BTIME_BRP_Pos          0                                    /*!< CAN BTIME: BRP Position    */
#define CAN_BTIME_BRP_Msk          (0x3Ful << CAN_BTIME_BRP_Pos)        /*!< CAN BTIME: BRP Mask        */

/* CAN IIDR Bit Field Definitions */
#define CAN_IIDR_INTID_Pos         0                                    /*!< CAN IIDR: INTID Position   */
#define CAN_IIDR_INTID_Msk         (0xFFFFul << CAN_IIDR_INTID_Pos)     /*!< CAN IIDR: INTID Mask       */

/* CAN TEST Bit Field Definitions */
#define CAN_TEST_RX_Pos            7                                    /*!< CAN TEST: RX Position      */
#define CAN_TEST_RX_Msk            (0x1ul << CAN_TEST_RX_Pos)           /*!< CAN TEST: RX Mask          */

#define CAN_TEST_TX_Pos            5                                    /*!< CAN TEST: TX Position      */
#define CAN_TEST_TX_Msk            (0x3ul << CAN_TEST_TX_Pos)           /*!< CAN TEST: TX Mask          */

#define CAN_TEST_LBACK_Pos         4                                    /*!< CAN TEST: LBACK Position   */
#define CAN_TEST_LBACK_Msk         (0x1ul << CAN_TEST_LBACK_Pos)        /*!< CAN TEST: LBACK Mask       */
             
#define CAN_TEST_SILENT_Pos        3                                    /*!< CAN TEST: Silent Position  */
#define CAN_TEST_SILENT_Msk        (0x1ul << CAN_TEST_SILENT_Pos)       /*!< CAN TEST: Silent Mask      */

#define CAN_TEST_BASIC_Pos         2                                    /*!< CAN TEST: Basic Position   */
#define CAN_TEST_BASIC_Msk         (0x1ul << CAN_TEST_BASIC_Pos)        /*!< CAN TEST: Basic Mask       */

/* CAN BPRE Bit Field Definitions */
#define CAN_BRPE_BRPE_Pos          0                                    /*!< CAN BRPE: BRPE Position    */
#define CAN_BRPE_BRPE_Msk          (0xFul << CAN_BRPE_BRPE_Pos)         /*!< CAN BRPE: BRPE Mask        */

/* CAN IFn_CREQ Bit Field Definitions */
#define CAN_IF_CREQ_BUSY_Pos       15                                     /*!< CAN IFnCREQ: BUSY Position */
#define CAN_IF_CREQ_BUSY_Msk       (0x1ul << CAN_IF_CREQ_BUSY_Pos)        /*!< CAN IFnCREQ: BUSY Mask     */

#define CAN_IF_CREQ_MSGNUM_Pos     0                                      /*!< CAN IFnCREQ: MSGNUM Position */
#define CAN_IF_CREQ_MSGNUM_Msk     (0x3Ful << CAN_IF_CREQ_MSGNUM_Pos)     /*!< CAN IFnCREQ: MSGNUM Mask     */

/* CAN IFn_CMASK Bit Field Definitions */
#define CAN_IF_CMASK_WRRD_Pos      7                                      /*!< CAN IFnCMASK: WRRD Position */
#define CAN_IF_CMASK_WRRD_Msk      (0x1ul << CAN_IF_CMASK_WRRD_Pos)       /*!< CAN IFnCMASK: WRRD Mask     */

#define CAN_IF_CMASK_MASK_Pos      6                                      /*!< CAN IFnCMASK: MASK Position */
#define CAN_IF_CMASK_MASK_Msk      (0x1ul << CAN_IF_CMASK_MASK_Pos)       /*!< CAN IFnCMASK: MASK Mask     */

#define CAN_IF_CMASK_ARB_Pos       5                                      /*!< CAN IFnCMASK: ARB Position  */
#define CAN_IF_CMASK_ARB_Msk       (0x1ul << CAN_IF_CMASK_ARB_Pos)        /*!< CAN IFnCMASK: ARB Mask      */

#define CAN_IF_CMASK_CONTROL_Pos   4                                     /*!< CAN IFnCMASK: CONTROL Position */
#define CAN_IF_CMASK_CONTROL_Msk   (0x1ul << CAN_IF_CMASK_CONTROL_Pos)   /*!< CAN IFnCMASK: CONTROL Mask */

#define CAN_IF_CMASK_CLRINTPND_Pos 3                                       /*!< CAN IFnCMASK: CLRINTPND Position */
#define CAN_IF_CMASK_CLRINTPND_Msk (0x1ul << CAN_IF_CMASK_CLRINTPND_Pos)   /*!< CAN IFnCMASK: CLRINTPND Mask */
  
#define CAN_IF_CMASK_TXRQSTNEWDAT_Pos 2                                         /*!< CAN IFnCMASK: TXRQSTNEWDAT Position */
#define CAN_IF_CMASK_TXRQSTNEWDAT_Msk (0x1ul << CAN_IF_CMASK_TXRQSTNEWDAT_Pos)  /*!< CAN IFnCMASK: TXRQSTNEWDAT Mask     */

#define CAN_IF_CMASK_DATAA_Pos     1                                    /*!< CAN IFnCMASK: DATAA Position */
#define CAN_IF_CMASK_DATAA_Msk     (0x1ul << CAN_IF_CMASK_DATAA_Pos)    /*!< CAN IFnCMASK: DATAA Mask     */

#define CAN_IF_CMASK_DATAB_Pos     0                                    /*!< CAN IFnCMASK: DATAB Position */
#define CAN_IF_CMASK_DATAB_Msk     (0x1ul << CAN_IF_CMASK_DATAB_Pos)    /*!< CAN IFnCMASK: DATAB Mask     */

/* CAN IFn_MASK1 Bit Field Definitions */
#define CAN_IF_MASK1_MSK_Pos       0                                    /*!< CAN IFnMASK1: MSK Position   */
#define CAN_IF_MASK1_MSK_Msk       (0xFFul << CAN_IF_MASK1_MSK_Pos)     /*!< CAN IFnMASK1: MSK Mask       */

/* CAN IFn_MASK2 Bit Field Definitions */
#define CAN_IF_MASK2_MXTD_Pos      15                                   /*!< CAN IFnMASK2: MXTD Position */
#define CAN_IF_MASK2_MXTD_Msk      (0x1ul << CAN_IF_MASK2_MXTD_Pos)     /*!< CAN IFnMASK2: MXTD Mask     */

#define CAN_IF_MASK2_MDIR_Pos      14                                   /*!< CAN IFnMASK2: MDIR Position */
#define CAN_IF_MASK2_MDIR_Msk      (0x1ul << CAN_IF_MASK2_MDIR_Pos)     /*!< CAN IFnMASK2: MDIR Mask     */

#define CAN_IF_MASK2_MSK_Pos       0                                    /*!< CAN IFnMASK2: MSK Position */
#define CAN_IF_MASK2_MSK_Msk       (0x1FFul << CAN_IF_MASK2_MSK_Pos)    /*!< CAN IFnMASK2: MSK Mask     */

/* CAN IFn_ARB1 Bit Field Definitions */
#define CAN_IF_ARB1_ID_Pos         0                                    /*!< CAN IFnARB1: ID Position   */
#define CAN_IF_ARB1_ID_Msk         (0xFFFFul << CAN_IF_ARB1_ID_Pos)     /*!< CAN IFnARB1: ID Mask       */

/* CAN IFn_ARB2 Bit Field Definitions */        
#define CAN_IF_ARB2_MSGVAL_Pos     15                                   /*!< CAN IFnARB2: MSGVAL Position */
#define CAN_IF_ARB2_MSGVAL_Msk     (0x1ul << CAN_IF_ARB2_MSGVAL_Pos)    /*!< CAN IFnARB2: MSGVAL Mask     */

#define CAN_IF_ARB2_XTD_Pos        14                                   /*!< CAN IFnARB2: XTD Position    */
#define CAN_IF_ARB2_XTD_Msk        (0x1ul << CAN_IF_ARB2_XTD_Pos)       /*!< CAN IFnARB2: XTD Mask        */

#define CAN_IF_ARB2_DIR_Pos        13                                   /*!< CAN IFnARB2: DIR Position    */
#define CAN_IF_ARB2_DIR_Msk        (0x1ul << CAN_IF_ARB2_DIR_Pos)       /*!< CAN IFnARB2: DIR Mask        */

#define CAN_IF_ARB2_ID_Pos         0                                    /*!< CAN IFnARB2: ID Position     */
#define CAN_IF_ARB2_ID_Msk         (0x1FFFul << CAN_IF_ARB2_ID_Pos)     /*!< CAN IFnARB2: ID Mask         */

/* CAN IFn_MCON Bit Field Definitions */
#define CAN_IF_MCON_NEWDAT_Pos     15                                   /*!< CAN IFnMCON: NEWDAT Position */ 
#define CAN_IF_MCON_NEWDAT_Msk     (0x1ul << CAN_IF_MCON_NEWDAT_Pos)    /*!< CAN IFnMCON: NEWDAT Mask     */ 

#define CAN_IF_MCON_MSGLST_Pos     14                                   /*!< CAN IFnMCON: MSGLST Position */ 
#define CAN_IF_MCON_MSGLST_Msk     (0x1ul << CAN_IF_MCON_MSGLST_Pos)    /*!< CAN IFnMCON: MSGLST Mask     */ 

#define CAN_IF_MCON_INTPND_Pos     13                                   /*!< CAN IFnMCON: INTPND Position */ 
#define CAN_IF_MCON_INTPND_Msk     (0x1ul << CAN_IF_MCON_INTPND_Pos)    /*!< CAN IFnMCON: INTPND Mask     */ 

#define CAN_IF_MCON_UMASK_Pos      12                                   /*!< CAN IFnMCON: UMASK Position  */ 
#define CAN_IF_MCON_UMASK_Msk      (0x1ul << CAN_IF_MCON_UMASK_Pos)     /*!< CAN IFnMCON: UMASK Mask      */ 

#define CAN_IF_MCON_TXIE_Pos       11                                   /*!< CAN IFnMCON: TXIE Position   */ 
#define CAN_IF_MCON_TXIE_Msk       (0x1ul << CAN_IF_MCON_TXIE_Pos)      /*!< CAN IFnMCON: TXIE Mask       */ 

#define CAN_IF_MCON_RXIE_Pos       10                                   /*!< CAN IFnMCON: RXIE Position   */ 
#define CAN_IF_MCON_RXIE_Msk       (0x1ul << CAN_IF_MCON_RXIE_Pos)      /*!< CAN IFnMCON: RXIE Mask       */ 

#define CAN_IF_MCON_RMTEN_Pos      9                                    /*!< CAN IFnMCON: RMTEN Position  */ 
#define CAN_IF_MCON_RMTEN_Msk      (0x1ul << CAN_IF_MCON_RMTEN_Pos)     /*!< CAN IFnMCON: RMTEN Mask      */ 

#define CAN_IF_MCON_TXRQST_Pos     8                                    /*!< CAN IFnMCON: TXRQST Position */ 
#define CAN_IF_MCON_TXRQST_Msk     (0x1ul << CAN_IF_MCON_TXRQST_Pos)    /*!< CAN IFnMCON: TXRQST Mask     */ 

#define CAN_IF_MCON_EOB_Pos        7                                    /*!< CAN IFnMCON: EOB Position    */ 
#define CAN_IF_MCON_EOB_Msk        (0x1ul << CAN_IF_MCON_EOB_Pos)       /*!< CAN IFnMCON: EOB Mask        */ 

#define CAN_IF_MCON_DLC_Pos        0                                    /*!< CAN IFnMCON: DLC Position    */ 
#define CAN_IF_MCON_DLC_Msk        (0xFul << CAN_IF_MCON_DLC_Pos)       /*!< CAN IFnMCON: DLC Mask        */ 

/* CAN IFn_DATA_A1 Bit Field Definitions */
#define CAN_IF_DAT_A1_DATA1_Pos    8                                    /*!< CAN IFnDATAA1: DATA1 Position */ 
#define CAN_IF_DAT_A1_DATA1_Msk    (0xFFul << CAN_IF_DAT_A1_DATA1_Pos)  /*!< CAN IFnDATAA1: DATA1 Mask     */ 

#define CAN_IF_DAT_A1_DATA0_Pos    0                                    /*!< CAN IFnDATAA1: DATA0 Position */ 
#define CAN_IF_DAT_A1_DATA0_Msk    (0xFFul << CAN_IF_DAT_A1_DATA0_Pos)  /*!< CAN IFnDATAA1: DATA0 Mask     */ 

/* CAN IFn_DATA_A2 Bit Field Definitions */ 
#define CAN_IF_DAT_A2_DATA3_Pos    8                                    /*!< CAN IFnDATAA1: DATA3 Position */ 
#define CAN_IF_DAT_A2_DATA3_Msk    (0xFFul << CAN_IF_DAT_A2_DATA3_Pos)  /*!< CAN IFnDATAA1: DATA3 Mask     */ 

#define CAN_IF_DAT_A2_DATA2_Pos    0                                    /*!< CAN IFnDATAA1: DATA2 Position */ 
#define CAN_IF_DAT_A2_DATA2_Msk    (0xFFul << CAN_IF_DAT_A2_DATA2_Pos)  /*!< CAN IFnDATAA1: DATA2 Mask     */ 

/* CAN IFn_DATA_B1 Bit Field Definitions */
#define CAN_IF_DAT_B1_DATA5_Pos    8                                    /*!< CAN IFnDATAB1: DATA5 Position */ 
#define CAN_IF_DAT_B1_DATA5_Msk    (0xFFul << CAN_IF_DAT_B1_DATA5_Pos)  /*!< CAN IFnDATAB1: DATA5 Mask */ 

#define CAN_IF_DAT_B1_DATA4_Pos    0                                    /*!< CAN IFnDATAB1: DATA4 Position */ 
#define CAN_IF_DAT_B1_DATA4_Msk    (0xFFul << CAN_IF_DAT_B1_DATA4_Pos)  /*!< CAN IFnDATAB1: DATA4 Mask */ 

/* CAN IFn_DATA_B2 Bit Field Definitions */
#define CAN_IF_DAT_B2_DATA7_Pos    8                                    /*!< CAN IFnDATAB2: DATA7 Position */ 
#define CAN_IF_DAT_B2_DATA7_Msk    (0xFFul << CAN_IF_DAT_B2_DATA7_Pos)  /*!< CAN IFnDATAB2: DATA7 Mask     */ 

#define CAN_IF_DAT_B2_DATA6_Pos    0                                    /*!< CAN IFnDATAB2: DATA6 Position */ 
#define CAN_IF_DAT_B2_DATA6_Msk    (0xFFul << CAN_IF_DAT_B2_DATA6_Pos)  /*!< CAN IFnDATAB2: DATA6 Mask     */ 

/* CAN IFn_TXRQST1 Bit Field Definitions */
#define CAN_IF_TXRQST1_TXRQST_Pos  0                                        /*!< CAN IFnTXRQST1: TXRQST Position */ 
#define CAN_IF_TXRQST1_TXRQST_Msk  (0xFFFFul << CAN_IF_TXRQST1_TXRQST_Pos)  /*!< CAN IFnTXRQST1: TXRQST Mask     */ 

/* CAN IFn_TXRQST2 Bit Field Definitions */
#define CAN_IF_TXRQST2_TXRQST_Pos  0                                        /*!< CAN IFnTXRQST2: TXRQST Position  */ 
#define CAN_IF_TXRQST2_TXRQST_Msk  (0xFFFFul << CAN_IF_TXRQST2_TXRQST_Pos)  /*!< CAN IFnTXRQST2: TXRQST Mask      */ 

/* CAN IFn_NDAT1 Bit Field Definitions */
#define CAN_IF_NDAT1_NEWDATA_Pos   0                                        /*!< CAN IFnNDAT1: NEWDATA Position */ 
#define CAN_IF_NDAT1_NEWDATA_Msk   (0xFFFFul << CAN_IF_NDAT1_NEWDATA_Pos)   /*!< CAN IFnNDAT1: NEWDATA Mask     */ 

/* CAN IFn_NDAT2 Bit Field Definitions */
#define CAN_IF_NDAT2_NEWDATA_Pos   0                                        /*!< CAN IFnNDAT2: NEWDATA Position */ 
#define CAN_IF_NDAT2_NEWDATA_Msk   (0xFFFFul << CAN_IF_NDAT2_NEWDATA_Pos)   /*!< CAN IFnNDAT2: NEWDATA Mask     */ 

/* CAN IFn_IPND1 Bit Field Definitions */
#define CAN_IF_IPND1_INTPND_Pos   0                                         /*!< CAN IFnIPND1: INTPND Position */ 
#define CAN_IF_IPND1_INTPND_Msk   (0xFFFFul << CAN_IF_IPND1_INTPND_Pos)     /*!< CAN IFnIPND1: INTPND Mask     */ 

/* CAN IFn_IPND2 Bit Field Definitions */
#define CAN_IF_IPND2_INTPND_Pos   0                                         /*!< CAN IFnIPND2: INTPND Position */ 
#define CAN_IF_IPND2_INTPND_Msk   (0xFFFFul << CAN_IF_IPND2_INTPND_Pos)     /*!< CAN IFnIPND2: INTPND Mask     */

/* CAN IFn_MVLD1 Bit Field Definitions */
#define CAN_IF_MVLD1_MSGVAL_Pos   0                                         /*!< CAN IFnMVLD1: MSGVAL Position */
#define CAN_IF_MVLD1_MSGVAL_Msk   (0xFFFFul << CAN_IF_MVLD1_MSGVAL_Pos)     /*!< CAN IFnMVLD1: MSGVAL Mask     */

/* CAN IFn_MVLD2 Bit Field Definitions */
#define CAN_IF_MVLD2_MSGVAL_Pos   0                                         /*!< CAN IFnMVLD2: MSGVAL Position */        
#define CAN_IF_MVLD2_MSGVAL_Msk   (0xFFFFul << CAN_IF_MVLD2_MSGVAL_Pos)     /*!< CAN IFnMVLD2: MSGVAL Mask     */

/* CAN WUEN Bit Field Definitions */
#define CAN_WUEN_WAKUP_EN_Pos     0                                         /*!< CAN WUEN: WAKUP_EN Position */
#define CAN_WUEN_WAKUP_EN_Msk    (0x1ul << CAN_WUEN_WAKUP_EN_Pos)           /*!< CAN WUEN: WAKUP_EN Mask     */

/* CAN WUSTATUS Bit Field Definitions */
#define CAN_WUSTATUS_WAKUP_STS_Pos     0                                      /*!< CAN WUSTATUS: WAKUP_STS Position */
#define CAN_WUSTATUS_WAKUP_STS_Msk    (0x1ul << CAN_WUSTATUS_WAKUP_STS_Pos)   /*!< CAN WUSTATUS: WAKUP_STS Mask     */


/**@}*/ /* CAN_CONST */
/**@}*/ /* end of CAN register group */


/*---------------------- System Clock Controller -------------------------*/
/**
    @addtogroup CLK System Clock Controller(CLK)
    Memory Mapped Structure for CLK Controller
@{ */
 
typedef struct
{

    __IO uint32_t PWRCTL;                /*!< [0x0000] System Power-down Control Register                               */
    __IO uint32_t AHBCLK;                /*!< [0x0004] AHB Devices Clock Enable Control Register                        */
    __IO uint32_t APBCLK0;               /*!< [0x0008] APB Devices Clock Enable Control Register 0                      */
    __IO uint32_t APBCLK1;               /*!< [0x000c] APB Devices Clock Enable Control Register 1                      */
    __IO uint32_t CLKSEL0;               /*!< [0x0010] Clock Source Select Control Register 0                           */
    __IO uint32_t CLKSEL1;               /*!< [0x0014] Clock Source Select Control Register 1                           */
    __IO uint32_t CLKSEL2;               /*!< [0x0018] Clock Source Select Control Register 2                           */
    __IO uint32_t CLKSEL3;               /*!< [0x001c] Clock Source Select Control Register 3                           */
    __IO uint32_t CLKDIV0;               /*!< [0x0020] Clock Divider Number Register 0                                  */
    __IO uint32_t CLKDIV1;               /*!< [0x0024] Clock Divider Number Register 1                                  */
         uint32_t RESERVE0[6];

    __IO uint32_t PLLCTL;                /*!< [0x0040] PLL Control Register                                             */
         uint32_t RESERVE1[3];

    __I  uint32_t STATUS;                /*!< [0x0050] Clock Status Monitor Register                                    */
         uint32_t RESERVE2[3];

    __IO uint32_t CLKOCTL;               /*!< [0x0060] Clock Output Control Register                               */
         uint32_t RESERVE3[3];

    __IO uint32_t CLKDCTL;               /*!< [0x0070] Clock Fail Detector Control Register                             */
    __IO uint32_t CLKDSTS;               /*!< [0x0074] Clock Fail Detector Status Register                              */
    __IO uint32_t CDUPB;                 /*!< [0x0078] Clock Frequency Detector Upper Boundary Register                 */
    __IO uint32_t CDLOWB;                /*!< [0x007c] Clock Frequency Detector Low Boundary Register                   */

} CLK_T;

/**
    @addtogroup CLK_CONST CLK Bit Field Definition
    Constant Definitions for CLK Controller
@{ */

#define CLK_PWRCTL_HXTEN_Pos             (0)
#define CLK_PWRCTL_HXTEN_Msk             (0x1ul << CLK_PWRCTL_HXTEN_Pos)

#define CLK_PWRCTL_LXTEN_Pos             (1)
#define CLK_PWRCTL_LXTEN_Msk             (0x1ul << CLK_PWRCTL_LXTEN_Pos)

#define CLK_PWRCTL_HIRCEN_Pos            (2)
#define CLK_PWRCTL_HIRCEN_Msk            (0x1ul << CLK_PWRCTL_HIRCEN_Pos)

#define CLK_PWRCTL_LIRCEN_Pos            (3)
#define CLK_PWRCTL_LIRCEN_Msk            (0x1ul << CLK_PWRCTL_LIRCEN_Pos)

#define CLK_PWRCTL_PDWKDLY_Pos           (4)
#define CLK_PWRCTL_PDWKDLY_Msk           (0x1ul << CLK_PWRCTL_PDWKDLY_Pos)

#define CLK_PWRCTL_PDWKIEN_Pos           (5)
#define CLK_PWRCTL_PDWKIEN_Msk           (0x1ul << CLK_PWRCTL_PDWKIEN_Pos)

#define CLK_PWRCTL_PDWKIF_Pos            (6)
#define CLK_PWRCTL_PDWKIF_Msk            (0x1ul << CLK_PWRCTL_PDWKIF_Pos)

#define CLK_PWRCTL_PDEN_Pos              (7)
#define CLK_PWRCTL_PDEN_Msk              (0x1ul << CLK_PWRCTL_PDEN_Pos)

#define CLK_PWRCTL_PDWTCPU_Pos           (8)
#define CLK_PWRCTL_PDWTCPU_Msk           (0x1ul << CLK_PWRCTL_PDWTCPU_Pos)

#define CLK_PWRCTL_DBPDEN_Pos            (9)
#define CLK_PWRCTL_DBPDEN_Msk            (0x1ul << CLK_PWRCTL_DBPDEN_Pos)

#define CLK_PWRCTL_HXTGAIN_Pos           (10)
#define CLK_PWRCTL_HXTGAIN_Msk           (0x3ul << CLK_PWRCTL_HXTGAIN_Pos)

#define CLK_PWRCTL_HXTSELTYP_Pos          (12)
#define CLK_PWRCTL_HXTSELTYP_Msk          (0x1ul << CLK_PWRCTL_HXTSELTYP_Pos)

#define CLK_AHBCLK_PDMACKEN_Pos              (1)
#define CLK_AHBCLK_PDMACKEN_Msk              (0x1ul << CLK_AHBCLK_PDMACKEN_Pos)

#define CLK_AHBCLK_ISPCKEN_Pos               (2)
#define CLK_AHBCLK_ISPCKEN_Msk               (0x1ul << CLK_AHBCLK_ISPCKEN_Pos)

#define CLK_AHBCLK_EBICKEN_Pos               (3)
#define CLK_AHBCLK_EBICKEN_Msk               (0x1ul << CLK_AHBCLK_EBICKEN_Pos)

#define CLK_AHBCLK_USBHCKEN_Pos              (4)
#define CLK_AHBCLK_USBHCKEN_Msk              (0x1ul << CLK_AHBCLK_USBHCKEN_Pos)

#define CLK_AHBCLK_CRCCKEN_Pos               (7)
#define CLK_AHBCLK_CRCCKEN_Msk               (0x1ul << CLK_AHBCLK_CRCCKEN_Pos)

#define CLK_AHBCLK_FMCIDLE_Pos           (15)
#define CLK_AHBCLK_FMCIDLE_Msk           (0x1ul << CLK_AHBCLK_FMCIDLE_Pos)

#define CLK_APBCLK0_WDTCKEN_Pos              (0)
#define CLK_APBCLK0_WDTCKEN_Msk              (0x1ul << CLK_APBCLK0_WDTCKEN_Pos)

#define CLK_APBCLK0_RTCCKEN_Pos              (1)
#define CLK_APBCLK0_RTCCKEN_Msk              (0x1ul << CLK_APBCLK0_RTCCKEN_Pos)

#define CLK_APBCLK0_TMR0CKEN_Pos           (2)
#define CLK_APBCLK0_TMR0CKEN_Msk           (0x1ul << CLK_APBCLK0_TMR0CKEN_Pos)

#define CLK_APBCLK0_TMR1CKEN_Pos           (3)
#define CLK_APBCLK0_TMR1CKEN_Msk           (0x1ul << CLK_APBCLK0_TMR1CKEN_Pos)

#define CLK_APBCLK0_TMR2CKEN_Pos           (4)
#define CLK_APBCLK0_TMR2CKEN_Msk           (0x1ul << CLK_APBCLK0_TMR2CKEN_Pos)

#define CLK_APBCLK0_TMR3CKEN_Pos           (5)
#define CLK_APBCLK0_TMR3CKEN_Msk           (0x1ul << CLK_APBCLK0_TMR3CKEN_Pos)

#define CLK_APBCLK0_CLKOCKEN_Pos          (6)
#define CLK_APBCLK0_CLKOCKEN_Msk          (0x1ul << CLK_APBCLK0_CLKOCKEN_Pos)

#define CLK_APBCLK0_ACMP01CKEN_Pos           (7)
#define CLK_APBCLK0_ACMP01CKEN_Msk           (0x1ul << CLK_APBCLK0_ACMP01CKEN_Pos)

#define CLK_APBCLK0_I2C0CKEN_Pos             (8)
#define CLK_APBCLK0_I2C0CKEN_Msk             (0x1ul << CLK_APBCLK0_I2C0CKEN_Pos)

#define CLK_APBCLK0_I2C1CKEN_Pos             (9)
#define CLK_APBCLK0_I2C1CKEN_Msk             (0x1ul << CLK_APBCLK0_I2C1CKEN_Pos)

#define CLK_APBCLK0_SPI0CKEN_Pos             (12)
#define CLK_APBCLK0_SPI0CKEN_Msk             (0x1ul << CLK_APBCLK0_SPI0CKEN_Pos)

#define CLK_APBCLK0_SPI1CKEN_Pos             (13)
#define CLK_APBCLK0_SPI1CKEN_Msk             (0x1ul << CLK_APBCLK0_SPI1CKEN_Pos)

#define CLK_APBCLK0_SPI2CKEN_Pos             (14)
#define CLK_APBCLK0_SPI2CKEN_Msk             (0x1ul << CLK_APBCLK0_SPI2CKEN_Pos)

#define CLK_APBCLK0_UART0CKEN_Pos            (16)
#define CLK_APBCLK0_UART0CKEN_Msk            (0x1ul << CLK_APBCLK0_UART0CKEN_Pos)

#define CLK_APBCLK0_UART1CKEN_Pos            (17)
#define CLK_APBCLK0_UART1CKEN_Msk            (0x1ul << CLK_APBCLK0_UART1CKEN_Pos)

#define CLK_APBCLK0_UART2CKEN_Pos            (18)
#define CLK_APBCLK0_UART2CKEN_Msk            (0x1ul << CLK_APBCLK0_UART2CKEN_Pos)

#define CLK_APBCLK0_UART3CKEN_Pos            (19)
#define CLK_APBCLK0_UART3CKEN_Msk            (0x1ul << CLK_APBCLK0_UART3CKEN_Pos)

#define CLK_APBCLK0_CAN0CKEN_Pos             (24)
#define CLK_APBCLK0_CAN0CKEN_Msk             (0x1ul << CLK_APBCLK0_CAN0CKEN_Pos)

#define CLK_APBCLK0_OTGCKEN_Pos              (26)
#define CLK_APBCLK0_OTGCKEN_Msk              (0x1ul << CLK_APBCLK0_OTGCKEN_Pos)

#define CLK_APBCLK0_USBDCKEN_Pos             (27)
#define CLK_APBCLK0_USBDCKEN_Msk             (0x1ul << CLK_APBCLK0_USBDCKEN_Pos)

#define CLK_APBCLK0_EADCCKEN_Pos            (28)
#define CLK_APBCLK0_EADCCKEN_Msk            (0x1ul << CLK_APBCLK0_EADCCKEN_Pos)

#define CLK_APBCLK1_SC0CKEN_Pos              (0)
#define CLK_APBCLK1_SC0CKEN_Msk              (0x1ul << CLK_APBCLK1_SC0CKEN_Pos)

#define CLK_APBCLK1_DACCKEN_Pos              (12)
#define CLK_APBCLK1_DACCKEN_Msk              (0x1ul << CLK_APBCLK1_DACCKEN_Pos)

#define CLK_APBCLK1_PWM0CKEN_Pos             (16)
#define CLK_APBCLK1_PWM0CKEN_Msk             (0x1ul << CLK_APBCLK1_PWM0CKEN_Pos)

#define CLK_APBCLK1_PWM1CKEN_Pos             (17)
#define CLK_APBCLK1_PWM1CKEN_Msk             (0x1ul << CLK_APBCLK1_PWM1CKEN_Pos)

#define CLK_APBCLK1_TKCKEN_Pos               (25)
#define CLK_APBCLK1_TKCKEN_Msk               (0x1ul << CLK_APBCLK1_TKCKEN_Pos)

#define CLK_CLKSEL0_HCLKSEL_Pos             (0)
#define CLK_CLKSEL0_HCLKSEL_Msk             (0x7ul << CLK_CLKSEL0_HCLKSEL_Pos)

#define CLK_CLKSEL0_STCLKSEL_Pos            (3)
#define CLK_CLKSEL0_STCLKSEL_Msk            (0x7ul << CLK_CLKSEL0_STCLKSEL_Pos)

#define CLK_CLKSEL0_PCLK0SEL_Pos            (6)
#define CLK_CLKSEL0_PCLK0SEL_Msk            (0x1ul << CLK_CLKSEL0_PCLK0SEL_Pos)

#define CLK_CLKSEL0_PCLK1SEL_Pos            (7)
#define CLK_CLKSEL0_PCLK1SEL_Msk            (0x1ul << CLK_CLKSEL0_PCLK1SEL_Pos)

#define CLK_CLKSEL1_WDTSEL_Pos              (0)
#define CLK_CLKSEL1_WDTSEL_Msk              (0x3ul << CLK_CLKSEL1_WDTSEL_Pos)

#define CLK_CLKSEL1_TMR0SEL_Pos           (8)
#define CLK_CLKSEL1_TMR0SEL_Msk           (0x7ul << CLK_CLKSEL1_TMR0SEL_Pos)

#define CLK_CLKSEL1_TMR1SEL_Pos           (12)
#define CLK_CLKSEL1_TMR1SEL_Msk           (0x7ul << CLK_CLKSEL1_TMR1SEL_Pos)

#define CLK_CLKSEL1_TMR2SEL_Pos           (16)
#define CLK_CLKSEL1_TMR2SEL_Msk           (0x7ul << CLK_CLKSEL1_TMR2SEL_Pos)

#define CLK_CLKSEL1_TMR3SEL_Pos           (20)
#define CLK_CLKSEL1_TMR3SEL_Msk           (0x7ul << CLK_CLKSEL1_TMR3SEL_Pos)

#define CLK_CLKSEL1_UARTSEL_Pos             (24)
#define CLK_CLKSEL1_UARTSEL_Msk             (0x3ul << CLK_CLKSEL1_UARTSEL_Pos)

#define CLK_CLKSEL1_CLKOSEL_Pos          (28)
#define CLK_CLKSEL1_CLKOSEL_Msk          (0x3ul << CLK_CLKSEL1_CLKOSEL_Pos)

#define CLK_CLKSEL1_WWDTSEL_Pos             (30)
#define CLK_CLKSEL1_WWDTSEL_Msk             (0x3ul << CLK_CLKSEL1_WWDTSEL_Pos)

#define CLK_CLKSEL2_PWM0SEL_Pos             (0)
#define CLK_CLKSEL2_PWM0SEL_Msk             (0x1ul << CLK_CLKSEL2_PWM0SEL_Pos)

#define CLK_CLKSEL2_PWM1SEL_Pos             (1)
#define CLK_CLKSEL2_PWM1SEL_Msk             (0x1ul << CLK_CLKSEL2_PWM1SEL_Pos)

#define CLK_CLKSEL2_SPI0SEL_Pos             (2)
#define CLK_CLKSEL2_SPI0SEL_Msk             (0x3ul << CLK_CLKSEL2_SPI0SEL_Pos)

#define CLK_CLKSEL2_SPI1SEL_Pos             (4)
#define CLK_CLKSEL2_SPI1SEL_Msk             (0x3ul << CLK_CLKSEL2_SPI1SEL_Pos)

#define CLK_CLKSEL2_SPI2SEL_Pos             (6)
#define CLK_CLKSEL2_SPI2SEL_Msk             (0x3ul << CLK_CLKSEL2_SPI2SEL_Pos)

#define CLK_CLKSEL3_SC0SEL_Pos               (0)
#define CLK_CLKSEL3_SC0SEL_Msk               (0x3ul << CLK_CLKSEL3_SC0SEL_Pos)

#define CLK_CLKSEL3_RTCSEL_Pos              (8)
#define CLK_CLKSEL3_RTCSEL_Msk              (0x1ul << CLK_CLKSEL3_RTCSEL_Pos)

#define CLK_CLKDIV0_HCLKDIV_Pos             (0)
#define CLK_CLKDIV0_HCLKDIV_Msk             (0xful << CLK_CLKDIV0_HCLKDIV_Pos)

#define CLK_CLKDIV0_USBDIV_Pos              (4)
#define CLK_CLKDIV0_USBDIV_Msk              (0xful << CLK_CLKDIV0_USBDIV_Pos)

#define CLK_CLKDIV0_UARTDIV_Pos             (8)
#define CLK_CLKDIV0_UARTDIV_Msk             (0xful << CLK_CLKDIV0_UARTDIV_Pos)

#define CLK_CLKDIV0_EADCDIV_Pos             (16)
#define CLK_CLKDIV0_EADCDIV_Msk             (0xfful << CLK_CLKDIV0_EADCDIV_Pos)

#define CLK_CLKDIV1_SC0DIV_Pos              (0)
#define CLK_CLKDIV1_SC0DIV_Msk              (0xfful << CLK_CLKDIV1_SC0DIV_Pos)

#define CLK_PLLCTL_FBDIV_Pos             (0)
#define CLK_PLLCTL_FBDIV_Msk             (0x1fful << CLK_PLLCTL_FBDIV_Pos)

#define CLK_PLLCTL_INDIV_Pos             (9)
#define CLK_PLLCTL_INDIV_Msk             (0x1ful << CLK_PLLCTL_INDIV_Pos)

#define CLK_PLLCTL_OUTDIV_Pos            (14)
#define CLK_PLLCTL_OUTDIV_Msk            (0x3ul << CLK_PLLCTL_OUTDIV_Pos)

#define CLK_PLLCTL_PD_Pos                (16)
#define CLK_PLLCTL_PD_Msk                (0x1ul << CLK_PLLCTL_PD_Pos)

#define CLK_PLLCTL_BP_Pos                (17)
#define CLK_PLLCTL_BP_Msk                (0x1ul << CLK_PLLCTL_BP_Pos)

#define CLK_PLLCTL_OE_Pos                (18)
#define CLK_PLLCTL_OE_Msk                (0x1ul << CLK_PLLCTL_OE_Pos)

#define CLK_PLLCTL_PLLSRC_Pos            (19)
#define CLK_PLLCTL_PLLSRC_Msk            (0x1ul << CLK_PLLCTL_PLLSRC_Pos)

#define CLK_PLLCTL_STBSEL_Pos            (23)
#define CLK_PLLCTL_STBSEL_Msk            (0x1ul << CLK_PLLCTL_STBSEL_Pos)

#define CLK_STATUS_HXTSTB_Pos            (0)
#define CLK_STATUS_HXTSTB_Msk            (0x1ul << CLK_STATUS_HXTSTB_Pos)

#define CLK_STATUS_LXTSTB_Pos            (1)
#define CLK_STATUS_LXTSTB_Msk            (0x1ul << CLK_STATUS_LXTSTB_Pos)

#define CLK_STATUS_PLLSTB_Pos            (2)
#define CLK_STATUS_PLLSTB_Msk            (0x1ul << CLK_STATUS_PLLSTB_Pos)

#define CLK_STATUS_LIRCSTB_Pos           (3)
#define CLK_STATUS_LIRCSTB_Msk           (0x1ul << CLK_STATUS_LIRCSTB_Pos)

#define CLK_STATUS_HIRCSTB_Pos           (4)
#define CLK_STATUS_HIRCSTB_Msk           (0x1ul << CLK_STATUS_HIRCSTB_Pos)

#define CLK_STATUS_CLKSFAIL_Pos          (7)
#define CLK_STATUS_CLKSFAIL_Msk          (0x1ul << CLK_STATUS_CLKSFAIL_Pos)

#define CLK_CLKOCTL_FSEL_Pos             (0)
#define CLK_CLKOCTL_FSEL_Msk             (0xful << CLK_CLKOCTL_FSEL_Pos)

#define CLK_CLKOCTL_CLKOEN_Pos           (4)
#define CLK_CLKOCTL_CLKOEN_Msk           (0x1ul << CLK_CLKOCTL_CLKOEN_Pos)

#define CLK_CLKOCTL_DIV1EN_Pos             (5)
#define CLK_CLKOCTL_DIV1EN_Msk             (0x1ul << CLK_CLKOCTL_DIV1EN_Pos)

#define CLK_CLKOCTL_CLK1HZEN_Pos          (6)
#define CLK_CLKOCTL_CLK1HZEN_Msk          (0x1ul << CLK_CLKOCTL_CLK1HZEN_Pos)

#define CLK_CLKDCTL_HXTFDEN_Pos          (4)
#define CLK_CLKDCTL_HXTFDEN_Msk          (0x1ul << CLK_CLKDCTL_HXTFDEN_Pos)

#define CLK_CLKDCTL_HXTFIEN_Pos          (5)
#define CLK_CLKDCTL_HXTFIEN_Msk          (0x1ul << CLK_CLKDCTL_HXTFIEN_Pos)

#define CLK_CLKDCTL_LXTFDEN_Pos          (12)
#define CLK_CLKDCTL_LXTFDEN_Msk          (0x1ul << CLK_CLKDCTL_LXTFDEN_Pos)

#define CLK_CLKDCTL_LXTFIEN_Pos          (13)
#define CLK_CLKDCTL_LXTFIEN_Msk          (0x1ul << CLK_CLKDCTL_LXTFIEN_Pos)

#define CLK_CLKDCTL_HXTFQDEN_Pos         (16)
#define CLK_CLKDCTL_HXTFQDEN_Msk         (0x1ul << CLK_CLKDCTL_HXTFQDEN_Pos)

#define CLK_CLKDCTL_HXTFQIEN_Pos         (17)
#define CLK_CLKDCTL_HXTFQIEN_Msk         (0x1ul << CLK_CLKDCTL_HXTFQIEN_Pos)

#define CLK_CLKDSTS_HXTFIF_Pos           (0)
#define CLK_CLKDSTS_HXTFIF_Msk           (0x1ul << CLK_CLKDSTS_HXTFIF_Pos)

#define CLK_CLKDSTS_LXTFIF_Pos           (1)
#define CLK_CLKDSTS_LXTFIF_Msk           (0x1ul << CLK_CLKDSTS_LXTFIF_Pos)

#define CLK_CLKDSTS_HXTFQIF_Pos          (8)
#define CLK_CLKDSTS_HXTFQIF_Msk          (0x1ul << CLK_CLKDSTS_HXTFQIF_Pos)

#define CLK_CDUPB_UPERBD_Pos               (0)
#define CLK_CDUPB_UPERBD_Msk               (0x3fful << CLK_CDUPB_UPERBD_Pos)

#define CLK_CDLOWB_LOWERBD_Pos             (0)
#define CLK_CDLOWB_LOWERBD_Msk             (0x3fful << CLK_CDLOWB_LOWERBD_Pos)


/**@}*/ /* CLK_CONST */
/**@}*/ /* end of CLK register group */


/*---------------------- Cyclic Redundancy Check Controller -------------------------*/
/**
    @addtogroup CRC Cyclic Redundancy Check Controller(CRC)
    Memory Mapped Structure for CRC Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] CRC Control Register                                             */
    __IO uint32_t DAT;                   /*!< [0x0004] CRC Write Data Register                                          */
    __IO uint32_t SEED;                  /*!< [0x0008] CRC Seed Register                                                */
    __I  uint32_t CHECKSUM;              /*!< [0x000c] CRC Checksum Register                                            */

} CRC_T;

/**
    @addtogroup CRC_CONST CRC Bit Field Definition
    Constant Definitions for CRC Controller
@{ */

#define CRC_CTL_CRCEN_Pos                (0)
#define CRC_CTL_CRCEN_Msk                (0x1ul << CRC_CTL_CRCEN_Pos)

#define CRC_CTL_CRCRST_Pos               (1)
#define CRC_CTL_CRCRST_Msk               (0x1ul << CRC_CTL_CRCRST_Pos)

#define CRC_CTL_DATREV_Pos               (24)
#define CRC_CTL_DATREV_Msk               (0x1ul << CRC_CTL_DATREV_Pos)

#define CRC_CTL_CHKSREV_Pos              (25)
#define CRC_CTL_CHKSREV_Msk              (0x1ul << CRC_CTL_CHKSREV_Pos)

#define CRC_CTL_DATFMT_Pos               (26)
#define CRC_CTL_DATFMT_Msk               (0x1ul << CRC_CTL_DATFMT_Pos)

#define CRC_CTL_CHKSFMT_Pos              (27)
#define CRC_CTL_CHKSFMT_Msk              (0x1ul << CRC_CTL_CHKSFMT_Pos)

#define CRC_CTL_DATLEN_Pos               (28)
#define CRC_CTL_DATLEN_Msk               (0x3ul << CRC_CTL_DATLEN_Pos)

#define CRC_CTL_CRCMODE_Pos              (30)
#define CRC_CTL_CRCMODE_Msk              (0x3ul << CRC_CTL_CRCMODE_Pos)

#define CRC_DAT_DAT_Pos                  (0)
#define CRC_DAT_DAT_Msk                  (0xfffffffful << CRC_DAT_DAT_Pos)

#define CRC_SEED_SEED_Pos                (0)
#define CRC_SEED_SEED_Msk                (0xfffffffful << CRC_SEED_SEED_Pos)

#define CRC_CHECKSUM_CHECKSUM_Pos        (0)
#define CRC_CHECKSUM_CHECKSUM_Msk        (0xfffffffful << CRC_CHECKSUM_CHECKSUM_Pos)

/**@}*/ /* CRC_CONST */
/**@}*/ /* end of CRC register group */


/*---------------------- Digital to Analog Converter -------------------------*/
/**
    @addtogroup DAC Digital to Analog Converter(DAC)
    Memory Mapped Structure for DAC Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] DAC Control Register                                             */
    __IO uint32_t SWTRG;                 /*!< [0x0004] DAC Software Trigger Control Register                            */
    __IO uint32_t DAT;                   /*!< [0x0008] DAC Data Holding Register                                        */
    __I  uint32_t DATOUT;                /*!< [0x000c] DAC Data Output Register                                         */
    __IO uint32_t STATUS;                /*!< [0x0010] DAC Status Register                                              */
    __IO uint32_t TCTL;                  /*!< [0x0014] DAC Timing Control Register                                      */

} DAC_T;

/**
    @addtogroup DAC_CONST DAC Bit Field Definition
    Constant Definitions for DAC Controller
@{ */

#define DAC_CTL_DACEN_Pos                (0)
#define DAC_CTL_DACEN_Msk                (0x1ul << DAC_CTL_DACEN_Pos)

#define DAC_CTL_DACIEN_Pos               (1)
#define DAC_CTL_DACIEN_Msk               (0x1ul << DAC_CTL_DACIEN_Pos)

#define DAC_CTL_DMAEN_Pos                (2)
#define DAC_CTL_DMAEN_Msk                (0x1ul << DAC_CTL_DMAEN_Pos)

#define DAC_CTL_DMAIEN_Pos               (3)
#define DAC_CTL_DMAIEN_Msk               (0x1ul << DAC_CTL_DMAIEN_Pos)

#define DAC_CTL_TRGEN_Pos                (4)
#define DAC_CTL_TRGEN_Msk                (0x1ul << DAC_CTL_TRGEN_Pos)

#define DAC_CTL_TRGSEL_Pos               (5)
#define DAC_CTL_TRGSEL_Msk               (0x7ul << DAC_CTL_TRGSEL_Pos)

#define DAC_CTL_BYPASS_Pos               (8)
#define DAC_CTL_BYPASS_Msk               (0x1ul << DAC_CTL_BYPASS_Pos)

#define DAC_CTL_TENBITEN_Pos             (9)
#define DAC_CTL_TENBITEN_Msk             (0x1ul << DAC_CTL_TENBITEN_Pos)

#define DAC_CTL_LALIGN_Pos               (10)
#define DAC_CTL_LALIGN_Msk               (0x1ul << DAC_CTL_LALIGN_Pos)

#define DAC_CTL_ETRGSEL_Pos              (12)
#define DAC_CTL_ETRGSEL_Msk              (0x3ul << DAC_CTL_ETRGSEL_Pos)

#define DAC_SWTRG_SWTRG_Pos              (0)
#define DAC_SWTRG_SWTRG_Msk              (0x1ul << DAC_SWTRG_SWTRG_Pos)

#define DAC_DAT_DAC_DAT_Pos              (0)
#define DAC_DAT_DAC_DAT_Msk              (0xfffful << DAC_DAT_DAC_DAT_Pos)

#define DAC_DATOUT_DATOUT_Pos            (0)
#define DAC_DATOUT_DATOUT_Msk            (0xffful << DAC_DATOUT_DATOUT_Pos)

#define DAC_STATUS_FINISH_Pos            (0)
#define DAC_STATUS_FINISH_Msk            (0x1ul << DAC_STATUS_FINISH_Pos)

#define DAC_STATUS_DMAUDR_Pos            (1)
#define DAC_STATUS_DMAUDR_Msk            (0x1ul << DAC_STATUS_DMAUDR_Pos)

#define DAC_STATUS_BUSY_Pos              (8)
#define DAC_STATUS_BUSY_Msk              (0x1ul << DAC_STATUS_BUSY_Pos)

#define DAC_TCTL_SETTLET_Pos             (0)
#define DAC_TCTL_SETTLET_Msk             (0x3fful << DAC_TCTL_SETTLET_Pos)

/**@}*/ /* DAC_CONST */
/**@}*/ /* end of DAC register group */


/*---------------------- External Bus Interface Controller -------------------------*/
/**
    @addtogroup EBI External Bus Interface Controller(EBI)
    Memory Mapped Structure for EBI Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL0;                  /*!< [0x0000] External Bus Interface Bank0 Control Register                    */
    __IO uint32_t TCTL0;                 /*!< [0x0004] External Bus Interface Bank0 Timing Control Register             */
         uint32_t RESERVE0[2];

    __IO uint32_t CTL1;                  /*!< [0x0010] External Bus Interface Bank1 Control Register                    */
    __IO uint32_t TCTL1;                 /*!< [0x0014] External Bus Interface Bank1 Timing Control Register             */

} EBI_T;

/**
    @addtogroup EBI_CONST EBI Bit Field Definition
    Constant Definitions for EBI Controller
@{ */

#define EBI_CTL0_EXTEN_Pos               (0)
#define EBI_CTL0_EXTEN_Msk               (0x1ul << EBI_CTL0_EXTEN_Pos)

#define EBI_CTL0_EXTDW16_Pos             (1)
#define EBI_CTL0_EXTDW16_Msk             (0x1ul << EBI_CTL0_EXTDW16_Pos)

#define EBI_CTL0_CSPOLINV_Pos            (2)
#define EBI_CTL0_CSPOLINV_Msk            (0x1ul << EBI_CTL0_CSPOLINV_Pos)

#define EBI_CTL0_MCLKDIV_Pos             (8)
#define EBI_CTL0_MCLKDIV_Msk             (0x7ul << EBI_CTL0_MCLKDIV_Pos)

#define EBI_CTL0_EXTTALE_Pos             (16)
#define EBI_CTL0_EXTTALE_Msk             (0x7ul << EBI_CTL0_EXTTALE_Pos)

#define EBI_CTL0_WBUFEN_Pos              (24)
#define EBI_CTL0_WBUFEN_Msk              (0x1ul << EBI_CTL0_WBUFEN_Pos)

#define EBI_TCTL0_EXTTACC_Pos            (3)
#define EBI_TCTL0_EXTTACC_Msk            (0x1ful << EBI_TCTL0_EXTTACC_Pos)

#define EBI_TCTL0_EXTTAHD_Pos            (8)
#define EBI_TCTL0_EXTTAHD_Msk            (0x7ul << EBI_TCTL0_EXTTAHD_Pos)

#define EBI_TCTL0_EXTIW2X_Pos            (12)
#define EBI_TCTL0_EXTIW2X_Msk            (0xful << EBI_TCTL0_EXTIW2X_Pos)

#define EBI_TCTL0_RAHDOFF_Pos            (22)
#define EBI_TCTL0_RAHDOFF_Msk            (0x1ul << EBI_TCTL0_RAHDOFF_Pos)

#define EBI_TCTL0_WAHDOFF_Pos            (23)
#define EBI_TCTL0_WAHDOFF_Msk            (0x1ul << EBI_TCTL0_WAHDOFF_Pos)

#define EBI_TCTL0_EXTIR2R_Pos            (24)
#define EBI_TCTL0_EXTIR2R_Msk            (0xful << EBI_TCTL0_EXTIR2R_Pos)

#define EBI_CTL1_EXTEN_Pos               (0)
#define EBI_CTL1_EXTEN_Msk               (0x1ul << EBI_CTL1_EXTEN_Pos)

#define EBI_CTL1_EXTDW16_Pos             (1)
#define EBI_CTL1_EXTDW16_Msk             (0x1ul << EBI_CTL1_EXTDW16_Pos)

#define EBI_CTL1_CSPOLINV_Pos            (2)
#define EBI_CTL1_CSPOLINV_Msk            (0x1ul << EBI_CTL1_CSPOLINV_Pos)

#define EBI_CTL1_MCLKDIV_Pos             (8)
#define EBI_CTL1_MCLKDIV_Msk             (0x7ul << EBI_CTL1_MCLKDIV_Pos)

#define EBI_TCTL1_EXTTACC_Pos            (3)
#define EBI_TCTL1_EXTTACC_Msk            (0x1ful << EBI_TCTL1_EXTTACC_Pos)

#define EBI_TCTL1_EXTTAHD_Pos            (8)
#define EBI_TCTL1_EXTTAHD_Msk            (0x7ul << EBI_TCTL1_EXTTAHD_Pos)

#define EBI_TCTL1_EXTIW2X_Pos            (12)
#define EBI_TCTL1_EXTIW2X_Msk            (0xful << EBI_TCTL1_EXTIW2X_Pos)

#define EBI_TCTL1_RAHDOFF_Pos            (22)
#define EBI_TCTL1_RAHDOFF_Msk            (0x1ul << EBI_TCTL1_RAHDOFF_Pos)

#define EBI_TCTL1_WAHDOFF_Pos            (23)
#define EBI_TCTL1_WAHDOFF_Msk            (0x1ul << EBI_TCTL1_WAHDOFF_Pos)

#define EBI_TCTL1_EXTIR2R_Pos            (24)
#define EBI_TCTL1_EXTIR2R_Msk            (0xful << EBI_TCTL1_EXTIR2R_Pos)

/**@}*/ /* EBI_CONST */
/**@}*/ /* end of EBI register group */


/*---------------------- Flash Memory Controller -------------------------*/
/**
    @addtogroup FMC Flash Memory Controller(FMC)
    Memory Mapped Structure for FMC Controller
@{ */
 
typedef struct
{

    __IO uint32_t ISPCTL;                /*!< [0x0000] ISP Control Register                                             */
    __IO uint32_t ISPADDR;               /*!< [0x0004] ISP Address Register                                             */
    __IO uint32_t ISPDAT;                /*!< [0x0008] ISP Data Register                                                */
    __IO uint32_t ISPCMD;                /*!< [0x000c] ISP CMD Register                                                 */
    __IO uint32_t ISPTRG;                /*!< [0x0010] ISP Trigger Control Register                                     */
    __I  uint32_t DFBA;                  /*!< [0x0014] Data Flash Base Address                                          */
    __IO uint32_t FTCTL;                 /*!< [0x0018] Flash Access Time Control Register                               */
         uint32_t RESERVE0[9];

    __I  uint32_t ISPSTS;                /*!< [0x0040] ISP Status Register                                              */
         uint32_t RESERVE1[15];

    __IO uint32_t MPDAT0;                /*!< [0x0080] ISP Data0 Register                                               */
    __IO uint32_t MPDAT1;                /*!< [0x0084] ISP Data1 Register                                               */
    __IO uint32_t MPDAT2;                /*!< [0x0088] ISP Data2 Register                                               */
    __IO uint32_t MPDAT3;                /*!< [0x008c] ISP Data3 Register                                               */
         uint32_t RESERVE2[12];

    __I  uint32_t MPSTS;                 /*!< [0x00c0] ISP Multi-Program Status Register                                */
    __I  uint32_t MPADDR;                /*!< [0x00c4] ISP Multi-Program Address Register                               */
} FMC_T;

/**
    @addtogroup FMC_CONST FMC Bit Field Definition
    Constant Definitions for FMC Controller
@{ */

#define FMC_ISPCTL_ISPEN_Pos             (0)
#define FMC_ISPCTL_ISPEN_Msk             (0x1ul << FMC_ISPCTL_ISPEN_Pos)

#define FMC_ISPCTL_BS_Pos                (1)
#define FMC_ISPCTL_BS_Msk                (0x1ul << FMC_ISPCTL_BS_Pos)

#define FMC_ISPCTL_SPUEN_Pos             (2)
#define FMC_ISPCTL_SPUEN_Msk             (0x1ul << FMC_ISPCTL_SPUEN_Pos)

#define FMC_ISPCTL_APUEN_Pos             (3)
#define FMC_ISPCTL_APUEN_Msk             (0x1ul << FMC_ISPCTL_APUEN_Pos)

#define FMC_ISPCTL_CFGUEN_Pos            (4)
#define FMC_ISPCTL_CFGUEN_Msk            (0x1ul << FMC_ISPCTL_CFGUEN_Pos)

#define FMC_ISPCTL_LDUEN_Pos             (5)
#define FMC_ISPCTL_LDUEN_Msk             (0x1ul << FMC_ISPCTL_LDUEN_Pos)

#define FMC_ISPCTL_ISPFF_Pos             (6)
#define FMC_ISPCTL_ISPFF_Msk             (0x1ul << FMC_ISPCTL_ISPFF_Pos)

#define FMC_ISPCTL_CAHOLD_Pos            (7)
#define FMC_ISPCTL_CAHOLD_Msk            (0x1ul << FMC_ISPCTL_CAHOLD_Pos)

#define FMC_ISPCTL_PT20_Pos              (8)
#define FMC_ISPCTL_PT20_Msk              (0x7ul << FMC_ISPCTL_PT20_Pos)

#define FMC_ISPCTL_ET20_Pos              (12)
#define FMC_ISPCTL_ET20_Msk              (0x7ul << FMC_ISPCTL_ET20_Pos)

#define FMC_ISPCTL_BL_Pos                (16)
#define FMC_ISPCTL_BL_Msk                (0x1ul << FMC_ISPCTL_BL_Pos)

#define FMC_ISPADDR_ISPADDR_Pos          (0)
#define FMC_ISPADDR_ISPADDR_Msk          (0xfffffffful << FMC_ISPADDR_ISPADDR_Pos)

#define FMC_ISPDAT_ISPDAT_Pos            (0)
#define FMC_ISPDAT_ISPDAT_Msk            (0xfffffffful << FMC_ISPDAT_ISPDAT_Pos)

#define FMC_ISPCMD_CMD_Pos               (0)
#define FMC_ISPCMD_CMD_Msk               (0x7ful << FMC_ISPCMD_CMD_Pos)

#define FMC_ISPTRG_ISPGO_Pos             (0)
#define FMC_ISPTRG_ISPGO_Msk             (0x1ul << FMC_ISPTRG_ISPGO_Pos)

#define FMC_DFBA_DFBA_Pos                (0)
#define FMC_DFBA_DFBA_Msk                (0xfffffffful << FMC_DFBA_DFBA_Pos)

#define FMC_FTCTL_FPSEN_Pos              (0)
#define FMC_FTCTL_FPSEN_Msk              (0x1ul << FMC_FTCTL_FPSEN_Pos)

#define FMC_FTCTL_FATS_Pos               (1)
#define FMC_FTCTL_FATS_Msk               (0x7ul << FMC_FTCTL_FATS_Pos)

#define FMC_FTCTL_FOM_Pos                (4)
#define FMC_FTCTL_FOM_Msk                (0x7ul << FMC_FTCTL_FOM_Pos)

#define FMC_ISPSTS_ISPGO_Pos             (0)
#define FMC_ISPSTS_ISPGO_Msk             (0x1ul << FMC_ISPSTS_ISPGO_Pos)

#define FMC_ISPSTS_CBS_Pos               (1)
#define FMC_ISPSTS_CBS_Msk               (0x3ul << FMC_ISPSTS_CBS_Pos)

#define FMC_ISPSTS_MBS_Pos               (3)
#define FMC_ISPSTS_MBS_Msk               (0x1ul << FMC_ISPSTS_MBS_Pos)

#define FMC_ISPSTS_PGFF_Pos              (5)
#define FMC_ISPSTS_PGFF_Msk              (0x1ul << FMC_ISPSTS_PGFF_Pos)

#define FMC_ISPSTS_ISPFF_Pos             (6)
#define FMC_ISPSTS_ISPFF_Msk             (0x1ul << FMC_ISPSTS_ISPFF_Pos)

#define FMC_ISPSTS_VECMAP_Pos            (9)
#define FMC_ISPSTS_VECMAP_Msk            (0x7ffful << FMC_ISPSTS_VECMAP_Pos)

#define FMC_ISPSTS_SCODE_Pos             (31)
#define FMC_ISPSTS_SCODE_Msk             (0x1ul << FMC_ISPSTS_SCODE_Pos)

#define FMC_MPDAT0_ISPDAT0_Pos           (0)
#define FMC_MPDAT0_ISPDAT0_Msk           (0xfffffffful << FMC_MPDAT0_ISPDAT0_Pos)

#define FMC_MPDAT1_ISPDAT1_Pos           (0)
#define FMC_MPDAT1_ISPDAT1_Msk           (0xfffffffful << FMC_MPDAT1_ISPDAT1_Pos)

#define FMC_MPDAT2_ISPDAT2_Pos           (0)
#define FMC_MPDAT2_ISPDAT2_Msk           (0xfffffffful << FMC_MPDAT2_ISPDAT2_Pos)

#define FMC_MPDAT3_ISPDAT3_Pos           (0)
#define FMC_MPDAT3_ISPDAT3_Msk           (0xfffffffful << FMC_MPDAT3_ISPDAT3_Pos)

#define FMC_MPSTS_ISPGO_Pos              (0)
#define FMC_MPSTS_ISPGO_Msk              (0x1ul << FMC_MPSTS_ISPGO_Pos)

#define FMC_MPSTS_PPGO_Pos               (1)
#define FMC_MPSTS_PPGO_Msk               (0x1ul << FMC_MPSTS_PPGO_Pos)

#define FMC_MPSTS_ISPFF_Pos              (2)
#define FMC_MPSTS_ISPFF_Msk              (0x1ul << FMC_MPSTS_ISPFF_Pos)

#define FMC_MPSTS_D0_Pos                 (4)
#define FMC_MPSTS_D0_Msk                 (0x1ul << FMC_MPSTS_D0_Pos)

#define FMC_MPSTS_D1_Pos                 (5)
#define FMC_MPSTS_D1_Msk                 (0x1ul << FMC_MPSTS_D1_Pos)

#define FMC_MPSTS_D2_Pos                 (6)
#define FMC_MPSTS_D2_Msk                 (0x1ul << FMC_MPSTS_D2_Pos)

#define FMC_MPSTS_D3_Pos                 (7)
#define FMC_MPSTS_D3_Msk                 (0x1ul << FMC_MPSTS_D3_Pos)

#define FMC_MPADDR_MPADDR_Pos            (0)
#define FMC_MPADDR_MPADDR_Msk            (0xfffffffful << FMC_MPADDR_MPADDR_Pos)

/**@}*/ /* FMC_CONST */
/**@}*/ /* end of FMC register group */


/*---------------------- System Manger Controller -------------------------*/
/**
    @addtogroup GCR System Manger Controller(SYS)
    Memory Mapped Structure for GCR Controller
@{ */
 
typedef struct
{

    __I  uint32_t PDID;                  /*!< [0x0000] Part Device Identification Number Register                       */
    __IO uint32_t RSTSTS;                /*!< [0x0004] System Reset Source Register                                     */
    __IO uint32_t IPRST0;                /*!< [0x0008] Peripheral  Reset Control Register 1                             */
    __IO uint32_t IPRST1;                /*!< [0x000c] Peripheral Reset Control Register 2                              */
    __IO uint32_t IPRST2;                /*!< [0x0010] Peripheral Reset Control Register 3                              */
         uint32_t RESERVE0[1];     
    __IO uint32_t BODCTL;                /*!< [0x0018] Brown-Out Detector Control Register                              */
    __IO uint32_t IVSCTL;                /*!< [0x001c] Internal Voltage Source Control Register                         */
         uint32_t RESERVE1[1];   
    __IO uint32_t PORCTL;                /*!< [0x0024] Power-On-Reset Controller Register                               */
    __IO uint32_t VREFCTL;               /*!< [0x0028] VREF Control Register                                            */
    __IO uint32_t USBPHY;                /*!< [0x002c] USB HPY control register                                         */
    __IO uint32_t GPA_MFPL;              /*!< [0x0030] GPIOA Low Byte Multiple Function Control Register                */
    __IO uint32_t GPA_MFPH;              /*!< [0x0034] GPIOA High Byte Multiple Function Control Register               */
    __IO uint32_t GPB_MFPL;              /*!< [0x0038] GPIOB Low Byte Multiple Function Control Register                */
    __IO uint32_t GPB_MFPH;              /*!< [0x003c] GPIOB High Byte Multiple Function Control Register               */
    __IO uint32_t GPC_MFPL;              /*!< [0x0040] GPIOC Low Byte Multiple Function Control Register                */
    __IO uint32_t GPC_MFPH;              /*!< [0x0044] GPIOC High Byte Multiple Function Control Register               */
    __IO uint32_t GPD_MFPL;              /*!< [0x0048] GPIOD Low Byte Multiple Function Control Register                */
    __IO uint32_t GPD_MFPH;              /*!< [0x004c] GPIOD High Byte Multiple Function Control Register               */
    __IO uint32_t GPE_MFPL;              /*!< [0x0050] GPIOE Low Byte Multiple Function Control Register                */
    __IO uint32_t GPE_MFPH;              /*!< [0x0054] GPIOE High Byte Multiple Function Control Register               */
    __IO uint32_t GPF_MFPL;              /*!< [0x0058] GPIOF Low Byte Multiple Function Control Register                */
         uint32_t RESERVE2[25];

    __IO uint32_t SRAM_INTCTL;           /*!< [0x00c0] System SRAM Interrupt Enable Control Register                    */
    __I  uint32_t SRAM_STATUS;           /*!< [0x00c4] System SRAM Parity Error Status Register                         */
    __I  uint32_t SRAM_ERRADDR;          /*!< [0x00c8] System SRAM Parity Check Error Address Register                  */
         uint32_t RESERVE3[1];

    __IO uint32_t SRAM_BISTCTL;          /*!< [0x00d0] System SRAM BIST Test Control Register                           */
    __I  uint32_t SRAM_BISTSTS;          /*!< [0x00d4] System SRAM BIST Test Status Register                            */
         uint32_t RESERVE4[6];

    __IO uint32_t IRCTCTL;               /*!< [0x00f0] IRC Trim Control Register                                        */
    __IO uint32_t IRCTIEN;               /*!< [0x00f4] IRC Trim Interrupt Enable Register                               */
    __IO uint32_t IRCTISTS;              /*!< [0x00f8] IRC Trim Interrupt Status Register                               */
         uint32_t RESERVE5[1];

    __IO uint32_t REGLCTL;               /*!< [0x0100] Register Write Protect register                                  */
         uint32_t RESERVE6[4];

    __I  uint32_t TSOFFSET;              /*!< [0x0114] Temperature sensor offset Register                               */
         uint32_t RESERVE7[2];

} GCR_T;

/**
    @addtogroup GCR_CONST SYS Bit Field Definition
    Constant Definitions for GCR Controller
@{ */

#define SYS_PDID_PDID_Pos                (0)
#define SYS_PDID_PDID_Msk                (0xfffffffful << SYS_PDID_PDID_Pos)

#define SYS_RSTSTS_PORF_Pos              (0)
#define SYS_RSTSTS_PORF_Msk              (0x1ul << SYS_RSTSTS_PORF_Pos)

#define SYS_RSTSTS_PINRF_Pos             (1)
#define SYS_RSTSTS_PINRF_Msk             (0x1ul << SYS_RSTSTS_PINRF_Pos)

#define SYS_RSTSTS_WDTRF_Pos             (2)
#define SYS_RSTSTS_WDTRF_Msk             (0x1ul << SYS_RSTSTS_WDTRF_Pos)

#define SYS_RSTSTS_LVRRF_Pos             (3)
#define SYS_RSTSTS_LVRRF_Msk             (0x1ul << SYS_RSTSTS_LVRRF_Pos)

#define SYS_RSTSTS_BODRF_Pos             (4)
#define SYS_RSTSTS_BODRF_Msk             (0x1ul << SYS_RSTSTS_BODRF_Pos)

#define SYS_RSTSTS_SYSRF_Pos             (5)
#define SYS_RSTSTS_SYSRF_Msk             (0x1ul << SYS_RSTSTS_SYSRF_Pos)

#define SYS_RSTSTS_CPURF_Pos             (7)
#define SYS_RSTSTS_CPURF_Msk             (0x1ul << SYS_RSTSTS_CPURF_Pos)

#define SYS_IPRST0_CHIPRST_Pos           (0)
#define SYS_IPRST0_CHIPRST_Msk           (0x1ul << SYS_IPRST0_CHIPRST_Pos)

#define SYS_IPRST0_CPURST_Pos            (1)
#define SYS_IPRST0_CPURST_Msk            (0x1ul << SYS_IPRST0_CPURST_Pos)

#define SYS_IPRST0_PDMARST_Pos           (2)
#define SYS_IPRST0_PDMARsT_Msk           (0x1ul << GCR_IPRST0_PDMARST_Pos)

#define SYS_IPRST0_EBIRST_Pos            (3)
#define SYS_IPRST0_EBIRST_Msk            (0x1ul << SYS_IPRST0_EBIRST_Pos)

#define SYS_IPRST0_USBHRST_Pos           (4)
#define SYS_IPRST0_USBHRST_Msk           (0x1ul << SYS_IPRST0_USBHRST_Pos)

#define SYS_IPRST0_CRCRST_Pos            (5)
#define SYS_IPRST0_CRCRST_Msk            (0x1ul << SYS_IPRST0_CRCRST_Pos)

#define SYS_IPRST1_GPIORST_Pos           (1)
#define SYS_IPRST1_GPIORST_Msk           (0x1ul << SYS_IPRST1_GPIORST_Pos)

#define SYS_IPRST1_TMR0RST_Pos           (2)
#define SYS_IPRST1_TMR0RST_Msk           (0x1ul << SYS_IPRST1_TMR0RST_Pos)

#define SYS_IPRST1_TMR1RST_Pos           (3)
#define SYS_IPRST1_TMR1RST_Msk           (0x1ul << SYS_IPRST1_TMR1RST_Pos)

#define SYS_IPRST1_TMR2RST_Pos           (4)
#define SYS_IPRST1_TMR2RST_Msk           (0x1ul << SYS_IPRST1_TMR2RST_Pos)

#define SYS_IPRST1_TMR3RST_Pos           (5)
#define SYS_IPRST1_TMR3RST_Msk           (0x1ul << SYS_IPRST1_TMR3RST_Pos)

#define SYS_IPRST1_ACMP01RST_Pos         (7)
#define SYS_IPRST1_ACMP01RST_Msk         (0x1ul << SYS_IPRST1_ACMP01RST_Pos)

#define SYS_IPRST1_I2C0RST_Pos           (8)
#define SYS_IPRST1_I2C0RST_Msk           (0x1ul << SYS_IPRST1_I2C0RST_Pos)

#define SYS_IPRST1_I2C1RST_Pos           (9)
#define SYS_IPRST1_I2C1RST_Msk           (0x1ul << SYS_IPRST1_I2C1RST_Pos)

#define SYS_IPRST1_SPI0RST_Pos           (12)
#define SYS_IPRST1_SPI0RST_Msk           (0x1ul << SYS_IPRST1_SPI0RST_Pos)

#define SYS_IPRST1_SPI1RST_Pos           (13)
#define SYS_IPRST1_SPI1RST_Msk           (0x1ul << SYS_IPRST1_SPI1RST_Pos)

#define SYS_IPRST1_SPI2RST_Pos           (14)
#define SYS_IPRST1_SPI2RST_Msk           (0x1ul << SYS_IPRST1_SPI2RST_Pos)

#define SYS_IPRST1_UART0RST_Pos          (16)
#define SYS_IPRST1_UART0RST_Msk          (0x1ul << SYS_IPRST1_UART0RST_Pos)

#define SYS_IPRST1_UART1RST_Pos          (17)
#define SYS_IPRST1_UART1RST_Msk          (0x1ul << SYS_IPRST1_UART1RST_Pos)

#define SYS_IPRST1_UART2RST_Pos          (18)
#define SYS_IPRST1_UART2RST_Msk          (0x1ul << SYS_IPRST1_UART2RST_Pos)

#define SYS_IPRST1_UART3RST_Pos          (19)
#define SYS_IPRST1_UART3RST_Msk          (0x1ul << SYS_IPRST1_UART3RST_Pos)

#define SYS_IPRST1_CAN0RST_Pos           (24)
#define SYS_IPRST1_CAN0RST_Msk           (0x1ul << SYS_IPRST1_CAN0RST_Pos)

#define SYS_IPRST1_OTGRST_Pos            (26)
#define SYS_IPRST1_OTGRST_Msk            (0x1ul << SYS_IPRST1_OTGRST_Pos)

#define SYS_IPRST1_USBDRST_Pos           (27)
#define SYS_IPRST1_USBDRST_Msk           (0x1ul << SYS_IPRST1_USBDRST_Pos)

#define SYS_IPRST1_EADCRST_Pos          (28)
#define SYS_IPRST1_EADCRST_Msk          (0x1ul << SYS_IPRST1_EADCRST_Pos)

#define SYS_IPRST2_SC0RST_Pos            (0)
#define SYS_IPRST2_SC0RST_Msk            (0x1ul << SYS_IPRST2_SC0RST_Pos)

#define SYS_IPRST2_DACRST_Pos            (12)
#define SYS_IPRST2_DACRST_Msk            (0x1ul << SYS_IPRST2_DACRST_Pos)

#define SYS_IPRST2_PWM0RST_Pos           (16)
#define SYS_IPRST2_PWM0RST_Msk           (0x1ul << SYS_IPRST2_PWM0RST_Pos)

#define SYS_IPRST2_PWM1RST_Pos           (17)
#define SYS_IPRST2_PWM1RST_Msk           (0x1ul << SYS_IPRST2_PWM1RST_Pos)

#define SYS_IPRST2_TKRST_Pos             (25)
#define SYS_IPRST2_TKRST_Msk             (0x1ul << SYS_IPRST2_TKRST_Pos)

#define SYS_BODCTL_BODEN_Pos             (0)
#define SYS_BODCTL_BODEN_Msk             (0x1ul << SYS_BODCTL_BODEN_Pos)

#define SYS_BODCTL_BODVL_Pos             (1)
#define SYS_BODCTL_BODVL_Msk             (0x3ul << SYS_BODCTL_BODVL_Pos)

#define SYS_BODCTL_BODRSTEN_Pos          (3)
#define SYS_BODCTL_BODRSTEN_Msk          (0x1ul << SYS_BODCTL_BODRSTEN_Pos)

#define SYS_BODCTL_BODIF_Pos             (4)
#define SYS_BODCTL_BODIF_Msk             (0x1ul << SYS_BODCTL_BODIF_Pos)

#define SYS_BODCTL_BODLPM_Pos            (5)
#define SYS_BODCTL_BODLPM_Msk            (0x1ul << SYS_BODCTL_BODLPM_Pos)

#define SYS_BODCTL_BODOUT_Pos            (6)
#define SYS_BODCTL_BODOUT_Msk            (0x1ul << SYS_BODCTL_BODOUT_Pos)

#define SYS_BODCTL_LVREN_Pos             (7)
#define SYS_BODCTL_LVREN_Msk             (0x1ul << SYS_BODCTL_LVREN_Pos)

#define SYS_BODCTL_BODDGSEL_Pos          (8)
#define SYS_BODCTL_BODDGSEL_Msk          (0x7ul << SYS_BODCTL_BODDGSEL_Pos)

#define SYS_BODCTL_LVRDGSEL_Pos          (12)
#define SYS_BODCTL_LVRDGSEL_Msk          (0x7ul << SYS_BODCTL_LVRDGSEL_Pos)

#define SYS_IVSCTL_VTEMPEN_Pos           (0)
#define SYS_IVSCTL_VTEMPEN_Msk           (0x1ul << SYS_IVSCTL_VTEMPEN_Pos)

#define SYS_IVSCTL_VBATUGEN_Pos          (1)
#define SYS_IVSCTL_VBATUGEN_Msk          (0x1ul << SYS_IVSCTL_VBATUGEN_Pos)

#define SYS_PORCTL_POROFF_Pos            (0)
#define SYS_PORCTL_POROFF_Msk            (0xfffful << SYS_PORCTL_POROFF_Pos)

#define SYS_VREFCTL_IVREFREN_Pos         (0)
#define SYS_VREFCTL_IVREFREN_Msk         (0x3ul << SYS_VREFCTL_IVREFREN_Pos)

#define SYS_VREFCTL_IVREFVL_Pos          (2)
#define SYS_VREFCTL_IVREFVL_Msk          (0x3ul << SYS_VREFCTL_IVREFVL_Pos)

#define SYS_VREFCTL_VREFSSEL_Pos         (4)
#define SYS_VREFCTL_VREFSSEL_Msk         (0x1ul << SYS_VREFCTL_VREFSSEL_Pos)

#define SYS_USBPHY_USBROLE_Pos           (0)
#define SYS_USBPHY_USBROLE_Msk           (0x3ul << SYS_USBPHY_USBROLE_Pos)

#define SYS_USBPHY_LDO33EN_Pos           (8)
#define SYS_USBPHY_LDO33EN_Msk           (0x1ul << SYS_USBPHY_LDO33EN_Pos)

#define SYS_GPA_MFPL_PA0MFP_Pos          (0)
#define SYS_GPA_MFPL_PA0MFP_Msk          (0xful << SYS_GPA_MFPL_PA0MFP_Pos)

#define SYS_GPA_MFPL_PA1MFP_Pos          (4)
#define SYS_GPA_MFPL_PA1MFP_Msk          (0xful << SYS_GPA_MFPL_PA1MFP_Pos)

#define SYS_GPA_MFPL_PA2MFP_Pos          (8)
#define SYS_GPA_MFPL_PA2MFP_Msk          (0xful << SYS_GPA_MFPL_PA2MFP_Pos)

#define SYS_GPA_MFPL_PA3MFP_Pos          (12)
#define SYS_GPA_MFPL_PA3MFP_Msk          (0xful << SYS_GPA_MFPL_PA3MFP_Pos)

#define SYS_GPA_MFPL_PA4MFP_Pos          (16)
#define SYS_GPA_MFPL_PA4MFP_Msk          (0xful << SYS_GPA_MFPL_PA4MFP_Pos)

#define SYS_GPA_MFPL_PA5MFP_Pos          (20)
#define SYS_GPA_MFPL_PA5MFP_Msk          (0xful << SYS_GPA_MFPL_PA5MFP_Pos)

#define SYS_GPA_MFPL_PA6MFP_Pos          (24)
#define SYS_GPA_MFPL_PA6MFP_Msk          (0xful << SYS_GPA_MFPL_PA6MFP_Pos)

#define SYS_GPA_MFPL_PA7MFP_Pos          (28)
#define SYS_GPA_MFPL_PA7MFP_Msk          (0xful << SYS_GPA_MFPL_PA7MFP_Pos)

#define SYS_GPA_MFPH_PA8MFP_Pos          (0)
#define SYS_GPA_MFPH_PA8MFP_Msk          (0xful << SYS_GPA_MFPH_PA8MFP_Pos)

#define SYS_GPA_MFPH_PA9MFP_Pos         (4)
#define SYS_GPA_MFPH_PA9MFP_Msk          (0xful << SYS_GPA_MFPH_PA9MFP_Pos)

#define SYS_GPA_MFPH_PA10MFP_Pos         (8)
#define SYS_GPA_MFPH_PA10MFP_Msk         (0xful << SYS_GPA_MFPH_PA10MFP_Pos)

#define SYS_GPA_MFPH_PA11MFP_Pos         (12)
#define SYS_GPA_MFPH_PA11MFP_Msk         (0xful << SYS_GPA_MFPH_PA11MFP_Pos)

#define SYS_GPA_MFPH_PA12MFP_Pos         (16)
#define SYS_GPA_MFPH_PA12MFP_Msk         (0xful << SYS_GPA_MFPH_PA12MFP_Pos)

#define SYS_GPA_MFPH_PA13MFP_Pos         (20)
#define SYS_GPA_MFPH_PA13MFP_Msk         (0xful << SYS_GPA_MFPH_PA13MFP_Pos)

#define SYS_GPA_MFPH_PA14MFP_Pos         (24)
#define SYS_GPA_MFPH_PA14MFP_Msk         (0xful << SYS_GPA_MFPH_PA14MFP_Pos)

#define SYS_GPA_MFPH_PA15MFP_Pos         (28)
#define SYS_GPA_MFPH_PA15MFP_Msk         (0xful << SYS_GPA_MFPH_PA15MFP_Pos)

#define SYS_GPB_MFPL_PB0MFP_Pos          (0)
#define SYS_GPB_MFPL_PB0MFP_Msk          (0xful << SYS_GPB_MFPL_PB0MFP_Pos)

#define SYS_GPB_MFPL_PB1MFP_Pos          (4)
#define SYS_GPB_MFPL_PB1MFP_Msk          (0xful << SYS_GPB_MFPL_PB1MFP_Pos)

#define SYS_GPB_MFPL_PB2MFP_Pos          (8)
#define SYS_GPB_MFPL_PB2MFP_Msk          (0xful << SYS_GPB_MFPL_PB2MFP_Pos)

#define SYS_GPB_MFPL_PB3MFP_Pos          (12)
#define SYS_GPB_MFPL_PB3MFP_Msk          (0xful << SYS_GPB_MFPL_PB3MFP_Pos)

#define SYS_GPB_MFPL_PB4MFP_Pos          (16)
#define SYS_GPB_MFPL_PB4MFP_Msk          (0xful << SYS_GPB_MFPL_PB4MFP_Pos)

#define SYS_GPB_MFPL_PB5MFP_Pos          (20)
#define SYS_GPB_MFPL_PB5MFP_Msk          (0xful << SYS_GPB_MFPL_PB5MFP_Pos)

#define SYS_GPB_MFPL_PB6MFP_Pos          (24)
#define SYS_GPB_MFPL_PB6MFP_Msk          (0xful << SYS_GPB_MFPL_PB6MFP_Pos)

#define SYS_GPB_MFPL_PB7MFP_Pos          (28)
#define SYS_GPB_MFPL_PB7MFP_Msk          (0xful << SYS_GPB_MFPL_PB7MFP_Pos)

#define SYS_GPB_MFPH_PB8MFP_Pos          (0)
#define SYS_GPB_MFPH_PB8MFP_Msk          (0xful << SYS_GPB_MFPH_PB8MFP_Pos)

#define SYS_GPB_MFPH_PB9MFP_Pos          (4)
#define SYS_GPB_MFPH_PB9MFP_Msk          (0xful << SYS_GPB_MFPH_PB9MFP_Pos)

#define SYS_GPB_MFPH_PB10MFP_Pos         (8)
#define SYS_GPB_MFPH_PB10MFP_Msk         (0xful << SYS_GPB_MFPH_PB10MFP_Pos)

#define SYS_GPB_MFPH_PB11MFP_Pos         (12)
#define SYS_GPB_MFPH_PB11MFP_Msk         (0xful << SYS_GPB_MFPH_PB11MFP_Pos)

#define SYS_GPB_MFPH_PB12MFP_Pos         (16)
#define SYS_GPB_MFPH_PB12MFP_Msk         (0xful << SYS_GPB_MFPH_PB12MFP_Pos)

#define SYS_GPB_MFPH_PB13MFP_Pos         (20)
#define SYS_GPB_MFPH_PB13MFP_Msk         (0xful << SYS_GPB_MFPH_PB13MFP_Pos)

#define SYS_GPB_MFPH_PB14MFP_Pos         (24)
#define SYS_GPB_MFPH_PB14MFP_Msk         (0xful << SYS_GPB_MFPH_PB14MFP_Pos)

#define SYS_GPB_MFPH_PB15MFP_Pos         (28)
#define SYS_GPB_MFPH_PB15MFP_Msk         (0xful << SYS_GPB_MFPH_PB15MFP_Pos)

#define SYS_GPC_MFPL_PC0MFP_Pos          (0)
#define SYS_GPC_MFPL_PC0MFP_Msk          (0xful << SYS_GPC_MFPL_PC0MFP_Pos)

#define SYS_GPC_MFPL_PC1MFP_Pos          (4)
#define SYS_GPC_MFPL_PC1MFP_Msk          (0xful << SYS_GPC_MFPL_PC1MFP_Pos)

#define SYS_GPC_MFPL_PC2MFP_Pos          (8)
#define SYS_GPC_MFPL_PC2MFP_Msk          (0xful << SYS_GPC_MFPL_PC2MFP_Pos)

#define SYS_GPC_MFPL_PC3MFP_Pos          (12)
#define SYS_GPC_MFPL_PC3MFP_Msk          (0xful << SYS_GPC_MFPL_PC3MFP_Pos)

#define SYS_GPC_MFPL_PC4MFP_Pos          (16)
#define SYS_GPC_MFPL_PC4MFP_Msk          (0xful << SYS_GPC_MFPL_PC4MFP_Pos)

#define SYS_GPC_MFPL_PC5MFP_Pos          (20)
#define SYS_GPC_MFPL_PC5MFP_Msk          (0xful << SYS_GPC_MFPL_PC5MFP_Pos)

#define SYS_GPC_MFPL_PC6MFP_Pos          (24)
#define SYS_GPC_MFPL_PC6MFP_Msk          (0xful << SYS_GPC_MFPL_PC6MFP_Pos)

#define SYS_GPC_MFPL_PC7MFP_Pos          (28)
#define SYS_GPC_MFPL_PC7MFP_Msk          (0xful << SYS_GPC_MFPL_PC7MFP_Pos)

#define SYS_GPC_MFPH_PC8MFP_Pos          (0)
#define SYS_GPC_MFPH_PC8MFP_Msk          (0xful << GCR_GPC_MFPH_PC8MFP_Pos)

#define SYS_GPC_MFPH_PC9MFP_Pos          (4)
#define SYS_GPC_MFPH_PC9MFP_Msk          (0xful << SYS_GPC_MFPH_PC9MFP_Pos)

#define SYS_GPC_MFPH_PC10MFP_Pos         (8)
#define SYS_GPC_MFPH_PC10MFP_Msk         (0xful << SYS_GPC_MFPH_PC10MFP_Pos)

#define SYS_GPC_MFPH_PC11MFP_Pos         (12)
#define SYS_GPC_MFPH_PC11MFP_Msk         (0xful << SYS_GPC_MFPH_PC11MFP_Pos)

#define SYS_GPC_MFPH_PC12MFP_Pos         (16)
#define SYS_GPC_MFPH_PC12MFP_Msk         (0xful << SYS_GPC_MFPH_PC12MFP_Pos)

#define SYS_GPC_MFPH_PC13MFP_Pos         (20)
#define SYS_GPC_MFPH_PC13MFP_Msk         (0xful << SYS_GPC_MFPH_PC13MFP_Pos)

#define SYS_GPC_MFPH_PC14MFP_Pos         (24)
#define SYS_GPC_MFPH_PC14MFP_Msk         (0xful << SYS_GPC_MFPH_PC14MFP_Pos)

#define SYS_GPC_MFPH_PC15MFP_Pos         (28)
#define SYS_GPC_MFPH_PC15MFP_Msk         (0xful << SYS_GPC_MFPH_PC15MFP_Pos)

#define SYS_GPD_MFPL_PD0MFP_Pos          (0)
#define SYS_GPD_MFPL_PD0MFP_Msk          (0xful << SYS_GPD_MFPL_PD0MFP_Pos)

#define SYS_GPD_MFPL_PD1MFP_Pos          (4)
#define SYS_GPD_MFPL_PD1MFP_Msk          (0xful << SYS_GPD_MFPL_PD1MFP_Pos)

#define SYS_GPD_MFPL_PD2MFP_Pos          (8)
#define SYS_GPD_MFPL_PD2MFP_Msk          (0xful << SYS_GPD_MFPL_PD2MFP_Pos)

#define SYS_GPD_MFPL_PD3MFP_Pos          (12)
#define SYS_GPD_MFPL_PD3MFP_Msk          (0xful << SYS_GPD_MFPL_PD3MFP_Pos)

#define SYS_GPD_MFPL_PD4MFP_Pos          (16)
#define SYS_GPD_MFPL_PD4MFP_Msk          (0xful << SYS_GPD_MFPL_PD4MFP_Pos)

#define SYS_GPD_MFPL_PD5MFP_Pos          (20)
#define SYS_GPD_MFPL_PD5MFP_Msk          (0xful << SYS_GPD_MFPL_PD5MFP_Pos)

#define SYS_GPD_MFPL_PD6MFP_Pos          (24)
#define SYS_GPD_MFPL_PD6MFP_Msk          (0xful << SYS_GPD_MFPL_PD6MFP_Pos)

#define SYS_GPD_MFPL_PD7MFP_Pos          (28)
#define SYS_GPD_MFPL_PD7MFP_Msk          (0xful << SYS_GPD_MFPL_PD7MFP_Pos)

#define SYS_GPD_MFPH_PD8MFP_Pos          (0)
#define SYS_GPD_MFPH_PD8MFP_Msk          (0xful << SYS_GPD_MFPH_PD8MFP_Pos)

#define SYS_GPD_MFPH_PD9MFP_Pos          (4)
#define SYS_GPD_MFPH_PD9MFP_Msk          (0xful << SYS_GPD_MFPH_PD9MFP_Pos)

#define SYS_GPD_MFPH_PD10MFP_Pos         (8)
#define SYS_GPD_MFPH_PD10MFP_Msk         (0xful << SYS_GPD_MFPH_PD10MFP_Pos)

#define SYS_GPD_MFPH_PD11MFP_Pos         (12)
#define SYS_GPD_MFPH_PD11MFP_Msk         (0xful << SYS_GPD_MFPH_PD11MFP_Pos)

#define SYS_GPD_MFPH_PD12MFP_Pos         (16)
#define SYS_GPD_MFPH_PD12MFP_Msk         (0xful << SYS_GPD_MFPH_PD12MFP_Pos)

#define SYS_GPD_MFPH_PD13MFP_Pos        (20)
#define SYS_GPD_MFPH_PD13MFP_Msk         (0xful << SYS_GPD_MFPH_PD13MFP_Pos)

#define SYS_GPD_MFPH_PD14MFP_Pos         (24)
#define SYS_GPD_MFPH_PD14MFP_Msk         (0xful << SYS_GPD_MFPH_PD14MFP_Pos)

#define SYS_GPD_MFPH_PD15MFP_Pos         (28)
#define SYS_GPD_MFPH_PD15MFP_Msk         (0xful << SYS_GPD_MFPH_PD15MFP_Pos)

#define SYS_GPE_MFPL_PE0MFP_Pos          (0)
#define SYS_GPE_MFPL_PE0MFP_Msk          (0xful << SYS_GPE_MFPL_PE0MFP_Pos)

#define SYS_GPE_MFPL_PE1MFP_Pos          (4)
#define SYS_GPE_MFPL_PE1MFP_Msk          (0xful << SYS_GPE_MFPL_PE1MFP_Pos)

#define SYS_GPE_MFPL_PE2MFP_Pos          (8)
#define SYS_GPE_MFPL_PE2MFP_Msk          (0xful << SYS_GPE_MFPL_PE2MFP_Pos)

#define SYS_GPE_MFPL_PE3MFP_Pos          (12)
#define SYS_GPE_MFPL_PE3MFP_Msk          (0xful << SYS_GPE_MFPL_PE3MFP_Pos)

#define SYS_GPE_MFPL_PE4MFP_Pos          (16)
#define SYS_GPE_MFPL_PE4MFP_Msk          (0xful << SYS_GPE_MFPL_PE4MFP_Pos)

#define SYS_GPE_MFPL_PE5MFP_Pos          (20)
#define SYS_GPE_MFPL_PE5MFP_Msk          (0xful << SYS_GPE_MFPL_PE5MFP_Pos)

#define SYS_GPE_MFPL_PE6MFP_Pos          (24)
#define SYS_GPE_MFPL_PE6MFP_Msk          (0xful << SYS_GPE_MFPL_PE6MFP_Pos)

#define SYS_GPE_MFPL_PE7MFP_Pos          (28)
#define SYS_GPE_MFPL_PE7MFP_Msk          (0xful << SYS_GPE_MFPL_PE7MFP_Pos)

#define SYS_GPE_MFPH_PE8MFP_Pos          (0)
#define SYS_GPE_MFPH_PE8MFP_Msk          (0xful << SYS_GPE_MFPH_PE8MFP_Pos)

#define SYS_GPE_MFPH_PE9MFP_Pos          (4)
#define SYS_GPE_MFPH_PE9MFP_Msk          (0xful << SYS_GPE_MFPH_PE9MFP_Pos)

#define SYS_GPE_MFPH_PE10MFP_Pos         (8)
#define SYS_GPE_MFPH_PE10MFP_Msk         (0xful << SYS_GPE_MFPH_PE10MFP_Pos)

#define SYS_GPE_MFPH_PE11MFP_Pos         (12)
#define SYS_GPE_MFPH_PE11MFP_Msk         (0xful << SYS_GPE_MFPH_PE11MFP_Pos)

#define SYS_GPE_MFPH_PE12MFP_Pos         (16)
#define SYS_GPE_MFPH_PE12MFP_Msk         (0xful << SYS_GPE_MFPH_PE12MFP_Pos)

#define SYS_GPE_MFPH_PE13MFP_Pos         (20)
#define SYS_GPE_MFPH_PE13MFP_Msk         (0xful << SYS_GPE_MFPH_PE13MFP_Pos)

#define SYS_GPE_MFPH_PE14MFP_Pos         (24)
#define SYS_GPE_MFPH_PE14MFP_Msk         (0xful << SYS_GPE_MFPH_PE14MFP_Pos)

#define SYS_GPF_MFPL_PF0MFP_Pos          (0)
#define SYS_GPF_MFPL_PF0MFP_Msk          (0xful << SYS_GPF_MFPL_PF0MFP_Pos)

#define SYS_GPF_MFPL_PF1MFP_Pos          (4)
#define SYS_GPF_MFPL_PF1MFP_Msk          (0xful << SYS_GPF_MFPL_PF1MFP_Pos)

#define SYS_GPF_MFPL_PF2MFP_Pos          (8)
#define SYS_GPF_MFPL_PF2MFP_Msk          (0xful << SYS_GPF_MFPL_PF2MFP_Pos)

#define SYS_GPF_MFPL_PF3MFP_Pos          (12)
#define SYS_GPF_MFPL_PF3MFP_Msk          (0xful << SYS_GPF_MFPL_PF3MFP_Pos)

#define SYS_GPF_MFPL_PF4MFP_Pos          (16)
#define SYS_GPF_MFPL_PF4MFP_Msk          (0xful << SYS_GPF_MFPL_PF4MFP_Pos)

#define SYS_GPF_MFPL_PF5MFP_Pos          (20)
#define SYS_GPF_MFPL_PF5MFP_Msk          (0xful << SYS_GPF_MFPL_PF5MFP_Pos)

#define SYS_GPF_MFPL_PF6MFP_Pos          (24)
#define SYS_GPF_MFPL_PF6MFP_Msk          (0xful << SYS_GPF_MFPL_PF6MFP_Pos)

#define SYS_GPF_MFPL_PF7_MFP_Pos         (28)
#define SYS_GPF_MFPL_PF7_MFP_Msk         (0xful << SYS_GPF_MFPL_PF7_MFP_Pos)

#define SYS_SRAM_INTCTL_PERRIEN_Pos      (0)
#define SYS_SRAM_INTCTL_PERRIEN_Msk      (0x1ul << SYS_SRAM_INTCTL_PERRIEN_Pos)

#define SYS_SRAM_STATUS_PERRIF_Pos       (0)
#define SYS_SRAM_STATUS_PERRIF_Msk       (0x1ul << SYS_SRAM_STATUS_PERRIF_Pos)

#define SYS_SRAM_ERRADDR_ERRADDR_Pos     (0)
#define SYS_SRAM_ERRADDR_ERRADDR_Msk     (0xfffffffful << SYS_SRAM_ERRADDR_ERRADDR_Pos)

#define SYS_SRAM_BISTCTL_SRBIST0_Pos     (0)
#define SYS_SRAM_BISTCTL_SRBIST0_Msk     (0x1ul << SYS_SRAM_BISTCTL_SRBIST0_Pos)

#define SYS_SRAM_BISTCTL_SRBIST1_Pos     (1)
#define SYS_SRAM_BISTCTL_SRBIST1_Msk     (0x1ul << SYS_SRAM_BISTCTL_SRBIST1_Pos)

#define SYS_SRAM_BISTCTL_CRBIST_Pos      (2)
#define SYS_SRAM_BISTCTL_CRBIST_Msk      (0x1ul << SYS_SRAM_BISTCTL_CRBIST_Pos)

#define SYS_SRAM_BISTCTL_CANBIST_Pos     (3)
#define SYS_SRAM_BISTCTL_CANBIST_Msk     (0x1ul << SYS_SRAM_BISTCTL_CANBIST_Pos)

#define SYS_SRAM_BISTCTL_USBBIST_Pos     (4)
#define SYS_SRAM_BISTCTL_USBBIST_Msk     (0x1ul << SYS_SRAM_BISTCTL_USBBIST_Pos)

#define SYS_SRAM_BISTSTS_SRBISTEF0_Pos   (0)
#define SYS_SRAM_BISTSTS_SRBISTEF0_Msk   (0x1ul << SYS_SRAM_BISTSTS_SRBISTEF0_Pos)

#define SYS_SRAM_BISTSTS_SRBISTEF1_Pos   (1)
#define SYS_SRAM_BISTSTS_SRBISTEF1_Msk   (0x1ul << SYS_SRAM_BISTSTS_SRBISTEF1_Pos)

#define SYS_SRAM_BISTSTS_CRBISTEF_Pos    (2)
#define SYS_SRAM_BISTSTS_CRBISTEF_Msk    (0x1ul << SYS_SRAM_BISTSTS_CRBISTEF_Pos)

#define SYS_SRAM_BISTSTS_CANBEF_Pos      (3)
#define SYS_SRAM_BISTSTS_CANBEF_Msk      (0x1ul << SYS_SRAM_BISTSTS_CANBEF_Pos)

#define SYS_SRAM_BISTSTS_USBBEF_Pos      (4)
#define SYS_SRAM_BISTSTS_USBBEF_Msk      (0x1ul << SYS_SRAM_BISTSTS_USBBEF_Pos)

#define SYS_SRAM_BISTSTS_SRBEND0_Pos     (16)
#define SYS_SRAM_BISTSTS_SRBEND0_Msk     (0x1ul << SYS_SRAM_BISTSTS_SRBEND0_Pos)

#define SYS_SRAM_BISTSTS_SRBEND1_Pos     (17)
#define SYS_SRAM_BISTSTS_SRBEND1_Msk     (0x1ul << SYS_SRAM_BISTSTS_SRBEND1_Pos)

#define SYS_SRAM_BISTSTS_CRBEND_Pos      (18)
#define SYS_SRAM_BISTSTS_CRBEND_Msk      (0x1ul << SYS_SRAM_BISTSTS_CRBEND_Pos)

#define SYS_SRAM_BISTSTS_CANBEND_Pos     (19)
#define SYS_SRAM_BISTSTS_CANBEND_Msk     (0x1ul << SYS_SRAM_BISTSTS_CANBEND_Pos)

#define SYS_SRAM_BISTSTS_USBBEND_Pos     (20)
#define SYS_SRAM_BISTSTS_USBBEND_Msk     (0x1ul << SYS_SRAM_BISTSTS_USBBEND_Pos)

#define SYS_IRCTCTL_FREQSEL_Pos          (0)
#define SYS_IRCTCTL_FREQSEL_Msk          (0x3ul << SYS_IRCTCTL_FREQSEL_Pos)

#define SYS_IRCTCTL_LOOPSEL_Pos          (4)
#define SYS_IRCTCTL_LOOPSEL_Msk          (0x3ul << SYS_IRCTCTL_LOOPSEL_Pos)

#define SYS_IRCTCTL_RETRYCNT_Pos         (6)
#define SYS_IRCTCTL_RETRYCNT_Msk         (0x3ul << SYS_IRCTCTL_RETRYCNT_Pos)

#define SYS_IRCTCTL_CESTOPEN_Pos         (8)
#define SYS_IRCTCTL_CESTOPEN_Msk         (0x1ul << SYS_IRCTCTL_CESTOPEN_Pos)

#define SYS_IRCTIEN_TFAILIEN_Pos         (1)
#define SYS_IRCTIEN_TFAILIEN_Msk         (0x1ul << SYS_IRCTIEN_TFAILIEN_Pos)

#define SYS_IRCTIEN_CLKEIEN_Pos          (2)
#define SYS_IRCTIEN_CLKEIEN_Msk          (0x1ul << SYS_IRCTIEN_CLKEIEN_Pos)

#define SYS_IRCTISTS_FREQLOCK_Pos        (0)
#define SYS_IRCTISTS_FREQLOCK_Msk        (0x1ul << GCR_IRCTISTS_FREQLOCK_Pos)

#define SYS_IRCTISTS_TFAILIF_Pos         (1)
#define SYS_IRCTISTS_TFAILIF_Msk         (0x1ul << SYS_IRCTISTS_TFAILIF_Pos)

#define SYS_IRCTISTS_CLKEIF_Pos          (2)
#define SYS_IRCTISTS_CLKEIF_Msk          (0x1ul << SYS_IRCTISTS_CLKEIF_Pos)

#define SYS_REGLCTL_REGLCTL_Pos          (0)
#define SYS_REGLCTL_REGLCTL_Msk          (0xfful << SYS_REGLCTL_REGLCTL_Pos)

#define SYS_TSOFFSET_VTEMP_Pos           (0)
#define SYS_TSOFFSET_VTEMP_Msk           (0xffful << SYS_TSOFFSET_VTEMP_Pos)


/**@}*/ /* GCR_CONST */
/**@}*/ /* end of GCR register group */


/*---------------------- General Purpose Input/Output Controller -------------------------*/
/**
    @addtogroup GPIO General Purpose Input/Output Controller(GPIO)
    Memory Mapped Structure for GPIO Controller
@{ */
 
typedef struct
{

    __IO uint32_t MODE;               /*!< [0x0000] GPIO I/O Mode Control                                              */
    __IO uint32_t DINOFF;             /*!< [0x0004] GPIO Digital Input Path Disable Control                            */
    __IO uint32_t DOUT;               /*!< [0x0008] GPIO Data Output Value                                             */
    __IO uint32_t DATMSK;             /*!< [0x000c] GPIO Data Output Write Mask                                        */
    __IO uint32_t PIN;                /*!< [0x0010] GPIO Pin Value                                                     */
    __IO uint32_t DBEN;               /*!< [0x0014] GPIO De-Bounce Enable Control                                      */
    __IO uint32_t INTTYPE;            /*!< [0x0018] GPIO Interrupt Mode Control                                        */
    __IO uint32_t INTEN;              /*!< [0x001c] GPIO Interrupt Enable Control                                      */
    __IO uint32_t INTSRC;             /*!< [0x0020] GPIO Interrupt Source Flag                                         */
    __IO uint32_t SMTEN;              /*!< [0x0024] GPIO Input Buffer Schmitt Trigger Enable                           */
    __IO uint32_t SLEWCTL;            /*!< [0x0028] GPIO High Slew Rate Control                                        */

} GPIO_T;

typedef struct
{
 
    __IO uint32_t DBCTL;          /*!< [0x0440] Interrupt De-bounce Control                                      */

} GPIO_DBCTL_T;

/**
    @addtogroup GPIO_CONST GPIO Bit Field Definition
    Constant Definitions for GPIO Controller
@{ */

#define GPIO_MODE_MODE0_Pos              (0)
#define GPIO_MODE_MODE0_Msk              (0x3ul << GPIO_MODE_MODE0_Pos)

#define GPIO_MODE_MODE1_Pos              (2)
#define GPIO_MODE_MODE1_Msk              (0x3ul << GPIO_MODE_MODE1_Pos)

#define GPIO_MODE_MODE2_Pos              (4)
#define GPIO_MODE_MODE2_Msk              (0x3ul << GPIO_MODE_MODE2_Pos)

#define GPIO_MODE_MODE3_Pos              (6)
#define GPIO_MODE_MODE3_Msk              (0x3ul << GPIO_MODE_MODE3_Pos)

#define GPIO_MODE_MODE4_Pos              (8)
#define GPIO_MODE_MODE4_Msk              (0x3ul << GPIO_MODE_MODE4_Pos)

#define GPIO_MODE_MODE5_Pos              (10)
#define GPIO_MODE_MODE5_Msk              (0x3ul << GPIO_MODE_MODE5_Pos)

#define GPIO_MODE_MODE6_Pos              (12)
#define GPIO_MODE_MODE6_Msk              (0x3ul << GPIO_MODE_MODE6_Pos)

#define GPIO_MODE_MODE7_Pos              (14)
#define GPIO_MODE_MODE7_Msk              (0x3ul << GPIO_MODE_MODE7_Pos)

#define GPIO_MODE_MODE8_Pos              (16)
#define GPIO_MODE_MODE8_Msk              (0x3ul << GPIO_MODE_MODE8_Pos)

#define GPIO_MODE_MODE9_Pos              (18)
#define GPIO_MODE_MODE9_Msk              (0x3ul << GPIO_MODE_MODE9_Pos)

#define GPIO_MODE_MODE10_Pos             (20)
#define GPIO_MODE_MODE10_Msk             (0x3ul << GPIO_MODE_MODE10_Pos)

#define GPIO_MODE_MODE11_Pos             (22)
#define GPIO_MODE_MODE11_Msk             (0x3ul << GPIO_MODE_MODE11_Pos)

#define GPIO_MODE_MODE12_Pos             (24)
#define GPIO_MODE_MODE12_Msk             (0x3ul << GPIO_MODE_MODE12_Pos)

#define GPIO_MODE_MODE13_Pos             (26)
#define GPIO_MODE_MODE13_Msk             (0x3ul << GPIO_MODE_MODE13_Pos)

#define GPIO_MODE_MODE14_Pos             (28)
#define GPIO_MODE_MODE14_Msk             (0x3ul << GPIO_MODE_MODE14_Pos)

#define GPIO_MODE_MODE15_Pos             (30)
#define GPIO_MODE_MODE15_Msk             (0x3ul << GPIO_MODE_MODE15_Pos)

#define GPIO_DINOFF_DINOFF0_Pos          (16)
#define GPIO_DINOFF_DINOFF0_Msk          (0x1ul << GPIO_DINOFF_DINOFF0_Pos)

#define GPIO_DINOFF_DINOFF1_Pos          (17)
#define GPIO_DINOFF_DINOFF1_Msk          (0x1ul << GPIO_DINOFF_DINOFF1_Pos)

#define GPIO_DINOFF_DINOFF2_Pos          (18)
#define GPIO_DINOFF_DINOFF2_Msk          (0x1ul << GPIO_DINOFF_DINOFF2_Pos)

#define GPIO_DINOFF_DINOFF3_Pos          (19)
#define GPIO_DINOFF_DINOFF3_Msk          (0x1ul << GPIO_DINOFF_DINOFF3_Pos)

#define GPIO_DINOFF_DINOFF4_Pos          (20)
#define GPIO_DINOFF_DINOFF4_Msk          (0x1ul << GPIO_DINOFF_DINOFF4_Pos)

#define GPIO_DINOFF_DINOFF5_Pos          (21)
#define GPIO_DINOFF_DINOFF5_Msk          (0x1ul << GPIO_DINOFF_DINOFF5_Pos)

#define GPIO_DINOFF_DINOFF6_Pos          (22)
#define GPIO_DINOFF_DINOFF6_Msk          (0x1ul << GPIO_DINOFF_DINOFF6_Pos)

#define GPIO_DINOFF_DINOFF7_Pos          (23)
#define GPIO_DINOFF_DINOFF7_Msk          (0x1ul << GPIO_DINOFF_DINOFF7_Pos)

#define GPIO_DINOFF_DINOFF8_Pos          (24)
#define GPIO_DINOFF_DINOFF8_Msk          (0x1ul << GPIO_DINOFF_DINOFF8_Pos)

#define GPIO_DINOFF_DINOFF9_Pos          (25)
#define GPIO_DINOFF_DINOFF9_Msk          (0x1ul << GPIO_DINOFF_DINOFF9_Pos)

#define GPIO_DINOFF_DINOFF10_Pos         (26)
#define GPIO_DINOFF_DINOFF10_Msk         (0x1ul << GPIO_DINOFF_DINOFF10_Pos)

#define GPIO_DINOFF_DINOFF11_Pos         (27)
#define GPIO_DINOFF_DINOFF11_Msk         (0x1ul << GPIO_DINOFF_DINOFF11_Pos)

#define GPIO_DINOFF_DINOFF12_Pos         (28)
#define GPIO_DINOFF_DINOFF12_Msk         (0x1ul << GPIO_DINOFF_DINOFF12_Pos)

#define GPIO_DINOFF_DINOFF13_Pos         (29)
#define GPIO_DINOFF_DINOFF13_Msk         (0x1ul << GPIO_DINOFF_DINOFF13_Pos)

#define GPIO_DINOFF_DINOFF14_Pos         (30)
#define GPIO_DINOFF_DINOFF14_Msk         (0x1ul << GPIO_DINOFF_DINOFF14_Pos)

#define GPIO_DINOFF_DINOFF15_Pos         (31)
#define GPIO_DINOFF_DINOFF15_Msk         (0x1ul << GPIO_DINOFF_DINOFF15_Pos)

#define GPIO_DOUT_DOUT0_Pos              (0)
#define GPIO_DOUT_DOUT0_Msk              (0x1ul << GPIO_DOUT_DOUT0_Pos)

#define GPIO_DOUT_DOUT1_Pos              (1)
#define GPIO_DOUT_DOUT1_Msk              (0x1ul << GPIO_DOUT_DOUT1_Pos)

#define GPIO_DOUT_DOUT2_Pos              (2)
#define GPIO_DOUT_DOUT2_Msk              (0x1ul << GPIO_DOUT_DOUT2_Pos)

#define GPIO_DOUT_DOUT3_Pos              (3)
#define GPIO_DOUT_DOUT3_Msk              (0x1ul << GPIO_DOUT_DOUT3_Pos)

#define GPIO_DOUT_DOUT4_Pos              (4)
#define GPIO_DOUT_DOUT4_Msk              (0x1ul << GPIO_DOUT_DOUT4_Pos)

#define GPIO_DOUT_DOUT5_Pos              (5)
#define GPIO_DOUT_DOUT5_Msk              (0x1ul << GPIO_DOUT_DOUT5_Pos)

#define GPIO_DOUT_DOUT6_Pos              (6)
#define GPIO_DOUT_DOUT6_Msk              (0x1ul << GPIO_DOUT_DOUT6_Pos)

#define GPIO_DOUT_DOUT7_Pos              (7)
#define GPIO_DOUT_DOUT7_Msk              (0x1ul << GPIO_DOUT_DOUT7_Pos)

#define GPIO_DOUT_DOUT8_Pos              (8)
#define GPIO_DOUT_DOUT8_Msk              (0x1ul << GPIO_DOUT_DOUT8_Pos)

#define GPIO_DOUT_DOUT9_Pos              (9)
#define GPIO_DOUT_DOUT9_Msk              (0x1ul << GPIO_DOUT_DOUT9_Pos)

#define GPIO_DOUT_DOUT10_Pos             (10)
#define GPIO_DOUT_DOUT10_Msk             (0x1ul << GPIO_DOUT_DOUT10_Pos)

#define GPIO_DOUT_DOUT11_Pos             (11)
#define GPIO_DOUT_DOUT11_Msk             (0x1ul << GPIO_DOUT_DOUT11_Pos)

#define GPIO_DOUT_DOUT12_Pos             (12)
#define GPIO_DOUT_DOUT12_Msk             (0x1ul << GPIO_DOUT_DOUT12_Pos)

#define GPIO_DOUT_DOUT13_Pos             (13)
#define GPIO_DOUT_DOUT13_Msk             (0x1ul << GPIO_DOUT_DOUT13_Pos)

#define GPIO_DOUT_DOUT14_Pos             (14)
#define GPIO_DOUT_DOUT14_Msk             (0x1ul << GPIO_DOUT_DOUT14_Pos)

#define GPIO_DOUT_DOUT15_Pos             (15)
#define GPIO_DOUT_DOUT15_Msk             (0x1ul << GPIO_DOUT_DOUT15_Pos)

#define GPIO_DATMSK_DMASK0_Pos           (0)
#define GPIO_DATMSK_DMASK0_Msk           (0x1ul << GPIO_DATMSK_DMASK0_Pos)

#define GPIO_DATMSK_DMASK1_Pos           (1)
#define GPIO_DATMSK_DMASK1_Msk           (0x1ul << GPIO_DATMSK_DMASK1_Pos)

#define GPIO_DATMSK_DMASK2_Pos           (2)
#define GPIO_DATMSK_DMASK2_Msk           (0x1ul << GPIO_DATMSK_DMASK2_Pos)

#define GPIO_DATMSK_DMASK3_Pos           (3)
#define GPIO_DATMSK_DMASK3_Msk           (0x1ul << GPIO_DATMSK_DMASK3_Pos)

#define GPIO_DATMSK_DMASK4_Pos           (4)
#define GPIO_DATMSK_DMASK4_Msk           (0x1ul << GPIO_DATMSK_DMASK4_Pos)

#define GPIO_DATMSK_DMASK5_Pos           (5)
#define GPIO_DATMSK_DMASK5_Msk           (0x1ul << GPIO_DATMSK_DMASK5_Pos)

#define GPIO_DATMSK_DMASK6_Pos           (6)
#define GPIO_DATMSK_DMASK6_Msk           (0x1ul << GPIO_DATMSK_DMASK6_Pos)

#define GPIO_DATMSK_DMASK7_Pos           (7)
#define GPIO_DATMSK_DMASK7_Msk           (0x1ul << GPIO_DATMSK_DMASK7_Pos)

#define GPIO_DATMSK_DMASK8_Pos           (8)
#define GPIO_DATMSK_DMASK8_Msk           (0x1ul << GPIO_DATMSK_DMASK8_Pos)

#define GPIO_DATMSK_DMASK9_Pos           (9)
#define GPIO_DATMSK_DMASK9_Msk           (0x1ul << GPIO_DATMSK_DMASK9_Pos)

#define GPIO_DATMSK_DMASK10_Pos          (10)
#define GPIO_DATMSK_DMASK10_Msk          (0x1ul << GPIO_DATMSK_DMASK10_Pos)

#define GPIO_DATMSK_DMASK11_Pos          (11)
#define GPIO_DATMSK_DMASK11_Msk          (0x1ul << GPIO_DATMSK_DMASK11_Pos)

#define GPIO_DATMSK_DMASK12_Pos          (12)
#define GPIO_DATMSK_DMASK12_Msk          (0x1ul << GPIO_DATMSK_DMASK12_Pos)

#define GPIO_DATMSK_DMASK13_Pos          (13)
#define GPIO_DATMSK_DMASK13_Msk          (0x1ul << GPIO_DATMSK_DMASK13_Pos)

#define GPIO_DATMSK_DMASK14_Pos          (14)
#define GPIO_DATMSK_DMASK14_Msk          (0x1ul << GPIO_DATMSK_DMASK14_Pos)

#define GPIO_DATMSK_DMASK15_Pos          (15)
#define GPIO_DATMSK_DMASK15_Msk          (0x1ul << GPIO_DATMSK_DMASK15_Pos)

#define GPIO_PIN_PIN0_Pos                (0)
#define GPIO_PIN_PIN0_Msk                (0x1ul << GPIO_PIN_PIN0_Pos)

#define GPIO_PIN_PIN1_Pos                (1)
#define GPIO_PIN_PIN1_Msk                (0x1ul << GPIO_PIN_PIN1_Pos)

#define GPIO_PIN_PIN2_Pos                (2)
#define GPIO_PIN_PIN2_Msk                (0x1ul << GPIO_PIN_PIN2_Pos)

#define GPIO_PIN_PIN3_Pos                (3)
#define GPIO_PIN_PIN3_Msk                (0x1ul << GPIO_PIN_PIN3_Pos)

#define GPIO_PIN_PIN4_Pos                (4)
#define GPIO_PIN_PIN4_Msk                (0x1ul << GPIO_PIN_PIN4_Pos)

#define GPIO_PIN_PIN5_Pos                (5)
#define GPIO_PIN_PIN5_Msk                (0x1ul << GPIO_PIN_PIN5_Pos)

#define GPIO_PIN_PIN6_Pos                (6)
#define GPIO_PIN_PIN6_Msk                (0x1ul << GPIO_PIN_PIN6_Pos)

#define GPIO_PIN_PIN7_Pos                (7)
#define GPIO_PIN_PIN7_Msk                (0x1ul << GPIO_PIN_PIN7_Pos)

#define GPIO_PIN_PIN8_Pos                (8)
#define GPIO_PIN_PIN8_Msk                (0x1ul << GPIO_PIN_PIN8_Pos)

#define GPIO_PIN_PIN9_Pos                (9)
#define GPIO_PIN_PIN9_Msk                (0x1ul << GPIO_PIN_PIN9_Pos)

#define GPIO_PIN_PIN10_Pos               (10)
#define GPIO_PIN_PIN10_Msk               (0x1ul << GPIO_PIN_PIN10_Pos)

#define GPIO_PIN_PIN11_Pos               (11)
#define GPIO_PIN_PIN11_Msk               (0x1ul << GPIO_PIN_PIN11_Pos)

#define GPIO_PIN_PIN12_Pos               (12)
#define GPIO_PIN_PIN12_Msk               (0x1ul << GPIO_PIN_PIN12_Pos)

#define GPIO_PIN_PIN13_Pos               (13)
#define GPIO_PIN_PIN13_Msk               (0x1ul << GPIO_PIN_PIN13_Pos)

#define GPIO_PIN_PIN14_Pos               (14)
#define GPIO_PIN_PIN14_Msk               (0x1ul << GPIO_PIN_PIN14_Pos)

#define GPIO_PIN_PIN15_Pos               (15)
#define GPIO_PIN_PIN15_Msk               (0x1ul << GPIO_PIN_PIN15_Pos)

#define GPIO_DBEN_DBEN0_Pos              (0)
#define GPIO_DBEN_DBEN0_Msk              (0x1ul << GPIO_DBEN_DBEN0_Pos)

#define GPIO_DBEN_DBEN1_Pos              (1)
#define GPIO_DBEN_DBEN1_Msk              (0x1ul << GPIO_DBEN_DBEN1_Pos)

#define GPIO_DBEN_DBEN2_Pos              (2)
#define GPIO_DBEN_DBEN2_Msk              (0x1ul << GPIO_DBEN_DBEN2_Pos)

#define GPIO_DBEN_DBEN3_Pos              (3)
#define GPIO_DBEN_DBEN3_Msk              (0x1ul << GPIO_DBEN_DBEN3_Pos)

#define GPIO_DBEN_DBEN4_Pos              (4)
#define GPIO_DBEN_DBEN4_Msk              (0x1ul << GPIO_DBEN_DBEN4_Pos)

#define GPIO_DBEN_DBEN5_Pos              (5)
#define GPIO_DBEN_DBEN5_Msk              (0x1ul << GPIO_DBEN_DBEN5_Pos)

#define GPIO_DBEN_DBEN6_Pos              (6)
#define GPIO_DBEN_DBEN6_Msk              (0x1ul << GPIO_DBEN_DBEN6_Pos)

#define GPIO_DBEN_DBEN7_Pos              (7)
#define GPIO_DBEN_DBEN7_Msk              (0x1ul << GPIO_DBEN_DBEN7_Pos)

#define GPIO_DBEN_DBEN8_Pos              (8)
#define GPIO_DBEN_DBEN8_Msk              (0x1ul << GPIO_DBEN_DBEN8_Pos)

#define GPIO_DBEN_DBEN9_Pos              (9)
#define GPIO_DBEN_DBEN9_Msk              (0x1ul << GPIO_DBEN_DBEN9_Pos)

#define GPIO_DBEN_DBEN10_Pos             (10)
#define GPIO_DBEN_DBEN10_Msk             (0x1ul << GPIO_DBEN_DBEN10_Pos)

#define GPIO_DBEN_DBEN11_Pos             (11)
#define GPIO_DBEN_DBEN11_Msk             (0x1ul << GPIO_DBEN_DBEN11_Pos)

#define GPIO_DBEN_DBEN12_Pos             (12)
#define GPIO_DBEN_DBEN12_Msk             (0x1ul << GPIO_DBEN_DBEN12_Pos)

#define GPIO_DBEN_DBEN13_Pos             (13)
#define GPIO_DBEN_DBEN13_Msk             (0x1ul << GPIO_DBEN_DBEN13_Pos)

#define GPIO_DBEN_DBEN14_Pos             (14)
#define GPIO_DBEN_DBEN14_Msk             (0x1ul << GPIO_DBEN_DBEN14_Pos)

#define GPIO_DBEN_DBEN15_Pos             (15)
#define GPIO_DBEN_DBEN15_Msk             (0x1ul << GPIO_DBEN_DBEN15_Pos)

#define GPIO_INTTYPE_TYPE0_Pos           (0)
#define GPIO_INTTYPE_TYPE0_Msk           (0x1ul << GPIO_INTTYPE_TYPE0_Pos)

#define GPIO_INTTYPE_TYPE1_Pos           (1)
#define GPIO_INTTYPE_TYPE1_Msk           (0x1ul << GPIO_INTTYPE_TYPE1_Pos)

#define GPIO_INTTYPE_TYPE2_Pos           (2)
#define GPIO_INTTYPE_TYPE2_Msk           (0x1ul << GPIO_INTTYPE_TYPE2_Pos)

#define GPIO_INTTYPE_TYPE3_Pos           (3)
#define GPIO_INTTYPE_TYPE3_Msk           (0x1ul << GPIO_INTTYPE_TYPE3_Pos)

#define GPIO_INTTYPE_TYPE4_Pos           (4)
#define GPIO_INTTYPE_TYPE4_Msk           (0x1ul << GPIO_INTTYPE_TYPE4_Pos)

#define GPIO_INTTYPE_TYPE5_Pos           (5)
#define GPIO_INTTYPE_TYPE5_Msk           (0x1ul << GPIO_INTTYPE_TYPE5_Pos)

#define GPIO_INTTYPE_TYPE6_Pos           (6)
#define GPIO_INTTYPE_TYPE6_Msk           (0x1ul << GPIO_INTTYPE_TYPE6_Pos)

#define GPIO_INTTYPE_TYPE7_Pos           (7)
#define GPIO_INTTYPE_TYPE7_Msk           (0x1ul << GPIO_INTTYPE_TYPE7_Pos)

#define GPIO_INTTYPE_TYPE8_Pos           (8)
#define GPIO_INTTYPE_TYPE8_Msk           (0x1ul << GPIO_INTTYPE_TYPE8_Pos)

#define GPIO_INTTYPE_TYPE9_Pos           (9)
#define GPIO_INTTYPE_TYPE9_Msk           (0x1ul << GPIO_INTTYPE_TYPE9_Pos)

#define GPIO_INTTYPE_TYPE10_Pos          (10)
#define GPIO_INTTYPE_TYPE10_Msk          (0x1ul << GPIO_INTTYPE_TYPE10_Pos)

#define GPIO_INTTYPE_TYPE11_Pos          (11)
#define GPIO_INTTYPE_TYPE11_Msk          (0x1ul << GPIO_INTTYPE_TYPE11_Pos)

#define GPIO_INTTYPE_TYPE12_Pos          (12)
#define GPIO_INTTYPE_TYPE12_Msk          (0x1ul << GPIO_INTTYPE_TYPE12_Pos)

#define GPIO_INTTYPE_TYPE13_Pos          (13)
#define GPIO_INTTYPE_TYPE13_Msk          (0x1ul << GPIO_INTTYPE_TYPE13_Pos)

#define GPIO_INTTYPE_TYPE14_Pos          (14)
#define GPIO_INTTYPE_TYPE14_Msk          (0x1ul << GPIO_INTTYPE_TYPE14_Pos)

#define GPIO_INTTYPE_TYPE15_Pos          (15)
#define GPIO_INTTYPE_TYPE15_Msk          (0x1ul << GPIO_INTTYPE_TYPE15_Pos)

#define GPIO_INTEN_FLIEN0_Pos            (0)
#define GPIO_INTEN_FLIEN0_Msk            (0x1ul << GPIO_INTEN_FLIEN0_Pos)

#define GPIO_INTEN_FLIEN1_Pos            (1)
#define GPIO_INTEN_FLIEN1_Msk            (0x1ul << GPIO_INTEN_FLIEN1_Pos)

#define GPIO_INTEN_FLIEN2_Pos            (2)
#define GPIO_INTEN_FLIEN2_Msk            (0x1ul << GPIO_INTEN_FLIEN2_Pos)

#define GPIO_INTEN_FLIEN3_Pos            (3)
#define GPIO_INTEN_FLIEN3_Msk            (0x1ul << GPIO_INTEN_FLIEN3_Pos)

#define GPIO_INTEN_FLIEN4_Pos            (4)
#define GPIO_INTEN_FLIEN4_Msk            (0x1ul << GPIO_INTEN_FLIEN4_Pos)

#define GPIO_INTEN_FLIEN5_Pos            (5)
#define GPIO_INTEN_FLIEN5_Msk            (0x1ul << GPIO_INTEN_FLIEN5_Pos)

#define GPIO_INTEN_FLIEN6_Pos            (6)
#define GPIO_INTEN_FLIEN6_Msk            (0x1ul << GPIO_INTEN_FLIEN6_Pos)

#define GPIO_INTEN_FLIEN7_Pos            (7)
#define GPIO_INTEN_FLIEN7_Msk            (0x1ul << GPIO_INTEN_FLIEN7_Pos)

#define GPIO_INTEN_FLIEN8_Pos            (8)
#define GPIO_INTEN_FLIEN8_Msk            (0x1ul << GPIO_INTEN_FLIEN8_Pos)

#define GPIO_INTEN_FLIEN9_Pos            (9)
#define GPIO_INTEN_FLIEN9_Msk            (0x1ul << GPIO_INTEN_FLIEN9_Pos)

#define GPIO_INTEN_FLIEN10_Pos           (10)
#define GPIO_INTEN_FLIEN10_Msk           (0x1ul << GPIO_INTEN_FLIEN10_Pos)

#define GPIO_INTEN_FLIEN11_Pos           (11)
#define GPIO_INTEN_FLIEN11_Msk           (0x1ul << GPIO_INTEN_FLIEN11_Pos)

#define GPIO_INTEN_FLIEN12_Pos           (12)
#define GPIO_INTEN_FLIEN12_Msk           (0x1ul << GPIO_INTEN_FLIEN12_Pos)

#define GPIO_INTEN_FLIEN13_Pos           (13)
#define GPIO_INTEN_FLIEN13_Msk           (0x1ul << GPIO_INTEN_FLIEN13_Pos)

#define GPIO_INTEN_FLIEN14_Pos           (14)
#define GPIO_INTEN_FLIEN14_Msk           (0x1ul << GPIO_INTEN_FLIEN14_Pos)

#define GPIO_INTEN_FLIEN15_Pos           (15)
#define GPIO_INTEN_FLIEN15_Msk           (0x1ul << GPIO_INTEN_FLIEN15_Pos)

#define GPIO_INTEN_RHIEN0_Pos            (16)
#define GPIO_INTEN_RHIEN0_Msk            (0x1ul << GPIO_INTEN_RHIEN0_Pos)

#define GPIO_INTEN_RHIEN1_Pos            (17)
#define GPIO_INTEN_RHIEN1_Msk            (0x1ul << GPIO_INTEN_RHIEN1_Pos)

#define GPIO_INTEN_RHIEN2_Pos            (18)
#define GPIO_INTEN_RHIEN2_Msk            (0x1ul << GPIO_INTEN_RHIEN2_Pos)

#define GPIO_INTEN_RHIEN3_Pos            (19)
#define GPIO_INTEN_RHIEN3_Msk            (0x1ul << GPIO_INTEN_RHIEN3_Pos)

#define GPIO_INTEN_RHIEN4_Pos            (20)
#define GPIO_INTEN_RHIEN4_Msk            (0x1ul << GPIO_INTEN_RHIEN4_Pos)

#define GPIO_INTEN_RHIEN5_Pos            (21)
#define GPIO_INTEN_RHIEN5_Msk            (0x1ul << GPIO_INTEN_RHIEN5_Pos)

#define GPIO_INTEN_RHIEN6_Pos            (22)
#define GPIO_INTEN_RHIEN6_Msk            (0x1ul << GPIO_INTEN_RHIEN6_Pos)

#define GPIO_INTEN_RHIEN7_Pos            (23)
#define GPIO_INTEN_RHIEN7_Msk            (0x1ul << GPIO_INTEN_RHIEN7_Pos)

#define GPIO_INTEN_RHIEN8_Pos            (24)
#define GPIO_INTEN_RHIEN8_Msk            (0x1ul << GPIO_INTEN_RHIEN8_Pos)

#define GPIO_INTEN_RHIEN9_Pos            (25)
#define GPIO_INTEN_RHIEN9_Msk            (0x1ul << GPIO_INTEN_RHIEN9_Pos)

#define GPIO_INTEN_RHIEN10_Pos           (26)
#define GPIO_INTEN_RHIEN10_Msk           (0x1ul << GPIO_INTEN_RHIEN10_Pos)

#define GPIO_INTEN_RHIEN11_Pos           (27)
#define GPIO_INTEN_RHIEN11_Msk           (0x1ul << GPIO_INTEN_RHIEN11_Pos)

#define GPIO_INTEN_RHIEN12_Pos           (28)
#define GPIO_INTEN_RHIEN12_Msk           (0x1ul << GPIO_INTEN_RHIEN12_Pos)

#define GPIO_INTEN_RHIEN13_Pos           (29)
#define GPIO_INTEN_RHIEN13_Msk           (0x1ul << GPIO_INTEN_RHIEN13_Pos)

#define GPIO_INTEN_RHIEN14_Pos           (30)
#define GPIO_INTEN_RHIEN14_Msk           (0x1ul << GPIO_INTEN_RHIEN14_Pos)

#define GPIO_INTEN_RHIEN15_Pos           (31)
#define GPIO_INTEN_RHIEN15_Msk           (0x1ul << GPIO_INTEN_RHIEN15_Pos)

#define GPIO_INTSRC_INTSRC0_Pos          (0)
#define GPIO_INTSRC_INTSRC0_Msk          (0x1ul << GPIO_INTSRC_INTSRC0_Pos)

#define GPIO_INTSRC_INTSRC1_Pos          (1)
#define GPIO_INTSRC_INTSRC1_Msk          (0x1ul << GPIO_INTSRC_INTSRC1_Pos)

#define GPIO_INTSRC_INTSRC2_Pos          (2)
#define GPIO_INTSRC_INTSRC2_Msk          (0x1ul << GPIO_INTSRC_INTSRC2_Pos)

#define GPIO_INTSRC_INTSRC3_Pos          (3)
#define GPIO_INTSRC_INTSRC3_Msk          (0x1ul << GPIO_INTSRC_INTSRC3_Pos)

#define GPIO_INTSRC_INTSRC4_Pos          (4)
#define GPIO_INTSRC_INTSRC4_Msk          (0x1ul << GPIO_INTSRC_INTSRC4_Pos)

#define GPIO_INTSRC_INTSRC5_Pos          (5)
#define GPIO_INTSRC_INTSRC5_Msk          (0x1ul << GPIO_INTSRC_INTSRC5_Pos)

#define GPIO_INTSRC_INTSRC6_Pos          (6)
#define GPIO_INTSRC_INTSRC6_Msk          (0x1ul << GPIO_INTSRC_INTSRC6_Pos)

#define GPIO_INTSRC_INTSRC7_Pos          (7)
#define GPIO_INTSRC_INTSRC7_Msk          (0x1ul << GPIO_INTSRC_INTSRC7_Pos)

#define GPIO_INTSRC_INTSRC8_Pos          (8)
#define GPIO_INTSRC_INTSRC8_Msk          (0x1ul << GPIO_INTSRC_INTSRC8_Pos)

#define GPIO_INTSRC_INTSRC9_Pos          (9)
#define GPIO_INTSRC_INTSRC9_Msk          (0x1ul << GPIO_INTSRC_INTSRC9_Pos)

#define GPIO_INTSRC_INTSRC10_Pos         (10)
#define GPIO_INTSRC_INTSRC10_Msk         (0x1ul << GPIO_INTSRC_INTSRC10_Pos)

#define GPIO_INTSRC_INTSRC11_Pos         (11)
#define GPIO_INTSRC_INTSRC11_Msk         (0x1ul << GPIO_INTSRC_INTSRC11_Pos)

#define GPIO_INTSRC_INTSRC12_Pos         (12)
#define GPIO_INTSRC_INTSRC12_Msk         (0x1ul << GPIO_INTSRC_INTSRC12_Pos)

#define GPIO_INTSRC_INTSRC13_Pos         (13)
#define GPIO_INTSRC_INTSRC13_Msk         (0x1ul << GPIO_INTSRC_INTSRC13_Pos)

#define GPIO_INTSRC_INTSRC14_Pos         (14)
#define GPIO_INTSRC_INTSRC14_Msk         (0x1ul << GPIO_INTSRC_INTSRC14_Pos)

#define GPIO_INTSRC_INTSRC15_Pos         (15)
#define GPIO_INTSRC_INTSRC15_Msk         (0x1ul << GPIO_INTSRC_INTSRC15_Pos)

#define GPIO_SMTEN_SMTEN0_Pos            (0)
#define GPIO_SMTEN_SMTEN0_Msk            (0x1ul << GPIO_SMTEN_SMTEN0_Pos)

#define GPIO_SMTEN_SMTEN1_Pos            (1)
#define GPIO_SMTEN_SMTEN1_Msk            (0x1ul << GPIO_SMTEN_SMTEN1_Pos)

#define GPIO_SMTEN_SMTEN2_Pos            (2)
#define GPIO_SMTEN_SMTEN2_Msk            (0x1ul << GPIO_SMTEN_SMTEN2_Pos)

#define GPIO_SMTEN_SMTEN3_Pos            (3)
#define GPIO_SMTEN_SMTEN3_Msk            (0x1ul << GPIO_SMTEN_SMTEN3_Pos)

#define GPIO_SMTEN_SMTEN4_Pos            (4)
#define GPIO_SMTEN_SMTEN4_Msk            (0x1ul << GPIO_SMTEN_SMTEN4_Pos)

#define GPIO_SMTEN_SMTEN5_Pos            (5)
#define GPIO_SMTEN_SMTEN5_Msk            (0x1ul << GPIO_SMTEN_SMTEN5_Pos)

#define GPIO_SMTEN_SMTEN6_Pos            (6)
#define GPIO_SMTEN_SMTEN6_Msk            (0x1ul << GPIO_SMTEN_SMTEN6_Pos)

#define GPIO_SMTEN_SMTEN7_Pos            (7)
#define GPIO_SMTEN_SMTEN7_Msk            (0x1ul << GPIO_SMTEN_SMTEN7_Pos)

#define GPIO_SMTEN_SMTEN8_Pos            (8)
#define GPIO_SMTEN_SMTEN8_Msk            (0x1ul << GPIO_SMTEN_SMTEN8_Pos)

#define GPIO_SMTEN_SMTEN9_Pos            (9)
#define GPIO_SMTEN_SMTEN9_Msk            (0x1ul << GPIO_SMTEN_SMTEN9_Pos)

#define GPIO_SMTEN_SMTEN10_Pos           (10)
#define GPIO_SMTEN_SMTEN10_Msk           (0x1ul << GPIO_SMTEN_SMTEN10_Pos)

#define GPIO_SMTEN_SMTEN11_Pos           (11)
#define GPIO_SMTEN_SMTEN11_Msk           (0x1ul << GPIO_SMTEN_SMTEN11_Pos)

#define GPIO_SMTEN_SMTEN12_Pos           (12)
#define GPIO_SMTEN_SMTEN12_Msk           (0x1ul << GPIO_SMTEN_SMTEN12_Pos)

#define GPIO_SMTEN_SMTEN13_Pos           (13)
#define GPIO_SMTEN_SMTEN13_Msk           (0x1ul << GPIO_SMTEN_SMTEN13_Pos)

#define GPIO_SMTEN_SMTEN14_Pos           (14)
#define GPIO_SMTEN_SMTEN14_Msk           (0x1ul << GPIO_SMTEN_SMTEN14_Pos)

#define GPIO_SMTEN_SMTEN15_Pos           (15)
#define GPIO_SMTEN_SMTEN15_Msk           (0x1ul << GPIO_SMTEN_SMTEN15_Pos)

#define GPIO_SLEWCTL_HSREN0_Pos          (0)
#define GPIO_SLEWCTL_HSREN0_Msk          (0x1ul << GPIO_SLEWCTL_HSREN0_Pos)

#define GPIO_SLEWCTL_HSREN1_Pos          (1)
#define GPIO_SLEWCTL_HSREN1_Msk          (0x1ul << GPIO_SLEWCTL_HSREN1_Pos)

#define GPIO_SLEWCTL_HSREN2_Pos          (2)
#define GPIO_SLEWCTL_HSREN2_Msk          (0x1ul << GPIO_SLEWCTL_HSREN2_Pos)

#define GPIO_SLEWCTL_HSREN3_Pos          (3)
#define GPIO_SLEWCTL_HSREN3_Msk          (0x1ul << GPIO_SLEWCTL_HSREN3_Pos)

#define GPIO_SLEWCTL_HSREN4_Pos          (4)
#define GPIO_SLEWCTL_HSREN4_Msk          (0x1ul << GPIO_SLEWCTL_HSREN4_Pos)

#define GPIO_SLEWCTL_HSREN5_Pos          (5)
#define GPIO_SLEWCTL_HSREN5_Msk          (0x1ul << GPIO_SLEWCTL_HSREN5_Pos)

#define GPIO_SLEWCTL_HSREN6_Pos          (6)
#define GPIO_SLEWCTL_HSREN6_Msk          (0x1ul << GPIO_SLEWCTL_HSREN6_Pos)

#define GPIO_SLEWCTL_HSREN7_Pos          (7)
#define GPIO_SLEWCTL_HSREN7_Msk          (0x1ul << GPIO_SLEWCTL_HSREN7_Pos)

#define GPIO_SLEWCTL_HSREN8_Pos          (8)
#define GPIO_SLEWCTL_HSREN8_Msk          (0x1ul << GPIO_SLEWCTL_HSREN8_Pos)

#define GPIO_SLEWCTL_HSREN9_Pos          (9)
#define GPIO_SLEWCTL_HSREN9_Msk          (0x1ul << GPIO_SLEWCTL_HSREN9_Pos)

#define GPIO_SLEWCTL_HSREN10_Pos         (10)
#define GPIO_SLEWCTL_HSREN10_Msk         (0x1ul << GPIO_SLEWCTL_HSREN10_Pos)

#define GPIO_SLEWCTL_HSREN11_Pos         (11)
#define GPIO_SLEWCTL_HSREN11_Msk         (0x1ul << GPIO_SLEWCTL_HSREN11_Pos)

#define GPIO_SLEWCTL_HSREN12_Pos         (12)
#define GPIO_SLEWCTL_HSREN12_Msk         (0x1ul << GPIO_SLEWCTL_HSREN12_Pos)

#define GPIO_SLEWCTL_HSREN13_Pos         (13)
#define GPIO_SLEWCTL_HSREN13_Msk         (0x1ul << GPIO_SLEWCTL_HSREN13_Pos)

#define GPIO_SLEWCTL_HSREN14_Pos         (14)
#define GPIO_SLEWCTL_HSREN14_Msk         (0x1ul << GPIO_SLEWCTL_HSREN14_Pos)

#define GPIO_SLEWCTL_HSREN15_Pos         (15)
#define GPIO_SLEWCTL_HSREN15_Msk         (0x1ul << GPIO_SLEWCTL_HSREN15_Pos)

#define GPIO_DBCTL_DBCLKSEL_Pos          (0)                                         
#define GPIO_DBCTL_DBCLKSEL_Msk          (0xFul << GPIO_DBCTL_DBCLKSEL_Pos)       

#define GPIO_DBCTL_DBCLKSRC_Pos          (4)                                          
#define GPIO_DBCTL_DBCLKSRC_Msk          (1ul << GPIO_DBCTL_DBCLKSRC_Pos)        

#define GPIO_DBCTL_ICLKON_Pos            (5)                                           
#define GPIO_DBCTL_ICLKON_Msk            (1ul << GPIO_DBCTL_ICLKON_Pos)         


/**@}*/ /* GPIO_CONST */
/**@}*/ /* end of GPIO register group */


/*---------------------- Inter-IC Bus Controller -------------------------*/
/**
    @addtogroup I2C Inter-IC Bus Controller(I2C)
    Memory Mapped Structure for I2C Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] I2C Control Register                                             */
    __IO uint32_t ADDR0;                 /*!< [0x0004] I2C Slave Address Register0                                      */
    __IO uint32_t DAT;                   /*!< [0x0008] I2C Data Register                                                */
    __I  uint32_t STATUS;                /*!< [0x000c] I2C Status Register                                              */
    __IO uint32_t CLKDIV;                /*!< [0x0010] I2C Clock Divided Register                                       */
    __IO uint32_t TOCTL;                 /*!< [0x0014] I2C Time-out Control Register                                    */
    __IO uint32_t ADDR1;                 /*!< [0x0018] I2C Slave Address Register1                                      */
    __IO uint32_t ADDR2;                 /*!< [0x001c] I2C Slave Address Register2                                      */
    __IO uint32_t ADDR3;                 /*!< [0x0020] I2C Slave Address Register3                                      */
    __IO uint32_t ADDRMSK0;              /*!< [0x0024] I2C Slave Address Mask Register0                                 */
    __IO uint32_t ADDRMSK1;              /*!< [0x0028] I2C Slave Address Mask Register1                                 */
    __IO uint32_t ADDRMSK2;              /*!< [0x002c] I2C Slave Address Mask Register2                                 */
    __IO uint32_t ADDRMSK3;              /*!< [0x0030] I2C Slave Address Mask Register3                                 */
         uint32_t RESERVE0[2];

    __IO uint32_t WKCTL;                 /*!< [0x003c] I2C Wake-up Control Register                                     */
    __IO uint32_t WKSTS;                 /*!< [0x0040] I2C Wake-up Status Register                                      */
    __IO uint32_t BUSCTL;                /*!< [0x0044] I2C Bus Management Control Register                              */
    __IO uint32_t BUSTCTL;               /*!< [0x0048] I2C Bus Management Timer Control Register                        */
    __IO uint32_t BUSSTS;                /*!< [0x004c] I2C Bus Management Status Register                               */
    __IO uint32_t PKTSIZE;               /*!< [0x0050] I2C Packet Error Checking Byte Number Register                   */
    __I  uint32_t PKTCRC;                /*!< [0x0054] I2C Packet Error Checking Byte Value Register                    */
    __IO uint32_t BUSTOUT;               /*!< [0x0058] I2C Bus Management Timer Register                                */
    __IO uint32_t CLKTOUT;               /*!< [0x005c] I2C Bus Management Clock Low Timer Register                      */

} I2C_T;

/**
    @addtogroup I2C_CONST I2C Bit Field Definition
    Constant Definitions for I2C Controller
@{ */

#define I2C_CTL_AA_Pos                   (2)
#define I2C_CTL_AA_Msk                   (0x1ul << I2C_CTL_AA_Pos)

#define I2C_CTL_SI_Pos                   (3)
#define I2C_CTL_SI_Msk                   (0x1ul << I2C_CTL_SI_Pos)

#define I2C_CTL_STO_Pos                  (4)
#define I2C_CTL_STO_Msk                  (0x1ul << I2C_CTL_STO_Pos)

#define I2C_CTL_STA_Pos                  (5)
#define I2C_CTL_STA_Msk                  (0x1ul << I2C_CTL_STA_Pos)

#define I2C_CTL_I2CEN_Pos                (6)
#define I2C_CTL_I2CEN_Msk                (0x1ul << I2C_CTL_I2CEN_Pos)

#define I2C_CTL_INTEN_Pos                (7)
#define I2C_CTL_INTEN_Msk                (0x1ul << I2C_CTL_INTEN_Pos)

#define I2C_ADDR0_GC_Pos                 (0)
#define I2C_ADDR0_GC_Msk                 (0x1ul << I2C_ADDR0_GC_Pos)

#define I2C_ADDR0_ADDR_Pos               (1)
#define I2C_ADDR0_ADDR_Msk               (0x7ful << I2C_ADDR0_ADDR_Pos)

#define I2C_DAT_DAT_Pos                  (0)
#define I2C_DAT_DAT_Msk                  (0xfful << I2C_DAT_DAT_Pos)

#define I2C_STATUS_STATUS_Pos            (0)
#define I2C_STATUS_STATUS_Msk            (0xfful << I2C_STATUS_STATUS_Pos)

#define I2C_CLKDIV_DIVIDER_Pos           (0)
#define I2C_CLKDIV_DIVIDER_Msk           (0xfful << I2C_CLKDIV_DIVIDER_Pos)

#define I2C_TOCTL_TOIF_Pos               (0)
#define I2C_TOCTL_TOIF_Msk               (0x1ul << I2C_TOCTL_TOIF_Pos)

#define I2C_TOCTL_TOCDIV4_Pos            (1)
#define I2C_TOCTL_TOCDIV4_Msk            (0x1ul << I2C_TOCTL_TOCDIV4_Pos)

#define I2C_TOCTL_TOCEN_Pos              (2)
#define I2C_TOCTL_TOCEN_Msk              (0x1ul << I2C_TOCTL_TOCEN_Pos)

#define I2C_ADDR1_GC_Pos                 (0)
#define I2C_ADDR1_GC_Msk                 (0x1ul << I2C_ADDR1_GC_Pos)

#define I2C_ADDR1_ADDR_Pos               (1)
#define I2C_ADDR1_ADDR_Msk               (0x7ful << I2C_ADDR1_ADDR_Pos)

#define I2C_ADDR2_GC_Pos                 (0)
#define I2C_ADDR2_GC_Msk                 (0x1ul << I2C_ADDR2_GC_Pos)

#define I2C_ADDR2_ADDR_Pos               (1)
#define I2C_ADDR2_ADDR_Msk               (0x7ful << I2C_ADDR2_ADDR_Pos)

#define I2C_ADDR3_GC_Pos                 (0)
#define I2C_ADDR3_GC_Msk                 (0x1ul << I2C_ADDR3_GC_Pos)

#define I2C_ADDR3_ADDR_Pos               (1)
#define I2C_ADDR3_ADDR_Msk               (0x7ful << I2C_ADDR3_ADDR_Pos)

#define I2C_ADDRMSK0_ADDRMSK_Pos         (1)
#define I2C_ADDRMSK0_ADDRMSK_Msk         (0x7ful << I2C_ADDRMSK0_ADDRMSK_Pos)

#define I2C_ADDRMSK1_ADDRMSK_Pos         (1)
#define I2C_ADDRMSK1_ADDRMSK_Msk         (0x7ful << I2C_ADDRMSK1_ADDRMSK_Pos)

#define I2C_ADDRMSK2_ADDRMSK_Pos         (1)
#define I2C_ADDRMSK2_ADDRMSK_Msk         (0x7ful << I2C_ADDRMSK2_ADDRMSK_Pos)

#define I2C_ADDRMSK3_ADDRMSK_Pos         (1)
#define I2C_ADDRMSK3_ADDRMSK_Msk         (0x7ful << I2C_ADDRMSK3_ADDRMSK_Pos)

#define I2C_WKCTL_WKEN_Pos               (0)
#define I2C_WKCTL_WKEN_Msk               (0x1ul << I2C_WKCTL_WKEN_Pos)

#define I2C_WKSTS_WKIF_Pos               (0)
#define I2C_WKSTS_WKIF_Msk               (0x1ul << I2C_WKSTS_WKIF_Pos)

#define I2C_BUSCTL_ACKMEN_Pos            (0)
#define I2C_BUSCTL_ACKMEN_Msk            (0x1ul << I2C_BUSCTL_ACKMEN_Pos)

#define I2C_BUSCTL_PECEN_Pos             (1)
#define I2C_BUSCTL_PECEN_Msk             (0x1ul << I2C_BUSCTL_PECEN_Pos)

#define I2C_BUSCTL_BMDEN_Pos             (2)
#define I2C_BUSCTL_BMDEN_Msk             (0x1ul << I2C_BUSCTL_BMDEN_Pos)

#define I2C_BUSCTL_BMHEN_Pos             (3)
#define I2C_BUSCTL_BMHEN_Msk             (0x1ul << I2C_BUSCTL_BMHEN_Pos)

#define I2C_BUSCTL_ALERTEN_Pos           (4)
#define I2C_BUSCTL_ALERTEN_Msk           (0x1ul << I2C_BUSCTL_ALERTEN_Pos)

#define I2C_BUSCTL_SCTLOSTS_Pos          (5)
#define I2C_BUSCTL_SCTLOSTS_Msk          (0x1ul << I2C_BUSCTL_SCTLOSTS_Pos)

#define I2C_BUSCTL_SCTLOEN_Pos           (6)
#define I2C_BUSCTL_SCTLOEN_Msk           (0x1ul << I2C_BUSCTL_SCTLOEN_Pos)

#define I2C_BUSCTL_BUSEN_Pos             (7)
#define I2C_BUSCTL_BUSEN_Msk             (0x1ul << I2C_BUSCTL_BUSEN_Pos)

#define I2C_BUSCTL_PECTXEN_Pos           (8)
#define I2C_BUSCTL_PECTXEN_Msk           (0x1ul << I2C_BUSCTL_PECTXEN_Pos)

#define I2C_BUSCTL_TIDLE_Pos             (9)
#define I2C_BUSCTL_TIDLE_Msk             (0x1ul << I2C_BUSCTL_TIDLE_Pos)

#define I2C_BUSCTL_PECCLR_Pos            (10)
#define I2C_BUSCTL_PECCLR_Msk            (0x1ul << I2C_BUSCTL_PECCLR_Pos)

#define I2C_BUSCTL_ACKM9SI_Pos           (11)
#define I2C_BUSCTL_ACKM9SI_Msk           (0x1ul << I2C_BUSCTL_ACKM9SI_Pos)

#define I2C_BUSTCTL_BUSTOEN_Pos          (0)
#define I2C_BUSTCTL_BUSTOEN_Msk          (0x1ul << I2C_BUSTCTL_BUSTOEN_Pos)

#define I2C_BUSTCTL_CLKTOEN_Pos          (1)
#define I2C_BUSTCTL_CLKTOEN_Msk          (0x1ul << I2C_BUSTCTL_CLKTOEN_Pos)

#define I2C_BUSTCTL_BUSTOIEN_Pos         (2)
#define I2C_BUSTCTL_BUSTOIEN_Msk         (0x1ul << I2C_BUSTCTL_BUSTOIEN_Pos)

#define I2C_BUSTCTL_CLKTOIEN_Pos         (3)
#define I2C_BUSTCTL_CLKTOIEN_Msk         (0x1ul << I2C_BUSTCTL_CLKTOIEN_Pos)

#define I2C_BUSTCTL_TORSTEN_Pos          (4)
#define I2C_BUSTCTL_TORSTEN_Msk          (0x1ul << I2C_BUSTCTL_TORSTEN_Pos)

#define I2C_BUSTCTL_PECIEN_Pos           (5)
#define I2C_BUSTCTL_PECIEN_Msk           (0x1ul << I2C_BUSTCTL_PECIEN_Pos)

#define I2C_BUSSTS_BUSY_Pos              (0)
#define I2C_BUSSTS_BUSY_Msk              (0x1ul << I2C_BUSSTS_BUSY_Pos)

#define I2C_BUSSTS_BCDONE_Pos            (1)
#define I2C_BUSSTS_BCDONE_Msk            (0x1ul << I2C_BUSSTS_BCDONE_Pos)

#define I2C_BUSSTS_PECERR_Pos            (2)
#define I2C_BUSSTS_PECERR_Msk            (0x1ul << I2C_BUSSTS_PECERR_Pos)

#define I2C_BUSSTS_ALERT_Pos             (3)
#define I2C_BUSSTS_ALERT_Msk             (0x1ul << I2C_BUSSTS_ALERT_Pos)

#define I2C_BUSSTS_SCTLDIN_Pos           (4)
#define I2C_BUSSTS_SCTLDIN_Msk           (0x1ul << I2C_BUSSTS_SCTLDIN_Pos)

#define I2C_BUSSTS_BUSTO_Pos             (5)
#define I2C_BUSSTS_BUSTO_Msk             (0x1ul << I2C_BUSSTS_BUSTO_Pos)

#define I2C_BUSSTS_CLKTO_Pos             (6)
#define I2C_BUSSTS_CLKTO_Msk             (0x1ul << I2C_BUSSTS_CLKTO_Pos)

#define I2C_PKTSIZE_PLDSIZE_Pos          (0)
#define I2C_PKTSIZE_PLDSIZE_Msk          (0xfful << I2C_PKTSIZE_PLDSIZE_Pos)

#define I2C_PKTCRC_PECCRC_Pos            (0)
#define I2C_PKTCRC_PECCRC_Msk            (0xfful << I2C_PKTCRC_PECCRC_Pos)

#define I2C_BUSTOUT_BUSTO_Pos            (0)
#define I2C_BUSTOUT_BUSTO_Msk            (0xfful << I2C_BUSTOUT_BUSTO_Pos)

#define I2C_CLKTOUT_CLKTO_Pos            (0)
#define I2C_CLKTOUT_CLKTO_Msk            (0xfful << I2C_CLKTOUT_CLKTO_Pos)

/**@}*/ /* I2C_CONST */
/**@}*/ /* end of I2C register group */


/*---------------------- USB On-The-Go Controller -------------------------*/
/**
    @addtogroup OTG USB On-The-Go Controller(OTG)
    Memory Mapped Structure for OTG Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] OTG Control Register                                             */
    __IO uint32_t PHYCTL;                /*!< [0x0004] OTG PHY Control Register                                         */
    __IO uint32_t INTEN;                 /*!< [0x0008] OTG Interrupt Enable Register                                    */
    __IO uint32_t INTSTS;                /*!< [0x000c] OTG Interrupt Status Register                                    */
    __I  uint32_t STATUS;                /*!< [0x0010] OTG Functional Status Register                                   */

} OTG_T;

/**
    @addtogroup OTG_CONST OTG Bit Field Definition
    Constant Definitions for OTG Controller
@{ */

#define OTG_CTL_VBUSDROP_Pos             (0)
#define OTG_CTL_VBUSDROP_Msk             (0x1ul << OTG_CTL_VBUSDROP_Pos)

#define OTG_CTL_BUSREQ_Pos               (1)
#define OTG_CTL_BUSREQ_Msk               (0x1ul << OTG_CTL_BUSREQ_Pos)

#define OTG_CTL_HNPREQEN_Pos             (2)
#define OTG_CTL_HNPREQEN_Msk             (0x1ul << OTG_CTL_HNPREQEN_Pos)

#define OTG_CTL_OTGEN_Pos                (4)
#define OTG_CTL_OTGEN_Msk                (0x1ul << OTG_CTL_OTGEN_Pos)

#define OTG_CTL_WKEN_Pos                 (5)
#define OTG_CTL_WKEN_Msk                 (0x1ul << OTG_CTL_WKEN_Pos)

#define OTG_PHYCTL_OTGPHYEN_Pos          (0)
#define OTG_PHYCTL_OTGPHYEN_Msk          (0x1ul << OTG_PHYCTL_OTGPHYEN_Pos)

#define OTG_PHYCTL_IDDETEN_Pos           (1)
#define OTG_PHYCTL_IDDETEN_Msk           (0x1ul << OTG_PHYCTL_IDDETEN_Pos)

#define OTG_PHYCTL_VBUSENPOL_Pos         (4)
#define OTG_PHYCTL_VBUSENPOL_Msk         (0x1ul << OTG_PHYCTL_VBUSENPOL_Pos)

#define OTG_PHYCTL_VBUSSTPOL_Pos         (5)
#define OTG_PHYCTL_VBUSSTPOL_Msk         (0x1ul << OTG_PHYCTL_VBUSSTPOL_Pos)

#define OTG_INTEN_ROLECHGIEN_Pos         (0)
#define OTG_INTEN_ROLECHGIEN_Msk         (0x1ul << OTG_INTEN_ROLECHGIEN_Pos)

#define OTG_INTEN_VBUSERRIEN_Pos         (1)
#define OTG_INTEN_VBUSERRIEN_Msk         (0x1ul << OTG_INTEN_VBUSERRIEN_Pos)

#define OTG_INTEN_SRPFIEN_Pos            (2)
#define OTG_INTEN_SRPFIEN_Msk            (0x1ul << OTG_INTEN_SRPFIEN_Pos)

#define OTG_INTEN_HNPFIEN_Pos            (3)
#define OTG_INTEN_HNPFIEN_Msk            (0x1ul << OTG_INTEN_HNPFIEN_Pos)

#define OTG_INTEN_GOIDLEIEN_Pos          (4)
#define OTG_INTEN_GOIDLEIEN_Msk          (0x1ul << OTG_INTEN_GOIDLEIEN_Pos)

#define OTG_INTEN_IDCHGIEN_Pos           (5)
#define OTG_INTEN_IDCHGIEN_Msk           (0x1ul << OTG_INTEN_IDCHGIEN_Pos)

#define OTG_INTEN_PDEVIEN_Pos            (6)
#define OTG_INTEN_PDEVIEN_Msk            (0x1ul << OTG_INTEN_PDEVIEN_Pos)

#define OTG_INTEN_HOSTIEN_Pos            (7)
#define OTG_INTEN_HOSTIEN_Msk            (0x1ul << OTG_INTEN_HOSTIEN_Pos)

#define OTG_INTEN_BVLDCHGIEN_Pos         (8)
#define OTG_INTEN_BVLDCHGIEN_Msk         (0x1ul << OTG_INTEN_BVLDCHGIEN_Pos)

#define OTG_INTEN_AVLDCHGIEN_Pos         (9)
#define OTG_INTEN_AVLDCHGIEN_Msk         (0x1ul << OTG_INTEN_AVLDCHGIEN_Pos)

#define OTG_INTEN_VBUSCHGIEN_Pos         (10)
#define OTG_INTEN_VBUSCHGIEN_Msk         (0x1ul << OTG_INTEN_VBUSCHGIEN_Pos)

#define OTG_INTEN_SENDCHGIEN_Pos         (11)
#define OTG_INTEN_SENDCHGIEN_Msk         (0x1ul << OTG_INTEN_SENDCHGIEN_Pos)

#define OTG_INTEN_SRPDETIEN_Pos          (13)
#define OTG_INTEN_SRPDETIEN_Msk          (0x1ul << OTG_INTEN_SRPDIEN_Pos)

#define OTG_INTSTS_ROLECHGIF_Pos         (0)
#define OTG_INTSTS_ROLECHGIF_Msk         (0x1ul << OTG_INTSTS_ROLECHGIF_Pos)

#define OTG_INTSTS_VBUSERRIF_Pos         (1)
#define OTG_INTSTS_VBUSERRIF_Msk         (0x1ul << OTG_INTSTS_VBUSERRIF_Pos)

#define OTG_INTSTS_SRPFIF_Pos            (2)
#define OTG_INTSTS_SRPFIF_Msk            (0x1ul << OTG_INTSTS_SRPFIF_Pos)

#define OTG_INTSTS_HNPFIF_Pos            (3)
#define OTG_INTSTS_HNPFIF_Msk            (0x1ul << OTG_INTSTS_HNPFIF_Pos)

#define OTG_INTSTS_GOIDLEIF_Pos          (4)
#define OTG_INTSTS_GOIDLEIF_Msk          (0x1ul << OTG_INTSTS_GOIDLEIF_Pos)

#define OTG_INTSTS_IDCHGIF_Pos           (5)
#define OTG_INTSTS_IDCHGIF_Msk           (0x1ul << OTG_INTSTS_IDCHGIF_Pos)

#define OTG_INTSTS_PDEVIF_Pos            (6)
#define OTG_INTSTS_PDEVIF_Msk            (0x1ul << OTG_INTSTS_PDEVIF_Pos)

#define OTG_INTSTS_HOSTIF_Pos            (7)
#define OTG_INTSTS_HOSTIF_Msk            (0x1ul << OTG_INTSTS_HOSTIF_Pos)

#define OTG_INTSTS_BVLDCHGIF_Pos         (8)
#define OTG_INTSTS_BVLDCHGIF_Msk         (0x1ul << OTG_INTSTS_BVLDCHGIF_Pos)

#define OTG_INTSTS_AVLDCHGIF_Pos         (9)
#define OTG_INTSTS_AVLDCHGIF_Msk         (0x1ul << OTG_INTSTS_AVLDCHGIF_Pos)

#define OTG_INTSTS_VBUSCHGIF_Pos         (10)
#define OTG_INTSTS_VBUSCHGIF_Msk         (0x1ul << OTG_INTSTS_VBUSCHGIF_Pos)

#define OTG_INTSTS_SENDCHGIF_Pos         (11)
#define OTG_INTSTS_SENDCHGIF_Msk         (0x1ul << OTG_INTSTS_SENDCHGIF_Pos)

#define OTG_INTSTS_SRPDETIF_Pos          (13)
#define OTG_INTSTS_SRPDETIF_Msk          (0x1ul << OTG_INTSTS_SRPDETIF_Pos)

#define OTG_STATUS_OVERCUR_Pos           (0)
#define OTG_STATUS_OVERCUR_Msk           (0x1ul << OTG_STATUS_OVERCUR_Pos)

#define OTG_STATUS_IDSTS_Pos             (1)
#define OTG_STATUS_IDSTS_Msk             (0x1ul << OTG_STATUS_IDSTS_Pos)

#define OTG_STATUS_SESSEND_Pos           (2)
#define OTG_STATUS_SESSEND_Msk           (0x1ul << OTG_STATUS_SESSEND_Pos)

#define OTG_STATUS_BVLD_Pos              (3)
#define OTG_STATUS_BVLD_Msk              (0x1ul << OTG_STATUS_BVLD_Pos)

#define OTG_STATUS_AVLD_Pos              (4)
#define OTG_STATUS_AVLD_Msk              (0x1ul << OTG_STATUS_AVLD_Pos)

#define OTG_STATUS_VBUSVLD_Pos           (5)
#define OTG_STATUS_VBUSVLD_Msk           (0x1ul << OTG_STATUS_VBUSVLD_Pos)

/**@}*/ /* OTG_CONST */
/**@}*/ /* end of OTG register group */


/*---------------------- Peripheral Direct Memory Access Controller -------------------------*/
/**
    @addtogroup PDMA Peripheral Direct Memory Access Controller(PDMA)
    Memory Mapped Structure for PDMA Controller
@{ */
 
 typedef struct {
    __IO uint32_t CTL;                   /*!< Offset: 0x0000 Descriptor Table Control Register of DMA Channel */
    __IO uint32_t SA;                    /*!< Offset: 0x0004 Source Address Register of DMA Channel */
    __IO uint32_t DA;                    /*!< Offset: 0x0008 Destination Address Register of DMA Channel */
    __IO uint32_t NEXT;                  /*!< Offset: 0x000C First Scatter-Gather Descriptor Table Offset Address of DMA Channel */
} DSCT_T;
 
typedef struct
{
    DSCT_T DSCT[12];                    /*!< Offset: 0x0000 ~ 0x00BC   DMA Embedded Description Table */
    uint32_t RESERVE0[16];

    __I  uint32_t CURSCAT0;              /*!< [0x0100] Current Scatter-Gather Description Table Address of PDMA Channel 0 */
    __I  uint32_t CURSCAT1;              /*!< [0x0104] Current Scatter-Gather Description Table Address of PDMA Channel 1 */
    __I  uint32_t CURSCAT2;              /*!< [0x0108] Current Scatter-Gather Description Table Address of PDMA Channel 2 */
    __I  uint32_t CURSCAT3;              /*!< [0x010c] Current Scatter-Gather Description Table Address of PDMA Channel 3 */
    __I  uint32_t CURSCAT4;              /*!< [0x0110] Current Scatter-Gather Description Table Address of PDMA Channel 4 */
    __I  uint32_t CURSCAT5;              /*!< [0x0114] Current Scatter-Gather Description Table Address of PDMA Channel 5 */
    __I  uint32_t CURSCAT6;              /*!< [0x0118] Current Scatter-Gather Description Table Address of PDMA Channel 6 */
    __I  uint32_t CURSCAT7;              /*!< [0x011c] Current Scatter-Gather Description Table Address of PDMA Channel 7 */
    __I  uint32_t CURSCAT8;              /*!< [0x0120] Current Scatter-Gather Description Table Address of PDMA Channel 8 */
    __I  uint32_t CURSCAT9;              /*!< [0x0124] Current Scatter-Gather Description Table Address of PDMA Channel 9 */
    __I  uint32_t CURSCAT10;             /*!< [0x0128] Current Scatter-Gather Description Table Address of PDMA Channel 10 */
    __I  uint32_t CURSCAT11;             /*!< [0x012c] Current Scatter-Gather Description Table Address of PDMA Channel 11 */
         uint32_t RESERVE1[180];

    __IO uint32_t CHCTL;                 /*!< [0x0400] PDMA Channel Control Register                                    */
    __O  uint32_t STOP;                  /*!< [0x0404] PDMA Transfer Stop Control Register                              */
    __O  uint32_t SWREQ;                 /*!< [0x0408] PDMA Software Request Register                                   */
    __I  uint32_t TRGSTS;                /*!< [0x040c] PDMA Channel Request Status Register                             */
    __IO uint32_t PRISET;                /*!< [0x0410] PDMA Fixed Priority Setting Register                             */
    __O  uint32_t PRICLR;                /*!< [0x0414] PDMA Fixed Priority Clear Register                               */
    __IO uint32_t INTEN;                 /*!< [0x0418] PDMA Interrupt Enable Register                                   */
    __IO uint32_t INTSTS;                /*!< [0x041c] PDMA Interrupt Status Register                                   */
    __IO uint32_t ABTSTS;                /*!< [0x0420] PDMA Channel Read/Write Target Abort Flag Register               */
    __IO uint32_t TDSTS;                 /*!< [0x0424] PDMA Channel Transfer Done Flag Register                         */
    __IO uint32_t SCATSTS;               /*!< [0x0428] PDMA Scatter-Gather Table Empty Status Register                  */
    __I  uint32_t TACTSTS;               /*!< [0x042c] PDMA Transfer Active Flag Register                               */
         uint32_t RESERVE2[3];

    __IO uint32_t SCATBA;                /*!< [0x043c] PDMA Scatter-Gather Description Table Base Address Register      */
    __IO uint32_t TOC0_1;                /*!< [0x0440] PDMA Timeout Counter Ch1 and Ch0 Register                        */
    __IO uint32_t TOC2_3;                /*!< [0x0444] PDMA Timeout Counter Ch3 and Ch2 Register                        */
    __IO uint32_t TOC4_5;                /*!< [0x0448] PDMA Timeout Counter Ch5 and Ch4 Register                        */
    __IO uint32_t TOC6_7;                /*!< [0x044c] PDMA Timeout Counter Ch7 and Ch6 Register                        */
    __IO uint32_t TOC8_9;                /*!< [0x0450] PDMA Timeout Counter Ch9 and Ch8 Register                        */
    __IO uint32_t TOC10_11;              /*!< [0x0454] PDMA Timeout Counter Ch11 and Ch10 Register                      */
         uint32_t RESERVE3[10];

    __IO uint32_t REQSEL0_3;             /*!< [0x0480] PDMA Request Source Select Register 0                            */
    __IO uint32_t REQSEL4_7;             /*!< [0x0484] PDMA Request Source Select Register 1                            */
    __IO uint32_t REQSEL8_11;            /*!< [0x0488] PDMA Request Source Select Register 2                            */
         uint32_t RESERVE4[733];
} PDMA_T;

/**
    @addtogroup PDMA_CONST PDMA Bit Field Definition
    Constant Definitions for PDMA Controller
@{ */

/* PDMA DSCT CTL Bit Field Definitions */
#define PDMA_DSCT_CTL_OPMODE_Pos         (0)                                           /*!< PDMA DSCT CTL: OPMODE Position */
#define PDMA_DSCT_CTL_OPMODE_Msk         (0x3ul << PDMA_DSCT_CTL_OPMODE_Pos)           /*!< PDMA DSCT CTL: OPMODE Mask */

#define PDMA_DSCT_CTL_TXTYPE_Pos         (2)                                           /*!< PDMA DSCT CTL: TXTYPE Position */
#define PDMA_DSCT_CTL_TXTYPE_Msk         (1ul << PDMA_DSCT_CTL_TXTYPE_Pos)             /*!< PDMA DSCT CTL: TXTYPE Mask */

#define PDMA_DSCT_CTL_BURSIZE_Pos        (4)                                           /*!< PDMA DSCT CTL: BURSIZE Position */
#define PDMA_DSCT_CTL_BURSIZE_Msk        (0x7ul << PDMA_DSCT_CTL_BURSIZE_Pos)          /*!< PDMA DSCT CTL: BURSIZE Mask */

#define PDMA_DSCT_CTL_TBINTDIS_Pos       (7)                                           /*!< PDMA DSCT CTL: TBINTDIS Position */
#define PDMA_DSCT_CTL_TBINTDIS_Msk       (1ul << PDMA_DSCT_CTL_TBINTDIS_Pos)           /*!< PDMA DSCT CTL: TBINTDIS Mask */

#define PDMA_DSCT_CTL_SAINC_Pos          (8)                                           /*!< PDMA DSCT CTL: SAINC Position */
#define PDMA_DSCT_CTL_SAINC_Msk          (0x3ul << PDMA_DSCT_CTL_SAINC_Pos)            /*!< PDMA DSCT CTL: SAINC Mask */

#define PDMA_DSCT_CTL_DAINC_Pos          (10)                                          /*!< PDMA DSCT CTL: DAINC Position */
#define PDMA_DSCT_CTL_DAINC_Msk          (0x3ul << PDMA_DSCT_CTL_DAINC_Pos)            /*!< PDMA DSCT CTL: DAINC Mask */

#define PDMA_DSCT_CTL_TXWIDTH_Pos        (12)                                          /*!< PDMA DSCT CTL: TXWIDTH Position */
#define PDMA_DSCT_CTL_TXWIDTH_Msk        (0x3ul << PDMA_DSCT_CTL_TXWIDTH_Pos)           /*!< PDMA DSCT CTL: TXWIDTH Mask */

#define PDMA_DSCT_CTL_TXCNT_Pos          (16)                                          /*!< PDMA DSCT CTL: TXCNT Position */
#define PDMA_DSCT_CTL_TXCNT_Msk          (0x3FFFul << PDMA_DSCT_CTL_TXCNT_Pos)         /*!< PDMA DSCT CTL: TXCNT Mask */

/* PDMA DSCT_SA Bit Field Definitions */
#define PDMA_DSCT_SA_SA_Pos              (0)                                           /*!< PDMA DSCT_SA: SA Position */
#define PDMA_DSCT_SA_SA_Msk              (0xFFFFFFFFul << PDMA_DSCT_SA_SA_Pos)         /*!< PDMA DSCT_SA: SA Mask */

/* PDMA DSCT_DA Bit Field Definitions */
#define PDMA_DSCT_DA_DA_Pos              (0)                                           /*!< PDMA DSCT_DA: DA Position */
#define PDMA_DSCT_DA_DA_Msk              (0xFFFFFFFFul << PDMA_DSCT_DA_DA_Pos)         /*!< PDMA DSCT_DA: DA Mask */

/* PDMA DSCT_NEXT Bit Field Definitions */
#define PDMA_DSCT_NEXT_NEXT_Pos          (0)                                           /*!< PDMA DSCT_NEXT: NEXT Position */
#define PDMA_DSCT_NEXT_NEXT_Msk          (0xFFFFul << PDMA_DSCT_NEXT_NEXT_Pos)         /*!< PDMA DSCT_NEXT: NEXT Mask */

#define PDMA_DSCT0_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT0_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT0_CTL_OPMODE_Pos)

#define PDMA_DSCT0_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT0_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT0_CTL_TXTYPE_Pos)

#define PDMA_DSCT0_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT0_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT0_CTL_BURSIZE_Pos)

#define PDMA_DSCT0_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT0_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT0_CTL_TBINTDIS_Pos)

#define PDMA_DSCT0_CTL_SAINC_Pos         (8)
#define PDMA_DSCT0_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT0_CTL_SAINC_Pos)

#define PDMA_DSCT0_CTL_DAINC_Pos         (10)
#define PDMA_DSCT0_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT0_CTL_DAINC_Pos)

#define PDMA_DSCT0_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT0_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT0_CTL_TXWIDTH_Pos)

#define PDMA_DSCT0_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT0_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT0_CTL_TXCNT_Pos)

#define PDMA_DSCT0_SA_SA_Pos             (0)
#define PDMA_DSCT0_SA_SA_Msk             (0xfffffffful << PDMA_DSCT0_SA_SA_Pos)

#define PDMA_DSCT0_DA_DA_Pos             (0)
#define PDMA_DSCT0_DA_DA_Msk             (0xfffffffful << PDMA_DSCT0_DA_DA_Pos)

#define PDMA_DSCT0_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT0_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT0_NEXT_NEXT_Pos)

#define PDMA_DSCT1_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT1_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT1_CTL_OPMODE_Pos)

#define PDMA_DSCT1_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT1_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT1_CTL_TXTYPE_Pos)

#define PDMA_DSCT1_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT1_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT1_CTL_BURSIZE_Pos)

#define PDMA_DSCT1_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT1_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT1_CTL_TBINTDIS_Pos)

#define PDMA_DSCT1_CTL_SAINC_Pos         (8)
#define PDMA_DSCT1_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT1_CTL_SAINC_Pos)

#define PDMA_DSCT1_CTL_DAINC_Pos         (10)
#define PDMA_DSCT1_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT1_CTL_DAINC_Pos)

#define PDMA_DSCT1_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT1_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT1_CTL_TXWIDTH_Pos)

#define PDMA_DSCT1_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT1_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT1_CTL_TXCNT_Pos)

#define PDMA_DSCT1_SA_SA_Pos             (0)
#define PDMA_DSCT1_SA_SA_Msk             (0xfffffffful << PDMA_DSCT1_SA_SA_Pos)

#define PDMA_DSCT1_DA_DA_Pos             (0)
#define PDMA_DSCT1_DA_DA_Msk             (0xfffffffful << PDMA_DSCT1_DA_DA_Pos)

#define PDMA_DSCT1_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT1_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT1_NEXT_NEXT_Pos)

#define PDMA_DSCT2_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT2_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT2_CTL_OPMODE_Pos)

#define PDMA_DSCT2_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT2_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT2_CTL_TXTYPE_Pos)

#define PDMA_DSCT2_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT2_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT2_CTL_BURSIZE_Pos)

#define PDMA_DSCT2_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT2_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT2_CTL_TBINTDIS_Pos)

#define PDMA_DSCT2_CTL_SAINC_Pos         (8)
#define PDMA_DSCT2_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT2_CTL_SAINC_Pos)

#define PDMA_DSCT2_CTL_DAINC_Pos         (10)
#define PDMA_DSCT2_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT2_CTL_DAINC_Pos)

#define PDMA_DSCT2_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT2_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT2_CTL_TXWIDTH_Pos)

#define PDMA_DSCT2_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT2_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT2_CTL_TXCNT_Pos)

#define PDMA_DSCT2_SA_SA_Pos             (0)
#define PDMA_DSCT2_SA_SA_Msk             (0xfffffffful << PDMA_DSCT2_SA_SA_Pos)

#define PDMA_DSCT2_DA_DA_Pos             (0)
#define PDMA_DSCT2_DA_DA_Msk             (0xfffffffful << PDMA_DSCT2_DA_DA_Pos)

#define PDMA_DSCT2_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT2_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT2_NEXT_NEXT_Pos)

#define PDMA_DSCT3_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT3_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT3_CTL_OPMODE_Pos)

#define PDMA_DSCT3_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT3_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT3_CTL_TXTYPE_Pos)

#define PDMA_DSCT3_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT3_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT3_CTL_BURSIZE_Pos)

#define PDMA_DSCT3_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT3_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT3_CTL_TBINTDIS_Pos)

#define PDMA_DSCT3_CTL_SAINC_Pos         (8)
#define PDMA_DSCT3_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT3_CTL_SAINC_Pos)

#define PDMA_DSCT3_CTL_DAINC_Pos         (10)
#define PDMA_DSCT3_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT3_CTL_DAINC_Pos)

#define PDMA_DSCT3_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT3_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT3_CTL_TXWIDTH_Pos)

#define PDMA_DSCT3_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT3_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT3_CTL_TXCNT_Pos)

#define PDMA_DSCT3_SA_SA_Pos             (0)
#define PDMA_DSCT3_SA_SA_Msk             (0xfffffffful << PDMA_DSCT3_SA_SA_Pos)

#define PDMA_DSCT3_DA_DA_Pos             (0)
#define PDMA_DSCT3_DA_DA_Msk             (0xfffffffful << PDMA_DSCT3_DA_DA_Pos)

#define PDMA_DSCT3_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT3_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT3_NEXT_NEXT_Pos)

#define PDMA_DSCT4_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT4_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT4_CTL_OPMODE_Pos)

#define PDMA_DSCT4_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT4_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT4_CTL_TXTYPE_Pos)

#define PDMA_DSCT4_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT4_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT4_CTL_BURSIZE_Pos)

#define PDMA_DSCT4_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT4_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT4_CTL_TBINTDIS_Pos)

#define PDMA_DSCT4_CTL_SAINC_Pos         (8)
#define PDMA_DSCT4_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT4_CTL_SAINC_Pos)

#define PDMA_DSCT4_CTL_DAINC_Pos         (10)
#define PDMA_DSCT4_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT4_CTL_DAINC_Pos)

#define PDMA_DSCT4_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT4_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT4_CTL_TXWIDTH_Pos)

#define PDMA_DSCT4_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT4_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT4_CTL_TXCNT_Pos)

#define PDMA_DSCT4_SA_SA_Pos             (0)
#define PDMA_DSCT4_SA_SA_Msk             (0xfffffffful << PDMA_DSCT4_SA_SA_Pos)

#define PDMA_DSCT4_DA_DA_Pos             (0)
#define PDMA_DSCT4_DA_DA_Msk             (0xfffffffful << PDMA_DSCT4_DA_DA_Pos)

#define PDMA_DSCT4_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT4_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT4_NEXT_NEXT_Pos)

#define PDMA_DSCT5_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT5_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT5_CTL_OPMODE_Pos)

#define PDMA_DSCT5_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT5_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT5_CTL_TXTYPE_Pos)

#define PDMA_DSCT5_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT5_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT5_CTL_BURSIZE_Pos)

#define PDMA_DSCT5_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT5_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT5_CTL_TBINTDIS_Pos)

#define PDMA_DSCT5_CTL_SAINC_Pos         (8)
#define PDMA_DSCT5_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT5_CTL_SAINC_Pos)

#define PDMA_DSCT5_CTL_DAINC_Pos         (10)
#define PDMA_DSCT5_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT5_CTL_DAINC_Pos)

#define PDMA_DSCT5_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT5_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT5_CTL_TXWIDTH_Pos)

#define PDMA_DSCT5_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT5_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT5_CTL_TXCNT_Pos)

#define PDMA_DSCT5_SA_SA_Pos             (0)
#define PDMA_DSCT5_SA_SA_Msk             (0xfffffffful << PDMA_DSCT5_SA_SA_Pos)

#define PDMA_DSCT5_DA_DA_Pos             (0)
#define PDMA_DSCT5_DA_DA_Msk             (0xfffffffful << PDMA_DSCT5_DA_DA_Pos)

#define PDMA_DSCT5_NEXT_NEXT_Pos          (2)
#define PDMA_DSCT5_NEXT_NEXT_Msk          (0x3ffful << PDMA_DSCT_NEXT_NEXT_Pos)

#define PDMA_DSCT6_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT6_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT6_CTL_OPMODE_Pos)

#define PDMA_DSCT6_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT6_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT6_CTL_TXTYPE_Pos)

#define PDMA_DSCT6_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT6_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT6_CTL_BURSIZE_Pos)

#define PDMA_DSCT6_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT6_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT6_CTL_TBINTDIS_Pos)

#define PDMA_DSCT6_CTL_SAINC_Pos         (8)
#define PDMA_DSCT6_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT6_CTL_SAINC_Pos)

#define PDMA_DSCT6_CTL_DAINC_Pos         (10)
#define PDMA_DSCT6_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT6_CTL_DAINC_Pos)

#define PDMA_DSCT6_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT6_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT6_CTL_TXWIDTH_Pos)

#define PDMA_DSCT6_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT6_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT6_CTL_TXCNT_Pos)

#define PDMA_DSCT6_SA_SA_Pos             (0)
#define PDMA_DSCT6_SA_SA_Msk             (0xfffffffful << PDMA_DSCT6_SA_SA_Pos)

#define PDMA_DSCT6_DA_DA_Pos             (0)
#define PDMA_DSCT6_DA_DA_Msk             (0xfffffffful << PDMA_DSCT6_DA_DA_Pos)

#define PDMA_DSCT6_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT6_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT6_NEXT_NEXT_Pos)

#define PDMA_DSCT7_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT7_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT7_CTL_OPMODE_Pos)

#define PDMA_DSCT7_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT7_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT7_CTL_TXTYPE_Pos)

#define PDMA_DSCT7_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT7_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT7_CTL_BURSIZE_Pos)

#define PDMA_DSCT7_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT7_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT7_CTL_TBINTDIS_Pos)

#define PDMA_DSCT7_CTL_SAINC_Pos         (8)
#define PDMA_DSCT7_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT7_CTL_SAINC_Pos)

#define PDMA_DSCT7_CTL_DAINC_Pos         (10)
#define PDMA_DSCT7_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT7_CTL_DAINC_Pos)

#define PDMA_DSCT7_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT7_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT7_CTL_TXWIDTH_Pos)

#define PDMA_DSCT7_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT7_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT7_CTL_TXCNT_Pos)

#define PDMA_DSCT7_SA_SA_Pos             (0)
#define PDMA_DSCT7_SA_SA_Msk             (0xfffffffful << PDMA_DSCT7_SA_SA_Pos)

#define PDMA_DSCT7_DA_DA_Pos             (0)
#define PDMA_DSCT7_DA_DA_Msk             (0xfffffffful << PDMA_DSCT7_DA_DA_Pos)

#define PDMA_DSCT7_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT7_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT7_NEXT_NEXT_Pos)

#define PDMA_DSCT8_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT8_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT8_CTL_OPMODE_Pos)

#define PDMA_DSCT8_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT8_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT8_CTL_TXTYPE_Pos)

#define PDMA_DSCT8_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT8_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT8_CTL_BURSIZE_Pos)

#define PDMA_DSCT8_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT8_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT8_CTL_TBINTDIS_Pos)

#define PDMA_DSCT8_CTL_SAINC_Pos         (8)
#define PDMA_DSCT8_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT8_CTL_SAINC_Pos)

#define PDMA_DSCT8_CTL_DAINC_Pos         (10)
#define PDMA_DSCT8_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT8_CTL_DAINC_Pos)

#define PDMA_DSCT8_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT8_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT8_CTL_TXWIDTH_Pos)

#define PDMA_DSCT8_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT8_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT8_CTL_TXCNT_Pos)

#define PDMA_DSCT8_SA_SA_Pos             (0)
#define PDMA_DSCT8_SA_SA_Msk             (0xfffffffful << PDMA_DSCT8_SA_SA_Pos)

#define PDMA_DSCT8_DA_DA_Pos             (0)
#define PDMA_DSCT8_DA_DA_Msk             (0xfffffffful << PDMA_DSCT8_DA_DA_Pos)

#define PDMA_DSCT8_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT8_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT8_NEXT_NEXT_Pos)

#define PDMA_DSCT9_CTL_OPMODE_Pos        (0)
#define PDMA_DSCT9_CTL_OPMODE_Msk        (0x3ul << PDMA_DSCT9_CTL_OPMODE_Pos)

#define PDMA_DSCT9_CTL_TXTYPE_Pos        (2)
#define PDMA_DSCT9_CTL_TXTYPE_Msk        (0x1ul << PDMA_DSCT9_CTL_TXTYPE_Pos)

#define PDMA_DSCT9_CTL_BURSIZE_Pos       (4)
#define PDMA_DSCT9_CTL_BURSIZE_Msk       (0x7ul << PDMA_DSCT9_CTL_BURSIZE_Pos)

#define PDMA_DSCT9_CTL_TBINTDIS_Pos      (7)
#define PDMA_DSCT9_CTL_TBINTDIS_Msk      (0x1ul << PDMA_DSCT9_CTL_TBINTDIS_Pos)

#define PDMA_DSCT9_CTL_SAINC_Pos         (8)
#define PDMA_DSCT9_CTL_SAINC_Msk         (0x3ul << PDMA_DSCT9_CTL_SAINC_Pos)

#define PDMA_DSCT9_CTL_DAINC_Pos         (10)
#define PDMA_DSCT9_CTL_DAINC_Msk         (0x3ul << PDMA_DSCT9_CTL_DAINC_Pos)

#define PDMA_DSCT9_CTL_TXWIDTH_Pos       (12)
#define PDMA_DSCT9_CTL_TXWIDTH_Msk       (0x3ul << PDMA_DSCT9_CTL_TXWIDTH_Pos)

#define PDMA_DSCT9_CTL_TXCNT_Pos         (16)
#define PDMA_DSCT9_CTL_TXCNT_Msk         (0x3ffful << PDMA_DSCT9_CTL_TXCNT_Pos)

#define PDMA_DSCT9_SA_SA_Pos             (0)
#define PDMA_DSCT9_SA_SA_Msk             (0xfffffffful << PDMA_DSCT9_SA_SA_Pos)

#define PDMA_DSCT9_DA_DA_Pos             (0)
#define PDMA_DSCT9_DA_DA_Msk             (0xfffffffful << PDMA_DSCT9_DA_DA_Pos)

#define PDMA_DSCT9_NEXT_NEXT_Pos         (2)
#define PDMA_DSCT9_NEXT_NEXT_Msk         (0x3ffful << PDMA_DSCT9_NEXT_NEXT_Pos)

#define PDMA_DSCT10_CTL_OPMODE_Pos       (0)
#define PDMA_DSCT10_CTL_OPMODE_Msk       (0x3ul << PDMA_DSCT10_CTL_OPMODE_Pos)

#define PDMA_DSCT10_CTL_TXTYPE_Pos       (2)
#define PDMA_DSCT10_CTL_TXTYPE_Msk       (0x1ul << PDMA_DSCT10_CTL_TXTYPE_Pos)

#define PDMA_DSCT10_CTL_BURSIZE_Pos      (4)
#define PDMA_DSCT10_CTL_BURSIZE_Msk      (0x7ul << PDMA_DSCT10_CTL_BURSIZE_Pos)

#define PDMA_DSCT10_CTL_TBINTDIS_Pos     (7)
#define PDMA_DSCT10_CTL_TBINTDIS_Msk     (0x1ul << PDMA_DSCT10_CTL_TBINTDIS_Pos)

#define PDMA_DSCT10_CTL_SAINC_Pos        (8)
#define PDMA_DSCT10_CTL_SAINC_Msk        (0x3ul << PDMA_DSCT10_CTL_SAINC_Pos)

#define PDMA_DSCT10_CTL_DAINC_Pos        (10)
#define PDMA_DSCT10_CTL_DAINC_Msk        (0x3ul << PDMA_DSCT10_CTL_DAINC_Pos)

#define PDMA_DSCT10_CTL_TXWIDTH_Pos      (12)
#define PDMA_DSCT10_CTL_TXWIDTH_Msk      (0x3ul << PDMA_DSCT10_CTL_TXWIDTH_Pos)

#define PDMA_DSCT10_CTL_TXCNT_Pos        (16)
#define PDMA_DSCT10_CTL_TXCNT_Msk        (0x3ffful << PDMA_DSCT10_CTL_TXCNT_Pos)

#define PDMA_DSCT10_SA_SA_Pos            (0)
#define PDMA_DSCT10_SA_SA_Msk            (0xfffffffful << PDMA_DSCT10_SA_SA_Pos)

#define PDMA_DSCT10_DA_DA_Pos            (0)
#define PDMA_DSCT10_DA_DA_Msk            (0xfffffffful << PDMA_DSCT10_DA_DA_Pos)

#define PDMA_DSCT10_NEXT_NEXT_Pos        (2)
#define PDMA_DSCT10_NEXT_NEXT_Msk        (0x3ffful << PDMA_DSCT10_NEXT_NEXT_Pos)

#define PDMA_DSCT11_CTL_OPMODE_Pos       (0)
#define PDMA_DSCT11_CTL_OPMODE_Msk       (0x3ul << PDMA_DSCT11_CTL_OPMODE_Pos)

#define PDMA_DSCT11_CTL_TXTYPE_Pos       (2)
#define PDMA_DSCT11_CTL_TXTYPE_Msk       (0x1ul << PDMA_DSCT11_CTL_TXTYPE_Pos)

#define PDMA_DSCT11_CTL_BURSIZE_Pos      (4)
#define PDMA_DSCT11_CTL_BURSIZE_Msk      (0x7ul << PDMA_DSCT11_CTL_BURSIZE_Pos)

#define PDMA_DSCT11_CTL_TBINTDIS_Pos     (7)
#define PDMA_DSCT11_CTL_TBINTDIS_Msk     (0x1ul << PDMA_DSCT11_CTL_TBINTDIS_Pos)

#define PDMA_DSCT11_CTL_SAINC_Pos        (8)
#define PDMA_DSCT11_CTL_SAINC_Msk        (0x3ul << PDMA_DSCT11_CTL_SAINC_Pos)

#define PDMA_DSCT11_CTL_DAINC_Pos        (10)
#define PDMA_DSCT11_CTL_DAINC_Msk        (0x3ul << PDMA_DSCT11_CTL_DAINC_Pos)

#define PDMA_DSCT11_CTL_TXWIDTH_Pos      (12)
#define PDMA_DSCT11_CTL_TXWIDTH_Msk      (0x3ul << PDMA_DSCT11_CTL_TXWIDTH_Pos)

#define PDMA_DSCT11_CTL_TXCNT_Pos        (16)
#define PDMA_DSCT11_CTL_TXCNT_Msk        (0x3ffful << PDMA_DSCT11_CTL_TXCNT_Pos)

#define PDMA_DSCT11_SA_SA_Pos            (0)
#define PDMA_DSCT11_SA_SA_Msk            (0xfffffffful << PDMA_DSCT11_SA_SA_Pos)

#define PDMA_DSCT11_DA_DA_Pos            (0)
#define PDMA_DSCT11_DA_DA_Msk            (0xfffffffful << PDMA_DSCT11_DA_DA_Pos)

#define PDMA_DSCT11_NEXT_NEXT_Pos        (2)
#define PDMA_DSCT11_NEXT_NEXT_Msk        (0x3ffful << PDMA_DSCT11_NEXT_NEXT_Pos)

#define PDMA_CURSCAT0_CURADDR_Pos        (0)
#define PDMA_CURSCAT0_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT0_CURADDR_Pos)

#define PDMA_CURSCAT1_CURADDR_Pos        (0)
#define PDMA_CURSCAT1_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT1_CURADDR_Pos)

#define PDMA_CURSCAT2_CURADDR_Pos        (0)
#define PDMA_CURSCAT2_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT2_CURADDR_Pos)

#define PDMA_CURSCAT3_CURADDR_Pos        (0)
#define PDMA_CURSCAT3_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT3_CURADDR_Pos)

#define PDMA_CURSCAT4_CURADDR_Pos        (0)
#define PDMA_CURSCAT4_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT4_CURADDR_Pos)

#define PDMA_CURSCAT5_CURADDR_Pos        (0)
#define PDMA_CURSCAT5_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT5_CURADDR_Pos)

#define PDMA_CURSCAT6_CURADDR_Pos        (0)
#define PDMA_CURSCAT6_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT6_CURADDR_Pos)

#define PDMA_CURSCAT7_CURADDR_Pos        (0)
#define PDMA_CURSCAT7_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT7_CURADDR_Pos)

#define PDMA_CURSCAT8_CURADDR_Pos        (0)
#define PDMA_CURSCAT8_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT8_CURADDR_Pos)

#define PDMA_CURSCAT9_CURADDR_Pos        (0)
#define PDMA_CURSCAT9_CURADDR_Msk        (0xfffffffful << PDMA_CURSCAT9_CURADDR_Pos)

#define PDMA_CURSCAT10_CURADDR_Pos       (0)
#define PDMA_CURSCAT10_CURADDR_Msk       (0xfffffffful << PDMA_CURSCAT10_CURADDR_Pos)

#define PDMA_CURSCAT11_CURADDR_Pos       (0)
#define PDMA_CURSCAT11_CURADDR_Msk       (0xfffffffful << PDMA_CURSCAT11_CURADDR_Pos)

#define PDMA_CHCTL_CHENx_Pos             (0)
#define PDMA_CHCTL_CHENx_Msk             (0xffful << PDMA_CHCTL_CHENx_Pos)

#define PDMA_STOP_STOPx_Pos              (0)
#define PDMA_STOP_STOPx_Msk              (0xffful << PDMA_STOP_STOPx_Pos)

#define PDMA_SWREQ_SWREQx_Pos            (0)
#define PDMA_SWREQ_SWREQx_Msk            (0xffful << PDMA_SWREQ_SWREQx_Pos)

#define PDMA_TRGSTS_REQSTSx_Pos          (0)
#define PDMA_TRGSTS_REQSTSx_Msk          (0xffful << PDMA_TRGSTS_REQSTSx_Pos)

#define PDMA_PRISET_FPRISETx_Pos         (0)
#define PDMA_PRISET_FPRISETx_Msk         (0xffful << PDMA_PRISET_FPRISETx_Pos)

#define PDMA_PRICLR_FPRICLRx_Pos         (0)
#define PDMA_PRICLR_FPRICLRx_Msk         (0xffful << PDMA_PRICLR_FPRICLRx_Pos)

#define PDMA_INTEN_INTENx_Pos            (0)
#define PDMA_INTEN_INTENx_Msk            (0xffful << PDMA_INTEN_INTENx_Pos)

#define PDMA_INTSTS_ABTIF_Pos            (0)
#define PDMA_INTSTS_ABTIF_Msk            (0x1ul << PDMA_INTSTS_ABTIF_Pos)

#define PDMA_INTSTS_TDIF_Pos             (1)
#define PDMA_INTSTS_TDIF_Msk             (0x1ul << PDMA_INTSTS_TDIF_Pos)

#define PDMA_INTSTS_TINTRWEN_Pos         (2)
#define PDMA_INTSTS_TINTRWEN_Msk         (0x1ul << PDMA_INTSTS_TINTRWEN_Pos)

#define PDMA_INTSTS_TXTOF_Pos            (6)
#define PDMA_INTSTS_TXTOF_Msk            (0x1ul << PDMA_INTSTS_TXTOF_Pos)

#define PDMA_INTSTS_TTOREN_Pos           (7)
#define PDMA_INTSTS_TTOREN_Msk           (0x1ul << PDMA_INTSTS_TTOREN_Pos)

#define PDMA_INTSTS_REQTOFx_Pos          (8)
#define PDMA_INTSTS_REQTOFx_Msk          (0xffful << PDMA_INTSTS_REQTOFx_Pos)

#define PDMA_ABTSTS_ABTIFx_Pos           (0)
#define PDMA_ABTSTS_ABTIFx_Msk           (0xffful << PDMA_ABTSTS_ABTIFx_Pos)

#define PDMA_TDSTS_TDIFx_Pos             (0)
#define PDMA_TDSTS_TDIFx_Msk             (0xffful << PDMA_TDSTS_TDIFx_Pos)

#define PDMA_SCATSTS_TEMPTYFx_Pos        (0)
#define PDMA_SCATSTS_TEMPTYFx_Msk        (0xffful << PDMA_SCATSTS_TEMPTYFx_Pos)

#define PDMA_TACTSTS_TXACTFx_Pos         (0)
#define PDMA_TACTSTS_TXACTFx_Msk         (0xffful << PDMA_TACTSTS_TXACTFx_Pos)

#define PDMA_SCATBA_SCATBA_Pos           (16)
#define PDMA_SCATBA_SCATBA_Msk           (0xfffful << PDMA_SCATBA_SCATBA_Pos)

#define PDMA_TOC0_1_TOC0_Pos             (0)
#define PDMA_TOC0_1_TOC0_Msk             (0xfffful << PDMA_TOC0_1_TOC0_Pos)

#define PDMA_TOC0_1_TOC1_Pos             (16)
#define PDMA_TOC0_1_TOC1_Msk             (0xfffful << PDMA_TOC0_1_TOC1_Pos)

#define PDMA_TOC2_3_TOC2_Pos             (0)
#define PDMA_TOC2_3_TOC2_Msk             (0xfffful << PDMA_TOC2_3_TOC2_Pos)

#define PDMA_TOC2_3_TOC3_Pos             (16)
#define PDMA_TOC2_3_TOC3_Msk             (0xfffful << PDMA_TOC2_3_TOC3_Pos)

#define PDMA_TOC4_5_TOC4_Pos             (0)
#define PDMA_TOC4_5_TOC4_Msk             (0xfffful << PDMA_TOC4_5_TOC4_Pos)

#define PDMA_TOC4_5_TOC5_Pos             (16)
#define PDMA_TOC4_5_TOC5_Msk             (0xfffful << PDMA_TOC4_5_TOC5_Pos)

#define PDMA_TOC6_7_TOC6_Pos             (0)
#define PDMA_TOC6_7_TOC6_Msk             (0xfffful << PDMA_TOC6_7_TOC6_Pos)

#define PDMA_TOC6_7_TOC7_Pos             (16)
#define PDMA_TOC6_7_TOC7_Msk             (0xfffful << PDMA_TOC6_7_TOC7_Pos)

#define PDMA_TOC8_9_TOC8_Pos             (0)
#define PDMA_TOC8_9_TOC8_Msk             (0xfffful << PDMA_TOC8_9_TOC8_Pos)

#define PDMA_TOC8_9_TOC9_Pos             (16)
#define PDMA_TOC8_9_TOC9_Msk             (0xfffful << PDMA_TOC8_9_TOC9_Pos)

#define PDMA_TOC10_11_TOC10_Pos          (0)
#define PDMA_TOC10_11_TOC10_Msk          (0xfffful << PDMA_TOC10_11_TOC10_Pos)

#define PDMA_TOC10_11_TOC11_Pos          (16)
#define PDMA_TOC10_11_TOC11_Msk          (0xfffful << PDMA_TOC10_11_TOC11_Pos)

#define PDMA_REQSEL0_3_REQSRC0_Pos       (0)
#define PDMA_REQSEL0_3_REQSRC0_Msk       (0x1ful << PDMA_REQSEL0_3_REQSRC0_Pos)

#define PDMA_REQSEL0_3_REQSRC1_Pos       (8)
#define PDMA_REQSEL0_3_REQSRC1_Msk       (0x1ful << PDMA_REQSEL0_3_REQSRC1_Pos)

#define PDMA_REQSEL0_3_REQSRC2_Pos       (16)
#define PDMA_REQSEL0_3_REQSRC2_Msk       (0x1ful << PDMA_REQSEL0_3_REQSRC2_Pos)

#define PDMA_REQSEL0_3_REQSRC3_Pos       (24)
#define PDMA_REQSEL0_3_REQSRC3_Msk       (0x1ful << PDMA_REQSEL0_3_REQSRC3_Pos)

#define PDMA_REQSEL4_7_REQSRC4_Pos       (0)
#define PDMA_REQSEL4_7_REQSRC4_Msk       (0x1ful << PDMA_REQSEL4_7_REQSRC4_Pos)

#define PDMA_REQSEL4_7_REQSRC5_Pos       (8)
#define PDMA_REQSEL4_7_REQSRC5_Msk       (0x1ful << PDMA_REQSEL4_7_REQSRC5_Pos)

#define PDMA_REQSEL4_7_REQSRC6_Pos       (16)
#define PDMA_REQSEL4_7_REQSRC6_Msk       (0x1ful << PDMA_REQSEL4_7_REQSRC6_Pos)

#define PDMA_REQSEL4_7_REQSRC7_Pos       (24)
#define PDMA_REQSEL4_7_REQSRC7_Msk       (0x1ful << PDMA_REQSEL4_7_REQSRC7_Pos)

#define PDMA_REQSEL8_11_REQSRC8_Pos      (0)
#define PDMA_REQSEL8_11_REQSRC8_Msk      (0x1ful << PDMA_REQSEL8_11_REQSRC8_Pos)

#define PDMA_REQSEL8_11_REQSRC9_Pos      (8)
#define PDMA_REQSEL8_11_REQSRC9_Msk      (0x1ful << PDMA_REQSEL8_11_REQSRC9_Pos)

#define PDMA_REQSEL8_11_REQSRC10_Pos     (16)
#define PDMA_REQSEL8_11_REQSRC10_Msk     (0x1ful << PDMA_REQSEL8_11_REQSRC10_Pos)

#define PDMA_REQSEL8_11_REQSRC11_Pos     (24)
#define PDMA_REQSEL8_11_REQSRC11_Msk     (0x1ful << PDMA_REQSEL8_11_REQSRC11_Pos)

/**@}*/ /* PDMA_CONST */
/**@}*/ /* end of PDMA register group */


/*---------------------- Pulse Width Modulation Controller -------------------------*/
/**
    @addtogroup PWM Pulse Width Modulation Controller(PWM)
    Memory Mapped Structure for PWM Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL0;                  /*!< [0x0000] PWM Control Register 0                                           */
    __IO uint32_t CTL1;                  /*!< [0x0004] PWM Control Register 1                                           */
    __IO uint32_t SYNC;                  /*!< [0x0008] PWM Synchronization Register                                     */
    __IO uint32_t SWSYNC;                /*!< [0x000c] PWM Software Control Synchronization Register                    */
    __IO uint32_t CLKSRC;                /*!< [0x0010] PWM Clock Source Register                                        */
    __IO uint32_t CLKPSC0_1;             /*!< [0x0014] PWM Clock Pre-scale Register 0                                   */
    __IO uint32_t CLKPSC2_3;             /*!< [0x0018] PWM Clock Pre-scale Register 2                                   */
    __IO uint32_t CLKPSC4_5;             /*!< [0x001c] PWM Clock Pre-scale Register 4                                   */
    __IO uint32_t CNTEN;                 /*!< [0x0020] PWM Counter Enable Register                                      */
    __IO uint32_t CNTCLR;                /*!< [0x0024] PWM Clear Counter Register                                       */
    __IO uint32_t LOAD;                  /*!< [0x0028] PWM Load Register                                                */
         uint32_t RESERVE0[1];

    __IO uint32_t PERIOD0;               /*!< [0x0030] PWM Period Register 0                                           */
    __IO uint32_t PERIOD1;               /*!< [0x0034] PWM Period Register 1                                           */
    __IO uint32_t PERIOD2;               /*!< [0x0038] PWM Period Register 2                                           */
    __IO uint32_t PERIOD3;               /*!< [0x003c] PWM Period Register 3                                           */
    __IO uint32_t PERIOD4;               /*!< [0x0040] PWM Period Register 4                                           */
    __IO uint32_t PERIOD5;               /*!< [0x0044] PWM Period Register 5                                           */
         uint32_t RESERVE1[2];

    __IO uint32_t CMPDAT0;               /*!< [0x0050] PWM Comparator Register 0                                        */
    __IO uint32_t CMPDAT1;               /*!< [0x0054] PWM Comparator Register 1                                        */
    __IO uint32_t CMPDAT2;               /*!< [0x0058] PWM Comparator Register 2                                        */
    __IO uint32_t CMPDAT3;               /*!< [0x005c] PWM Comparator Register 3                                        */
    __IO uint32_t CMPDAT4;               /*!< [0x0060] PWM Comparator Register 4                                        */
    __IO uint32_t CMPDAT5;               /*!< [0x0064] PWM Comparator Register 5                                        */
         uint32_t RESERVE2[2];

    __IO uint32_t DTCTL0_1;              /*!< [0x0070] PWM Dead-Time Control Register 0                                 */
    __IO uint32_t DTCTL2_3;              /*!< [0x0074] PWM Dead-Time Control Register 2                                 */
    __IO uint32_t DTCTL4_5;              /*!< [0x0078] PWM Dead-Time Control Register 4                                 */
         uint32_t RESERVE3[1];

    __IO uint32_t PHS0_1;                /*!< [0x0080] PWM Counter Phase Register 0                                     */
    __IO uint32_t PHS2_3;                /*!< [0x0084] PWM Counter Phase Register 2                                     */
    __IO uint32_t PHS4_5;                /*!< [0x0088] PWM Counter Phase Register 4                                     */
         uint32_t RESERVE4[1];

    __I  uint32_t CNT0;                  /*!< [0x0090] PWM Counter Register 0                                           */
    __I  uint32_t CNT1;                  /*!< [0x0094] PWM Counter Register 1                                           */
    __I  uint32_t CNT2;                  /*!< [0x0098] PWM Counter Register 2                                           */
    __I  uint32_t CNT3;                  /*!< [0x009c] PWM Counter Register 3                                           */
    __I  uint32_t CNT4;                  /*!< [0x00a0] PWM Counter Register 4                                           */
    __I  uint32_t CNT5;                  /*!< [0x00a4] PWM Counter Register 5                                           */
         uint32_t RESERVE5[2];

    __IO uint32_t WGCTL0;                /*!< [0x00b0] PWM Generation Register 0                                        */
    __IO uint32_t WGCTL1;                /*!< [0x00b4] PWM Generation Register 1                                        */
    __IO uint32_t MSKEN;                 /*!< [0x00b8] PWM Mask Enable Register                                         */
    __IO uint32_t MSK;                   /*!< [0x00bc] PWM Mask Data Register                                           */
    __IO uint32_t BNF;                   /*!< [0x00c0] PWM Brake Noise Filter Register                                  */
    __IO uint32_t FAILBRK;               /*!< [0x00c4] PWM System Fail Brake Control Register                           */
    __IO uint32_t BRKCTL0_1;             /*!< [0x00c8] PWM Brake Edge Detect Control Register 0                         */
    __IO uint32_t BRKCTL2_3;             /*!< [0x00cc] PWM Brake Edge Detect Control Register 2                         */
    __IO uint32_t BRKCTL4_5;             /*!< [0x00d0] PWM Brake Edge Detect Control Register 4                         */
    __IO uint32_t POLCTL;                /*!< [0x00d4] PWM Pin Polar Inverse Register                                   */
    __IO uint32_t POEN;                  /*!< [0x00d8] PWM Output Enable Register                                       */
    __O  uint32_t SWBRK;                 /*!< [0x00dc] PWM Software Brake Control Register                              */
    __IO uint32_t INTEN0;                /*!< [0x00e0] PWM Interrupt Enable Register 0                                  */
    __IO uint32_t INTEN1;                /*!< [0x00e4] PWM Interrupt Enable Register 1                                  */
    __IO uint32_t INTSTS0;               /*!< [0x00e8] PWM Interrupt Flag Register 0                                    */
    __IO uint32_t INTSTS1;               /*!< [0x00ec] PWM Interrupt Flag Register 1                                    */
    __IO uint32_t IFA;                   /*!< [0x00f0] PWM Interrupt Flag Accumulator Register                          */
    __IO uint32_t DACTRGEN;              /*!< [0x00f4] PWM Trigger DAC Enable Register                                  */
    __IO uint32_t EADCTS0;               /*!< [0x00f8] PWM Trigger EADC Source Select Register 0                        */
    __IO uint32_t EADCTS1;               /*!< [0x00fc] PWM Trigger EADC Source Select Register 1                        */
    __IO uint32_t FTRGCMP0_1;            /*!< [0x0100] PWM Free Trigger Compare Register 0                              */
    __IO uint32_t FTRGCMP2_3;            /*!< [0x0104] PWM Free Trigger Compare Register 2                              */
    __IO uint32_t FTRGCMP4_5;            /*!< [0x0108] PWM Free Trigger Compare Register 4                              */
         uint32_t RESERVE6[1];

    __IO uint32_t SSCTL;                 /*!< [0x0110] PWM Synchronous Start Control Register                           */
    __O  uint32_t SSTRG;                 /*!< [0x0114] PWM Synchronous Start Trigger Register                           */
         uint32_t RESERVE7[2];

    __IO uint32_t STATUS;                /*!< [0x0120] PWM Status Register                                              */
         uint32_t RESERVE8[55];

    __IO uint32_t CAPINEN;               /*!< [0x0200] PWM Capture Input Enable Register                                */
    __IO uint32_t CAPCTL;                /*!< [0x0204] PWM Capture Control Register                                     */
    __I  uint32_t CAPSTS;                /*!< [0x0208] PWM Capture Status Register                                      */
    __I  uint32_t RCAPDAT0;              /*!< [0x020c] PWM Rising Capture Data Register 0                               */
    __I  uint32_t FCAPDAT0;              /*!< [0x0210] PWM Falling Capture Data Register 0                              */
    __I  uint32_t RCAPDAT1;              /*!< [0x0214] PWM Rising Capture Data Register 1                               */
    __I  uint32_t FCAPDAT1;              /*!< [0x0218] PWM Falling Capture Data Register 1                              */
    __I  uint32_t RCAPDAT2;              /*!< [0x021c] PWM Rising Capture Data Register 2                               */
    __I  uint32_t FCAPDAT2;              /*!< [0x0220] PWM Falling Capture Data Register 2                              */
    __I  uint32_t RCAPDAT3;              /*!< [0x0224] PWM Rising Capture Data Register 3                               */
    __I  uint32_t FCAPDAT3;              /*!< [0x0228] PWM Falling Capture Data Register 3                              */
    __I  uint32_t RCAPDAT4;              /*!< [0x022c] PWM Rising Capture Data Register 4                               */
    __I  uint32_t FCAPDAT4;              /*!< [0x0230] PWM Falling Capture Data Register 4                              */
    __I  uint32_t RCAPDAT5;              /*!< [0x0234] PWM Rising Capture Data Register 5                               */
    __I  uint32_t FCAPDAT5;              /*!< [0x0238] PWM Falling Capture Data Register 5                              */
    __IO uint32_t PDMACTL;               /*!< [0x023c] PWM PDMA Control Register                                        */
    __I  uint32_t PDMACAP0_1;            /*!< [0x0240] PWM Capture Channel 01 PDMA Register                             */
    __I  uint32_t PDMACAP2_3;            /*!< [0x0244] PWM Capture Channel 23 PDMA Register                             */
    __I  uint32_t PDMACAP4_5;            /*!< [0x0248] PWM Capture Channel 45 PDMA Register                             */
         uint32_t RESERVE9[1];

    __IO uint32_t CAPIEN;                /*!< [0x0250] PWM Capture Interrupt Enable Register                            */
    __IO uint32_t CAPIF;                 /*!< [0x0254] PWM Capture Interrupt Flag Register                              */
         uint32_t RESERVE10[43];

    __I  uint32_t PBUF0;                 /*!< [0x0304] PWM PERIOD0 Buffer                                               */
    __I  uint32_t PBUF1;                 /*!< [0x0308] PWM PERIOD1 Buffer                                               */
    __I  uint32_t PBUF2;                 /*!< [0x030c] PWM PERIOD2 Buffer                                               */
    __I  uint32_t PBUF3;                 /*!< [0x0310] PWM PERIOD3 Buffer                                               */
    __I  uint32_t PBUF4;                 /*!< [0x0314] PWM PERIOD4 Buffer                                               */
    __I  uint32_t PBUF5;                 /*!< [0x0318] PWM PERIOD5 Buffer                                               */
    __I  uint32_t CMPBUF0;               /*!< [0x031c] PWM CMP0 Buffer                                                  */
    __I  uint32_t CMPBUF1;               /*!< [0x0320] PWM CMP1 Buffer                                                  */
    __I  uint32_t CMPBUF2;               /*!< [0x0324] PWM CMP2 Buffer                                                  */
    __I  uint32_t CMPBUF3;               /*!< [0x0328] PWM CMP3 Buffer                                                  */
    __I  uint32_t CMPBUF4;               /*!< [0x032c] PWM CMP4 Buffer                                                  */
    __I  uint32_t CMPBUF5;               /*!< [0x0330] PWM CMP5 Buffer                                                  */
         uint32_t RESERVE11[3];

    __I  uint32_t FTCBUF0_1;             /*!< [0x0340] PWM FTCMR0 Buffer                                                */
    __I  uint32_t FTCBUF2_3;             /*!< [0x0344] PWM FTCMR2 Buffer                                                */
    __I  uint32_t FTCBUF4_5;             /*!< [0x0348] PWM FTCMR4 Buffer                                                */
    __IO uint32_t FTCI;                  /*!< [0x034c] PWM FCMPDAT Indicator Register                                   */
         uint32_t RESERVE12[812];
} PWM_T;

/**
    @addtogroup PWM_CONST PWM Bit Field Definition
    Constant Definitions for PWM Controller
@{ */

#define PWM_CTL0_CTRLDn_Pos              (0)
#define PWM_CTL0_CTRLDn_Msk              (0x3ful << PWM_CTL0_CTRLDn_Pos)

#define PWM_CTL0_CTRLD0_Pos              (0)
#define PWM_CTL0_CTRLD0_Msk              (0x1ul << PWM_CTL0_CTRLD0_Pos)

#define PWM_CTL0_CTRLD1_Pos              (1)
#define PWM_CTL0_CTRLD1_Msk              (0x1ul << PWM_CTL0_CTRLD1_Pos)

#define PWM_CTL0_CTRLD2_Pos              (2)
#define PWM_CTL0_CTRLD2_Msk              (0x1ul << PWM_CTL0_CTRLD2_Pos)

#define PWM_CTL0_CTRLD3_Pos              (3)
#define PWM_CTL0_CTRLD3_Msk              (0x1ul << PWM_CTL0_CTRLD3_Pos)

#define PWM_CTL0_CTRLD4_Pos              (4)
#define PWM_CTL0_CTRLD4_Msk              (0x1ul << PWM_CTL0_CTRLD4_Pos)

#define PWM_CTL0_CTRLD5_Pos              (5)
#define PWM_CTL0_CTRLD5_Msk              (0x1ul << PWM_CTL0_CTRLD5_Pos)

#define PWM_CTL0_WINLDENn_Pos            (8)
#define PWM_CTL0_WINLDENn_Msk            (0x3ful << PWM_CTL0_WINLDENn_Pos)

#define PWM_CTL0_WINLDEN0_Pos            (8)
#define PWM_CTL0_WINLDEN0_Msk            (0x1ul << PWM_CTL0_WINLDEN0_Pos)

#define PWM_CTL0_WINLDEN1_Pos            (9)
#define PWM_CTL0_WINLDEN1_Msk            (0x1ul << PWM_CTL0_WINLDEN1_Pos)

#define PWM_CTL0_WINLDEN2_Pos            (10)
#define PWM_CTL0_WINLDEN2_Msk            (0x1ul << PWM_CTL0_WINLDEN2_Pos)

#define PWM_CTL0_WINLDEN3_Pos            (11)
#define PWM_CTL0_WINLDEN3_Msk            (0x1ul << PWM_CTL0_WINLDEN3_Pos)

#define PWM_CTL0_WINLDEN4_Pos            (12)
#define PWM_CTL0_WINLDEN4_Msk            (0x1ul << PWM_CTL0_WINLDEN4_Pos)

#define PWM_CTL0_WINLDEN5_Pos            (13)
#define PWM_CTL0_WINLDEN5_Msk            (0x1ul << PWM_CTL0_WINLDEN5_Pos)

#define PWM_CTL0_IMMLDENn_Pos            (16)
#define PWM_CTL0_IMMLDENn_LOADn_Msk      (0x3ful << PWM_CTL0_IMMLDENn_Pos)

#define PWM_CTL0_IMMLDEN0_Pos            (16)
#define PWM_CTL0_IMMLDEN0_LOADn_Msk      (0x1ul << PWM_CTL0_IMMLDEN0_Pos)

#define PWM_CTL0_IMMLDEN1_Pos            (17)
#define PWM_CTL0_IMMLDEN1_LOADn_Msk      (0x1ul << PWM_CTL0_IMMLDEN1_Pos)

#define PWM_CTL0_IMMLDEN2_Pos            (18)
#define PWM_CTL0_IMMLDEN2_LOADn_Msk      (0x1ul << PWM_CTL0_IMMLDEN2_Pos)

#define PWM_CTL0_IMMLDEN3_Pos            (19)
#define PWM_CTL0_IMMLDEN3_LOADn_Msk      (0x1ul << PWM_CTL0_IMMLDEN3_Pos)

#define PWM_CTL0_IMMLDEN4_Pos            (20)
#define PWM_CTL0_IMMLDEN4_LOADn_Msk      (0x1ul << PWM_CTL0_IMMLDEN4_Pos)

#define PWM_CTL0_IMMLDEN5_Pos            (21)
#define PWM_CTL0_IMMLDEN5_LOADn_Msk      (0x1ul << PWM_CTL0_IMMLDEN5_Pos)

#define PWM_CTL0_GROUPEN_Pos             (24)
#define PWM_CTL0_GROUPEN_Msk             (0x1ul << PWM_CTL0_GROUPEN_Pos)

#define PWM_CTL0_DBGHALT_Pos             (30)
#define PWM_CTL0_DBGHALT_Msk             (0x1ul << PWM_CTL0_DBGHALT_Pos)

#define PWM_CTL0_DBGTRIOFF_Pos           (31)
#define PWM_CTL0_DBGTRIOFF_Msk           (0x1ul << PWM_CTL0_DBGTRIOFF_Pos)

#define PWM_CTL1_CNTTYPEn_Pos            (0)
#define PWM_CTL1_CNTTYPEn_Msk            (0xffful << PWM_CTL1_CNTTYPEn_Pos)

#define PWM_CTL1_CNTTYPE0_Pos            (0)
#define PWM_CTL1_CNTTYPE0_Msk            (0x3ul << PWM_CTL1_CNTTYPE0_Pos)

#define PWM_CTL1_CNTTYPE1_Pos            (2)
#define PWM_CTL1_CNTTYPE1_Msk            (0x3ul << PWM_CTL1_CNTTYPE1_Pos)

#define PWM_CTL1_CNTTYPE2_Pos            (4)
#define PWM_CTL1_CNTTYPE2_Msk            (0x3ul << PWM_CTL1_CNTTYPE2_Pos)

#define PWM_CTL1_CNTTYPE3_Pos            (6)
#define PWM_CTL1_CNTTYPE3_Msk            (0x3ul << PWM_CTL1_CNTTYPE3_Pos)

#define PWM_CTL1_CNTTYPE4_Pos            (8)
#define PWM_CTL1_CNTTYPE4_Msk            (0x3ul << PWM_CTL1_CNTTYPE4_Pos)

#define PWM_CTL1_CNTTYPE5_Pos            (10)
#define PWM_CTL1_CNTTYPE5_Msk            (0x3ul << PWM_CTL1_CNTTYPE5_Pos)

#define PWM_CTL1_CNTMODEn_Pos            (16)
#define PWM_CTL1_CNTMODEn_Msk            (0x3ful << PWM_CTL1_CNTMODEn_Pos)

#define PWM_CTL1_CNTMODE0_Pos            (16)
#define PWM_CTL1_CNTMODE0_Msk            (0x1ul << PWM_CTL1_CNTMODE0_Pos)

#define PWM_CTL1_CNTMODE1_Pos            (17)
#define PWM_CTL1_CNTMODE1_Msk            (0x1ul << PWM_CTL1_CNTMODE1_Pos)

#define PWM_CTL1_CNTMODE2_Pos            (18)
#define PWM_CTL1_CNTMODE2_Msk            (0x1ul << PWM_CTL1_CNTMODE2_Pos)

#define PWM_CTL1_CNTMODE3_Pos            (19)
#define PWM_CTL1_CNTMODE3_Msk            (0x1ul << PWM_CTL1_CNTMODE3_Pos)

#define PWM_CTL1_CNTMODE4_Pos            (20)
#define PWM_CTL1_CNTMODE4_Msk            (0x1ul << PWM_CTL1_CNTMODE4_Pos)

#define PWM_CTL1_CNTMODE5_Pos            (21)
#define PWM_CTL1_CNTMODE5_Msk            (0x1ul << PWM_CTL1_CNTMODE5_Pos)

#define PWM_CTL1_PWMMODEn_Pos            (24)
#define PWM_CTL1_PWMMODEn_Msk            (0x7ul << PWM_CTL1_PWMMODEn_Pos)

#define PWM_CTL1_PWMMODE0_Pos            (24)
#define PWM_CTL1_PWMMODE0_Msk            (0x1ul << PWM_CTL1_PWMMODE0_Pos)

#define PWM_CTL1_PWMMODE2_Pos            (25)
#define PWM_CTL1_PWMMODE2_Msk            (0x1ul << PWM_CTL1_PWMMODE2_Pos)

#define PWM_CTL1_PWMMODE4_Pos            (26)
#define PWM_CTL1_PWMMODE4_Msk            (0x1ul << PWM_CTL1_PWMMODE4_Pos)

#define PWM_SYNC_PHSENn_Pos              (0)
#define PWM_SYNC_PHSENn_Msk              (0x7ul << PWM_SYNC_PHSENn_Pos)

#define PWM_SYNC_PHSEN0_Pos              (0)
#define PWM_SYNC_PHSEN0_Msk              (0x1ul << PWM_SYNC_PHSEN0_Pos)

#define PWM_SYNC_PHSEN2_Pos              (1)
#define PWM_SYNC_PHSEN2_Msk              (0x1ul << PWM_SYNC_PHSEN2_Pos)

#define PWM_SYNC_PHSEN4_Pos              (2)
#define PWM_SYNC_PHSEN4_Msk              (0x1ul << PWM_SYNC_PHSEN4_Pos)

#define PWM_SYNC_SINSRCn_Pos             (8)
#define PWM_SYNC_SINSRCn_Msk             (0x3ful << PWM_SYNC_SINSRCn_Pos)

#define PWM_SYNC_SINSRC0_Pos             (8)
#define PWM_SYNC_SINSRC0_Msk             (0x3ul << PWM_SYNC_SINSRC0_Pos)

#define PWM_SYNC_SINSRC2_Pos             (10)
#define PWM_SYNC_SINSRC2_Msk             (0x3ul << PWM_SYNC_SINSRC2_Pos)

#define PWM_SYNC_SINSRC4_Pos             (12)
#define PWM_SYNC_SINSRC4_Msk             (0x3ul << PWM_SYNC_SINSRC4_Pos)

#define PWM_SYNC_SNFLTEN_Pos             (16)
#define PWM_SYNC_SNFLTEN_Msk             (0x1ul << PWM_SYNC_SNFLTEN_Pos)

#define PWM_SYNC_SFLTCSEL_Pos            (17)
#define PWM_SYNC_SFLTCSEL_Msk            (0x7ul << PWM_SYNC_SFLTCSEL_Pos)

#define PWM_SYNC_SFLTCNT_Pos             (20)
#define PWM_SYNC_SFLTCNT_Msk             (0x7ul << PWM_SYNC_SFLTCNT_Pos)

#define PWM_SYNC_SINPINV_Pos             (23)
#define PWM_SYNC_SINPINV_Msk             (0x1ul << PWM_SYNC_SINPINV_Pos)

#define PWM_SYNC_PHSDIRn_Pos             (24)
#define PWM_SYNC_PHSDIRn_Msk             (0x7ul << PWM_SYNC_PHSDIRn_Pos)

#define PWM_SYNC_PHSDIR0_Pos             (24)
#define PWM_SYNC_PHSDIR0_Msk             (0x1ul << PWM_SYNC_PHSDIR0_Pos)

#define PWM_SYNC_PHSDIR2_Pos             (25)
#define PWM_SYNC_PHSDIR2_Msk             (0x1ul << PWM_SYNC_PHSDIR2_Pos)

#define PWM_SYNC_PHSDIR4_Pos             (26)
#define PWM_SYNC_PHSDIR4_Msk             (0x1ul << PWM_SYNC_PHSDIR4_Pos)

#define PWM_SWSYNC_SWSYNCn_Pos           (0)
#define PWM_SWSYNC_SWSYNCn_Msk           (0x7ul << PWM_SWSYNC_SWSYNCn_Pos)

#define PWM_SWSYNC_SWSYNC0_Pos           (0)
#define PWM_SWSYNC_SWSYNC0_Msk           (0x1ul << PWM_SWSYNC_SWSYNC0_Pos)

#define PWM_SWSYNC_SWSYNC2_Pos           (1)
#define PWM_SWSYNC_SWSYNC2_Msk           (0x1ul << PWM_SWSYNC_SWSYNC2_Pos)

#define PWM_SWSYNC_SWSYNC4_Pos           (2)
#define PWM_SWSYNC_SWSYNC4_Msk           (0x1ul << PWM_SWSYNC_SWSYNC4_Pos)

#define PWM_CLKSRC_ECLKSRC0_Pos          (0)
#define PWM_CLKSRC_ECLKSRC0_Msk          (0x7ul << PWM_CLKSRC_ECLKSRC0_Pos)

#define PWM_CLKSRC_ECLKSRC2_Pos          (8)
#define PWM_CLKSRC_ECLKSRC2_Msk          (0x7ul << PWM_CLKSRC_ECLKSRC2_Pos)

#define PWM_CLKSRC_ECLKSRC4_Pos          (16)
#define PWM_CLKSRC_ECLKSRC4_Msk          (0x7ul << PWM_CLKSRC_ECLKSRC4_Pos)

#define PWM_CLKPSC0_1_CLKPSC_Pos         (0)
#define PWM_CLKPSC0_1_CLKPSC_Msk         (0xffful << PWM_CLKPSC0_1_CLKPSC_Pos)

#define PWM_CLKPSC2_3_CLKPSC_Pos         (0)
#define PWM_CLKPSC2_3_CLKPSC_Msk         (0xffful << PWM_CLKPSC2_3_CLKPSC_Pos)

#define PWM_CLKPSC4_5_CLKPSC_Pos         (0)
#define PWM_CLKPSC4_5_CLKPSC_Msk         (0xffful << PWM_CLKPSC4_5_CLKPSC_Pos)

#define PWM_CNTEN_CNTENn_Pos             (0)
#define PWM_CNTEN_CNTENn_Msk             (0x3ful << PWM_CNTEN_CNTENn_Pos)

#define PWM_CNTEN_CNTEN0_Pos             (0)
#define PWM_CNTEN_CNTEN0_Msk             (0x1ul << PWM_CNTEN_CNTEN0_Pos)

#define PWM_CNTEN_CNTEN1_Pos             (1)
#define PWM_CNTEN_CNTEN1_Msk             (0x1ul << PWM_CNTEN_CNTEN1_Pos)

#define PWM_CNTEN_CNTEN2_Pos             (2)
#define PWM_CNTEN_CNTEN2_Msk             (0x1ul << PWM_CNTEN_CNTEN2_Pos)

#define PWM_CNTEN_CNTEN3_Pos             (3)
#define PWM_CNTEN_CNTEN3_Msk             (0x1ul << PWM_CNTEN_CNTEN3_Pos)

#define PWM_CNTEN_CNTEN4_Pos             (4)
#define PWM_CNTEN_CNTEN4_Msk             (0x1ul << PWM_CNTEN_CNTEN4_Pos)

#define PWM_CNTEN_CNTEN5_Pos             (5)
#define PWM_CNTEN_CNTEN5_Msk             (0x1ul << PWM_CNTEN_CNTEN5_Pos)

#define PWM_CNTCLR_CNTCLRn_Pos           (0)
#define PWM_CNTCLR_CNTCLRn_Msk           (0x3ful << PWM_CNTCLR_CNTCLRn_Pos)

#define PWM_CNTCLR_CNTCLR0_Pos           (0)
#define PWM_CNTCLR_CNTCLR0_Msk           (0x1ul << PWM_CNTCLR_CNTCLR0_Pos)

#define PWM_CNTCLR_CNTCLR1_Pos           (1)
#define PWM_CNTCLR_CNTCLR1_Msk           (0x1ul << PWM_CNTCLR_CNTCLR1_Pos)

#define PWM_CNTCLR_CNTCLR2_Pos           (2)
#define PWM_CNTCLR_CNTCLR2_Msk           (0x1ul << PWM_CNTCLR_CNTCLR2_Pos)

#define PWM_CNTCLR_CNTCLR3_Pos           (3)
#define PWM_CNTCLR_CNTCLR3_Msk           (0x1ul << PWM_CNTCLR_CNTCLR3_Pos)

#define PWM_CNTCLR_CNTCLR4_Pos           (4)
#define PWM_CNTCLR_CNTCLR4_Msk           (0x1ul << PWM_CNTCLR_CNTCLR4_Pos)

#define PWM_CNTCLR_CNTCLR5_Pos           (5)
#define PWM_CNTCLR_CNTCLR5_Msk           (0x1ul << PWM_CNTCLR_CNTCLR5_Pos)

#define PWM_LOAD_LOADn_Pos               (0)
#define PWM_LOAD_LOADn_Msk               (0x3ful << PWM_LOAD_LOADn_Pos)

#define PWM_LOAD_LOAD0_Pos               (0)
#define PWM_LOAD_LOAD0_Msk               (0x1ul << PWM_LOAD_LOAD0_Pos)

#define PWM_LOAD_LOAD1_Pos               (1)
#define PWM_LOAD_LOAD1_Msk               (0x1ul << PWM_LOAD_LOAD1_Pos)

#define PWM_LOAD_LOAD2_Pos               (2)
#define PWM_LOAD_LOAD2_Msk               (0x1ul << PWM_LOAD_LOAD2_Pos)

#define PWM_LOAD_LOAD3_Pos               (3)
#define PWM_LOAD_LOAD3_Msk               (0x1ul << PWM_LOAD_LOAD3_Pos)

#define PWM_LOAD_LOAD4_Pos               (4)
#define PWM_LOAD_LOAD4_Msk               (0x1ul << PWM_LOAD_LOAD4_Pos)

#define PWM_LOAD_LOAD5_Pos               (5)
#define PWM_LOAD_LOAD5_Msk               (0x1ul << PWM_LOAD_LOAD5_Pos)

#define PWM_PERIOD0_PERIOD_Pos           (0)
#define PWM_PERIOD0_PERIOD_Msk           (0xfffful << PWM_PERIOD0_PERIOD_Pos)

#define PWM_PERIOD1_PERIOD_Pos           (0)
#define PWM_PERIOD1_PERIOD_Msk           (0xfffful << PWM_PERIOD1_PERIOD_Pos)

#define PWM_PERIOD2_PERIOD_Pos           (0)
#define PWM_PERIOD2_PERIOD_Msk           (0xfffful << PWM_PERIOD2_PERIOD_Pos)

#define PWM_PERIOD3_PERIOD_Pos           (0)
#define PWM_PERIOD3_PERIOD_Msk           (0xfffful << PWM_PERIOD3_PERIOD_Pos)

#define PWM_PERIOD4_PERIOD_Pos           (0)
#define PWM_PERIOD4_PERIOD_Msk           (0xfffful << PWM_PERIOD4_PERIOD_Pos)

#define PWM_PERIOD5_PERIOD_Pos           (0)
#define PWM_PERIOD5_PERIOD_Msk           (0xfffful << PWM_PERIOD5_PERIOD_Pos)

#define PWM_CMPDAT0_CMPDAT_Pos           (0)
#define PWM_CMPDAT0_CMPDAT_Msk           (0xfffful << PWM_CMPDAT0_CMPDAT_Pos)

#define PWM_CMPDAT1_CMPDAT_Pos           (0)
#define PWM_CMPDAT1_CMPDAT_Msk           (0xfffful << PWM_CMPDAT1_CMPDAT_Pos)

#define PWM_CMPDAT2_CMPDAT_Pos           (0)
#define PWM_CMPDAT2_CMPDAT_Msk           (0xfffful << PWM_CMPDAT2_CMPDAT_Pos)

#define PWM_CMPDAT3_CMPDAT_Pos           (0)
#define PWM_CMPDAT3_CMPDAT_Msk           (0xfffful << PWM_CMPDAT3_CMPDAT_Pos)

#define PWM_CMPDAT4_CMPDAT_Pos           (0)
#define PWM_CMPDAT4_CMPDAT_Msk           (0xfffful << PWM_CMPDAT4_CMPDAT_Pos)

#define PWM_CMPDAT5_CMPDAT_Pos           (0)
#define PWM_CMPDAT5_CMPDAT_Msk           (0xfffful << PWM_CMPDAT5_CMPDAT_Pos)

#define PWM_DTCTL0_1_DTCNT_Pos           (0)
#define PWM_DTCTL0_1_DTCNT_Msk           (0xffful << PWM_DTCTL0_1_DTCNT_Pos)

#define PWM_DTCTL0_1_DTEN_Pos            (16)
#define PWM_DTCTL0_1_DTEN_Msk            (0x1ul << PWM_DTCTL0_1_DTEN_Pos)

#define PWM_DTCTL2_3_DTCNT_Pos           (0)
#define PWM_DTCTL2_3_DTCNT_Msk           (0xffful << PWM_DTCTL2_3_DTCNT_Pos)

#define PWM_DTCTL2_3_DTEN_Pos            (16)
#define PWM_DTCTL2_3_DTEN_Msk            (0x1ul << PWM_DTCTL2_3_DTEN_Pos)

#define PWM_DTCTL4_5_DTCNT_Pos           (0)
#define PWM_DTCTL4_5_DTCNT_Msk           (0xffful << PWM_DTCTL4_5_DTCNT_Pos)

#define PWM_DTCTL4_5_DTEN_Pos            (16)
#define PWM_DTCTL4_5_DTEN_Msk            (0x1ul << PWM_DTCTL4_5_DTEN_Pos)

#define PWM_PHS0_1_PHS_Pos               (0)
#define PWM_PHS0_1_PHS_Msk               (0xfffful << PWM_PHS0_1_PHS_Pos)

#define PWM_PHS2_3_PHS_Pos               (0)
#define PWM_PHS2_3_PHS_Msk               (0xfffful << PWM_PHS2_3_PHS_Pos)

#define PWM_PHS4_5_PHS_Pos               (0)
#define PWM_PHS4_5_PHS_Msk               (0xfffful << PWM_PHS4_5_PHS_Pos)

#define PWM_CNT0_CNT_Pos                 (0)
#define PWM_CNT0_CNT_Msk                 (0xfffful << PWM_CNT0_CNT_Pos)

#define PWM_CNT0_DIRF_Pos                (16)
#define PWM_CNT0_DIRF_Msk                (0x1ul << PWM_CNT0_DIRF_Pos)

#define PWM_CNT1_CNT_Pos                 (0)
#define PWM_CNT1_CNT_Msk                 (0xfffful << PWM_CNT1_CNT_Pos)

#define PWM_CNT1_DIRF_Pos                (16)
#define PWM_CNT1_DIRF_Msk                (0x1ul << PWM_CNT1_DIRF_Pos)

#define PWM_CNT2_CNT_Pos                 (0)
#define PWM_CNT2_CNT_Msk                 (0xfffful << PWM_CNT2_CNT_Pos)

#define PWM_CNT2_DIRF_Pos                (16)
#define PWM_CNT2_DIRF_Msk                (0x1ul << PWM_CNT2_DIRF_Pos)

#define PWM_CNT3_CNT_Pos                 (0)
#define PWM_CNT3_CNT_Msk                 (0xfffful << PWM_CNT3_CNT_Pos)

#define PWM_CNT3_DIRF_Pos                (16)
#define PWM_CNT3_DIRF_Msk                (0x1ul << PWM_CNT3_DIRF_Pos)

#define PWM_CNT4_CNT_Pos                 (0)
#define PWM_CNT4_CNT_Msk                 (0xfffful << PWM_CNT4_CNT_Pos)

#define PWM_CNT4_DIRF_Pos                (16)
#define PWM_CNT4_DIRF_Msk                (0x1ul << PWM_CNT4_DIRF_Pos)

#define PWM_CNT5_CNT_Pos                 (0)
#define PWM_CNT5_CNT_Msk                 (0xfffful << PWM_CNT5_CNT_Pos)

#define PWM_CNT5_DIRF_Pos                (16)
#define PWM_CNT5_DIRF_Msk                (0x1ul << PWM_CNT5_DIRF_Pos)

#define PWM_WGCTL0_ZPCTLn_Pos            (0)
#define PWM_WGCTL0_ZPCTLn_Msk            (0xffful << PWM_WGCTL0_ZPCTLn_Pos)

#define PWM_WGCTL0_ZPCTL0_Pos            (0)
#define PWM_WGCTL0_ZPCTL0_Msk            (0x3ul << PWM_WGCTL0_ZPCTL0_Pos)

#define PWM_WGCTL0_ZPCTL1_Pos            (2)
#define PWM_WGCTL0_ZPCTL1_Msk            (0x3ul << PWM_WGCTL0_ZPCTL1_Pos)

#define PWM_WGCTL0_ZPCTL2_Pos            (4)
#define PWM_WGCTL0_ZPCTL2_Msk            (0x3ul << PWM_WGCTL0_ZPCTL2_Pos)

#define PWM_WGCTL0_ZPCTL3_Pos            (6)
#define PWM_WGCTL0_ZPCTL3_Msk            (0x3ul << PWM_WGCTL0_ZPCTL3_Pos)

#define PWM_WGCTL0_ZPCTL4_Pos            (8)
#define PWM_WGCTL0_ZPCTL4_Msk            (0x3ul << PWM_WGCTL0_ZPCTL4_Pos)

#define PWM_WGCTL0_ZPCTL5_Pos            (10)
#define PWM_WGCTL0_ZPCTL5_Msk            (0x3ul << PWM_WGCTL0_ZPCTL5_Pos)

#define PWM_WGCTL0_PRDPCTLn_Pos          (16)
#define PWM_WGCTL0_PRDPCTLn_Msk          (0xffful << PWM_WGCTL0_PRDPCTLn_Pos)

#define PWM_WGCTL0_PRDPCTL0_Pos          (16)
#define PWM_WGCTL0_PRDPCTL0_Msk          (0x3ul << PWM_WGCTL0_PRDPCTL0_Pos)

#define PWM_WGCTL0_PRDPCTL1_Pos          (18)
#define PWM_WGCTL0_PRDPCTL1_Msk          (0x3ul << PWM_WGCTL0_PRDPCTL1_Pos)

#define PWM_WGCTL0_PRDPCTL2_Pos          (20)
#define PWM_WGCTL0_PRDPCTL2_Msk          (0x3ul << PWM_WGCTL0_PRDPCTL2_Pos)

#define PWM_WGCTL0_PRDPCTL3_Pos          (22)
#define PWM_WGCTL0_PRDPCTL3_Msk          (0x3ul << PWM_WGCTL0_PRDPCTL3_Pos)

#define PWM_WGCTL0_PRDPCTL4_Pos          (24)
#define PWM_WGCTL0_PRDPCTL4_Msk          (0x3ul << PWM_WGCTL0_PRDPCTL4_Pos)

#define PWM_WGCTL0_PRDPCTL5_Pos          (26)
#define PWM_WGCTL0_PRDPCTL5_Msk          (0x3ul << PWM_WGCTL0_PRDPCTL5_Pos)

#define PWM_WGCTL1_CMPUCTLn_Pos          (0)
#define PWM_WGCTL1_CMPUCTLn_Msk          (0xffful << PWM_WGCTL1_CMPUCTLn_Pos)

#define PWM_WGCTL1_CMPUCTL0_Pos          (0)
#define PWM_WGCTL1_CMPUCTL0_Msk          (0x3ul << PWM_WGCTL1_CMPUCTL0_Pos)

#define PWM_WGCTL1_CMPUCTL1_Pos          (2)
#define PWM_WGCTL1_CMPUCTL1_Msk          (0x3ul << PWM_WGCTL1_CMPUCTL1_Pos)

#define PWM_WGCTL1_CMPUCTL2_Pos          (4)
#define PWM_WGCTL1_CMPUCTL2_Msk          (0x3ul << PWM_WGCTL1_CMPUCTL2_Pos)

#define PWM_WGCTL1_CMPUCTL3_Pos          (6)
#define PWM_WGCTL1_CMPUCTL3_Msk          (0x3ul << PWM_WGCTL1_CMPUCTL3_Pos)

#define PWM_WGCTL1_CMPUCTL4_Pos          (8)
#define PWM_WGCTL1_CMPUCTL4_Msk          (0x3ul << PWM_WGCTL1_CMPUCTL4_Pos)

#define PWM_WGCTL1_CMPUCTL5_Pos          (10)
#define PWM_WGCTL1_CMPUCTL5_Msk          (0x3ul << PWM_WGCTL1_CMPUCTL5_Pos)

#define PWM_WGCTL1_CMPDCTLn_Pos          (16)
#define PWM_WGCTL1_CMPDCTLn_Msk          (0xffful << PWM_WGCTL1_CMPDCTLn_Pos)

#define PWM_WGCTL1_CMPDCTL0_Pos          (16)
#define PWM_WGCTL1_CMPDCTL0_Msk          (0x3ul << PWM_WGCTL1_CMPDCTL0_Pos)

#define PWM_WGCTL1_CMPDCTL1_Pos          (18)
#define PWM_WGCTL1_CMPDCTL1_Msk          (0x3ul << PWM_WGCTL1_CMPDCTL1_Pos)

#define PWM_WGCTL1_CMPDCTL2_Pos          (20)
#define PWM_WGCTL1_CMPDCTL2_Msk          (0x3ul << PWM_WGCTL1_CMPDCTL2_Pos)

#define PWM_WGCTL1_CMPDCTL3_Pos          (22)
#define PWM_WGCTL1_CMPDCTL3_Msk          (0x3ul << PWM_WGCTL1_CMPDCTL3_Pos)

#define PWM_WGCTL1_CMPDCTL4_Pos          (24)
#define PWM_WGCTL1_CMPDCTL4_Msk          (0x3ul << PWM_WGCTL1_CMPDCTL4_Pos)

#define PWM_WGCTL1_CMPDCTL5_Pos          (26)
#define PWM_WGCTL1_CMPDCTL5_Msk          (0x3ul << PWM_WGCTL1_CMPDCTL5_Pos)

#define PWM_MSKEN_MSKENn_Pos             (0)
#define PWM_MSKEN_MSKENn_Msk             (0x3ful << PWM_MSKEN_MSKENn_Pos)

#define PWM_MSKEN_MSKEN0_Pos             (0)
#define PWM_MSKEN_MSKEN0_Msk             (0x1ul << PWM_MSKEN_MSKEN0_Pos)

#define PWM_MSKEN_MSKEN1_Pos             (1)
#define PWM_MSKEN_MSKEN1_Msk             (0x1ul << PWM_MSKEN_MSKEN1_Pos)

#define PWM_MSKEN_MSKEN2_Pos             (2)
#define PWM_MSKEN_MSKEN2_Msk             (0x1ul << PWM_MSKEN_MSKEN2_Pos)

#define PWM_MSKEN_MSKEN3_Pos             (3)
#define PWM_MSKEN_MSKEN3_Msk             (0x1ul << PWM_MSKEN_MSKEN3_Pos)

#define PWM_MSKEN_MSKEN4_Pos             (4)
#define PWM_MSKEN_MSKEN4_Msk             (0x1ul << PWM_MSKEN_MSKEN4_Pos)

#define PWM_MSKEN_MSKEN5_Pos             (5)
#define PWM_MSKEN_MSKEN5_Msk             (0x1ul << PWM_MSKEN_MSKEN5_Pos)

#define PWM_MSK_MSKDATn_Pos              (0)
#define PWM_MSK_MSKDATn_Msk              (0x3ful << PWM_MSK_MSKDATn_Pos)

#define PWM_MSK_MSKDAT0_Pos              (0)
#define PWM_MSK_MSKDAT0_Msk              (0x1ul << PWM_MSK_MSKDAT0_Pos)

#define PWM_MSK_MSKDAT1_Pos              (1)
#define PWM_MSK_MSKDAT1_Msk              (0x1ul << PWM_MSK_MSKDAT1_Pos)

#define PWM_MSK_MSKDAT2_Pos              (2)
#define PWM_MSK_MSKDAT2_Msk              (0x1ul << PWM_MSK_MSKDAT2_Pos)

#define PWM_MSK_MSKDAT3_Pos              (3)
#define PWM_MSK_MSKDAT3_Msk              (0x1ul << PWM_MSK_MSKDAT3_Pos)

#define PWM_MSK_MSKDAT4_Pos              (4)
#define PWM_MSK_MSKDAT4_Msk              (0x1ul << PWM_MSK_MSKDAT4_Pos)

#define PWM_MSK_MSKDAT5_Pos              (5)
#define PWM_MSK_MSKDAT5_Msk              (0x1ul << PWM_MSK_MSKDAT5_Pos)

#define PWM_BNF_BRK0FEN_Pos              (0)
#define PWM_BNF_BRK0FEN_Msk              (0x1ul << PWM_BNF_BRK0FEN_Pos)

#define PWM_BNF_BRK0FCS_Pos              (1)
#define PWM_BNF_BRK0FCS_Msk              (0x7ul << PWM_BNF_BRK0FCS_Pos)

#define PWM_BNF_BRK0FCNT_Pos             (4)
#define PWM_BNF_BRK0FCNT_Msk             (0x7ul << PWM_BNF_BRK0FCNT_Pos)

#define PWM_BNF_BRK0PINV_Pos             (7)
#define PWM_BNF_BRK0PINV_Msk             (0x1ul << PWM_BNF_BRK0PINV_Pos)

#define PWM_BNF_BRK1FEN_Pos              (8)
#define PWM_BNF_BRK1FEN_Msk              (0x1ul << PWM_BNF_BRK1FEN_Pos)

#define PWM_BNF_BRK1FCS_Pos              (9)
#define PWM_BNF_BRK1FCS_Msk              (0x7ul << PWM_BNF_BRK1FCS_Pos)

#define PWM_BNF_BRK1FCNT_Pos             (12)
#define PWM_BNF_BRK1FCNT_Msk             (0x7ul << PWM_BNF_BRK1FCNT_Pos)

#define PWM_BNF_BRK1PINV_Pos             (15)
#define PWM_BNF_BRK1PINV_Msk             (0x1ul << PWM_BNF_BRK1PINV_Pos)

#define PWM_FAILBRK_CSSBRKEN_Pos         (0)
#define PWM_FAILBRK_CSSBRKEN_Msk         (0x1ul << PWM_FAILBRK_CSSBRKEN_Pos)

#define PWM_FAILBRK_BODBRKEN_Pos         (1)
#define PWM_FAILBRK_BODBRKEN_Msk         (0x1ul << PWM_FAILBRK_BODBRKEN_Pos)

#define PWM_FAILBRK_RAMBRKEN_Pos         (2)
#define PWM_FAILBRK_RAMBRKEN_Msk         (0x1ul << PWM_FAILBRK_RAMBRKEN_Pos)

#define PWM_FAILBRK_CORBRKEN_Pos         (3)
#define PWM_FAILBRK_CORBRKEN_Msk         (0x1ul << PWM_FAILBRK_CORBRKEN_Pos)

#define PWM_BRKCTL0_1_CP0EEN_Pos         (0)
#define PWM_BRKCTL0_1_CP0EEN_Msk         (0x1ul << PWM_BRKCTL0_1_CP0EEN_Pos)

#define PWM_BRKCTL0_1_CP1EEN_Pos         (1)
#define PWM_BRKCTL0_1_CP1EEN_Msk         (0x1ul << PWM_BRKCTL0_1_CP1EEN_Pos)

#define PWM_BRKCTL0_1_BRKP0EEN_Pos       (4)
#define PWM_BRKCTL0_1_BRKP0EEN_Msk       (0x1ul << PWM_BRKCTL0_1_BRKP0EEN_Pos)

#define PWM_BRKCTL0_1_BRKP1EEN_Pos       (5)
#define PWM_BRKCTL0_1_BRKP1EEN_Msk       (0x1ul << PWM_BRKCTL0_1_BRKP1EEN_Pos)

#define PWM_BRKCTL0_1_SYSEEN_Pos         (7)
#define PWM_BRKCTL0_1_SYSEEN_Msk         (0x1ul << PWM_BRKCTL0_1_SYSEEN_Pos)

#define PWM_BRKCTL0_1_CP0LEN_Pos         (8)
#define PWM_BRKCTL0_1_CP0LEN_Msk         (0x1ul << PWM_BRKCTL0_1_CP0LEN_Pos)

#define PWM_BRKCTL0_1_CP1LEN_Pos         (9)
#define PWM_BRKCTL0_1_CP1LEN_Msk         (0x1ul << PWM_BRKCTL0_1_CP1LEN_Pos)

#define PWM_BRKCTL0_1_BRKP0LEN_Pos       (12)
#define PWM_BRKCTL0_1_BRKP0LEN_Msk       (0x1ul << PWM_BRKCTL0_1_BRKP0LEN_Pos)

#define PWM_BRKCTL0_1_BRKP1LEN_Pos       (13)
#define PWM_BRKCTL0_1_BRKP1LEN_Msk       (0x1ul << PWM_BRKCTL0_1_BRKP1LEN_Pos)

#define PWM_BRKCTL0_1_SYSLEN_Pos          (15)
#define PWM_BRKCTL0_1_SYSLEN_Msk          (0x1ul << PWM_BRKCTL0_1_SYSLEN_Pos)

#define PWM_BRKCTL0_1_BRKAEVEN_Pos       (16)
#define PWM_BRKCTL0_1_BRKAEVEN_Msk       (0x3ul << PWM_BRKCTL0_1_BRKAEVEN_Pos)

#define PWM_BRKCTL0_1_BRKAODD_Pos        (18)
#define PWM_BRKCTL0_1_BRKAODD_Msk        (0x3ul << PWM_BRKCTL0_1_BRKAODD_Pos)

#define PWM_BRKCTL2_3_CP0EEN_Pos         (0)
#define PWM_BRKCTL2_3_CP0EEN_Msk         (0x1ul << PWM_BRKCTL2_3_CP0EEN_Pos)

#define PWM_BRKCTL2_3_CP1EEN_Pos         (1)
#define PWM_BRKCTL2_3_CP1EEN_Msk         (0x1ul << PWM_BRKCTL2_3_CP1EEN_Pos)

#define PWM_BRKCTL2_3_BRKP0EEN_Pos       (4)
#define PWM_BRKCTL2_3_BRKP0EEN_Msk       (0x1ul << PWM_BRKCTL2_3_BRKP0EEN_Pos)

#define PWM_BRKCTL2_3_BRKP1EEN_Pos       (5)
#define PWM_BRKCTL2_3_BRKP1EEN_Msk       (0x1ul << PWM_BRKCTL2_3_BRKP1EEN_Pos)

#define PWM_BRKCTL2_3_SYSEEN_Pos         (7)
#define PWM_BRKCTL2_3_SYSEEN_Msk         (0x1ul << PWM_BRKCTL2_3_SYSEEN_Pos)

#define PWM_BRKCTL2_3_CP0LEN_Pos         (8)
#define PWM_BRKCTL2_3_CP0LEN_Msk         (0x1ul << PWM_BRKCTL2_3_CP0LEN_Pos)

#define PWM_BRKCTL2_3_CP1LEN_Pos         (9)
#define PWM_BRKCTL2_3_CP1LEN_Msk         (0x1ul << PWM_BRKCTL2_3_CP1LEN_Pos)

#define PWM_BRKCTL2_3_BRKP0LEN_Pos       (12)
#define PWM_BRKCTL2_3_BRKP0LEN_Msk       (0x1ul << PWM_BRKCTL2_3_BRKP0LEN_Pos)

#define PWM_BRKCTL2_3_BRKP1LEN_Pos       (13)
#define PWM_BRKCTL2_3_BRKP1LEN_Msk       (0x1ul << PWM_BRKCTL2_3_BRKP1LEN_Pos)

#define PWM_BRKCTL2_3_SYSLEN_Pos          (15)
#define PWM_BRKCTL2_3_SYSLEN_Msk          (0x1ul << PWM_BRKCTL2_3_SYSLEN_Pos)

#define PWM_BRKCTL2_3_BRKAEVEN_Pos       (16)
#define PWM_BRKCTL2_3_BRKAEVEN_Msk       (0x3ul << PWM_BRKCTL2_3_BRKAEVEN_Pos)

#define PWM_BRKCTL2_3_BRKAODD_Pos        (18)
#define PWM_BRKCTL2_3_BRKAODD_Msk        (0x3ul << PWM_BRKCTL2_3_BRKAODD_Pos)

#define PWM_BRKCTL4_5_CP0EEN_Pos         (0)
#define PWM_BRKCTL4_5_CP0EEN_Msk         (0x1ul << PWM_BRKCTL4_5_CP0EEN_Pos)

#define PWM_BRKCTL4_5_CP1EEN_Pos         (1)
#define PWM_BRKCTL4_5_CP1EEN_Msk         (0x1ul << PWM_BRKCTL4_5_CP1EEN_Pos)

#define PWM_BRKCTL4_5_BRKP0EEN_Pos       (4)
#define PWM_BRKCTL4_5_BRKP0EEN_Msk       (0x1ul << PWM_BRKCTL4_5_BRKP0EEN_Pos)

#define PWM_BRKCTL4_5_BRKP1EEN_Pos       (5)
#define PWM_BRKCTL4_5_BRKP1EEN_Msk       (0x1ul << PWM_BRKCTL4_5_BRKP1EEN_Pos)

#define PWM_BRKCTL4_5_SYSEEN_Pos         (7)
#define PWM_BRKCTL4_5_SYSEEN_Msk         (0x1ul << PWM_BRKCTL4_5_SYSEEN_Pos)

#define PWM_BRKCTL4_5_CP0LEN_Pos         (8)
#define PWM_BRKCTL4_5_CP0LEN_Msk         (0x1ul << PWM_BRKCTL4_5_CP0LEN_Pos)

#define PWM_BRKCTL4_5_CP1LEN_Pos         (9)
#define PWM_BRKCTL4_5_CP1LEN_Msk         (0x1ul << PWM_BRKCTL4_5_CP1LEN_Pos)

#define PWM_BRKCTL4_5_BRKP0LEN_Pos       (12)
#define PWM_BRKCTL4_5_BRKP0LEN_Msk       (0x1ul << PWM_BRKCTL4_5_BRKP0LEN_Pos)

#define PWM_BRKCTL4_5_BRKP1LEN_Pos       (13)
#define PWM_BRKCTL4_5_BRKP1LEN_Msk       (0x1ul << PWM_BRKCTL4_5_BRKP1LEN_Pos)

#define PWM_BRKCTL4_5_SYSLEN_Pos          (15)
#define PWM_BRKCTL4_5_SYSLEN_Msk          (0x1ul << PWM_BRKCTL4_5_SYSLEN_Pos)

#define PWM_BRKCTL4_5_BRKAEVEN_Pos       (16)
#define PWM_BRKCTL4_5_BRKAEVEN_Msk       (0x3ul << PWM_BRKCTL4_5_BRKAEVEN_Pos)

#define PWM_BRKCTL4_5_BRKAODD_Pos        (18)
#define PWM_BRKCTL4_5_BRKAODD_Msk        (0x3ul << PWM_BRKCTL4_5_BRKAODD_Pos)

#define PWM_POLCTL_PINVn_Pos             (0)
#define PWM_POLCTL_PINVn_Msk             (0x3ful << PWM_POLCTL_PINVn_Pos)

#define PWM_POLCTL_PINV0_Pos             (0)
#define PWM_POLCTL_PINV0_Msk             (0x1ul << PWM_POLCTL_PINV0_Pos)

#define PWM_POLCTL_PINV1_Pos             (1)
#define PWM_POLCTL_PINV1_Msk             (0x1ul << PWM_POLCTL_PINV1_Pos)

#define PWM_POLCTL_PINV2_Pos             (2)
#define PWM_POLCTL_PINV2_Msk             (0x1ul << PWM_POLCTL_PINV2_Pos)

#define PWM_POLCTL_PINV3_Pos             (3)
#define PWM_POLCTL_PINV3_Msk             (0x1ul << PWM_POLCTL_PINV3_Pos)

#define PWM_POLCTL_PINV4_Pos             (4)
#define PWM_POLCTL_PINV4_Msk             (0x1ul << PWM_POLCTL_PINV4_Pos)

#define PWM_POLCTL_PINV5_Pos             (5)
#define PWM_POLCTL_PINV5_Msk             (0x1ul << PWM_POLCTL_PINV5_Pos)

#define PWM_POEN_POENn_Pos               (0)
#define PWM_POEN_POENn_Msk               (0x3ful << PWM_POEN_POENn_Pos)

#define PWM_POEN_POEN0_Pos               (0)
#define PWM_POEN_POEN0_Msk               (0x1ul << PWM_POEN_POEN0_Pos)

#define PWM_POEN_POEN1_Pos               (1)
#define PWM_POEN_POEN1_Msk               (0x1ul << PWM_POEN_POEN1_Pos)

#define PWM_POEN_POEN2_Pos               (2)
#define PWM_POEN_POEN2_Msk               (0x1ul << PWM_POEN_POEN2_Pos)

#define PWM_POEN_POEN3_Pos               (3)
#define PWM_POEN_POEN3_Msk               (0x1ul << PWM_POEN_POEN3_Pos)

#define PWM_POEN_POEN4_Pos               (4)
#define PWM_POEN_POEN4_Msk               (0x1ul << PWM_POEN_POEN4_Pos)

#define PWM_POEN_POEN5_Pos               (5)
#define PWM_POEN_POEN5_Msk               (0x1ul << PWM_POEN_POEN5_Pos)

#define PWM_SWBRK_BRKLTRGn_Pos           (8)
#define PWM_SWBRK_BRKLTRGn_Msk           (0x7ul << PWM_SWBRK_BRKLTRGn_Pos)

#define PWM_SWBRK_BRKLTRG0_Pos           (8)
#define PWM_SWBRK_BRKLTRG0_Msk           (0x1ul << PWM_SWBRK_BRKLTRG0_Pos)

#define PWM_SWBRK_BRKLTRG2_Pos           (9)
#define PWM_SWBRK_BRKLTRG2_Msk           (0x1ul << PWM_SWBRK_BRKLTRG2_Pos)

#define PWM_SWBRK_BRKLTRG4_Pos           (10)
#define PWM_SWBRK_BRKLTRG4_Msk           (0x1ul << PWM_SWBRK_BRKLTRG4_Pos)

#define PWM_INTEN0_ZIENn_Pos             (0)
#define PWM_INTEN0_ZIENn_Msk             (0x3ful << PWM_INTEN0_ZIENn_Pos)

#define PWM_INTEN0_ZIEN0_Pos             (0)
#define PWM_INTEN0_ZIEN0_Msk             (0x1ul << PWM_INTEN0_ZIEN0_Pos)

#define PWM_INTEN0_ZIEN1_Pos             (1)
#define PWM_INTEN0_ZIEN1_Msk             (0x1ul << PWM_INTEN0_ZIEN1_Pos)

#define PWM_INTEN0_ZIEN2_Pos             (2)
#define PWM_INTEN0_ZIEN2_Msk             (0x1ul << PWM_INTEN0_ZIEN2_Pos)

#define PWM_INTEN0_ZIEN3_Pos             (3)
#define PWM_INTEN0_ZIEN3_Msk             (0x1ul << PWM_INTEN0_ZIEN3_Pos)

#define PWM_INTEN0_ZIEN4_Pos             (4)
#define PWM_INTEN0_ZIEN4_Msk             (0x1ul << PWM_INTEN0_ZIEN4_Pos)

#define PWM_INTEN0_ZIEN5_Pos             (5)
#define PWM_INTEN0_ZIEN5_Msk             (0x1ul << PWM_INTEN0_ZIEN5_Pos)

#define PWM_INTEN0_IFAIEN0_1_Pos         (7)
#define PWM_INTEN0_IFAIEN0_1_Msk         (0x1ul << PWM_INTEN0_IFAIEN0_1_Pos)

#define PWM_INTEN0_PIENn_Pos             (8)
#define PWM_INTEN0_PIENn_Msk             (0x3ful << PWM_INTEN0_PIENn_Pos)

#define PWM_INTEN0_PIEN0_Pos             (8)
#define PWM_INTEN0_PIEN0_Msk             (0x1ul << PWM_INTEN0_PIEN0_Pos)

#define PWM_INTEN0_PIEN1_Pos             (9)
#define PWM_INTEN0_PIEN1_Msk             (0x1ul << PWM_INTEN0_PIEN1_Pos)

#define PWM_INTEN0_PIEN2_Pos             (10)
#define PWM_INTEN0_PIEN2_Msk             (0x1ul << PWM_INTEN0_PIEN2_Pos)

#define PWM_INTEN0_PIEN3_Pos             (11)
#define PWM_INTEN0_PIEN3_Msk             (0x1ul << PWM_INTEN0_PIEN3_Pos)

#define PWM_INTEN0_PIEN4_Pos             (12)
#define PWM_INTEN0_PIEN4_Msk             (0x1ul << PWM_INTEN0_PIEN4_Pos)

#define PWM_INTEN0_PIEN5_Pos             (13)
#define PWM_INTEN0_PIEN5_Msk             (0x1ul << PWM_INTEN0_PIEN5_Pos)

#define PWM_INTEN0_IFAIEN2_3_Pos         (15)
#define PWM_INTEN0_IFAIEN2_3_Msk         (0x1ul << PWM_INTEN0_IFAIEN2_3_Pos)

#define PWM_INTEN0_CMPUIENn_Pos          (16)
#define PWM_INTEN0_CMPUIENn_Msk          (0x3ful << PWM_INTEN0_CMPUIENn_Pos)

#define PWM_INTEN0_CMPUIEN0_Pos          (16)
#define PWM_INTEN0_CMPUIEN0_Msk          (0x1ul << PWM_INTEN0_CMPUIEN0_Pos)

#define PWM_INTEN0_CMPUIEN1_Pos          (17)
#define PWM_INTEN0_CMPUIEN1_Msk          (0x1ul << PWM_INTEN0_CMPUIEN1_Pos)

#define PWM_INTEN0_CMPUIEN2_Pos          (18)
#define PWM_INTEN0_CMPUIEN2_Msk          (0x1ul << PWM_INTEN0_CMPUIEN2_Pos)

#define PWM_INTEN0_CMPUIEN3_Pos          (19)
#define PWM_INTEN0_CMPUIEN3_Msk          (0x1ul << PWM_INTEN0_CMPUIEN3_Pos)

#define PWM_INTEN0_CMPUIEN4_Pos          (20)
#define PWM_INTEN0_CMPUIEN4_Msk          (0x1ul << PWM_INTEN0_CMPUIEN4_Pos)

#define PWM_INTEN0_CMPUIEN5_Pos          (21)
#define PWM_INTEN0_CMPUIEN5_Msk          (0x1ul << PWM_INTEN0_CMPUIEN5_Pos)

#define PWM_INTEN0_IFAIEN4_5_Pos         (23)
#define PWM_INTEN0_IFAIEN4_5_Msk         (0x1ul << PWM_INTEN0_IFAIEN4_5_Pos)

#define PWM_INTEN0_CMPDIENn_Pos          (24)
#define PWM_INTEN0_CMPDIENn_Msk          (0x3ful << PWM_INTEN0_CMPDIENn_Pos)

#define PWM_INTEN0_CMPDIEN0_Pos          (24)
#define PWM_INTEN0_CMPDIEN0_Msk          (0x1ul << PWM_INTEN0_CMPDIEN0_Pos)

#define PWM_INTEN0_CMPDIEN1_Pos          (25)
#define PWM_INTEN0_CMPDIEN1_Msk          (0x1ul << PWM_INTEN0_CMPDIEN1_Pos)

#define PWM_INTEN0_CMPDIEN2_Pos          (26)
#define PWM_INTEN0_CMPDIEN2_Msk          (0x1ul << PWM_INTEN0_CMPDIEN2_Pos)

#define PWM_INTEN0_CMPDIEN3_Pos          (27)
#define PWM_INTEN0_CMPDIEN3_Msk          (0x1ul << PWM_INTEN0_CMPDIEN3_Pos)

#define PWM_INTEN0_CMPDIEN4_Pos          (28)
#define PWM_INTEN0_CMPDIEN4_Msk          (0x1ul << PWM_INTEN0_CMPDIEN4_Pos)

#define PWM_INTEN0_CMPDIEN5_Pos          (29)
#define PWM_INTEN0_CMPDIEN5_Msk          (0x1ul << PWM_INTEN0_CMPDIEN5_Pos)

#define PWM_INTEN1_BRKEIEN0_1_Pos        (0)
#define PWM_INTEN1_BRKEIEN0_1_Msk        (0x1ul << PWM_INTEN1_BRKEIEN0_1_Pos)

#define PWM_INTEN1_BRKEIEN2_3_Pos        (1)
#define PWM_INTEN1_BRKEIEN2_3_Msk        (0x1ul << PWM_INTEN1_BRKEIEN2_3_Pos)

#define PWM_INTEN1_BRKEIEN4_5_Pos        (2)
#define PWM_INTEN1_BRKEIEN4_5_Msk        (0x1ul << PWM_INTEN1_BRKEIEN4_5_Pos)

#define PWM_INTEN1_BRKLIEN0_1_Pos        (8)
#define PWM_INTEN1_BRKLIEN0_1_Msk        (0x1ul << PWM_INTEN1_BRKLIEN0_1_Pos)

#define PWM_INTEN1_BRKLIEN2_3_Pos        (9)
#define PWM_INTEN1_BRKLIEN2_3_Msk        (0x1ul << PWM_INTEN1_BRKLIEN2_3_Pos)

#define PWM_INTEN1_BRKLIEN4_5_Pos        (10)
#define PWM_INTEN1_BRKLIEN4_5_Msk        (0x1ul << PWM_INTEN1_BRKLIEN4_5_Pos)

#define PWM_INTSTS0_ZIFn_Pos             (0)
#define PWM_INTSTS0_ZIFn_Msk             (0x3ful << PWM_INTSTS0_ZIFn_Pos)

#define PWM_INTSTS0_ZIF0_Pos             (0)
#define PWM_INTSTS0_ZIF0_Msk             (0x1ul << PWM_INTSTS0_ZIF0_Pos)

#define PWM_INTSTS0_ZIF1_Pos             (1)
#define PWM_INTSTS0_ZIF1_Msk             (0x1ul << PWM_INTSTS0_ZIF1_Pos)

#define PWM_INTSTS0_ZIF2_Pos             (2)
#define PWM_INTSTS0_ZIF2_Msk             (0x1ul << PWM_INTSTS0_ZIF2_Pos)

#define PWM_INTSTS0_ZIF3_Pos             (3)
#define PWM_INTSTS0_ZIF3_Msk             (0x1ul << PWM_INTSTS0_ZIF3_Pos)

#define PWM_INTSTS0_ZIF4_Pos             (4)
#define PWM_INTSTS0_ZIF4_Msk             (0x1ul << PWM_INTSTS0_ZIF4_Pos)

#define PWM_INTSTS0_ZIF5_Pos             (5)
#define PWM_INTSTS0_ZIF5_Msk             (0x1ul << PWM_INTSTS0_ZIF5_Pos)

#define PWM_INTSTS0_IFAIF0_1_Pos         (7)
#define PWM_INTSTS0_IFAIF0_1_Msk         (0x1ul << PWM_INTSTS0_IFAIF0_1_Pos)

#define PWM_INTSTS0_PIFn_Pos             (8)
#define PWM_INTSTS0_PIFn_Msk             (0x3ful << PWM_INTSTS0_PIFn_Pos)

#define PWM_INTSTS0_PIF0_Pos             (8)
#define PWM_INTSTS0_PIF0_Msk             (0x1ul << PWM_INTSTS0_PIF0_Pos)

#define PWM_INTSTS0_PIF1_Pos             (9)
#define PWM_INTSTS0_PIF1_Msk             (0x1ul << PWM_INTSTS0_PIF1_Pos)

#define PWM_INTSTS0_PIF2_Pos             (10)
#define PWM_INTSTS0_PIF2_Msk             (0x1ul << PWM_INTSTS0_PIF2_Pos)

#define PWM_INTSTS0_PIF3_Pos             (11)
#define PWM_INTSTS0_PIF3_Msk             (0x1ul << PWM_INTSTS0_PIF3_Pos)

#define PWM_INTSTS0_PIF4_Pos             (12)
#define PWM_INTSTS0_PIF4_Msk             (0x1ul << PWM_INTSTS0_PIF4_Pos)

#define PWM_INTSTS0_PIF5_Pos             (13)
#define PWM_INTSTS0_PIF5_Msk             (0x1ul << PWM_INTSTS0_PIF5_Pos)

#define PWM_INTSTS0_IFAIF2_3_Pos         (15)
#define PWM_INTSTS0_IFAIF2_3_Msk         (0x1ul << PWM_INTSTS0_IFAIF2_3_Pos)

#define PWM_INTSTS0_CMPUIFn_Pos          (16)
#define PWM_INTSTS0_CMPUIFn_Msk          (0x3ful << PWM_INTSTS0_CMPUIFn_Pos)

#define PWM_INTSTS0_CMPUIF0_Pos          (16)
#define PWM_INTSTS0_CMPUIF0_Msk          (0x1ul << PWM_INTSTS0_CMPUIF0_Pos)

#define PWM_INTSTS0_CMPUIF1_Pos          (17)
#define PWM_INTSTS0_CMPUIF1_Msk          (0x1ul << PWM_INTSTS0_CMPUIF1_Pos)

#define PWM_INTSTS0_CMPUIF2_Pos          (18)
#define PWM_INTSTS0_CMPUIF2_Msk          (0x1ul << PWM_INTSTS0_CMPUIF2_Pos)

#define PWM_INTSTS0_CMPUIF3_Pos          (19)
#define PWM_INTSTS0_CMPUIF3_Msk          (0x1ul << PWM_INTSTS0_CMPUIF3_Pos)

#define PWM_INTSTS0_CMPUIF4_Pos          (20)
#define PWM_INTSTS0_CMPUIF4_Msk          (0x1ul << PWM_INTSTS0_CMPUIF4_Pos)

#define PWM_INTSTS0_CMPUIF5_Pos          (21)
#define PWM_INTSTS0_CMPUIF5_Msk          (0x1ul << PWM_INTSTS0_CMPUIF5_Pos)

#define PWM_INTSTS0_IFAIF4_5_Pos         (23)
#define PWM_INTSTS0_IFAIF4_5_Msk         (0x1ul << PWM_INTSTS0_IFAIF4_5_Pos)

#define PWM_INTSTS0_CMPDIFn_Pos          (24)
#define PWM_INTSTS0_CMPDIFn_Msk          (0x3ful << PWM_INTSTS0_CMPDIFn_Pos)

#define PWM_INTSTS0_CMPDIF0_Pos          (24)
#define PWM_INTSTS0_CMPDIF0_Msk          (0x1ul << PWM_INTSTS0_CMPDIF0_Pos)

#define PWM_INTSTS0_CMPDIF1_Pos          (25)
#define PWM_INTSTS0_CMPDIF1_Msk          (0x1ul << PWM_INTSTS0_CMPDIF1_Pos)

#define PWM_INTSTS0_CMPDIF2_Pos          (26)
#define PWM_INTSTS0_CMPDIF2_Msk          (0x1ul << PWM_INTSTS0_CMPDIF2_Pos)

#define PWM_INTSTS0_CMPDIF3_Pos          (27)
#define PWM_INTSTS0_CMPDIF3_Msk          (0x1ul << PWM_INTSTS0_CMPDIF3_Pos)

#define PWM_INTSTS0_CMPDIF4_Pos          (28)
#define PWM_INTSTS0_CMPDIF4_Msk          (0x1ul << PWM_INTSTS0_CMPDIF4_Pos)

#define PWM_INTSTS0_CMPDIF5_Pos          (29)
#define PWM_INTSTS0_CMPDIF5_Msk          (0x1ul << PWM_INTSTS0_CMPDIF5_Pos)

#define PWM_INTSTS1_BRKEIFn_Pos          (0)
#define PWM_INTSTS1_BRKEIFn_Msk          (0x3ful << PWM_INTSTS1_BRKEIFn_Pos)

#define PWM_INTSTS1_BRKEIF0_Pos          (0)
#define PWM_INTSTS1_BRKEIF0_Msk          (0x1ul << PWM_INTSTS1_BRKEIF0_Pos)

#define PWM_INTSTS1_BRKEIF1_Pos          (1)
#define PWM_INTSTS1_BRKEIF1_Msk          (0x1ul << PWM_INTSTS1_BRKEIF1_Pos)

#define PWM_INTSTS1_BRKEIF2_Pos          (2)
#define PWM_INTSTS1_BRKEIF2_Msk          (0x1ul << PWM_INTSTS1_BRKEIF2_Pos)

#define PWM_INTSTS1_BRKEIF3_Pos          (3)
#define PWM_INTSTS1_BRKEIF3_Msk          (0x1ul << PWM_INTSTS1_BRKEIF3_Pos)

#define PWM_INTSTS1_BRKEIF4_Pos          (4)
#define PWM_INTSTS1_BRKEIF4_Msk          (0x1ul << PWM_INTSTS1_BRKEIF4_Pos)

#define PWM_INTSTS1_BRKEIF5_Pos          (5)
#define PWM_INTSTS1_BRKEIF5_Msk          (0x1ul << PWM_INTSTS1_BRKEIF5_Pos)

#define PWM_INTSTS1_BRKLIFn_Pos          (8)
#define PWM_INTSTS1_BRKLIFn_Msk          (0x3ful << PWM_INTSTS1_BRKLIFn_Pos)

#define PWM_INTSTS1_BRKLIF0_Pos          (8)
#define PWM_INTSTS1_BRKLIF0_Msk          (0x1ul << PWM_INTSTS1_BRKLIF0_Pos)

#define PWM_INTSTS1_BRKLIF1_Pos          (9)
#define PWM_INTSTS1_BRKLIF1_Msk          (0x1ul << PWM_INTSTS1_BRKLIF1_Pos)

#define PWM_INTSTS1_BRKLIF2_Pos          (10)
#define PWM_INTSTS1_BRKLIF2_Msk          (0x1ul << PWM_INTSTS1_BRKLIF2_Pos)

#define PWM_INTSTS1_BRKLIF3_Pos          (11)
#define PWM_INTSTS1_BRKLIF3_Msk          (0x1ul << PWM_INTSTS1_BRKLIF3_Pos)

#define PWM_INTSTS1_BRKLIF4_Pos          (12)
#define PWM_INTSTS1_BRKLIF4_Msk          (0x1ul << PWM_INTSTS1_BRKLIF4_Pos)

#define PWM_INTSTS1_BRKLIF5_Pos          (13)
#define PWM_INTSTS1_BRKLIF5_Msk          (0x1ul << PWM_INTSTS1_BRKLIF5_Pos)

#define PWM_INTSTS1_BRKESTS0_Pos         (16)
#define PWM_INTSTS1_BRKESTS0_Msk         (0x1ul << PWM_INTSTS1_BRKESTS0_Pos)

#define PWM_INTSTS1_BRKESTS1_Pos         (17)
#define PWM_INTSTS1_BRKESTS1_Msk         (0x1ul << PWM_INTSTS1_BRKESTS1_Pos)

#define PWM_INTSTS1_BRKESTS2_Pos         (18)
#define PWM_INTSTS1_BRKESTS2_Msk         (0x1ul << PWM_INTSTS1_BRKESTS2_Pos)

#define PWM_INTSTS1_BRKESTS3_Pos         (19)
#define PWM_INTSTS1_BRKESTS3_Msk         (0x1ul << PWM_INTSTS1_BRKESTS3_Pos)

#define PWM_INTSTS1_BRKESTS4_Pos         (20)
#define PWM_INTSTS1_BRKESTS4_Msk         (0x1ul << PWM_INTSTS1_BRKESTS4_Pos)

#define PWM_INTSTS1_BRKESTS5_Pos         (21)
#define PWM_INTSTS1_BRKESTS5_Msk         (0x1ul << PWM_INTSTS1_BRKESTS5_Pos)

#define PWM_INTSTS1_BRKLSTS0_Pos         (24)
#define PWM_INTSTS1_BRKLSTS0_Msk         (0x1ul << PWM_INTSTS1_BRKLSTS0_Pos)

#define PWM_INTSTS1_BRKLSTS1_Pos         (25)
#define PWM_INTSTS1_BRKLSTS1_Msk         (0x1ul << PWM_INTSTS1_BRKLSTS1_Pos)

#define PWM_INTSTS1_BRKLSTS2_Pos         (26)
#define PWM_INTSTS1_BRKLSTS2_Msk         (0x1ul << PWM_INTSTS1_BRKLSTS2_Pos)

#define PWM_INTSTS1_BRKLSTS3_Pos         (27)
#define PWM_INTSTS1_BRKLSTS3_Msk         (0x1ul << PWM_INTSTS1_BRKLSTS3_Pos)

#define PWM_INTSTS1_BRKLSTS4_Pos         (28)
#define PWM_INTSTS1_BRKLSTS4_Msk         (0x1ul << PWM_INTSTS1_BRKLSTS4_Pos)

#define PWM_INTSTS1_BRKLSTS5_Pos         (29)
#define PWM_INTSTS1_BRKLSTS5_Msk         (0x1ul << PWM_INTSTS1_BRKLSTS5_Pos)

#define PWM_IFA_IFCNT0_1_Pos             (0)
#define PWM_IFA_IFCNT0_1_Msk             (0xful << PWM_IFA_IFCNT0_1_Pos)

#define PWM_IFA_IFSEL0_1_Pos             (4)
#define PWM_IFA_IFSEL0_1_Msk             (0x7ul << PWM_IFA_IFSEL0_1_Pos)

#define PWM_IFA_IFAEN0_1_Pos             (7)
#define PWM_IFA_IFAEN0_1_Msk             (0x1ul << PWM_IFA_IFAEN0_1_Pos)

#define PWM_IFA_IFCNT2_3_Pos             (8)
#define PWM_IFA_IFCNT2_3_Msk             (0xful << PWM_IFA_IFCNT2_3_Pos)

#define PWM_IFA_IFSEL2_3_Pos             (12)
#define PWM_IFA_IFSEL2_3_Msk             (0x7ul << PWM_IFA_IFSEL2_3_Pos)

#define PWM_IFA_IFAEN2_3_Pos             (15)
#define PWM_IFA_IFAEN2_3_Msk             (0x1ul << PWM_IFA_IFAEN2_3_Pos)

#define PWM_IFA_IFCNT4_5_Pos             (16)
#define PWM_IFA_IFCNT4_5_Msk             (0xful << PWM_IFA_IFCNT4_5_Pos)

#define PWM_IFA_IFSEL4_5_Pos             (20)
#define PWM_IFA_IFSEL4_5_Msk             (0x7ul << PWM_IFA_IFSEL4_5_Pos)

#define PWM_IFA_IFAEN4_5_Pos             (23)
#define PWM_IFA_IFAEN4_5_Msk             (0x1ul << PWM_IFA_IFAEN4_5_Pos)

#define PWM_DACTRGEN_ZTEn_Pos            (0)
#define PWM_DACTRGEN_ZTEn_Msk            (0x3ful << PWM_DACTRGEN_ZTEn_Pos)

#define PWM_DACTRGEN_ZTE0_Pos            (0)
#define PWM_DACTRGEN_ZTE0_Msk            (0x1ul << PWM_DACTRGEN_ZTE0_Pos)

#define PWM_DACTRGEN_ZTE1_Pos            (1)
#define PWM_DACTRGEN_ZTE1_Msk            (0x1ul << PWM_DACTRGEN_ZTE1_Pos)

#define PWM_DACTRGEN_ZTE2_Pos            (2)
#define PWM_DACTRGEN_ZTE2_Msk            (0x1ul << PWM_DACTRGEN_ZTE2_Pos)

#define PWM_DACTRGEN_ZTE3_Pos            (3)
#define PWM_DACTRGEN_ZTE3_Msk            (0x1ul << PWM_DACTRGEN_ZTE3_Pos)

#define PWM_DACTRGEN_ZTE4_Pos            (4)
#define PWM_DACTRGEN_ZTE4_Msk            (0x1ul << PWM_DACTRGEN_ZTE4_Pos)

#define PWM_DACTRGEN_ZTE5_Pos            (5)
#define PWM_DACTRGEN_ZTE5_Msk            (0x1ul << PWM_DACTRGEN_ZTE5_Pos)

#define PWM_DACTRGEN_PTEn_Pos            (8)
#define PWM_DACTRGEN_PTEn_Msk            (0x3ful << PWM_DACTRGEN_PTEn_Pos)

#define PWM_DACTRGEN_PTE0_Pos            (8)
#define PWM_DACTRGEN_PTE0_Msk            (0x1ul << PWM_DACTRGEN_PTE0_Pos)

#define PWM_DACTRGEN_PTE1_Pos            (9)
#define PWM_DACTRGEN_PTE1_Msk            (0x1ul << PWM_DACTRGEN_PTE1_Pos)

#define PWM_DACTRGEN_PTE2_Pos            (10)
#define PWM_DACTRGEN_PTE2_Msk            (0x1ul << PWM_DACTRGEN_PTE2_Pos)

#define PWM_DACTRGEN_PTE3_Pos            (11)
#define PWM_DACTRGEN_PTE3_Msk            (0x1ul << PWM_DACTRGEN_PTE3_Pos)

#define PWM_DACTRGEN_PTE4_Pos            (12)
#define PWM_DACTRGEN_PTE4_Msk            (0x1ul << PWM_DACTRGEN_PTE4_Pos)

#define PWM_DACTRGEN_PTE5_Pos            (13)
#define PWM_DACTRGEN_PTE5_Msk            (0x1ul << PWM_DACTRGEN_PTE5_Pos)

#define PWM_DACTRGEN_CUTRGEn_Pos         (16)
#define PWM_DACTRGEN_CUTRGEn_Msk         (0x3ful << PWM_DACTRGEN_CUTRGEn_Pos)

#define PWM_DACTRGEN_CUTRGE0_Pos         (16)
#define PWM_DACTRGEN_CUTRGE0_Msk         (0x1ul << PWM_DACTRGEN_CUTRGE0_Pos)

#define PWM_DACTRGEN_CUTRGE1_Pos         (17)
#define PWM_DACTRGEN_CUTRGE1_Msk         (0x1ul << PWM_DACTRGEN_CUTRGE1_Pos)

#define PWM_DACTRGEN_CUTRGE2_Pos         (18)
#define PWM_DACTRGEN_CUTRGE2_Msk         (0x1ul << PWM_DACTRGEN_CUTRGE2_Pos)

#define PWM_DACTRGEN_CUTRGE3_Pos         (19)
#define PWM_DACTRGEN_CUTRGE3_Msk         (0x1ul << PWM_DACTRGEN_CUTRGE3_Pos)

#define PWM_DACTRGEN_CUTRGE4_Pos         (20)
#define PWM_DACTRGEN_CUTRGE4_Msk         (0x1ul << PWM_DACTRGEN_CUTRGE4_Pos)

#define PWM_DACTRGEN_CUTRGE5_Pos         (21)
#define PWM_DACTRGEN_CUTRGE5_Msk         (0x1ul << PWM_DACTRGEN_CUTRGE5_Pos)

#define PWM_DACTRGEN_CDTRGEn_Pos         (24)
#define PWM_DACTRGEN_CDTRGEn_Msk         (0x3ful << PWM_DACTRGEN_CDTRGEn_Pos)

#define PWM_DACTRGEN_CDTRGE0_Pos         (24)
#define PWM_DACTRGEN_CDTRGE0_Msk         (0x1ul << PWM_DACTRGEN_CDTRGE0_Pos)

#define PWM_DACTRGEN_CDTRGE1_Pos         (25)
#define PWM_DACTRGEN_CDTRGE1_Msk         (0x1ul << PWM_DACTRGEN_CDTRGE1_Pos)

#define PWM_DACTRGEN_CDTRGE2_Pos         (26)
#define PWM_DACTRGEN_CDTRGE2_Msk         (0x1ul << PWM_DACTRGEN_CDTRGE2_Pos)

#define PWM_DACTRGEN_CDTRGE3_Pos         (27)
#define PWM_DACTRGEN_CDTRGE3_Msk         (0x1ul << PWM_DACTRGEN_CDTRGE3_Pos)

#define PWM_DACTRGEN_CDTRGE4_Pos         (28)
#define PWM_DACTRGEN_CDTRGE4_Msk         (0x1ul << PWM_DACTRGEN_CDTRGE4_Pos)

#define PWM_DACTRGEN_CDTRGE5_Pos         (29)
#define PWM_DACTRGEN_CDTRGE5_Msk         (0x1ul << PWM_DACTRGEN_CDTRGE5_Pos)

#define PWM_EADCTS0_TRGSEL0_Pos          (0)
#define PWM_EADCTS0_TRGSEL0_Msk          (0xful << PWM_EADCTS0_TRGSEL0_Pos)

#define PWM_EADCTS0_TRGEN0_Pos           (7)
#define PWM_EADCTS0_TRGEN0_Msk           (0x1ul << PWM_EADCTS0_TRGEN0_Pos)

#define PWM_EADCTS0_TRGSEL1_Pos          (8)
#define PWM_EADCTS0_TRGSEL1_Msk          (0xful << PWM_EADCTS0_TRGSEL1_Pos)

#define PWM_EADCTS0_TRGEN1_Pos           (15)
#define PWM_EADCTS0_TRGEN1_Msk           (0x1ul << PWM_EADCTS0_TRGEN1_Pos)

#define PWM_EADCTS0_TRGSEL2_Pos          (16)
#define PWM_EADCTS0_TRGSEL2_Msk          (0xful << PWM_EADCTS0_TRGSEL2_Pos)

#define PWM_EADCTS0_TRGEN2_Pos           (23)
#define PWM_EADCTS0_TRGEN2_Msk           (0x1ul << PWM_EADCTS0_TRGEN2_Pos)

#define PWM_EADCTS0_TRGSEL3_Pos          (24)
#define PWM_EADCTS0_TRGSEL3_Msk          (0xful << PWM_EADCTS0_TRGSEL3_Pos)

#define PWM_EADCTS0_TRGEN3_Pos           (31)
#define PWM_EADCTS0_TRGEN3_Msk           (0x1ul << PWM_EADCTS0_TRGEN3_Pos)

#define PWM_EADCTS1_TRGSEL4_Pos          (0)
#define PWM_EADCTS1_TRGSEL4_Msk          (0xful << PWM_EADCTS1_TRGSEL4_Pos)

#define PWM_EADCTS1_TRGEN4_Pos           (7)
#define PWM_EADCTS1_TRGEN4_Msk           (0x1ul << PWM_EADCTS1_TRGEN4_Pos)

#define PWM_EADCTS1_TRGSEL5_Pos          (8)
#define PWM_EADCTS1_TRGSEL5_Msk          (0xful << PWM_EADCTS1_TRGSEL5_Pos)

#define PWM_EADCTS1_TRGEN5_Pos           (15)
#define PWM_EADCTS1_TRGEN5_Msk           (0x1ul << PWM_EADCTS1_TRGEN5_Pos)

#define PWM_FTRGCMP0_1_FCMPDAT_Pos       (0)
#define PWM_FTRGCMP0_1_FCMPDAT_Msk       (0xfffful << PWM_FTRGCMP0_1_FCMPDAT_Pos)

#define PWM_FTRGCMP2_3_FCMPDAT_Pos       (0)
#define PWM_FTRGCMP2_3_FCMPDAT_Msk       (0xfffful << PWM_FTRGCMP2_3_FCMPDAT_Pos)

#define PWM_FTRGCMP4_5_FCMPDAT_Pos       (0)
#define PWM_FTRGCMP4_5_FCMPDAT_Msk       (0xfffful << PWM_FTRGCMP4_5_FCMPDAT_Pos)

#define PWM_SSCTL_SSENn_Pos              (0)
#define PWM_SSCTL_SSENn_Msk              (0x3ful << PWM_SSCTL_SSENn_Pos)

#define PWM_SSCTL_SSEN0_Pos              (0)
#define PWM_SSCTL_SSEN0_Msk              (0x1ul << PWM_SSCTL_SSEN0_Pos)

#define PWM_SSCTL_SSEN1_Pos              (1)
#define PWM_SSCTL_SSEN1_Msk              (0x1ul << PWM_SSCTL_SSEN1_Pos)

#define PWM_SSCTL_SSEN2_Pos              (2)
#define PWM_SSCTL_SSEN2_Msk              (0x1ul << PWM_SSCTL_SSEN2_Pos)

#define PWM_SSCTL_SSEN3_Pos              (3)
#define PWM_SSCTL_SSEN3_Msk              (0x1ul << PWM_SSCTL_SSEN3_Pos)

#define PWM_SSCTL_SSEN4_Pos              (4)
#define PWM_SSCTL_SSEN4_Msk              (0x1ul << PWM_SSCTL_SSEN4_Pos)

#define PWM_SSCTL_SSEN5_Pos              (5)
#define PWM_SSCTL_SSEN5_Msk              (0x1ul << PWM_SSCTL_SSEN5_Pos)

#define PWM_SSTRG_CNTSEN_Pos             (0)
#define PWM_SSTRG_CNTSEN_Msk             (0x1ul << PWM_SSTRG_CNTSEN_Pos)

#define PWM_STATUS_CNTMAXn_Pos           (0)
#define PWM_STATUS_CNTMAXn_Msk           (0x3ful << PWM_STATUS_CNTMAXn_Pos)

#define PWM_STATUS_CNTMAX0_Pos           (0)
#define PWM_STATUS_CNTMAX0_Msk           (0x1ul << PWM_STATUS_CNTMAX0_Pos)

#define PWM_STATUS_CNTMAX1_Pos           (1)
#define PWM_STATUS_CNTMAX1_Msk           (0x1ul << PWM_STATUS_CNTMAX1_Pos)

#define PWM_STATUS_CNTMAX2_Pos           (2)
#define PWM_STATUS_CNTMAX2_Msk           (0x1ul << PWM_STATUS_CNTMAX2_Pos)

#define PWM_STATUS_CNTMAX3_Pos           (3)
#define PWM_STATUS_CNTMAX3_Msk           (0x1ul << PWM_STATUS_CNTMAX3_Pos)

#define PWM_STATUS_CNTMAX4_Pos           (4)
#define PWM_STATUS_CNTMAX4_Msk           (0x1ul << PWM_STATUS_CNTMAX4_Pos)

#define PWM_STATUS_CNTMAX5_Pos           (5)
#define PWM_STATUS_CNTMAX5_Msk           (0x1ul << PWM_STATUS_CNTMAX5_Pos)

#define PWM_STATUS_SYNCINn_Pos           (8)
#define PWM_STATUS_SYNCINn_Msk           (0x7ul << PWM_STATUS_SYNCINn_Pos)

#define PWM_STATUS_SYNCIN0_Pos           (8)
#define PWM_STATUS_SYNCIN0_Msk           (0x1ul << PWM_STATUS_SYNCIN0_Pos)

#define PWM_STATUS_SYNCIN2_Pos           (9)
#define PWM_STATUS_SYNCIN2_Msk           (0x1ul << PWM_STATUS_SYNCIN2_Pos)

#define PWM_STATUS_SYNCIN4_Pos           (10)
#define PWM_STATUS_SYNCIN4_Msk           (0x1ul << PWM_STATUS_SYNCIN4_Pos)

#define PWM_STATUS_ADCTRGn_Pos           (16)
#define PWM_STATUS_ADCTRGn_Msk           (0x3ful << PWM_STATUS_ADCTRGn_Pos)

#define PWM_STATUS_ADCTRG0_Pos           (16)
#define PWM_STATUS_ADCTRG0_Msk           (0x1ul << PWM_STATUS_ADCTRG0_Pos)

#define PWM_STATUS_ADCTRG1_Pos           (17)
#define PWM_STATUS_ADCTRG1_Msk           (0x1ul << PWM_STATUS_ADCTRG1_Pos)

#define PWM_STATUS_ADCTRG2_Pos           (18)
#define PWM_STATUS_ADCTRG2_Msk           (0x1ul << PWM_STATUS_ADCTRG2_Pos)

#define PWM_STATUS_ADCTRG3_Pos           (19)
#define PWM_STATUS_ADCTRG3_Msk           (0x1ul << PWM_STATUS_ADCTRG3_Pos)

#define PWM_STATUS_ADCTRG4_Pos           (20)
#define PWM_STATUS_ADCTRG4_Msk           (0x1ul << PWM_STATUS_ADCTRG4_Pos)

#define PWM_STATUS_ADCTRG5_Pos           (21)
#define PWM_STATUS_ADCTRG5_Msk           (0x1ul << PWM_STATUS_ADCTRG5_Pos)

#define PWM_STATUS_DACTRG_Pos            (24)
#define PWM_STATUS_DACTRG_Msk            (0x1ul << PWM_STATUS_DACTRG_Pos)

#define PWM_CAPINEN_CAPINENn_Pos         (0)
#define PWM_CAPINEN_CAPINENn_Msk         (0x3ful << PWM_CAPINEN_CAPINENn_Pos)

#define PWM_CAPINEN_CAPINEN0_Pos         (0)
#define PWM_CAPINEN_CAPINEN0_Msk         (0x1ul << PWM_CAPINEN_CAPINEN0_Pos)

#define PWM_CAPINEN_CAPINEN1_Pos         (1)
#define PWM_CAPINEN_CAPINEN1_Msk         (0x1ul << PWM_CAPINEN_CAPINEN1_Pos)

#define PWM_CAPINEN_CAPINEN2_Pos         (2)
#define PWM_CAPINEN_CAPINEN2_Msk         (0x1ul << PWM_CAPINEN_CAPINEN2_Pos)

#define PWM_CAPINEN_CAPINEN3_Pos         (3)
#define PWM_CAPINEN_CAPINEN3_Msk         (0x1ul << PWM_CAPINEN_CAPINEN3_Pos)

#define PWM_CAPINEN_CAPINEN4_Pos         (4)
#define PWM_CAPINEN_CAPINEN4_Msk         (0x1ul << PWM_CAPINEN_CAPINEN4_Pos)

#define PWM_CAPINEN_CAPINEN5_Pos         (5)
#define PWM_CAPINEN_CAPINEN5_Msk         (0x1ul << PWM_CAPINEN_CAPINEN5_Pos)

#define PWM_CAPCTL_CAPENn_Pos            (0)
#define PWM_CAPCTL_CAPENn_Msk            (0x3ful << PWM_CAPCTL_CAPENn_Pos)

#define PWM_CAPCTL_CAPEN0_Pos            (0)
#define PWM_CAPCTL_CAPEN0_Msk            (0x1ul << PWM_CAPCTL_CAPEN0_Pos)

#define PWM_CAPCTL_CAPEN1_Pos            (1)
#define PWM_CAPCTL_CAPEN1_Msk            (0x1ul << PWM_CAPCTL_CAPEN1_Pos)

#define PWM_CAPCTL_CAPEN2_Pos            (2)
#define PWM_CAPCTL_CAPEN2_Msk            (0x1ul << PWM_CAPCTL_CAPEN2_Pos)

#define PWM_CAPCTL_CAPEN3_Pos            (3)
#define PWM_CAPCTL_CAPEN3_Msk            (0x1ul << PWM_CAPCTL_CAPEN3_Pos)

#define PWM_CAPCTL_CAPEN4_Pos            (4)
#define PWM_CAPCTL_CAPEN4_Msk            (0x1ul << PWM_CAPCTL_CAPEN4_Pos)

#define PWM_CAPCTL_CAPEN5_Pos            (5)
#define PWM_CAPCTL_CAPEN5_Msk            (0x1ul << PWM_CAPCTL_CAPEN5_Pos)

#define PWM_CAPCTL_CAPINVn_Pos           (8)
#define PWM_CAPCTL_CAPINVn_Msk           (0x3ful << PWM_CAPCTL_CAPINVn_Pos)

#define PWM_CAPCTL_CAPINV0_Pos           (8)
#define PWM_CAPCTL_CAPINV0_Msk           (0x1ul << PWM_CAPCTL_CAPINV0_Pos)

#define PWM_CAPCTL_CAPINV1_Pos           (9)
#define PWM_CAPCTL_CAPINV1_Msk           (0x1ul << PWM_CAPCTL_CAPINV1_Pos)

#define PWM_CAPCTL_CAPINV2_Pos           (10)
#define PWM_CAPCTL_CAPINV2_Msk           (0x1ul << PWM_CAPCTL_CAPINV2_Pos)

#define PWM_CAPCTL_CAPINV3_Pos           (11)
#define PWM_CAPCTL_CAPINV3_Msk           (0x1ul << PWM_CAPCTL_CAPINV3_Pos)

#define PWM_CAPCTL_CAPINV4_Pos           (12)
#define PWM_CAPCTL_CAPINV4_Msk           (0x1ul << PWM_CAPCTL_CAPINV4_Pos)

#define PWM_CAPCTL_CAPINV5_Pos           (13)
#define PWM_CAPCTL_CAPINV5_Msk           (0x1ul << PWM_CAPCTL_CAPINV5_Pos)

#define PWM_CAPCTL_RCRLDENn_Pos          (16)
#define PWM_CAPCTL_RCRLDENn_Msk          (0x3ful << PWM_CAPCTL_RCRLDENn_Pos)

#define PWM_CAPCTL_RCRLDEN0_Pos          (16)
#define PWM_CAPCTL_RCRLDEN0_Msk          (0x1ul << PWM_CAPCTL_RCRLDEN0_Pos)

#define PWM_CAPCTL_RCRLDEN1_Pos          (17)
#define PWM_CAPCTL_RCRLDEN1_Msk          (0x1ul << PWM_CAPCTL_RCRLDEN1_Pos)

#define PWM_CAPCTL_RCRLDEN2_Pos          (18)
#define PWM_CAPCTL_RCRLDEN2_Msk          (0x1ul << PWM_CAPCTL_RCRLDEN2_Pos)

#define PWM_CAPCTL_RCRLDEN3_Pos          (19)
#define PWM_CAPCTL_RCRLDEN3_Msk          (0x1ul << PWM_CAPCTL_RCRLDEN3_Pos)

#define PWM_CAPCTL_RCRLDEN4_Pos          (20)
#define PWM_CAPCTL_RCRLDEN4_Msk          (0x1ul << PWM_CAPCTL_RCRLDEN4_Pos)

#define PWM_CAPCTL_RCRLDEN5_Pos          (21)
#define PWM_CAPCTL_RCRLDEN5_Msk          (0x1ul << PWM_CAPCTL_RCRLDEN5_Pos)

#define PWM_CAPCTL_FCRLDENn_Pos          (24)
#define PWM_CAPCTL_FCRLDENn_Msk          (0x3ful << PWM_CAPCTL_FCRLDENn_Pos)

#define PWM_CAPCTL_FCRLDEN0_Pos          (24)
#define PWM_CAPCTL_FCRLDEN0_Msk          (0x1ul << PWM_CAPCTL_FCRLDEN0_Pos)

#define PWM_CAPCTL_FCRLDEN1_Pos          (25)
#define PWM_CAPCTL_FCRLDEN1_Msk          (0x1ul << PWM_CAPCTL_FCRLDEN1_Pos)

#define PWM_CAPCTL_FCRLDEN2_Pos          (26)
#define PWM_CAPCTL_FCRLDEN2_Msk          (0x1ul << PWM_CAPCTL_FCRLDEN2_Pos)

#define PWM_CAPCTL_FCRLDEN3_Pos          (27)
#define PWM_CAPCTL_FCRLDEN3_Msk          (0x1ul << PWM_CAPCTL_FCRLDEN3_Pos)

#define PWM_CAPCTL_FCRLDEN4_Pos          (28)
#define PWM_CAPCTL_FCRLDEN4_Msk          (0x1ul << PWM_CAPCTL_FCRLDEN4_Pos)

#define PWM_CAPCTL_FCRLDEN5_Pos          (29)
#define PWM_CAPCTL_FCRLDEN5_Msk          (0x1ul << PWM_CAPCTL_FCRLDEN5_Pos)

#define PWM_CAPSTS_CRIFOVn_Pos           (0)
#define PWM_CAPSTS_CRIFOVn_Msk           (0x3ful << PWM_CAPSTS_CRIFOVn_Pos)

#define PWM_CAPSTS_CRIFOV0_Pos           (0)
#define PWM_CAPSTS_CRIFOV0_Msk           (0x1ul << PWM_CAPSTS_CRIFOV0_Pos)

#define PWM_CAPSTS_CRIFOV1_Pos           (1)
#define PWM_CAPSTS_CRIFOV1_Msk           (0x1ul << PWM_CAPSTS_CRIFOV1_Pos)

#define PWM_CAPSTS_CRIFOV2_Pos           (2)
#define PWM_CAPSTS_CRIFOV2_Msk           (0x1ul << PWM_CAPSTS_CRIFOV2_Pos)

#define PWM_CAPSTS_CRIFOV3_Pos           (3)
#define PWM_CAPSTS_CRIFOV3_Msk           (0x1ul << PWM_CAPSTS_CRIFOV3_Pos)

#define PWM_CAPSTS_CRIFOV4_Pos           (4)
#define PWM_CAPSTS_CRIFOV4_Msk           (0x1ul << PWM_CAPSTS_CRIFOV4_Pos)

#define PWM_CAPSTS_CRIFOV5_Pos           (5)
#define PWM_CAPSTS_CRIFOV5_Msk           (0x1ul << PWM_CAPSTS_CRIFOV5_Pos)

#define PWM_CAPSTS_CFIFOVn_Pos           (8)
#define PWM_CAPSTS_CFIFOVn_Msk           (0x3ful << PWM_CAPSTS_CFIFOVn_Pos)

#define PWM_CAPSTS_CFIFOV0_Pos           (8)
#define PWM_CAPSTS_CFIFOV0_Msk           (0x1ul << PWM_CAPSTS_CFIFOV0_Pos)

#define PWM_CAPSTS_CFIFOV1_Pos           (9)
#define PWM_CAPSTS_CFIFOV1_Msk           (0x1ul << PWM_CAPSTS_CFIFOV1_Pos)

#define PWM_CAPSTS_CFIFOV2_Pos           (10)
#define PWM_CAPSTS_CFIFOV2_Msk           (0x1ul << PWM_CAPSTS_CFIFOV2_Pos)

#define PWM_CAPSTS_CFIFOV3_Pos           (11)
#define PWM_CAPSTS_CFIFOV3_Msk           (0x1ul << PWM_CAPSTS_CFIFOV3_Pos)

#define PWM_CAPSTS_CFIFOV4_Pos           (12)
#define PWM_CAPSTS_CFIFOV4_Msk           (0x1ul << PWM_CAPSTS_CFIFOV4_Pos)

#define PWM_CAPSTS_CFIFOV5_Pos           (13)
#define PWM_CAPSTS_CFIFOV5_Msk           (0x1ul << PWM_CAPSTS_CFIFOV5_Pos)

#define PWM_RCAPDAT0_RCAPDAT_Pos         (0)
#define PWM_RCAPDAT0_RCAPDAT_Msk         (0xfffful << PWM_RCAPDAT0_RCAPDAT_Pos)

#define PWM_FCAPDAT0_FCAPDAT_Pos         (0)
#define PWM_FCAPDAT0_FCAPDAT_Msk         (0xfffful << PWM_FCAPDAT0_FCAPDAT_Pos)

#define PWM_RCAPDAT1_RCAPDAT_Pos         (0)
#define PWM_RCAPDAT1_RCAPDAT_Msk         (0xfffful << PWM_RCAPDAT1_RCAPDAT_Pos)

#define PWM_FCAPDAT1_FCAPDAT_Pos         (0)
#define PWM_FCAPDAT1_FCAPDAT_Msk         (0xfffful << PWM_FCAPDAT1_FCAPDAT_Pos)

#define PWM_RCAPDAT2_RCAPDAT_Pos         (0)
#define PWM_RCAPDAT2_RCAPDAT_Msk         (0xfffful << PWM_RCAPDAT2_RCAPDAT_Pos)

#define PWM_FCAPDAT2_FCAPDAT_Pos         (0)
#define PWM_FCAPDAT2_FCAPDAT_Msk         (0xfffful << PWM_FCAPDAT2_FCAPDAT_Pos)

#define PWM_RCAPDAT3_RCAPDAT_Pos         (0)
#define PWM_RCAPDAT3_RCAPDAT_Msk         (0xfffful << PWM_RCAPDAT3_RCAPDAT_Pos)

#define PWM_FCAPDAT3_FCAPDAT_Pos         (0)
#define PWM_FCAPDAT3_FCAPDAT_Msk         (0xfffful << PWM_FCAPDAT3_FCAPDAT_Pos)

#define PWM_RCAPDAT4_RCAPDAT_Pos         (0)
#define PWM_RCAPDAT4_RCAPDAT_Msk         (0xfffful << PWM_RCAPDAT4_RCAPDAT_Pos)

#define PWM_FCAPDAT4_FCAPDAT_Pos         (0)
#define PWM_FCAPDAT4_FCAPDAT_Msk         (0xfffful << PWM_FCAPDAT4_FCAPDAT_Pos)

#define PWM_RCAPDAT5_RCAPDAT_Pos         (0)
#define PWM_RCAPDAT5_RCAPDAT_Msk         (0xfffful << PWM_RCAPDAT5_RCAPDAT_Pos)

#define PWM_FCAPDAT5_FCAPDAT_Pos         (0)
#define PWM_FCAPDAT5_FCAPDAT_Msk         (0xfffful << PWM_FCAPDAT5_FCAPDAT_Pos)

#define PWM_PDMACTL_CHEN0_1_Pos          (0)
#define PWM_PDMACTL_CHEN0_1_Msk          (0x1ul << PWM_PDMACTL_CHEN0_1_Pos)

#define PWM_PDMACTL_CAPMOD0_1_Pos        (1)
#define PWM_PDMACTL_CAPMOD0_1_Msk        (0x3ul << PWM_PDMACTL_CAPMOD0_1_Pos)

#define PWM_PDMACTL_CAPORD0_1_Pos        (3)
#define PWM_PDMACTL_CAPORD0_1_Msk        (0x1ul << PWM_PDMACTL_CAPORD0_1_Pos)

#define PWM_PDMACTL_CHSEL0_1_Pos         (4)
#define PWM_PDMACTL_CHSEL0_1_Msk         (0x1ul << PWM_PDMACTL_CHSEL0_1_Pos)

#define PWM_PDMACTL_CHEN2_3_Pos          (8)
#define PWM_PDMACTL_CHEN2_3_Msk          (0x1ul << PWM_PDMACTL_CHEN2_3_Pos)

#define PWM_PDMACTL_CAPMOD2_3_Pos        (9)
#define PWM_PDMACTL_CAPMOD2_3_Msk        (0x3ul << PWM_PDMACTL_CAPMOD2_3_Pos)

#define PWM_PDMACTL_CAPORD2_3_Pos        (11)
#define PWM_PDMACTL_CAPORD2_3_Msk        (0x1ul << PWM_PDMACTL_CAPORD2_3_Pos)

#define PWM_PDMACTL_CHSEL2_3_Pos         (12)
#define PWM_PDMACTL_CHSEL2_3_Msk         (0x1ul << PWM_PDMACTL_CHSEL2_3_Pos)

#define PWM_PDMACTL_CHEN4_5_Pos          (16)
#define PWM_PDMACTL_CHEN4_5_Msk          (0x1ul << PWM_PDMACTL_CHEN4_5_Pos)

#define PWM_PDMACTL_CAPMOD4_5_Pos        (17)
#define PWM_PDMACTL_CAPMOD4_5_Msk        (0x3ul << PWM_PDMACTL_CAPMOD4_5_Pos)

#define PWM_PDMACTL_CAPORD4_5_Pos        (19)
#define PWM_PDMACTL_CAPORD4_5_Msk        (0x1ul << PWM_PDMACTL_CAPORD4_5_Pos)

#define PWM_PDMACTL_CHSEL4_5_Pos         (20)
#define PWM_PDMACTL_CHSEL4_5_Msk         (0x1ul << PWM_PDMACTL_CHSEL4_5_Pos)

#define PWM_PDMACAP0_1_CAPBUF_Pos        (0)
#define PWM_PDMACAP0_1_CAPBUF_Msk        (0xfffful << PWM_PDMACAP0_1_CAPBUF_Pos)

#define PWM_PDMACAP2_3_CAPBUF_Pos        (0)
#define PWM_PDMACAP2_3_CAPBUF_Msk        (0xfffful << PWM_PDMACAP2_3_CAPBUF_Pos)

#define PWM_PDMACAP4_5_CAPBUF_Pos        (0)
#define PWM_PDMACAP4_5_CAPBUF_Msk        (0xfffful << PWM_PDMACAP4_5_CAPBUF_Pos)

#define PWM_CAPIEN_CAPRIENn_Pos          (0)
#define PWM_CAPIEN_CAPRIENn_Msk          (0x3ful << PWM_CAPIEN_CAPRIENn_Pos)

#define PWM_CAPIEN_CAPRIEN0_Pos          (0)
#define PWM_CAPIEN_CAPRIEN0_Msk          (0x1ul << PWM_CAPIEN_CAPRIEN0_Pos)

#define PWM_CAPIEN_CAPRIEN1_Pos          (1)
#define PWM_CAPIEN_CAPRIEN1_Msk          (0x1ul << PWM_CAPIEN_CAPRIEN1_Pos)

#define PWM_CAPIEN_CAPRIEN2_Pos          (2)
#define PWM_CAPIEN_CAPRIEN2_Msk          (0x1ul << PWM_CAPIEN_CAPRIEN2_Pos)

#define PWM_CAPIEN_CAPRIEN3_Pos          (3)
#define PWM_CAPIEN_CAPRIEN3_Msk          (0x1ul << PWM_CAPIEN_CAPRIEN3_Pos)

#define PWM_CAPIEN_CAPRIEN4_Pos          (4)
#define PWM_CAPIEN_CAPRIEN4_Msk          (0x1ul << PWM_CAPIEN_CAPRIEN4_Pos)

#define PWM_CAPIEN_CAPRIEN5_Pos          (5)
#define PWM_CAPIEN_CAPRIEN5_Msk          (0x1ul << PWM_CAPIEN_CAPRIEN5_Pos)

#define PWM_CAPIEN_CAPFIENn_Pos          (8)
#define PWM_CAPIEN_CAPFIENn_Msk          (0x3ful << PWM_CAPIEN_CAPFIENn_Pos)

#define PWM_CAPIEN_CAPFIEN0_Pos          (8)
#define PWM_CAPIEN_CAPFIEN0_Msk          (0x1ul << PWM_CAPIEN_CAPFIEN0_Pos)

#define PWM_CAPIEN_CAPFIEN1_Pos          (9)
#define PWM_CAPIEN_CAPFIEN1_Msk          (0x1ul << PWM_CAPIEN_CAPFIEN1_Pos)

#define PWM_CAPIEN_CAPFIEN2_Pos          (10)
#define PWM_CAPIEN_CAPFIEN2_Msk          (0x1ul << PWM_CAPIEN_CAPFIEN2_Pos)

#define PWM_CAPIEN_CAPFIEN3_Pos          (11)
#define PWM_CAPIEN_CAPFIEN3_Msk          (0x1ul << PWM_CAPIEN_CAPFIEN3_Pos)

#define PWM_CAPIEN_CAPFIEN4_Pos          (12)
#define PWM_CAPIEN_CAPFIEN4_Msk          (0x1ul << PWM_CAPIEN_CAPFIEN4_Pos)

#define PWM_CAPIEN_CAPFIEN5_Pos          (13)
#define PWM_CAPIEN_CAPFIEN5_Msk          (0x1ul << PWM_CAPIEN_CAPFIEN5_Pos)

#define PWM_CAPIF_CAPRIFn_Pos            (0)
#define PWM_CAPIF_CAPRIFn_Msk            (0x3ful << PWM_CAPIF_CAPRIFn_Pos)

#define PWM_CAPIF_CAPRIF0_Pos            (0)
#define PWM_CAPIF_CAPRIF0_Msk            (0x1ul << PWM_CAPIF_CAPRIF0_Pos)

#define PWM_CAPIF_CAPRIF1_Pos            (1)
#define PWM_CAPIF_CAPRIF1_Msk            (0x1ul << PWM_CAPIF_CAPRIF1_Pos)

#define PWM_CAPIF_CAPRIF2_Pos            (2)
#define PWM_CAPIF_CAPRIF2_Msk            (0x1ul << PWM_CAPIF_CAPRIF2_Pos)

#define PWM_CAPIF_CAPRIF3_Pos            (3)
#define PWM_CAPIF_CAPRIF3_Msk            (0x1ul << PWM_CAPIF_CAPRIF3_Pos)

#define PWM_CAPIF_CAPRIF4_Pos            (4)
#define PWM_CAPIF_CAPRIF4_Msk            (0x1ul << PWM_CAPIF_CAPRIF4_Pos)

#define PWM_CAPIF_CAPRIF5_Pos            (5)
#define PWM_CAPIF_CAPRIF5_Msk            (0x1ul << PWM_CAPIF_CAPRIF5_Pos)

#define PWM_CAPIF_CAPFIFn_Pos            (8)
#define PWM_CAPIF_CAPFIFn_Msk            (0x3ful << PWM_CAPIF_CAPFIFn_Pos)

#define PWM_CAPIF_CAPFIF0_Pos            (8)
#define PWM_CAPIF_CAPFIF0_Msk            (0x1ul << PWM_CAPIF_CAPFIF0_Pos)

#define PWM_CAPIF_CAPFIF1_Pos            (9)
#define PWM_CAPIF_CAPFIF1_Msk            (0x1ul << PWM_CAPIF_CAPFIF1_Pos)

#define PWM_CAPIF_CAPFIF2_Pos            (10)
#define PWM_CAPIF_CAPFIF2_Msk            (0x1ul << PWM_CAPIF_CAPFIF2_Pos)

#define PWM_CAPIF_CAPFIF3_Pos            (11)
#define PWM_CAPIF_CAPFIF3_Msk            (0x1ul << PWM_CAPIF_CAPFIF3_Pos)

#define PWM_CAPIF_CAPFIF4_Pos            (12)
#define PWM_CAPIF_CAPFIF4_Msk            (0x1ul << PWM_CAPIF_CAPFIF4_Pos)

#define PWM_CAPIF_CAPFIF5_Pos            (13)
#define PWM_CAPIF_CAPFIF5_Msk            (0x1ul << PWM_CAPIF_CAPFIF5_Pos)

#define PWM_PBUF0_PBUF_Pos               (0)
#define PWM_PBUF0_PBUF_Msk               (0xfffful << PWM_PBUF0_PBUF_Pos)

#define PWM_PBUF1_PBUF_Pos               (0)
#define PWM_PBUF1_PBUF_Msk               (0xfffful << PWM_PBUF1_PBUF_Pos)

#define PWM_PBUF2_PBUF_Pos               (0)
#define PWM_PBUF2_PBUF_Msk               (0xfffful << PWM_PBUF2_PBUF_Pos)

#define PWM_PBUF3_PBUF_Pos               (0)
#define PWM_PBUF3_PBUF_Msk               (0xfffful << PWM_PBUF3_PBUF_Pos)

#define PWM_PBUF4_PBUF_Pos               (0)
#define PWM_PBUF4_PBUF_Msk               (0xfffful << PWM_PBUF4_PBUF_Pos)

#define PWM_PBUF5_PBUF_Pos               (0)
#define PWM_PBUF5_PBUF_Msk               (0xfffful << PWM_PBUF5_PBUF_Pos)

#define PWM_CMPBUF0_CMPBUF_Pos           (0)
#define PWM_CMPBUF0_CMPBUF_Msk           (0xfffful << PWM_CMPBUF0_CMPBUF_Pos)

#define PWM_CMPBUF1_CMPBUF_Pos           (0)
#define PWM_CMPBUF1_CMPBUF_Msk           (0xfffful << PWM_CMPBUF1_CMPBUF_Pos)

#define PWM_CMPBUF2_CMPBUF_Pos           (0)
#define PWM_CMPBUF2_CMPBUF_Msk           (0xfffful << PWM_CMPBUF2_CMPBUF_Pos)

#define PWM_CMPBUF3_CMPBUF_Pos           (0)
#define PWM_CMPBUF3_CMPBUF_Msk           (0xfffful << PWM_CMPBUF3_CMPBUF_Pos)

#define PWM_CMPBUF4_CMPBUF_Pos           (0)
#define PWM_CMPBUF4_CMPBUF_Msk           (0xfffful << PWM_CMPBUF4_CMPBUF_Pos)

#define PWM_CMPBUF5_CMPBUF_Pos           (0)
#define PWM_CMPBUF5_CMPBUF_Msk           (0xfffful << PWM_CMPBUF5_CMPBUF_Pos)

#define PWM_FTCBUF0_1_FTCMPBUF_Pos       (0)
#define PWM_FTCBUF0_1_FTCMPBUF_Msk       (0xfffful << PWM_FTCBUF0_1_FTCMPBUF_Pos)

#define PWM_FTCBUF2_3_FTCMPBUF_Pos       (0)
#define PWM_FTCBUF2_3_FTCMPBUF_Msk       (0xfffful << PWM_FTCBUF2_3_FTCMPBUF_Pos)

#define PWM_FTCBUF4_5_FTCMPBUF_Pos       (0)
#define PWM_FTCBUF4_5_FTCMPBUF_Msk       (0xfffful << PWM_FTCBUF4_5_FTCMPBUF_Pos)

#define PWM_FTCI_FTCMUn_Pos              (0)
#define PWM_FTCI_FTCMUn_Msk              (0x7ul << PWM_FTCI_FTCMUn_Pos)

#define PWM_FTCI_FTCMU0_Pos              (0)
#define PWM_FTCI_FTCMU0_Msk              (0x1ul << PWM_FTCI_FTCMU0_Pos)

#define PWM_FTCI_FTCMU2_Pos              (1)
#define PWM_FTCI_FTCMU2_Msk              (0x1ul << PWM_FTCI_FTCMU2_Pos)

#define PWM_FTCI_FTCMU4_Pos              (2)
#define PWM_FTCI_FTCMU4_Msk              (0x1ul << PWM_FTCI_FTCMU4_Pos)

#define PWM_FTCI_FTCMDn_Pos              (8)
#define PWM_FTCI_FTCMDn_Msk              (0x7ul << PWM_FTCI_FTCMDn_Pos)

#define PWM_FTCI_FTCMD0_Pos              (8)
#define PWM_FTCI_FTCMD0_Msk              (0x1ul << PWM_FTCI_FTCMD0_Pos)

#define PWM_FTCI_FTCMD2_Pos              (9)
#define PWM_FTCI_FTCMD2_Msk              (0x1ul << PWM_FTCI_FTCMD2_Pos)

#define PWM_FTCI_FTCMD4_Pos              (10)
#define PWM_FTCI_FTCMD4_Msk              (0x1ul << PWM_FTCI_FTCMD4_Pos)

/**@}*/ /* PWM_CONST */
/**@}*/ /* end of PWM register group */


/*---------------------- Real Time Clock Controller -------------------------*/
/**
    @addtogroup RTC Real Time Clock Controller(RTC)
    Memory Mapped Structure for RTC Controller
@{ */
 
typedef struct
{

    __IO uint32_t INIT;                  /*!< [0x0000] RTC Initiation Register                                          */
    __O  uint32_t RWEN;                  /*!< [0x0004] RTC Access Enable Register                                       */
    __IO uint32_t FREQADJ;               /*!< [0x0008] RTC Frequency Compensation Register                              */
    __IO uint32_t TIME;                  /*!< [0x000c] RTC Time Loading Register                                        */
    __IO uint32_t CAL;                   /*!< [0x0010] RTC Calendar Loading Register                                    */
    __IO uint32_t CLKFMT;                /*!< [0x0014] RTC Time Scale Selection Register                                */
    __IO uint32_t WEEKDAY;               /*!< [0x0018] RTC Day of the Week Register                                     */
    __IO uint32_t TALM;                  /*!< [0x001c] RTC Time Alarm Register                                          */
    __IO uint32_t CALM;                  /*!< [0x0020] RTC Calendar Alarm Register                                      */
    __I  uint32_t LEAPYEAR;              /*!< [0x0024] RTC Leap Year Indicator Register                                 */
    __IO uint32_t INTEN;                 /*!< [0x0028] RTC Interrupt Enable Register                                    */
    __IO uint32_t INTSTS;                /*!< [0x002c] RTC Interrupt Indicator Register                                 */
    __IO uint32_t TICK;                  /*!< [0x0030] RTC Time Tick Register                                           */
    __IO uint32_t TAMSK;                 /*!< [0x0034] RTC Time Alarm Mask Register                                     */
    __IO uint32_t CAMSK;                 /*!< [0x0038] RTC Calendar Alarm Mask Register                                 */
    __IO uint32_t SPRCTL;                /*!< [0x003c] RTC Spare Functional Control Register                            */
    __IO uint32_t SPR[20];          	 /*!< [0x0040 ~ 0x008c] RTC Spare Register 0 ~ 19                             	*/
         uint32_t RESERVE0[28];

    __IO uint32_t LXTCTL;                /*!< [0x0100] RTC 32.768 kHz Oscillator Control Register                       */
    __IO uint32_t LXTOCTL;               /*!< [0x0104] X32KO Pin Control Register                                       */
    __IO uint32_t LXTICTL;               /*!< [0x0108] X32KI Pin Control Register                                       */
    __IO uint32_t TAMPER;                /*!< [0x010c] TAMPER Pin Control Register                                      */

} RTC_T;

/**
    @addtogroup RTC_CONST RTC Bit Field Definition
    Constant Definitions for RTC Controller
@{ */

#define RTC_INIT_Active_Pos              (0)
#define RTC_INIT_Active_Msk              (0x1ul << RTC_INIT_Active_Pos)

#define RTC_INIT_INIT_Pos                (0)
#define RTC_INIT_INIT_Msk                (0xfffffffful << RTC_INIT_INIT_Pos)

#define RTC_RWEN_RWEN_Pos                (0)
#define RTC_RWEN_RWEN_Msk                (0xfffful << RTC_RWEN_RWEN_Pos)

#define RTC_RWEN_RWENF_Pos               (16)
#define RTC_RWEN_RWENF_Msk               (0x1ul << RTC_RWEN_RWENF_Pos)

#define RTC_FREQADJ_FRACTION_Pos         (0)
#define RTC_FREQADJ_FRACTION_Msk         (0x3ful << RTC_FREQADJ_FRACTION_Pos)

#define RTC_FREQADJ_INTEGER_Pos          (8)
#define RTC_FREQADJ_INTEGER_Msk          (0xful << RTC_FREQADJ_INTEGER_Pos)

#define RTC_TIME_SEC_Pos                 (0)
#define RTC_TIME_SEC_Msk                 (0xful << RTC_TIME_SEC_Pos)

#define RTC_TIME_TENSEC_Pos              (4)
#define RTC_TIME_TENSEC_Msk              (0x7ul << RTC_TIME_TENSEC_Pos)

#define RTC_TIME_MIN_Pos                 (8)
#define RTC_TIME_MIN_Msk                 (0xful << RTC_TIME_MIN_Pos)

#define RTC_TIME_TENMIN_Pos              (12)
#define RTC_TIME_TENMIN_Msk              (0x7ul << RTC_TIME_TENMIN_Pos)

#define RTC_TIME_HR_Pos                  (16)
#define RTC_TIME_HR_Msk                  (0xful << RTC_TIME_HR_Pos)

#define RTC_TIME_TENHR_Pos               (20)
#define RTC_TIME_TENHR_Msk               (0x3ul << RTC_TIME_TENHR_Pos)

#define RTC_CAL_DAY_Pos                  (0)
#define RTC_CAL_DAY_Msk                  (0xful << RTC_CAL_DAY_Pos)

#define RTC_CAL_TENDAY_Pos               (4)
#define RTC_CAL_TENDAY_Msk               (0x3ul << RTC_CAL_TENDAY_Pos)

#define RTC_CAL_MON_Pos                  (8)
#define RTC_CAL_MON_Msk                  (0xful << RTC_CAL_MON_Pos)

#define RTC_CAL_TENMON_Pos               (12)
#define RTC_CAL_TENMON_Msk               (0x1ul << RTC_CAL_TENMON_Pos)

#define RTC_CAL_YEAR_Pos                 (16)
#define RTC_CAL_YEAR_Msk                 (0xful << RTC_CAL_YEAR_Pos)

#define RTC_CAL_TENYEAR_Pos              (20)
#define RTC_CAL_TENYEAR_Msk              (0xful << RTC_CAL_TENYEAR_Pos)

#define RTC_CLKFMT_24HEN_Pos             (0)
#define RTC_CLKFMT_24HEN_Msk             (0x1ul << RTC_CLKFMT_24HEN_Pos)

#define RTC_WEEKDAY_WEEKDAY_Pos          (0)
#define RTC_WEEKDAY_WEEKDAY_Msk          (0x7ul << RTC_WEEKDAY_WEEKDAY_Pos)

#define RTC_TALM_SEC_Pos                 (0)
#define RTC_TALM_SEC_Msk                 (0xful << RTC_TALM_SEC_Pos)

#define RTC_TALM_TENSEC_Pos              (4)
#define RTC_TALM_TENSEC_Msk              (0x7ul << RTC_TALM_TENSEC_Pos)

#define RTC_TALM_MIN_Pos                 (8)
#define RTC_TALM_MIN_Msk                 (0xful << RTC_TALM_MIN_Pos)

#define RTC_TALM_TENMIN_Pos              (12)
#define RTC_TALM_TENMIN_Msk              (0x7ul << RTC_TALM_TENMIN_Pos)

#define RTC_TALM_HR_Pos                  (16)
#define RTC_TALM_HR_Msk                  (0xful << RTC_TALM_HR_Pos)

#define RTC_TALM_TENHR_Pos               (20)
#define RTC_TALM_TENHR_Msk               (0x3ul << RTC_TALM_TENHR_Pos)

#define RTC_CALM_DAY_Pos                 (0)
#define RTC_CALM_DAY_Msk                 (0xful << RTC_CALM_DAY_Pos)

#define RTC_CALM_TENDAY_Pos              (4)
#define RTC_CALM_TENDAY_Msk              (0x3ul << RTC_CALM_TENDAY_Pos)

#define RTC_CALM_MON_Pos                 (8)
#define RTC_CALM_MON_Msk                 (0xful << RTC_CALM_MON_Pos)

#define RTC_CALM_TENMON_Pos              (12)
#define RTC_CALM_TENMON_Msk              (0x1ul << RTC_CALM_TENMON_Pos)

#define RTC_CALM_YEAR_Pos                (16)
#define RTC_CALM_YEAR_Msk                (0xful << RTC_CALM_YEAR_Pos)

#define RTC_CALM_TENYEAR_Pos             (20)
#define RTC_CALM_TENYEAR_Msk             (0xful << RTC_CALM_TENYEAR_Pos)

#define RTC_LEAPYEAR_LEAPYEAR_Pos        (0)
#define RTC_LEAPYEAR_LEAPYEAR_Msk        (0x1ul << RTC_LEAPYEAR_LEAPYEAR_Pos)

#define RTC_INTEN_ALMIEN_Pos             (0)
#define RTC_INTEN_ALMIEN_Msk             (0x1ul << RTC_INTEN_ALMIEN_Pos)

#define RTC_INTEN_TICKIEN_Pos            (1)
#define RTC_INTEN_TICKIEN_Msk            (0x1ul << RTC_INTEN_TICKIEN_Pos)

#define RTC_INTEN_SNPDIEN_Pos            (2)
#define RTC_INTEN_SNPDIEN_Msk            (0x1ul << RTC_INTEN_SNPDIEN_Pos)

#define RTC_INTSTS_ALMIF_Pos             (0)
#define RTC_INTSTS_ALMIF_Msk             (0x1ul << RTC_INTSTS_ALMIF_Pos)

#define RTC_INTSTS_TICKIF_Pos            (1)
#define RTC_INTSTS_TICKIF_Msk            (0x1ul << RTC_INTSTS_TICKIF_Pos)

#define RTC_INTSTS_SNPDIF_Pos            (2)
#define RTC_INTSTS_SNPDIF_Msk            (0x1ul << RTC_INTSTS_SNPDIF_Pos)

#define RTC_TICK_TICK_Pos                (0)
#define RTC_TICK_TICK_Msk                (0x7ul << RTC_TICK_TICK_Pos)

#define RTC_TAMSK_MSEC_Pos               (0)
#define RTC_TAMSK_MSEC_Msk               (0x1ul << RTC_TAMSK_MSEC_Pos)

#define RTC_TAMSK_MTENSEC_Pos            (1)
#define RTC_TAMSK_MTENSEC_Msk            (0x1ul << RTC_TAMSK_MTENSEC_Pos)

#define RTC_TAMSK_MMIN_Pos               (2)
#define RTC_TAMSK_MMIN_Msk               (0x1ul << RTC_TAMSK_MMIN_Pos)

#define RTC_TAMSK_MTENMIN_Pos            (3)
#define RTC_TAMSK_MTENMIN_Msk            (0x1ul << RTC_TAMSK_MTENMIN_Pos)

#define RTC_TAMSK_MHR_Pos                (4)
#define RTC_TAMSK_MHR_Msk                (0x1ul << RTC_TAMSK_MHR_Pos)

#define RTC_TAMSK_MTENHR_Pos             (5)
#define RTC_TAMSK_MTENHR_Msk             (0x1ul << RTC_TAMSK_MTENHR_Pos)

#define RTC_CAMSK_MDAY_Pos               (0)
#define RTC_CAMSK_MDAY_Msk               (0x1ul << RTC_CAMSK_MDAY_Pos)

#define RTC_CAMSK_MTENDAY_Pos            (1)
#define RTC_CAMSK_MTENDAY_Msk            (0x1ul << RTC_CAMSK_MTENDAY_Pos)

#define RTC_CAMSK_MMON_Pos               (2)
#define RTC_CAMSK_MMON_Msk               (0x1ul << RTC_CAMSK_MMON_Pos)

#define RTC_CAMSK_MTENMON_Pos            (3)
#define RTC_CAMSK_MTENMON_Msk            (0x1ul << RTC_CAMSK_MTENMON_Pos)

#define RTC_CAMSK_MYEAR_Pos              (4)
#define RTC_CAMSK_MYEAR_Msk              (0x1ul << RTC_CAMSK_MYEAR_Pos)

#define RTC_CAMSK_MTENYEAR_Pos           (5)
#define RTC_CAMSK_MTENYEAR_Msk           (0x1ul << RTC_CAMSK_MTENYEAR_Pos)

#define RTC_SPRCTL_SNPDEN_Pos            (0)
#define RTC_SPRCTL_SNPDEN_Msk            (0x1ul << RTC_SPRCTL_SNPDEN_Pos)

#define RTC_SPRCTL_SNPTYPE0_Pos          (1)
#define RTC_SPRCTL_SNPTYPE0_Msk          (0x1ul << RTC_SPRCTL_SNPTYPE0_Pos)

#define RTC_SPRCTL_SPRRWEN_Pos           (2)
#define RTC_SPRCTL_SPRRWEN_Msk           (0x1ul << RTC_SPRCTL_SPRRWEN_Pos)

#define RTC_SPRCTL_SNPTYPE1_Pos          (3)
#define RTC_SPRCTL_SNPTYPE1_Msk          (0x1ul << RTC_SPRCTL_SNPTYPE1_Pos)

#define RTC_SPRCTL_SPRCSTS_Pos           (5)
#define RTC_SPRCTL_SPRCSTS_Msk           (0x1ul << RTC_SPRCTL_SPRCSTS_Pos)

#define RTC_SPRCTL_SPRRWRDY_Pos          (7)
#define RTC_SPRCTL_SPRRWRDY_Msk          (0x1ul << RTC_SPRCTL_SPRRWRDY_Pos)

#define RTC_SPR0_SPR_Pos                 (0)
#define RTC_SPR0_SPR_Msk                 (0xfffffffful << RTC_SPR0_SPR_Pos)

#define RTC_SPR1_SPR_Pos                 (0)
#define RTC_SPR1_SPR_Msk                 (0xfffffffful << RTC_SPR1_SPR_Pos)

#define RTC_SPR2_SPR_Pos                 (0)
#define RTC_SPR2_SPR_Msk                 (0xfffffffful << RTC_SPR2_SPR_Pos)

#define RTC_SPR3_SPR_Pos                 (0)
#define RTC_SPR3_SPR_Msk                 (0xfffffffful << RTC_SPR3_SPR_Pos)

#define RTC_SPR4_SPR_Pos                 (0)
#define RTC_SPR4_SPR_Msk                 (0xfffffffful << RTC_SPR4_SPR_Pos)

#define RTC_SPR5_SPR_Pos                 (0)
#define RTC_SPR5_SPR_Msk                 (0xfffffffful << RTC_SPR5_SPR_Pos)

#define RTC_SPR6_SPR_Pos                 (0)
#define RTC_SPR6_SPR_Msk                 (0xfffffffful << RTC_SPR6_SPR_Pos)

#define RTC_SPR7_SPR_Pos                 (0)
#define RTC_SPR7_SPR_Msk                 (0xfffffffful << RTC_SPR7_SPR_Pos)

#define RTC_SPR8_SPR_Pos                 (0)
#define RTC_SPR8_SPR_Msk                 (0xfffffffful << RTC_SPR8_SPR_Pos)

#define RTC_SPR9_SPR_Pos                 (0)
#define RTC_SPR9_SPR_Msk                 (0xfffffffful << RTC_SPR9_SPR_Pos)

#define RTC_SPR10_SPR_Pos                (0)
#define RTC_SPR10_SPR_Msk                (0xfffffffful << RTC_SPR10_SPR_Pos)

#define RTC_SPR11_SPR_Pos                (0)
#define RTC_SPR11_SPR_Msk                (0xfffffffful << RTC_SPR11_SPR_Pos)

#define RTC_SPR12_SPR_Pos                (0)
#define RTC_SPR12_SPR_Msk                (0xfffffffful << RTC_SPR12_SPR_Pos)

#define RTC_SPR13_SPR_Pos                (0)
#define RTC_SPR13_SPR_Msk                (0xfffffffful << RTC_SPR13_SPR_Pos)

#define RTC_SPR14_SPR_Pos                (0)
#define RTC_SPR14_SPR_Msk                (0xfffffffful << RTC_SPR14_SPR_Pos)

#define RTC_SPR15_SPR_Pos                (0)
#define RTC_SPR15_SPR_Msk                (0xfffffffful << RTC_SPR15_SPR_Pos)

#define RTC_SPR16_SPR_Pos                (0)
#define RTC_SPR16_SPR_Msk                (0xfffffffful << RTC_SPR16_SPR_Pos)

#define RTC_SPR17_SPR_Pos                (0)
#define RTC_SPR17_SPR_Msk                (0xfffffffful << RTC_SPR17_SPR_Pos)

#define RTC_SPR18_SPR_Pos                (0)
#define RTC_SPR18_SPR_Msk                (0xfffffffful << RTC_SPR18_SPR_Pos)

#define RTC_SPR19_SPR_Pos                (0)
#define RTC_SPR19_SPR_Msk                (0xfffffffful << RTC_SPR19_SPR_Pos)

#define RTC_LXTCTL_LXTEN_Pos             (0)
#define RTC_LXTCTL_LXTEN_Msk             (0x1ul << RTC_LXTCTL_LXTEN_Pos)

#define RTC_LXTCTL_GAIN_Pos              (1)
#define RTC_LXTCTL_GAIN_Msk              (0x7ul << RTC_LXTCTL_GAIN_Pos)

#define RTC_LXTOCTL_OPMODE_Pos           (0)
#define RTC_LXTOCTL_OPMODE_Msk           (0x3ul << RTC_LXTOCTL_OPMODE_Pos)

#define RTC_LXTOCTL_DOUT_Pos             (2)
#define RTC_LXTOCTL_DOUT_Msk             (0x1ul << RTC_LXTOCTL_DOUT_Pos)

#define RTC_LXTOCTL_CTLSEL_Pos           (3)
#define RTC_LXTOCTL_CTLSEL_Msk           (0x1ul << RTC_LXTOCTL_CTLSEL_Pos)

#define RTC_LXTICTL_OPMODE_Pos           (0)
#define RTC_LXTICTL_OPMODE_Msk           (0x3ul << RTC_LXTICTL_OPMODE_Pos)

#define RTC_LXTICTL_DOUT_Pos             (2)
#define RTC_LXTICTL_DOUT_Msk             (0x1ul << RTC_LXTICTL_DOUT_Pos)

#define RTC_LXTICTL_CTLSEL_Pos           (3)
#define RTC_LXTICTL_CTLSEL_Msk           (0x1ul << RTC_LXTICTL_CTLSEL_Pos)

#define RTC_TAMPER_OPMODE_Pos            (0)
#define RTC_TAMPER_OPMODE_Msk            (0x3ul << RTC_TAMPER_OPMODE_Pos)

#define RTC_TAMPER_DOUT_Pos              (2)
#define RTC_TAMPER_DOUT_Msk              (0x1ul << RTC_TAMPER_DOUT_Pos)

#define RTC_TAMPER_CTLSEL_Pos            (3)
#define RTC_TAMPER_CTLSEL_Msk            (0x1ul << RTC_TAMPER_CTLSEL_Pos)

/**@}*/ /* RTC_CONST */
/**@}*/ /* end of RTC register group */


/*---------------------- Smart Card Host Interface Controller -------------------------*/
/**
    @addtogroup SC Smart Card Host Interface Controller(SC)
    Memory Mapped Structure for SC Controller
@{ */
 
typedef struct
{

    __IO uint32_t DAT;                   /*!< [0x0000] SC Receiving/Transmit Holding Buffer Register.                   */
    __IO uint32_t CTL;                   /*!< [0x0004] SC Control Register.                                             */
    __IO uint32_t ALTCTL;                /*!< [0x0008] SC Alternate Control Register.                                   */
    __IO uint32_t EGTR;                  /*!< [0x000c] SC Extend Guard Time Register.                                   */
    __IO uint32_t RXTOUT;                /*!< [0x0010] SC Receive buffer Time-out Register.                             */
    __IO uint32_t ETUCTL;                /*!< [0x0014] SC ETU Control Register.                                         */
    __IO uint32_t INTEN;                 /*!< [0x0018] SC Interrupt Enable Control Register.                            */
    __I  uint32_t INTSTS;                /*!< [0x001c] SC Interrupt Status Register.                                    */
    __I  uint32_t STATUS;                /*!< [0x0020] SC Status Register.                                              */
    __IO uint32_t PINCTL;                /*!< [0x0024] SC Pin Control State Register.                                   */
    __IO uint32_t TMRCTL0;               /*!< [0x0028] SC Internal Timer Control Register 0.                            */
    __IO uint32_t TMRCTL1;               /*!< [0x002c] SC Internal Timer Control Register 1.                            */
    __IO uint32_t TMRCTL2;               /*!< [0x0030] SC Internal Timer Control Register 2.                            */
    __IO uint32_t UARTCTL;               /*!< [0x0034] SC UART Mode Control Register.                                   */
    __I  uint32_t TMRDAT0;               /*!< [0x0038] SC Timer Current Data Register A.                                */
    __I  uint32_t TMRDAT1_2;             /*!< [0x003c] SC Timer Current Data Register B.                                */
    __IO uint32_t PETCTL;                /*!< [0x0040] SC Parity Error Timing Control Register                          */
    __IO uint32_t EGT;                   /*!< [0x0044] SC Block Guard Time Extension Register                           */
    __IO uint32_t EGTADJ;                /*!< [0x0048] SC Extend Guard Time Adjustment Register                         */


} SC_T;

/**
    @addtogroup SC_CONST SC Bit Field Definition
    Constant Definitions for SC Controller
@{ */

#define SC_DAT_DAT_Pos                   (0)
#define SC_DAT_DAT_Msk                   (0xfful << SC_DAT_DAT_Pos)

#define SC_CTL_SCEN_Pos                  (0)
#define SC_CTL_SCEN_Msk                  (0x1ul << SC_CTL_SCEN_Pos)

#define SC_CTL_RXOFF_Pos                 (1)
#define SC_CTL_RXOFF_Msk                 (0x1ul << SC_CTL_RXOFF_Pos)

#define SC_CTL_TXOFF_Pos                 (2)
#define SC_CTL_TXOFF_Msk                 (0x1ul << SC_CTL_TXOFF_Pos)

#define SC_CTL_AUTOCEN_Pos               (3)
#define SC_CTL_AUTOCEN_Msk               (0x1ul << SC_CTL_AUTOCEN_Pos)

#define SC_CTL_CONSEL_Pos                (4)
#define SC_CTL_CONSEL_Msk                (0x3ul << SC_CTL_CONSEL_Pos)

#define SC_CTL_RXTRGLV_Pos               (6)
#define SC_CTL_RXTRGLV_Msk               (0x3ul << SC_CTL_RXTRGLV_Pos)

#define SC_CTL_BGT_Pos                   (8)
#define SC_CTL_BGT_Msk                   (0x1ful << SC_CTL_BGT_Pos)

#define SC_CTL_TMRSEL_Pos                (13)
#define SC_CTL_TMRSEL_Msk                (0x3ul << SC_CTL_TMRSEL_Pos)

#define SC_CTL_NSB_Pos                   (15)
#define SC_CTL_NSB_Msk                   (0x1ul << SC_CTL_NSB_Pos)

#define SC_CTL_RXRTY_Pos                 (16)
#define SC_CTL_RXRTY_Msk                 (0x7ul << SC_CTL_RXRTY_Pos)

#define SC_CTL_RXRTYEN_Pos               (19)
#define SC_CTL_RXRTYEN_Msk               (0x1ul << SC_CTL_RXRTYEN_Pos)

#define SC_CTL_TXRTY_Pos                 (20)
#define SC_CTL_TXRTY_Msk                 (0x7ul << SC_CTL_TXRTY_Pos)

#define SC_CTL_TXRTYEN_Pos               (23)
#define SC_CTL_TXRTYEN_Msk               (0x1ul << SC_CTL_TXRTYEN_Pos)

#define SC_CTL_CDDBSEL_Pos               (24)
#define SC_CTL_CDDBSEL_Msk               (0x3ul << SC_CTL_CDDBSEL_Pos)

#define SC_CTL_CDLV_Pos                  (26)
#define SC_CTL_CDLV_Msk                  (0x1ul << SC_CTL_CDLV_Pos)

#define SC_CTL_SYNC_Pos                  (30)
#define SC_CTL_SYNC_Msk                  (0x1ul << SC_CTL_SYNC_Pos)

#define SC_CTL_DBGOFF_Pos                (31)
#define SC_CTL_DBGOFF_Msk                (0x1ul << SC_CTL_DBGOFF_Pos)

#define SC_ALTCTL_TXRST_Pos              (0)
#define SC_ALTCTL_TXRST_Msk              (0x1ul << SC_ALTCTL_TXRST_Pos)

#define SC_ALTCTL_RXRST_Pos              (1)
#define SC_ALTCTL_RXRST_Msk              (0x1ul << SC_ALTCTL_RXRST_Pos)

#define SC_ALTCTL_DACTEN_Pos             (2)
#define SC_ALTCTL_DACTEN_Msk             (0x1ul << SC_ALTCTL_DACTEN_Pos)

#define SC_ALTCTL_ACTEN_Pos              (3)
#define SC_ALTCTL_ACTEN_Msk              (0x1ul << SC_ALTCTL_ACTEN_Pos)

#define SC_ALTCTL_WARSTEN_Pos            (4)
#define SC_ALTCTL_WARSTEN_Msk            (0x1ul << SC_ALTCTL_WARSTEN_Pos)

#define SC_ALTCTL_TIMER0EN_Pos           (5)
#define SC_ALTCTL_TIMER0EN_Msk           (0x1ul << SC_ALTCTL_TIMER0EN_Pos)

#define SC_ALTCTL_TIMER1EN_Pos           (6)
#define SC_ALTCTL_TIMER1EN_Msk           (0x1ul << SC_ALTCTL_TIMER1EN_Pos)

#define SC_ALTCTL_TIMER2EN_Pos           (7)
#define SC_ALTCTL_TIMER2EN_Msk           (0x1ul << SC_ALTCTL_TIMER2EN_Pos)

#define SC_ALTCTL_INITSEL_Pos            (8)
#define SC_ALTCTL_INITSEL_Msk            (0x3ul << SC_ALTCTL_INITSEL_Pos)

#define SC_ALTCTL_RXBGTEN_Pos            (12)
#define SC_ALTCTL_RXBGTEN_Msk            (0x1ul << SC_ALTCTL_RXBGTEN_Pos)

#define SC_ALTCTL_ACTSTS0_Pos            (13)
#define SC_ALTCTL_ACTSTS0_Msk            (0x1ul << SC_ALTCTL_ACTSTS0_Pos)

#define SC_ALTCTL_ACTSTS1_Pos            (14)
#define SC_ALTCTL_ACTSTS1_Msk            (0x1ul << SC_ALTCTL_ACTSTS1_Pos)

#define SC_ALTCTL_ACTSTS2_Pos            (15)
#define SC_ALTCTL_ACTSTS2_Msk            (0x1ul << SC_ALTCTL_ACTSTS2_Pos)

#define SC_ALTCTL_OUTSEL_Pos             (16)
#define SC_ALTCTL_OUTSEL_Msk             (0x1ul << SC_ALTCTL_OUTSEL_Pos)

#define SC_EGTR_EGT_Pos                  (0)
#define SC_EGTR_EGT_Msk                  (0xfful << SC_EGTR_EGT_Pos)

#define SC_RXTOUT_RFTM_Pos               (0)
#define SC_RXTOUT_RFTM_Msk               (0x1fful << SC_RXTOUT_RFTM_Pos)

#define SC_ETUCTL_ETURDIV_Pos            (0)
#define SC_ETUCTL_ETURDIV_Msk            (0xffful << SC_ETUCTL_ETURDIV_Pos)

#define SC_ETUCTL_CMPEN_Pos              (15)
#define SC_ETUCTL_CMPEN_Msk              (0x1ul << SC_ETUCTL_CMPEN_Pos)

#define SC_INTEN_RDAIEN_Pos              (0)
#define SC_INTEN_RDAIEN_Msk              (0x1ul << SC_INTEN_RDAIEN_Pos)

#define SC_INTEN_TBEIEN_Pos              (1)
#define SC_INTEN_TBEIEN_Msk              (0x1ul << SC_INTEN_TBEIEN_Pos)

#define SC_INTEN_TERRIEN_Pos             (2)
#define SC_INTEN_TERRIEN_Msk             (0x1ul << SC_INTEN_TERRIEN_Pos)

#define SC_INTEN_TMR0IEN_Pos             (3)
#define SC_INTEN_TMR0IEN_Msk             (0x1ul << SC_INTEN_TMR0IEN_Pos)

#define SC_INTEN_TMR1IEN_Pos             (4)
#define SC_INTEN_TMR1IEN_Msk             (0x1ul << SC_INTEN_TMR1IEN_Pos)

#define SC_INTEN_TMR2IEN_Pos             (5)
#define SC_INTEN_TMR2IEN_Msk             (0x1ul << SC_INTEN_TMR2IEN_Pos)

#define SC_INTEN_BGTIEN_Pos              (6)
#define SC_INTEN_BGTIEN_Msk              (0x1ul << SC_INTEN_BGTIEN_Pos)

#define SC_INTEN_CDIEN_Pos               (7)
#define SC_INTEN_CDIEN_Msk               (0x1ul << SC_INTEN_CDIEN_Pos)

#define SC_INTEN_INITIEN_Pos             (8)
#define SC_INTEN_INITIEN_Msk             (0x1ul << SC_INTEN_INITIEN_Pos)

#define SC_INTEN_RXTOIF_Pos              (9)
#define SC_INTEN_RXTOIF_Msk              (0x1ul << SC_INTEN_RXTOIF_Pos)

#define SC_INTEN_ACERRIEN_Pos            (10)
#define SC_INTEN_ACERRIEN_Msk            (0x1ul << SC_INTEN_ACERRIEN_Pos)

#define SC_INTSTS_RDAIF_Pos              (0)
#define SC_INTSTS_RDAIF_Msk              (0x1ul << SC_INTSTS_RDAIF_Pos)

#define SC_INTSTS_TBEIF_Pos              (1)
#define SC_INTSTS_TBEIF_Msk              (0x1ul << SC_INTSTS_TBEIF_Pos)

#define SC_INTSTS_TERRIF_Pos             (2)
#define SC_INTSTS_TERRIF_Msk             (0x1ul << SC_INTSTS_TERRIF_Pos)

#define SC_INTSTS_TMR0IF_Pos             (3)
#define SC_INTSTS_TMR0IF_Msk             (0x1ul << SC_INTSTS_TMR0IF_Pos)

#define SC_INTSTS_TMR1IF_Pos             (4)
#define SC_INTSTS_TMR1IF_Msk             (0x1ul << SC_INTSTS_TMR1IF_Pos)

#define SC_INTSTS_TMR2IF_Pos             (5)
#define SC_INTSTS_TMR2IF_Msk             (0x1ul << SC_INTSTS_TMR2IF_Pos)

#define SC_INTSTS_BGTIF_Pos              (6)
#define SC_INTSTS_BGTIF_Msk              (0x1ul << SC_INTSTS_BGTIF_Pos)

#define SC_INTSTS_CDIF_Pos               (7)
#define SC_INTSTS_CDIF_Msk               (0x1ul << SC_INTSTS_CDIF_Pos)

#define SC_INTSTS_INITIF_Pos             (8)
#define SC_INTSTS_INITIF_Msk             (0x1ul << SC_INTSTS_INITIF_Pos)

#define SC_INTSTS_RBTOIF_Pos             (9)
#define SC_INTSTS_RBTOIF_Msk             (0x1ul << SC_INTSTS_RBTOIF_Pos)

#define SC_INTSTS_ACERRIF_Pos            (10)
#define SC_INTSTS_ACERRIF_Msk            (0x1ul << SC_INTSTS_ACERRIF_Pos)

#define SC_STATUS_RXOV_Pos               (0)
#define SC_STATUS_RXOV_Msk               (0x1ul << SC_STATUS_RXOV_Pos)

#define SC_STATUS_RXEMPTY_Pos            (1)
#define SC_STATUS_RXEMPTY_Msk            (0x1ul << SC_STATUS_RXEMPTY_Pos)

#define SC_STATUS_RXFULLF_Pos            (2)
#define SC_STATUS_RXFULLF_Msk            (0x1ul << SC_STATUS_RXFULLF_Pos)

#define SC_STATUS_PEF_Pos                (4)
#define SC_STATUS_PEF_Msk                (0x1ul << SC_STATUS_PEF_Pos)

#define SC_STATUS_FEF_Pos                (5)
#define SC_STATUS_FEF_Msk                (0x1ul << SC_STATUS_FEF_Pos)

#define SC_STATUS_BEF_Pos                (6)
#define SC_STATUS_BEF_Msk                (0x1ul << SC_STATUS_BEF_Pos)

#define SC_STATUS_TXOVER_Pos             (8)
#define SC_STATUS_TXOVER_Msk             (0x1ul << SC_STATUS_TXOVER_Pos)

#define SC_STATUS_TXEMPTY_Pos            (9)
#define SC_STATUS_TXEMPTY_Msk            (0x1ul << SC_STATUS_TXEMPTY_Pos)

#define SC_STATUS_TXFULL_Pos             (10)
#define SC_STATUS_TXFULL_Msk             (0x1ul << SC_STATUS_TXFULL_Pos)

#define SC_STATUS_CREMOVE_Pos            (11)
#define SC_STATUS_CREMOVE_Msk            (0x1ul << SC_STATUS_CREMOVE_Pos)

#define SC_STATUS_CINSERT_Pos            (12)
#define SC_STATUS_CINSERT_Msk            (0x1ul << SC_STATUS_CINSERT_Pos)

#define SC_STATUS_CDPINSTS_Pos           (13)
#define SC_STATUS_CDPINSTS_Msk           (0x1ul << SC_STATUS_CDPINSTS_Pos)

#define SC_STATUS_RXPOINT_Pos            (16)
#define SC_STATUS_RXPOINT_Msk            (0x3ul << SC_STATUS_RXPOINT_Pos)

#define SC_STATUS_RXRERR_Pos             (21)
#define SC_STATUS_RXRERR_Msk             (0x1ul << SC_STATUS_RXRERR_Pos)

#define SC_STATUS_RXOVERR_Pos            (22)
#define SC_STATUS_RXOVERR_Msk            (0x1ul << SC_STATUS_RXOVERR_Pos)

#define SC_STATUS_RXACT_Pos              (23)
#define SC_STATUS_RXACT_Msk              (0x1ul << SC_STATUS_RXACT_Pos)

#define SC_STATUS_TXPOINT_Pos            (24)
#define SC_STATUS_TXPOINT_Msk            (0x3ul << SC_STATUS_TXPOINT_Pos)

#define SC_STATUS_TXRERR_Pos             (29)
#define SC_STATUS_TXRERR_Msk             (0x1ul << SC_STATUS_TXRERR_Pos)

#define SC_STATUS_TXOVERR_Pos            (30)
#define SC_STATUS_TXOVERR_Msk            (0x1ul << SC_STATUS_TXOVERR_Pos)

#define SC_STATUS_TXACT_Pos              (31)
#define SC_STATUS_TXACT_Msk              (0x1ul << SC_STATUS_TXACT_Pos)

#define SC_PINCTL_PWREN_Pos              (0)
#define SC_PINCTL_PWREN_Msk              (0x1ul << SC_PINCTL_PWREN_Pos)

#define SC_PINCTL_SCRST_Pos              (1)
#define SC_PINCTL_SCRST_Msk              (0x1ul << SC_PINCTL_SCRST_Pos)

#define SC_PINCTL_CSTOPLV_Pos            (5)
#define SC_PINCTL_CSTOPLV_Msk            (0x1ul << SC_PINCTL_CSTOPLV_Pos)

#define SC_PINCTL_CLKKEEP_Pos            (6)
#define SC_PINCTL_CLKKEEP_Msk            (0x1ul << SC_PINCTL_CLKKEEP_Pos)

#define SC_PINCTL_SCOENST_Pos            (8)
#define SC_PINCTL_SCOENST_Msk            (0x1ul << SC_PINCTL_SCOENST_Pos)

#define SC_PINCTL_SCDOUT_Pos             (9)
#define SC_PINCTL_SCDOUT_Msk             (0x1ul << SC_PINCTL_SCDOUT_Pos)

#define SC_PINCTL_PWRINV_Pos             (11)
#define SC_PINCTL_PWRINV_Msk             (0x1ul << SC_PINCTL_PWRINV_Pos)

#define SC_PINCTL_SCDIN_Pos              (12)
#define SC_PINCTL_SCDIN_Msk              (0x1ul << SC_PINCTL_SCDIN_Pos)

#define SC_PINCTL_DATSTS_Pos             (16)
#define SC_PINCTL_DATSTS_Msk             (0x1ul << SC_PINCTL_DATSTS_Pos)

#define SC_PINCTL_PWRSTS_Pos             (17)
#define SC_PINCTL_PWRSTS_Msk             (0x1ul << SC_PINCTL_PWRSTS_Pos)

#define SC_PINCTL_RSTSTS_Pos             (18)
#define SC_PINCTL_RSTSTS_Msk             (0x1ul << SC_PINCTL_RSTSTS_Pos)

#define SC_PINCTL_SYNC_Pos               (30)
#define SC_PINCTL_SYNC_Msk               (0x1ul << SC_PINCTL_SYNC_Pos)

#define SC_PINCTL_LOOPBK_Pos             (31)
#define SC_PINCTL_LOOPBK_Msk             (0x1ul << SC_PINCTL_LOOPBK_Pos)

#define SC_TMRCTL0_CNT0_Pos              (0)
#define SC_TMRCTL0_CNT0_Msk              (0xfffffful << SC_TMRCTL0_CNT0_Pos)

#define SC_TMRCTL0_OPMODE_Pos            (24)
#define SC_TMRCTL0_OPMODE_Msk            (0xful << SC_TMRCTL0_OPMODE_Pos)

#define SC_TMRCTL1_CNT1_Pos              (0)
#define SC_TMRCTL1_CNT1_Msk              (0xfful << SC_TMRCTL1_CNT1_Pos)

#define SC_TMRCTL1_OPMODE_Pos            (24)
#define SC_TMRCTL1_OPMODE_Msk            (0xful << SC_TMRCTL1_OPMODE_Pos)

#define SC_TMRCTL2_CNT2_Pos              (0)
#define SC_TMRCTL2_CNT2_Msk              (0xfful << SC_TMRCTL2_CNT2_Pos)

#define SC_TMRCTL2_OPMODE_Pos            (24)
#define SC_TMRCTL2_OPMODE_Msk            (0xful << SC_TMRCTL2_OPMODE_Pos)

#define SC_UARTCTL_UARTEN_Pos            (0)
#define SC_UARTCTL_UARTEN_Msk            (0x1ul << SC_UARTCTL_UARTEN_Pos)

#define SC_UARTCTL_WLS10_Pos             (4)
#define SC_UARTCTL_WLS10_Msk             (0x3ul << SC_UARTCTL_WLS10_Pos)

#define SC_UARTCTL_PBOFF_Pos             (6)
#define SC_UARTCTL_PBOFF_Msk             (0x1ul << SC_UARTCTL_PBOFF_Pos)

#define SC_UARTCTL_OPE_Pos               (7)
#define SC_UARTCTL_OPE_Msk               (0x1ul << SC_UARTCTL_OPE_Pos)

#define SC_TMRDAT0_CNT0_Pos              (0)
#define SC_TMRDAT0_CNT0_Msk              (0xfffffful << SC_TMRDAT0_CNT0_Pos)

#define SC_TMRDAT1_2_CNT1_Pos            (0)
#define SC_TMRDAT1_2_CNT1_Msk            (0xfful << SC_TMRDAT1_2_CNT1_Pos)

#define SC_TMRDAT1_2_CNT2_Pos            (8)
#define SC_TMRDAT1_2_CNT2_Msk            (0xfful << SC_TMRDAT1_2_CNT2_Pos)

#define SC_PETCTL_PEBST_Pos              (0)
#define SC_PETCTL_PEBST_Msk              (0xfful << SC_PETCTL_PEBST_Pos)

#define SC_PETCTL_PEBL_Pos               (8)
#define SC_PETCTL_PEBL_Msk               (0xfful << SC_PETCTL_PEBL_Pos)

#define SC_PETCTL_PETCEN_Pos             (24)
#define SC_PETCTL_PETCEN_Msk             (0x1ul << SC_PETCTL_PETCEN_Pos)

#define SC_EGT_BGTEXT_Pos                (0)
#define SC_EGT_BGTEXT_Msk                (0x1fful << SC_EGT_BGTEXT_Pos)

#define SC_EGT_BGTEXTEN_Pos              (24)
#define SC_EGT_BGTEXTEN_Msk              (0x1ul << SC_EGT_BGTEXTEN_Pos)

#define SC_EGTADJ_EGTA_Pos               (0)
#define SC_EGTADJ_EGTA_Msk               (0xfful << SC_EGTADJ_EGTA_Pos)

#define SC_EGTADJ_EGTAEN_Pos             (24)
#define SC_EGTADJ_EGTAEN_Msk             (0x1ul << SC_EGTADJ_EGTAEN_Pos)

/**@}*/ /* SC_CONST */
/**@}*/ /* end of SC register group */


/*---------------------- Serial Peripheral Interface Controller -------------------------*/
/**
    @addtogroup SPI Serial Peripheral Interface Controller(SPI)
    Memory Mapped Structure for SPI Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] Control Register                                                 */
    __IO uint32_t CLKDIV;                /*!< [0x0004] Clock Divider Register                                           */
    __IO uint32_t SSCTL;                 /*!< [0x0008] Slave Select Control Register                                    */
    __IO uint32_t PDMACTL;               /*!< [0x000c] SPI PDMA Control Register                                        */
    __IO uint32_t FIFOCTL;               /*!< [0x0010] SPI FIFO Control Register                                        */
    __IO uint32_t STATUS;                /*!< [0x0014] SPI Status Register                                              */
         uint32_t RESERVE0[2];

    __O  uint32_t TX;                    /*!< [0x0020] Data Transmit Register                                           */
         uint32_t RESERVE1[3];

    __I  uint32_t RX;                    /*!< [0x0030] Data Receive Register                                            */
         uint32_t RESERVE2[11];

    __IO uint32_t I2SCTL;                /*!< [0x0060] I2S Control Register                                             */
    __IO uint32_t I2SCLK;                /*!< [0x0064] I2S Clock Divider Control Register                               */
    __IO uint32_t I2SSTS;                /*!< [0x0068] I2S Status Register                                              */

} SPI_T;

/**
    @addtogroup SPI_CONST SPI Bit Field Definition
    Constant Definitions for SPI Controller
@{ */

#define SPI_CTL_SPIEN_Pos                (0)
#define SPI_CTL_SPIEN_Msk                (0x1ul << SPI_CTL_SPIEN_Pos)

#define SPI_CTL_RXNEG_Pos                (1)
#define SPI_CTL_RXNEG_Msk                (0x1ul << SPI_CTL_RXNEG_Pos)

#define SPI_CTL_TXNEG_Pos                (2)
#define SPI_CTL_TXNEG_Msk                (0x1ul << SPI_CTL_TXNEG_Pos)

#define SPI_CTL_CLKPOL_Pos               (3)
#define SPI_CTL_CLKPOL_Msk               (0x1ul << SPI_CTL_CLKPOL_Pos)

#define SPI_CTL_SUSPITV_Pos              (4)
#define SPI_CTL_SUSPITV_Msk              (0xful << SPI_CTL_SUSPITV_Pos)

#define SPI_CTL_DWIDTH_Pos               (8)
#define SPI_CTL_DWIDTH_Msk               (0x1ful << SPI_CTL_DWIDTH_Pos)

#define SPI_CTL_LSB_Pos                  (13)
#define SPI_CTL_LSB_Msk                  (0x1ul << SPI_CTL_LSB_Pos)

#define SPI_CTL_TWOBIT_Pos               (16)
#define SPI_CTL_TWOBIT_Msk               (0x1ul << SPI_CTL_TWOBIT_Pos)

#define SPI_CTL_UNITIEN_Pos              (17)
#define SPI_CTL_UNITIEN_Msk              (0x1ul << SPI_CTL_UNITIEN_Pos)

#define SPI_CTL_SLAVE_Pos                (18)
#define SPI_CTL_SLAVE_Msk                (0x1ul << SPI_CTL_SLAVE_Pos)

#define SPI_CTL_REORDER_Pos              (19)
#define SPI_CTL_REORDER_Msk              (0x1ul << SPI_CTL_REORDER_Pos)

#define SPI_CTL_QDIODIR_Pos              (20)
#define SPI_CTL_QDIODIR_Msk              (0x1ul << SPI_CTL_QDIODIR_Pos)

#define SPI_CTL_DUALIOEN_Pos             (21)
#define SPI_CTL_DUALIOEN_Msk             (0x1ul << SPI_CTL_DUALIOEN_Pos)

#define SPI_CTL_QUADIOEN_Pos             (22)
#define SPI_CTL_QUADIOEN_Msk             (0x1ul << SPI_CTL_QUADIOEN_Pos)

#define SPI_CLKDIV_DIVIDER_Pos           (0)
#define SPI_CLKDIV_DIVIDER_Msk           (0xfful << SPI_CLKDIV_DIVIDER_Pos)

#define SPI_SSCTL_SS_Pos                 (0)
#define SPI_SSCTL_SS_Msk                 (0x1ul << SPI_SSCTL_SS_Pos)

#define SPI_SSCTL_SSACTPOL_Pos           (2)
#define SPI_SSCTL_SSACTPOL_Msk           (0x1ul << SPI_SSCTL_SSACTPOL_Pos)

#define SPI_SSCTL_AUTOSS_Pos             (3)
#define SPI_SSCTL_AUTOSS_Msk             (0x1ul << SPI_SSCTL_AUTOSS_Pos)

#define SPI_SSCTL_SLV3WIRE_Pos           (4)
#define SPI_SSCTL_SLV3WIRE_Msk           (0x1ul << SPI_SSCTL_SLV3WIRE_Pos)

#define SPI_SSCTL_SLVTOIEN_Pos           (5)
#define SPI_SSCTL_SLVTOIEN_Msk           (0x1ul << SPI_SSCTL_SLVTOIEN_Pos)

#define SPI_SSCTL_SLVTORST_Pos           (6)
#define SPI_SSCTL_SLVTORST_Msk           (0x1ul << SPI_SSCTL_SLVTORST_Pos)

#define SPI_SSCTL_SLVBCEIEN_Pos          (8)
#define SPI_SSCTL_SLVBCEIEN_Msk          (0x1ul << SPI_SSCTL_SLVBCEIEN_Pos)

#define SPI_SSCTL_SLVUDRIEN_Pos          (9)
#define SPI_SSCTL_SLVUDRIEN_Msk          (0x1ul << SPI_SSCTL_SLVUDRIEN_Pos)

#define SPI_SSCTL_SSACTIEN_Pos           (12)
#define SPI_SSCTL_SSACTIEN_Msk           (0x1ul << SPI_SSCTL_SSACTIEN_Pos)

#define SPI_SSCTL_SSINAIEN_Pos           (13)
#define SPI_SSCTL_SSINAIEN_Msk           (0x1ul << SPI_SSCTL_SSINAIEN_Pos)

#define SPI_SSCTL_SLVTOCNT_Pos           (16)
#define SPI_SSCTL_SLVTOCNT_Msk           (0xfffful << SPI_SSCTL_SLVTOCNT_Pos)

#define SPI_PDMACTL_TXPDMAEN_Pos         (0)
#define SPI_PDMACTL_TXPDMAEN_Msk         (0x1ul << SPI_PDMACTL_TXPDMAEN_Pos)

#define SPI_PDMACTL_RXPDMAEN_Pos         (1)
#define SPI_PDMACTL_RXPDMAEN_Msk         (0x1ul << SPI_PDMACTL_RXPDMAEN_Pos)

#define SPI_PDMACTL_PDMARST_Pos          (2)
#define SPI_PDMACTL_PDMARST_Msk          (0x1ul << SPI_PDMACTL_PDMARST_Pos)

#define SPI_FIFOCTL_RXRST_Pos            (0)
#define SPI_FIFOCTL_RXRST_Msk            (0x1ul << SPI_FIFOCTL_RXRST_Pos)

#define SPI_FIFOCTL_TXRST_Pos            (1)
#define SPI_FIFOCTL_TXRST_Msk            (0x1ul << SPI_FIFOCTL_TXRST_Pos)

#define SPI_FIFOCTL_RXTHIEN_Pos          (2)
#define SPI_FIFOCTL_RXTHIEN_Msk          (0x1ul << SPI_FIFOCTL_RXTHIEN_Pos)

#define SPI_FIFOCTL_TXTHIEN_Pos          (3)
#define SPI_FIFOCTL_TXTHIEN_Msk          (0x1ul << SPI_FIFOCTL_TXTHIEN_Pos)

#define SPI_FIFOCTL_RXTOIEN_Pos          (4)
#define SPI_FIFOCTL_RXTOIEN_Msk          (0x1ul << SPI_FIFOCTL_RXTOIEN_Pos)

#define SPI_FIFOCTL_RXOVIEN_Pos          (5)
#define SPI_FIFOCTL_RXOVIEN_Msk          (0x1ul << SPI_FIFOCTL_RXOVIEN_Pos)

#define SPI_FIFOCTL_SLVUDFPOL_Pos        (6)
#define SPI_FIFOCTL_SLVUDFPOL_Msk        (0x1ul << SPI_FIFOCTL_SLVUDFPOL_Pos)

#define SPI_FIFOCTL_SLVUDFIEN_Pos        (7)
#define SPI_FIFOCTL_SLVUDFIEN_Msk        (0x1ul << SPI_FIFOCTL_SLVUDFIEN_Pos)

#define SPI_FIFOCTL_RXFIFOCLR_Pos        (8)
#define SPI_FIFOCTL_RXFIFOCLR_Msk        (0x1ul << SPI_FIFOCTL_RXFIFOCLR_Pos)

#define SPI_FIFOCTL_TXFIFOCLR_Pos        (9)
#define SPI_FIFOCTL_TXFIFOCLR_Msk        (0x1ul << SPI_FIFOCTL_TXFIFOCLR_Pos)

#define SPI_FIFOCTL_RXTH_Pos             (24)
#define SPI_FIFOCTL_RXTH_Msk             (0x7ul << SPI_FIFOCTL_RXTH_Pos)

#define SPI_FIFOCTL_TXTH_Pos             (28)
#define SPI_FIFOCTL_TXTH_Msk             (0x7ul << SPI_FIFOCTL_TXTH_Pos)

#define SPI_STATUS_BUSY_Pos              (0)
#define SPI_STATUS_BUSY_Msk              (0x1ul << SPI_STATUS_BUSY_Pos)

#define SPI_STATUS_UNITIF_Pos            (1)
#define SPI_STATUS_UNITIF_Msk            (0x1ul << SPI_STATUS_UNITIF_Pos)

#define SPI_STATUS_SSACTIF_Pos           (2)
#define SPI_STATUS_SSACTIF_Msk           (0x1ul << SPI_STATUS_SSACTIF_Pos)

#define SPI_STATUS_SSINAIF_Pos           (3)
#define SPI_STATUS_SSINAIF_Msk           (0x1ul << SPI_STATUS_SSINAIF_Pos)

#define SPI_STATUS_SSLINE_Pos            (4)
#define SPI_STATUS_SSLINE_Msk            (0x1ul << SPI_STATUS_SSLINE_Pos)

#define SPI_STATUS_SLVTOIF_Pos           (5)
#define SPI_STATUS_SLVTOIF_Msk           (0x1ul << SPI_STATUS_SLVTOIF_Pos)

#define SPI_STATUS_SLVBCEIF_Pos          (6)
#define SPI_STATUS_SLVBCEIF_Msk          (0x1ul << SPI_STATUS_SLVBCEIF_Pos)

#define SPI_STATUS_SLVUDRIF_Pos          (7)
#define SPI_STATUS_SLVUDRIF_Msk          (0x1ul << SPI_STATUS_SLVUDRIF_Pos)

#define SPI_STATUS_RXEMPTY_Pos           (8)
#define SPI_STATUS_RXEMPTY_Msk           (0x1ul << SPI_STATUS_RXEMPTY_Pos)

#define SPI_STATUS_RXFULL_Pos            (9)
#define SPI_STATUS_RXFULL_Msk            (0x1ul << SPI_STATUS_RXFULL_Pos)

#define SPI_STATUS_RXTHIF_Pos            (10)
#define SPI_STATUS_RXTHIF_Msk            (0x1ul << SPI_STATUS_RXTHIF_Pos)

#define SPI_STATUS_RXOVIF_Pos            (11)
#define SPI_STATUS_RXOVIF_Msk            (0x1ul << SPI_STATUS_RXOVIF_Pos)

#define SPI_STATUS_RXTOIF_Pos            (12)
#define SPI_STATUS_RXTOIF_Msk            (0x1ul << SPI_STATUS_RXTOIF_Pos)

#define SPI_STATUS_SPIENSTS_Pos          (15)
#define SPI_STATUS_SPIENSTS_Msk          (0x1ul << SPI_STATUS_SPIENSTS_Pos)

#define SPI_STATUS_TXEMPTY_Pos           (16)
#define SPI_STATUS_TXEMPTY_Msk           (0x1ul << SPI_STATUS_TXEMPTY_Pos)

#define SPI_STATUS_TXFULL_Pos            (17)
#define SPI_STATUS_TXFULL_Msk            (0x1ul << SPI_STATUS_TXFULL_Pos)

#define SPI_STATUS_TXTHIF_Pos            (18)
#define SPI_STATUS_TXTHIF_Msk            (0x1ul << SPI_STATUS_TXTHIF_Pos)

#define SPI_STATUS_SLVUDFIF_Pos          (19)
#define SPI_STATUS_SLVUDFIF_Msk          (0x1ul << SPI_STATUS_SLVUDFIF_Pos)

#define SPI_STATUS_TXRXRST_Pos           (23)
#define SPI_STATUS_TXRXRST_Msk           (0x1ul << SPI_STATUS_TXRXRST_Pos)

#define SPI_STATUS_RXCNT_Pos             (24)
#define SPI_STATUS_RXCNT_Msk             (0xful << SPI_STATUS_RXCNT_Pos)

#define SPI_STATUS_TXCNT_Pos             (28)
#define SPI_STATUS_TXCNT_Msk             (0xful << SPI_STATUS_TXCNT_Pos)

#define SPI_TX_TX_Pos                    (0)
#define SPI_TX_TX_Msk                    (0xfffffffful << SPI_TX_TX_Pos)

#define SPI_RX_RX_Pos                    (0)
#define SPI_RX_RX_Msk                    (0xfffffffful << SPI_RX_RX_Pos)

#define SPI_I2SCTL_I2SEN_Pos             (0)
#define SPI_I2SCTL_I2SEN_Msk             (0x1ul << SPI_I2SCTL_I2SEN_Pos)

#define SPI_I2SCTL_TXEN_Pos              (1)
#define SPI_I2SCTL_TXEN_Msk              (0x1ul << SPI_I2SCTL_TXEN_Pos)

#define SPI_I2SCTL_RXEN_Pos              (2)
#define SPI_I2SCTL_RXEN_Msk              (0x1ul << SPI_I2SCTL_RXEN_Pos)

#define SPI_I2SCTL_MUTE_Pos              (3)
#define SPI_I2SCTL_MUTE_Msk              (0x1ul << SPI_I2SCTL_MUTE_Pos)

#define SPI_I2SCTL_WDWIDTH_Pos           (4)
#define SPI_I2SCTL_WDWIDTH_Msk           (0x3ul << SPI_I2SCTL_WDWIDTH_Pos)

#define SPI_I2SCTL_MONO_Pos              (6)
#define SPI_I2SCTL_MONO_Msk              (0x1ul << SPI_I2SCTL_MONO_Pos)

#define SPI_I2SCTL_ORDER_Pos             (7)
#define SPI_I2SCTL_ORDER_Msk             (0x1ul << SPI_I2SCTL_ORDER_Pos)

#define SPI_I2SCTL_SLAVE_Pos             (8)
#define SPI_I2SCTL_SLAVE_Msk             (0x1ul << SPI_I2SCTL_SLAVE_Pos)

#define SPI_I2SCTL_MCLKEN_Pos            (15)
#define SPI_I2SCTL_MCLKEN_Msk            (0x1ul << SPI_I2SCTL_MCLKEN_Pos)

#define SPI_I2SCTL_RZCEN_Pos             (16)
#define SPI_I2SCTL_RZCEN_Msk             (0x1ul << SPI_I2SCTL_RZCEN_Pos)

#define SPI_I2SCTL_LZCEN_Pos             (17)
#define SPI_I2SCTL_LZCEN_Msk             (0x1ul << SPI_I2SCTL_LZCEN_Pos)

#define SPI_I2SCTL_RXLCH_Pos             (23)
#define SPI_I2SCTL_RXLCH_Msk             (0x1ul << SPI_I2SCTL_RXLCH_Pos)

#define SPI_I2SCTL_RZCIEN_Pos            (24)
#define SPI_I2SCTL_RZCIEN_Msk            (0x1ul << SPI_I2SCTL_RZCIEN_Pos)

#define SPI_I2SCTL_LZCIEN_Pos            (25)
#define SPI_I2SCTL_LZCIEN_Msk            (0x1ul << SPI_I2SCTL_LZCIEN_Pos)

#define SPI_I2SCTL_FORMAT_Pos            (28)
#define SPI_I2SCTL_FORMAT_Msk            (0x3ul << SPI_I2SCTL_FORMAT_Pos)

#define SPI_I2SCLK_MCLKDIV_Pos           (0)
#define SPI_I2SCLK_MCLKDIV_Msk           (0x3ful << SPI_I2SCLK_MCLKDIV_Pos)

#define SPI_I2SCLK_BCLKDIV_Pos           (8)
#define SPI_I2SCLK_BCLKDIV_Msk           (0x1fful << SPI_I2SCLK_BCLKDIV_Pos)

#define SPI_I2SSTS_RIGHT_Pos             (4)
#define SPI_I2SSTS_RIGHT_Msk             (0x1ul << SPI_I2SSTS_RIGHT_Pos)

#define SPI_I2SSTS_RXEMPTY_Pos           (8)
#define SPI_I2SSTS_RXEMPTY_Msk           (0x1ul << SPI_I2SSTS_RXEMPTY_Pos)

#define SPI_I2SSTS_RXFULL_Pos            (9)
#define SPI_I2SSTS_RXFULL_Msk            (0x1ul << SPI_I2SSTS_RXFULL_Pos)

#define SPI_I2SSTS_RXTHIF_Pos            (10)
#define SPI_I2SSTS_RXTHIF_Msk            (0x1ul << SPI_I2SSTS_RXTHIF_Pos)

#define SPI_I2SSTS_RXOVIF_Pos            (11)
#define SPI_I2SSTS_RXOVIF_Msk            (0x1ul << SPI_I2SSTS_RXOVIF_Pos)

#define SPI_I2SSTS_RXTOIF_Pos            (12)
#define SPI_I2SSTS_RXTOIF_Msk            (0x1ul << SPI_I2SSTS_RXTOIF_Pos)

#define SPI_I2SSTS_I2SENSTS_Pos          (15)
#define SPI_I2SSTS_I2SENSTS_Msk          (0x1ul << SPI_I2SSTS_I2SENSTS_Pos)

#define SPI_I2SSTS_TXEMPTY_Pos           (16)
#define SPI_I2SSTS_TXEMPTY_Msk           (0x1ul << SPI_I2SSTS_TXEMPTY_Pos)

#define SPI_I2SSTS_TXFULL_Pos            (17)
#define SPI_I2SSTS_TXFULL_Msk            (0x1ul << SPI_I2SSTS_TXFULL_Pos)

#define SPI_I2SSTS_TXTHIF_Pos            (18)
#define SPI_I2SSTS_TXTHIF_Msk            (0x1ul << SPI_I2SSTS_TXTHIF_Pos)

#define SPI_I2SSTS_TXUDFIF_Pos           (19)
#define SPI_I2SSTS_TXUDFIF_Msk           (0x1ul << SPI_I2SSTS_TXUDFIF_Pos)

#define SPI_I2SSTS_RZCIF_Pos             (20)
#define SPI_I2SSTS_RZCIF_Msk             (0x1ul << SPI_I2SSTS_RZCIF_Pos)

#define SPI_I2SSTS_LZCIF_Pos             (21)
#define SPI_I2SSTS_LZCIF_Msk             (0x1ul << SPI_I2SSTS_LZCIF_Pos)

#define SPI_I2SSTS_TXRXRST_Pos           (23)
#define SPI_I2SSTS_TXRXRST_Msk           (0x1ul << SPI_I2SSTS_TXRXRST_Pos)

#define SPI_I2SSTS_RXCNT_Pos             (24)
#define SPI_I2SSTS_RXCNT_Msk             (0x7ul << SPI_I2SSTS_RXCNT_Pos)

#define SPI_I2SSTS_TXCNT_Pos             (28)
#define SPI_I2SSTS_TXCNT_Msk             (0x7ul << SPI_I2SSTS_TXCNT_Pos)

/**@}*/ /* SPI_CONST */
/**@}*/ /* end of SPI register group */


/*---------------------- Touch Key Controller -------------------------*/
/**
    @addtogroup TK Touch Key Controller(TK)
    Memory Mapped Structure for TK Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] Touch Key Scan Control Register                                  */
    __IO uint32_t REFCTL;                /*!< [0x0004] Touch Key Reference Control Register                             */
    __IO uint32_t CCBDAT0;               /*!< [0x0008] Touch Key Complement Capacitor Bank Data Register 0              */
    __IO uint32_t CCBDAT1;               /*!< [0x000c] Touch Key Complement Capacitor Bank Data Register 1              */
    __IO uint32_t CCBDAT2;               /*!< [0x0010] Touch Key Complement Capacitor Bank Data Register 2              */
    __IO uint32_t CCBDAT3;               /*!< [0x0014] Touch Key Complement Capacitor Bank Data Register 3              */
    __IO uint32_t CCBDAT4;               /*!< [0x0018] Touch Key Complement Capacitor Bank Data Register 4              */
    __IO uint32_t IDLESEL;               /*!< [0x001c] Touch Key Idle State Control Register                            */
    __IO uint32_t POLSEL;                /*!< [0x0020] Touch Key Polarity Select Register                               */
    __IO uint32_t POLCTL;                /*!< [0x0024] Touch Key Polarity Control Register                              */
    __I  uint32_t STATUS;                /*!< [0x0028] Touch Key Status Register                                        */
    __I  uint32_t DAT0;                  /*!< [0x002c] Touch Key Data Register 0                                        */
    __I  uint32_t DAT1;                  /*!< [0x0030] Touch Key Data Register 1                                        */
    __I  uint32_t DAT2;                  /*!< [0x0034] Touch Key Data Register 2                                        */
    __I  uint32_t DAT3;                  /*!< [0x0038] Touch Key Data Register 3                                        */
    __I  uint32_t DAT4;                  /*!< [0x003c] Touch Key Data Register 4                                        */
    __IO uint32_t INTEN;                 /*!< [0x0040] Touch Key Interrupt Enable Register                              */
    __IO uint32_t TH0_1;                 /*!< [0x0044] Touch Key TK0/TK1 Threshold Control Register                     */
    __IO uint32_t TH2_3;                 /*!< [0x0048] Touch Key TK2/TK3 Threshold Control Register                     */
    __IO uint32_t TH4_5;                 /*!< [0x004c] Touch Key TK4/TK5 Threshold Control Register                     */
    __IO uint32_t TH6_7;                 /*!< [0x0050] Touch Key TK6/TK7 Threshold Control Register                     */
    __IO uint32_t TH8_9;                 /*!< [0x0054] Touch Key TK8/TK9 Threshold Control Register                     */
    __IO uint32_t TH10_11;               /*!< [0x0058] Touch Key TK10/TK11 Threshold Control Register                   */
    __IO uint32_t TH12_13;               /*!< [0x005c] Touch Key TK12/TK13 Threshold Control Register                   */
    __IO uint32_t TH14_15;               /*!< [0x0060] Touch Key TK14/TK15 Threshold Control Register                   */
    __IO uint32_t TH16;                 /*!< [0x0064] Touch Key TK16 Threshold Control Register                        */
         uint32_t RESERVE0[998];
} TK_T;

/**
    @addtogroup TK_CONST TK Bit Field Definition
    Constant Definitions for TK Controller
@{ */

#define TK_CTL_TKSEN0_Pos                (0)
#define TK_CTL_TKSEN0_Msk                (0x1ul << TK_CTL_TKSEN0_Pos)

#define TK_CTL_TKSEN1_Pos                (1)
#define TK_CTL_TKSEN1_Msk                (0x1ul << TK_CTL_TKSEN1_Pos)

#define TK_CTL_TKSEN2_Pos                (2)
#define TK_CTL_TKSEN2_Msk                (0x1ul << TK_CTL_TKSEN2_Pos)

#define TK_CTL_TKSEN3_Pos                (3)
#define TK_CTL_TKSEN3_Msk                (0x1ul << TK_CTL_TKSEN3_Pos)

#define TK_CTL_TKSEN4_Pos                (4)
#define TK_CTL_TKSEN4_Msk                (0x1ul << TK_CTL_TKSEN4_Pos)

#define TK_CTL_TKSEN5_Pos                (5)
#define TK_CTL_TKSEN5_Msk                (0x1ul << TK_CTL_TKSEN5_Pos)

#define TK_CTL_TKSEN6_Pos                (6)
#define TK_CTL_TKSEN6_Msk                (0x1ul << TK_CTL_TKSEN6_Pos)

#define TK_CTL_TKSEN7_Pos                (7)
#define TK_CTL_TKSEN7_Msk                (0x1ul << TK_CTL_TKSEN7_Pos)

#define TK_CTL_TKSEN8_Pos                (8)
#define TK_CTL_TKSEN8_Msk                (0x1ul << TK_CTL_TKSEN8_Pos)

#define TK_CTL_TKSEN9_Pos                (9)
#define TK_CTL_TKSEN9_Msk                (0x1ul << TK_CTL_TKSEN9_Pos)

#define TK_CTL_TKSEN10_Pos               (10)
#define TK_CTL_TKSEN10_Msk               (0x1ul << TK_CTL_TKSEN10_Pos)

#define TK_CTL_TKSEN11_Pos               (11)
#define TK_CTL_TKSEN11_Msk               (0x1ul << TK_CTL_TKSEN11_Pos)

#define TK_CTL_TKSEN12_Pos               (12)
#define TK_CTL_TKSEN12_Msk               (0x1ul << TK_CTL_TKSEN12_Pos)

#define TK_CTL_TKSEN13_Pos               (13)
#define TK_CTL_TKSEN13_Msk               (0x1ul << TK_CTL_TKSEN13_Pos)

#define TK_CTL_TKSEN14_Pos               (14)
#define TK_CTL_TKSEN14_Msk               (0x1ul << TK_CTL_TKSEN14_Pos)

#define TK_CTL_TKSEN15_Pos               (15)
#define TK_CTL_TKSEN15_Msk               (0x1ul << TK_CTL_TKSEN15_Pos)

#define TK_CTL_TKSEN16_Pos               (16)
#define TK_CTL_TKSEN16_Msk               (0x1ul << TK_CTL_TKSEN16_Pos)

#define TK_CTL_AVCCHSEL_Pos              (20)
#define TK_CTL_AVCCHSEL_Msk              (0x7ul << TK_CTL_AVCCHSEL_Pos)

#define TK_CTL_SCAN_Pos                  (24)
#define TK_CTL_SCAN_Msk                  (0x1ul << TK_CTL_SCAN_Pos)

#define TK_CTL_TMRTRGEN_Pos              (25)
#define TK_CTL_TMRTRGEN_Msk              (0x1ul << TK_CTL_TMRTRGEN_Pos)

#define TK_CTL_TKEN_Pos                  (31)
#define TK_CTL_TKEN_Msk                  (0x1ul << TK_CTL_TKEN_Pos)

#define TK_REFCTL_TKREN0_Pos             (0)
#define TK_REFCTL_TKREN0_Msk             (0x1ul << TK_REFCTL_TKREN0_Pos)

#define TK_REFCTL_TKREN1_Pos             (1)
#define TK_REFCTL_TKREN1_Msk             (0x1ul << TK_REFCTL_TKREN1_Pos)

#define TK_REFCTL_TKREN2_Pos             (2)
#define TK_REFCTL_TKREN2_Msk             (0x1ul << TK_REFCTL_TKREN2_Pos)

#define TK_REFCTL_TKREN3_Pos             (3)
#define TK_REFCTL_TKREN3_Msk             (0x1ul << TK_REFCTL_TKREN3_Pos)

#define TK_REFCTL_TKREN4_Pos             (4)
#define TK_REFCTL_TKREN4_Msk             (0x1ul << TK_REFCTL_TKREN4_Pos)

#define TK_REFCTL_TKREN5_Pos             (5)
#define TK_REFCTL_TKREN5_Msk             (0x1ul << TK_REFCTL_TKREN5_Pos)

#define TK_REFCTL_TKREN6_Pos             (6)
#define TK_REFCTL_TKREN6_Msk             (0x1ul << TK_REFCTL_TKREN6_Pos)

#define TK_REFCTL_TKREN7_Pos             (7)
#define TK_REFCTL_TKREN7_Msk             (0x1ul << TK_REFCTL_TKREN7_Pos)

#define TK_REFCTL_TKREN8_Pos             (8)
#define TK_REFCTL_TKREN8_Msk             (0x1ul << TK_REFCTL_TKREN8_Pos)

#define TK_REFCTL_TKREN9_Pos             (9)
#define TK_REFCTL_TKREN9_Msk             (0x1ul << TK_REFCTL_TKREN9_Pos)

#define TK_REFCTL_TKREN10_Pos            (10)
#define TK_REFCTL_TKREN10_Msk            (0x1ul << TK_REFCTL_TKREN10_Pos)

#define TK_REFCTL_TKREN11_Pos            (11)
#define TK_REFCTL_TKREN11_Msk            (0x1ul << TK_REFCTL_TKREN11_Pos)

#define TK_REFCTL_TKREN12_Pos            (12)
#define TK_REFCTL_TKREN12_Msk            (0x1ul << TK_REFCTL_TKREN12_Pos)

#define TK_REFCTL_TKREN13_Pos            (13)
#define TK_REFCTL_TKREN13_Msk            (0x1ul << TK_REFCTL_TKREN13_Pos)

#define TK_REFCTL_TKREN14_Pos            (14)
#define TK_REFCTL_TKREN14_Msk            (0x1ul << TK_REFCTL_TKREN14_Pos)

#define TK_REFCTL_TKREN15_Pos            (15)
#define TK_REFCTL_TKREN15_Msk            (0x1ul << TK_REFCTL_TKREN15_Pos)

#define TK_REFCTL_TKREN16_Pos            (16)
#define TK_REFCTL_TKREN16_Msk            (0x1ul << TK_REFCTL_TKREN16_Pos)

#define TK_REFCTL_SCANALL_Pos            (23)
#define TK_REFCTL_SCANALL_Msk            (0x1ul << TK_REFCTL_SCANALL_Pos)

#define TK_REFCTL_SENTCTL_Pos            (24)
#define TK_REFCTL_SENTCTL_Msk            (0x3ul << TK_REFCTL_SENTCTL_Pos)

#define TK_REFCTL_SENPTCTL_Pos           (28)
#define TK_REFCTL_SENPTCTL_Msk           (0x3ul << TK_REFCTL_SENPTCTL_Pos)

#define TK_CCBDAT0_CCBDAT0_Pos           (0)
#define TK_CCBDAT0_CCBDAT0_Msk           (0xfful << TK_CCBDAT0_CCBDAT0_Pos)

#define TK_CCBDAT0_CCBDAT1_Pos           (8)
#define TK_CCBDAT0_CCBDAT1_Msk           (0xfful << TK_CCBDAT0_CCBDAT1_Pos)

#define TK_CCBDAT0_CCBDAT2_Pos           (16)
#define TK_CCBDAT0_CCBDAT2_Msk           (0xfful << TK_CCBDAT0_CCBDAT2_Pos)

#define TK_CCBDAT0_CCBDAT3_Pos           (24)
#define TK_CCBDAT0_CCBDAT3_Msk           (0xfful << TK_CCBDAT0_CCBDAT3_Pos)

#define TK_CCBDAT1_CCBDAT4_Pos           (0)
#define TK_CCBDAT1_CCBDAT4_Msk           (0xfful << TK_CCBDAT1_CCBDAT4_Pos)

#define TK_CCBDAT1_CCBDAT5_Pos           (8)
#define TK_CCBDAT1_CCBDAT5_Msk           (0xfful << TK_CCBDAT1_CCBDAT5_Pos)

#define TK_CCBDAT1_CCBDAT6_Pos           (16)
#define TK_CCBDAT1_CCBDAT6_Msk           (0xfful << TK_CCBDAT1_CCBDAT6_Pos)

#define TK_CCBDAT1_CCBDAT7_Pos           (24)
#define TK_CCBDAT1_CCBDAT7_Msk           (0xfful << TK_CCBDAT1_CCBDAT7_Pos)

#define TK_CCBDAT2_CCBDAT8_Pos           (0)
#define TK_CCBDAT2_CCBDAT8_Msk           (0xfful << TK_CCBDAT2_CCBDAT8_Pos)

#define TK_CCBDAT2_CCBDAT9_Pos           (8)
#define TK_CCBDAT2_CCBDAT9_Msk           (0xfful << TK_CCBDAT2_CCBDAT9_Pos)

#define TK_CCBDAT2_CCBDAT10_Pos          (16)
#define TK_CCBDAT2_CCBDAT10_Msk          (0xfful << TK_CCBDAT2_CCBDAT10_Pos)

#define TK_CCBDAT2_CCBDAT11_Pos          (24)
#define TK_CCBDAT2_CCBDAT11_Msk          (0xfful << TK_CCBDAT2_CCBDAT11_Pos)

#define TK_CCBDAT3_CCBDAT12_Pos          (0)
#define TK_CCBDAT3_CCBDAT12_Msk          (0xfful << TK_CCBDAT3_CCBDAT12_Pos)

#define TK_CCBDAT3_CCBDAT13_Pos          (8)
#define TK_CCBDAT3_CCBDAT13_Msk          (0xfful << TK_CCBDAT3_CCBDAT13_Pos)

#define TK_CCBDAT3_CCBDAT14_Pos          (16)
#define TK_CCBDAT3_CCBDAT14_Msk          (0xfful << TK_CCBDAT3_CCBDAT14_Pos)

#define TK_CCBDAT3_CCBDAT15_Pos          (24)
#define TK_CCBDAT3_CCBDAT15_Msk          (0xfful << TK_CCBDAT3_CCBDAT15_Pos)

#define TK_CCBDAT4_CCBDAT16_Pos          (0)
#define TK_CCBDAT4_CCBDAT16_Msk          (0xfful << TK_CCBDAT4_CCBDAT16_Pos)

#define TK_CCBDAT4_REFCBDAT_Pos          (24)
#define TK_CCBDAT4_REFCBDAT_Msk          (0xfful << TK_CCBDAT4_REFCBDAT_Pos)

#define TK_IDLESEL_IDLSn_Pos             (0)
#define TK_IDLESEL_IDLSn_Msk             (0xfffffffful << TK_IDLESEL_IDLSn_Pos)

#define TK_POLSEL_POLSELn_Pos            (0)
#define TK_POLSEL_POLSELn_Msk            (0xfffffffful << TK_POLSEL_POLSELn_Pos)

#define TK_POLCTL_IDLS16_Pos             (0)
#define TK_POLCTL_IDLS16_Msk             (0x3ul << TK_POLCTL_IDLS16_Pos)

#define TK_POLCTL_POLSEL16_Pos           (2)
#define TK_POLCTL_POLSEL16_Msk           (0x3ul << TK_POLCTL_POLSEL16_Pos)

#define TK_POLCTL_CBPOLSEL_Pos           (4)
#define TK_POLCTL_CBPOLSEL_Msk           (0x3ul << TK_POLCTL_CBPOLSEL_Pos)

#define TK_POLCTL_POLEN0_Pos             (8)
#define TK_POLCTL_POLEN0_Msk             (0x1ul << TK_POLCTL_POLEN0_Pos)

#define TK_POLCTL_POLEN1_Pos             (9)
#define TK_POLCTL_POLEN1_Msk             (0x1ul << TK_POLCTL_POLEN1_Pos)

#define TK_POLCTL_POLEN2_Pos             (10)
#define TK_POLCTL_POLEN2_Msk             (0x1ul << TK_POLCTL_POLEN2_Pos)

#define TK_POLCTL_POLEN3_Pos             (11)
#define TK_POLCTL_POLEN3_Msk             (0x1ul << TK_POLCTL_POLEN3_Pos)

#define TK_POLCTL_POLEN4_Pos             (12)
#define TK_POLCTL_POLEN4_Msk             (0x1ul << TK_POLCTL_POLEN4_Pos)

#define TK_POLCTL_POLEN5_Pos             (13)
#define TK_POLCTL_POLEN5_Msk             (0x1ul << TK_POLCTL_POLEN5_Pos)

#define TK_POLCTL_POLEN6_Pos             (14)
#define TK_POLCTL_POLEN6_Msk             (0x1ul << TK_POLCTL_POLEN6_Pos)

#define TK_POLCTL_POLEN7_Pos             (15)
#define TK_POLCTL_POLEN7_Msk             (0x1ul << TK_POLCTL_POLEN7_Pos)

#define TK_POLCTL_POLEN8_Pos             (16)
#define TK_POLCTL_POLEN8_Msk             (0x1ul << TK_POLCTL_POLEN8_Pos)

#define TK_POLCTL_POLEN9_Pos             (17)
#define TK_POLCTL_POLEN9_Msk             (0x1ul << TK_POLCTL_POLEN9_Pos)

#define TK_POLCTL_POLEN10_Pos            (18)
#define TK_POLCTL_POLEN10_Msk            (0x1ul << TK_POLCTL_POLEN10_Pos)

#define TK_POLCTL_POLEN11_Pos            (19)
#define TK_POLCTL_POLEN11_Msk            (0x1ul << TK_POLCTL_POLEN11_Pos)

#define TK_POLCTL_POLEN12_Pos            (20)
#define TK_POLCTL_POLEN12_Msk            (0x1ul << TK_POLCTL_POLEN12_Pos)

#define TK_POLCTL_POLEN13_Pos            (21)
#define TK_POLCTL_POLEN13_Msk            (0x1ul << TK_POLCTL_POLEN13_Pos)

#define TK_POLCTL_POLEN14_Pos            (22)
#define TK_POLCTL_POLEN14_Msk            (0x1ul << TK_POLCTL_POLEN14_Pos)

#define TK_POLCTL_POLEN15_Pos            (23)
#define TK_POLCTL_POLEN15_Msk            (0x1ul << TK_POLCTL_POLEN15_Pos)

#define TK_POLCTL_POLEN16_Pos            (24)
#define TK_POLCTL_POLEN16_Msk            (0x1ul << TK_POLCTL_POLEN16_Pos)

#define TK_POLCTL_SPOTINIT_Pos           (31)
#define TK_POLCTL_SPOTINIT_Msk           (0x1ul << TK_POLCTL_SPOTINIT_Pos)

#define TK_STATUS_BUSY_Pos               (0)
#define TK_STATUS_BUSY_Msk               (0x1ul << TK_STATUS_BUSY_Pos)

#define TK_STATUS_SCIF_Pos               (1)
#define TK_STATUS_SCIF_Msk               (0x1ul << TK_STATUS_SCIF_Pos)

#define TK_STATUS_TKIF0_Pos              (8)
#define TK_STATUS_TKIF0_Msk              (0x1ul << TK_STATUS_TKIF0_Pos)

#define TK_STATUS_TKIF1_Pos              (9)
#define TK_STATUS_TKIF1_Msk              (0x1ul << TK_STATUS_TKIF1_Pos)

#define TK_STATUS_TKIF2_Pos              (10)
#define TK_STATUS_TKIF2_Msk              (0x1ul << TK_STATUS_TKIF2_Pos)

#define TK_STATUS_TKIF3_Pos              (11)
#define TK_STATUS_TKIF3_Msk              (0x1ul << TK_STATUS_TKIF3_Pos)

#define TK_STATUS_TKIF4_Pos              (12)
#define TK_STATUS_TKIF4_Msk              (0x1ul << TK_STATUS_TKIF4_Pos)

#define TK_STATUS_TKIF5_Pos              (13)
#define TK_STATUS_TKIF5_Msk              (0x1ul << TK_STATUS_TKIF5_Pos)

#define TK_STATUS_TKIF6_Pos              (14)
#define TK_STATUS_TKIF6_Msk              (0x1ul << TK_STATUS_TKIF6_Pos)

#define TK_STATUS_TKIF7_Pos              (15)
#define TK_STATUS_TKIF7_Msk              (0x1ul << TK_STATUS_TKIF7_Pos)

#define TK_STATUS_TKIF8_Pos              (16)
#define TK_STATUS_TKIF8_Msk              (0x1ul << TK_STATUS_TKIF8_Pos)

#define TK_STATUS_TKIF9_Pos              (17)
#define TK_STATUS_TKIF9_Msk              (0x1ul << TK_STATUS_TKIF9_Pos)

#define TK_STATUS_TKIF10_Pos             (18)
#define TK_STATUS_TKIF10_Msk             (0x1ul << TK_STATUS_TKIF10_Pos)

#define TK_STATUS_TKIF11_Pos             (19)
#define TK_STATUS_TKIF11_Msk             (0x1ul << TK_STATUS_TKIF11_Pos)

#define TK_STATUS_TKIF12_Pos             (20)
#define TK_STATUS_TKIF12_Msk             (0x1ul << TK_STATUS_TKIF12_Pos)

#define TK_STATUS_TKIF13_Pos             (21)
#define TK_STATUS_TKIF13_Msk             (0x1ul << TK_STATUS_TKIF13_Pos)

#define TK_STATUS_TKIF14_Pos             (22)
#define TK_STATUS_TKIF14_Msk             (0x1ul << TK_STATUS_TKIF14_Pos)

#define TK_STATUS_TKIF15_Pos             (23)
#define TK_STATUS_TKIF15_Msk             (0x1ul << TK_STATUS_TKIF15_Pos)

#define TK_STATUS_TKIF16_Pos             (24)
#define TK_STATUS_TKIF16_Msk             (0x1ul << TK_STATUS_TKIF16_Pos)

#define TK_DAT0_TKDAT0_Pos               (0)
#define TK_DAT0_TKDAT0_Msk               (0xfful << TK_DAT0_TKDAT0_Pos)

#define TK_DAT0_TKDAT1_Pos               (8)
#define TK_DAT0_TKDAT1_Msk               (0xfful << TK_DAT0_TKDAT1_Pos)

#define TK_DAT0_TKDAT2_Pos               (16)
#define TK_DAT0_TKDAT2_Msk               (0xfful << TK_DAT0_TKDAT2_Pos)

#define TK_DAT0_TKDAT3_Pos               (24)
#define TK_DAT0_TKDAT3_Msk               (0xfful << TK_DAT0_TKDAT3_Pos)

#define TK_DAT1_TKDAT4_Pos               (0)
#define TK_DAT1_TKDAT4_Msk               (0xfful << TK_DAT1_TKDAT4_Pos)

#define TK_DAT1_TKDAT5_Pos               (8)
#define TK_DAT1_TKDAT5_Msk               (0xfful << TK_DAT1_TKDAT5_Pos)

#define TK_DAT1_TKDAT6_Pos               (16)
#define TK_DAT1_TKDAT6_Msk               (0xfful << TK_DAT1_TKDAT6_Pos)

#define TK_DAT1_TKDAT7_Pos               (24)
#define TK_DAT1_TKDAT7_Msk               (0xfful << TK_DAT1_TKDAT7_Pos)

#define TK_DAT2_TKDAT8_Pos               (0)
#define TK_DAT2_TKDAT8_Msk               (0xfful << TK_DAT2_TKDAT8_Pos)

#define TK_DAT2_TKDAT9_Pos               (8)
#define TK_DAT2_TKDAT9_Msk               (0xfful << TK_DAT2_TKDAT9_Pos)

#define TK_DAT2_TKDAT10_Pos              (16)
#define TK_DAT2_TKDAT10_Msk              (0xfful << TK_DAT2_TKDAT10_Pos)

#define TK_DAT2_TKDAT11_Pos              (24)
#define TK_DAT2_TKDAT11_Msk              (0xfful << TK_DAT2_TKDAT11_Pos)

#define TK_DAT3_TKDAT12_Pos              (0)
#define TK_DAT3_TKDAT12_Msk              (0xfful << TK_DAT3_TKDAT12_Pos)

#define TK_DAT3_TKDAT13_Pos              (8)
#define TK_DAT3_TKDAT13_Msk              (0xfful << TK_DAT3_TKDAT13_Pos)

#define TK_DAT3_TKDAT14_Pos              (16)
#define TK_DAT3_TKDAT14_Msk              (0xfful << TK_DAT3_TKDAT14_Pos)

#define TK_DAT3_TKDAT15_Pos              (24)
#define TK_DAT3_TKDAT15_Msk              (0xfful << TK_DAT3_TKDAT15_Pos)

#define TK_DAT4_TKDAT16_Pos              (0)
#define TK_DAT4_TKDAT16_Msk              (0xfful << TK_DAT4_TKDAT16_Pos)

#define TK_INTEN_SCTHIEN_Pos             (0)
#define TK_INTEN_SCTHIEN_Msk             (0x1ul << TK_INTEN_SCTHIEN_Pos)

#define TK_INTEN_SCINTEN_Pos             (1)
#define TK_INTEN_SCINTEN_Msk             (0x1ul << TK_INTEN_SCINTEN_Pos)

#define TK_INTEN_THIMOD_Pos              (31)
#define TK_INTEN_THIMOD_Msk              (0x1ul << TK_INTEN_THIMOD_Pos)

#define TK_TH0_1_LTH0_Pos                (0)
#define TK_TH0_1_LTH0_Msk                (0xfful << TK_TH0_1_LTH0_Pos)

#define TK_TH0_1_HTH0_Pos                (8)
#define TK_TH0_1_HTH0_Msk                (0xfful << TK_TH0_1_HTH0_Pos)

#define TK_TH0_1_LTH1_Pos                (16)
#define TK_TH0_1_LTH1_Msk                (0xfful << TK_TH0_1_LTH1_Pos)

#define TK_TH0_1_HTH1_Pos                (24)
#define TK_TH0_1_HTH1_Msk                (0xfful << TK_TH0_1_HTH1_Pos)

#define TK_TH2_3_LTH2_Pos                (0)
#define TK_TH2_3_LTH2_Msk                (0xfful << TK_TH2_3_LTH2_Pos)

#define TK_TH2_3_HTH2_Pos                (8)
#define TK_TH2_3_HTH2_Msk                (0xfful << TK_TH2_3_HTH2_Pos)

#define TK_TH2_3_LTH3_Pos                (16)
#define TK_TH2_3_LTH3_Msk                (0xfful << TK_TH2_3_LTH3_Pos)

#define TK_TH2_3_HTH3_Pos                (24)
#define TK_TH2_3_HTH3_Msk                (0xfful << TK_TH2_3_HTH3_Pos)

#define TK_TH4_5_LTH4_Pos                (0)
#define TK_TH4_5_LTH4_Msk                (0xfful << TK_TH4_5_LTH4_Pos)

#define TK_TH4_5_HTH4_Pos                (8)
#define TK_TH4_5_HTH4_Msk                (0xfful << TK_TH4_5_HTH4_Pos)

#define TK_TH4_5_LTH5_Pos                (16)
#define TK_TH4_5_LTH5_Msk                (0xfful << TK_TH4_5_LTH5_Pos)

#define TK_TH4_5_HTH5_Pos                (24)
#define TK_TH4_5_HTH5_Msk                (0xfful << TK_TH4_5_HTH5_Pos)

#define TK_TH6_7_LTH6_Pos                (0)
#define TK_TH6_7_LTH6_Msk                (0xfful << TK_TH6_7_LTH6_Pos)

#define TK_TH6_7_HTH6_Pos                (8)
#define TK_TH6_7_HTH6_Msk                (0xfful << TK_TH6_7_HTH6_Pos)

#define TK_TH6_7_LTH7_Pos                (16)
#define TK_TH6_7_LTH7_Msk                (0xfful << TK_TH6_7_LTH7_Pos)

#define TK_TH6_7_HTH7_Pos                (24)
#define TK_TH6_7_HTH7_Msk                (0xfful << TK_TH6_7_HTH7_Pos)

#define TK_TH8_9_LTH8_Pos                (0)
#define TK_TH8_9_LTH8_Msk                (0xfful << TK_TH8_9_LTH8_Pos)

#define TK_TH8_9_HTH8_Pos                (8)
#define TK_TH8_9_HTH8_Msk                (0xfful << TK_TH8_9_HTH8_Pos)

#define TK_TH8_9_LTH9_Pos                (16)
#define TK_TH8_9_LTH9_Msk                (0xfful << TK_TH8_9_LTH9_Pos)

#define TK_TH8_9_HTH9_Pos                (24)
#define TK_TH8_9_HTH9_Msk                (0xfful << TK_TH8_9_HTH9_Pos)

#define TK_TH10_11_LTH10_Pos             (0)
#define TK_TH10_11_LTH10_Msk             (0xfful << TK_TH10_11_LTH10_Pos)

#define TK_TH10_11_HTH10_Pos             (8)
#define TK_TH10_11_HTH10_Msk             (0xfful << TK_TH10_11_HTH10_Pos)

#define TK_TH10_11_LTH11_Pos             (16)
#define TK_TH10_11_LTH11_Msk             (0xfful << TK_TH10_11_LTH11_Pos)

#define TK_TH10_11_HTH11_Pos             (24)
#define TK_TH10_11_HTH11_Msk             (0xfful << TK_TH10_11_HTH11_Pos)

#define TK_TH12_13_LTH12_Pos             (0)
#define TK_TH12_13_LTH12_Msk             (0xfful << TK_TH12_13_LTH12_Pos)

#define TK_TH12_13_HTH12_Pos             (8)
#define TK_TH12_13_HTH12_Msk             (0xfful << TK_TH12_13_HTH12_Pos)

#define TK_TH12_13_LTH13_Pos             (16)
#define TK_TH12_13_LTH13_Msk             (0xfful << TK_TH12_13_LTH13_Pos)

#define TK_TH12_13_HTH13_Pos             (24)
#define TK_TH12_13_HTH13_Msk             (0xfful << TK_TH12_13_HTH13_Pos)

#define TK_TH14_15_LTH14_Pos             (0)
#define TK_TH14_15_LTH14_Msk             (0xfful << TK_TH14_15_LTH14_Pos)

#define TK_TH14_15_HTH14_Pos             (8)
#define TK_TH14_15_HTH14_Msk             (0xfful << TK_TH14_15_HTH14_Pos)

#define TK_TH14_15_LTH15_Pos             (16)
#define TK_TH14_15_LTH15_Msk             (0xfful << TK_TH14_15_LTH15_Pos)

#define TK_TH14_15_HTH15_Pos             (24)
#define TK_TH14_15_HTH15_Msk             (0xfful << TK_TH14_15_HTH15_Pos)

#define TK_TH16_LTH16_Pos                (0)
#define TK_TH16_LTH16_Msk                (0xfful << TK_TH16_LTH16_Pos)

#define TK_TH16_HTH16_Pos                (8)
#define TK_TH16_HTH16_Msk                (0xfful << TK_TH16_HTH16_Pos)

/**@}*/ /* TK_CONST */
/**@}*/ /* end of TK register group */


/*---------------------- Timer Controller -------------------------*/
/**
    @addtogroup TIMER Timer Controller(TIMER)
    Memory Mapped Structure for TIMER Controller
@{ */
 
typedef struct
{
    __IO uint32_t CTL;                   /*!< [0x0000] Timer Control and Status Register                               */
    __IO uint32_t CMP;                   /*!< [0x0004] Timer Compare Register                                          */
    __IO uint32_t INTSTS;                /*!< [0x0008] Timer Interrupt Status Register                                 */
    __I  uint32_t CNT;                   /*!< [0x000c] Timer Data Register                                             */
    __I  uint32_t CAP;                   /*!< [0x0010] Timer Capture Data Register                                     */
    __IO uint32_t EXTCTL;                /*!< [0x0014] Timer External Control Register                                 */
    __IO uint32_t EINTSTS;               /*!< [0x0018] Timer External Interrupt Status Register                        */

} TIMER_T;

/**
    @addtogroup TIMER_CONST TIMER Bit Field Definition
    Constant Definitions for TIMER Controller
@{ */

#define TIMER_CTL_PSC_Pos                  (0)
#define TIMER_CTL_PSC_Msk                  (0xfful << TIMER_CTL_PSC_Pos)

#define TIMER_CTL_WKTKEN_Pos               (17)
#define TIMER_CTL_WKTKEN_Msk               (0x1ul << TIMER_CTL_WKTKEN_Pos)

#define TIMER_CTL_TRGSSEL_Pos              (18)
#define TIMER_CTL_TRGSSEL_Msk              (0x1ul << TIMER_CTL_TRGSSEL_Pos)

#define TIMER_CTL_TRGPWM_Pos               (19)
#define TIMER_CTL_TRGPWM_Msk               (0x1ul << TIMER_CTL_TRGPWM_Pos)

#define TIMER_CTL_TRGDAC_Pos               (20)
#define TIMER_CTL_TRGDAC_Msk               (0x1ul << TIMER_CTL_TRGDAC_Pos)

#define TIMER_CTL_TRGEADC_Pos              (21)
#define TIMER_CTL_TRGEADC_Msk              (0x1ul << TIMER_CTL_TRGEADC_Pos)

#define TIMER_CTL_TGLPINSEL_Pos            (22)
#define TIMER_CTL_TGLPINSEL_Msk            (0x1ul << TIMER_CTL_TGLPINSEL_Pos)

#define TIMER_CTL_WKEN_Pos                 (23)
#define TIMER_CTL_WKEN_Msk                 (0x1ul << TIMER_CTL_WKEN_Pos)

#define TIMER_CTL_EXTCNTEN_Pos             (24)
#define TIMER_CTL_EXTCNTEN_Msk             (0x1ul << TIMER_CTL_EXTCNTEN_Pos)

#define TIMER_CTL_ACTSTS_Pos               (25)
#define TIMER_CTL_ACTSTS_Msk               (0x1ul << TIMER_CTL_ACTSTS_Pos)

#define TIMER_CTL_RSTCNT_Pos               (26)
#define TIMER_CTL_RSTCNT_Msk               (0x1ul << TIMER_CTL_RSTCNT_Pos)

#define TIMER_CTL_OPMODE_Pos               (27)
#define TIMER_CTL_OPMODE_Msk               (0x3ul << TIMER_CTL_OPMODE_Pos)

#define TIMER_CTL_INTEN_Pos                (29)
#define TIMER_CTL_INTEN_Msk                (0x1ul << TIMER_CTL_INTEN_Pos)

#define TIMER_CTL_CNTEN_Pos                (30)
#define TIMER_CTL_CNTEN_Msk                (0x1ul << TIMER_CTL_CNTEN_Pos)

#define TIMER_CTL_ICEDEBUG_Pos             (31)
#define TIMER_CTL_ICEDEBUG_Msk             (0x1ul << TIMER_CTL_ICEDEBUG_Pos)

#define TIMER_CMP_CMPDAT_Pos               (0)
#define TIMER_CMP_CMPDAT_Msk               (0xfffffful << TIMER_CMP_CMPDAT_Pos)

#define TIMER_INTSTS_TIF_Pos               (0)
#define TIMER_INTSTS_TIF_Msk               (0x1ul << TIMER_INTSTS_TIF_Pos)

#define TIMER_INTSTS_TWKF_Pos              (1)
#define TIMER_INTSTS_TWKF_Msk              (0x1ul << TIMER_INTSTS_TWKF_Pos)

#define TIMER_CNT_CNT_Pos                  (0)
#define TIMER_CNT_CNT_Msk                  (0xfffffful << TIMER_CNT_CNT_Pos)

#define TIMER_CAP_CAPDAT_Pos               (0)
#define TIMER_CAP_CAPDAT_Msk               (0xfffffful << TIMER_CAP_CAPDAT_Pos)

#define TIMER_EXTCTL_CNTPHASE_Pos          (0)
#define TIMER_EXTCTL_CNTPHASE_Msk          (0x1ul << TIMER_EXTCTL_CNTPHASE_Pos)

#define TIMER_EXTCTL_CAPEDGE_Pos           (1)
#define TIMER_EXTCTL_CAPEDGE_Msk           (0x3ul << TIMER_EXTCTL_CAPEDGE_Pos)

#define TIMER_EXTCTL_CAPEN_Pos             (3)
#define TIMER_EXTCTL_CAPEN_Msk             (0x1ul << TIMER_EXTCTL_CAPEN_Pos)

#define TIMER_EXTCTL_CAPFUNCS_Pos          (4)
#define TIMER_EXTCTL_CAPFUNCS_Msk          (0x1ul << TIMER_EXTCTL_CAPFUNCS_Pos)

#define TIMER_EXTCTL_CAPIEN_Pos            (5)
#define TIMER_EXTCTL_CAPIEN_Msk            (0x1ul << TIMER_EXTCTL_CAPIEN_Pos)

#define TIMER_EXTCTL_CAPDBEN_Pos           (6)
#define TIMER_EXTCTL_CAPDBEN_Msk           (0x1ul << TIMER_EXTCTL_CAPDBEN_Pos)

#define TIMER_EXTCTL_ECNTDBEN_Pos          (7)
#define TIMER_EXTCTL_ECNTDBEN_Msk          (0x1ul << TIMER_EXTCTL_ECNTDBEN_Pos)

#define TIMER_EINTSTS_CAPIF_Pos            (0)
#define TIMER_EINTSTS_CAPIF_Msk            (0x1ul << TIMER_EINTSTS_CAPIF_Pos)
/**@}*/ /* TIMER_CONST */
/**@}*/ /* end of TIMER register group */


/*---------------------- Universal Asynchronous Receiver/Transmitter Controller -------------------------*/
/**
    @addtogroup UART Universal Asynchronous Receiver/Transmitter Controller(UART)
    Memory Mapped Structure for UART Controller
@{ */
 
typedef struct
{

    __IO uint32_t DAT;                   /*!< [0x0000] UART Receive/Transmit Holding Buffer Register                    */
    __IO uint32_t INTEN;                 /*!< [0x0004] UART Interrupt Enable Register                                   */
    __IO uint32_t FIFO;                  /*!< [0x0008] UART FIFO Control Register                                       */
    __IO uint32_t LINE;                  /*!< [0x000c] UART Line Control Register                                       */
    __IO uint32_t MODEM;                 /*!< [0x0010] UART Modem Control Register                                      */
    __IO uint32_t MODEMSTS;              /*!< [0x0014] UART Modem Status Register                                       */
    __IO uint32_t FIFOSTS;               /*!< [0x0018] UART FIFO Status Register                                        */
    __IO uint32_t INTSTS;                /*!< [0x001c] UART Interrupt Status Register                                   */
    __IO uint32_t TOUT;                  /*!< [0x0020] UART Time-out Register                                           */
    __IO uint32_t BAUD;                  /*!< [0x0024] UART Baud Rate Divisor Register                                  */
    __IO uint32_t IRDA;                  /*!< [0x0028] UART IrDA Control Register                                       */
    __IO uint32_t ALTCTL;                /*!< [0x002c] UART Alternate Control/Status Register                           */
    __IO uint32_t FUNCSEL;               /*!< [0x0030] UART Function Select Register                                    */
    __IO uint32_t LINCTL;                /*!< [0x0034] UART LIN Control Register                                        */
    __IO uint32_t LINSTS;                /*!< [0x0038] UART LIN Status Register                                         */

} UART_T;

/**
    @addtogroup UART_CONST UART Bit Field Definition
    Constant Definitions for UART Controller
@{ */

#define UART_DAT_DAT_Pos                 (0)
#define UART_DAT_DAT_Msk                 (0xfful << UART_DAT_DAT_Pos)

#define UART_INTEN_RDAIEN_Pos           (0)
#define UART_INTEN_RDAIEN_Msk           (0x1ul << UART_INTEN_RDAIEN_Pos)

#define UART_INTEN_THREIEN_Pos           (1)
#define UART_INTEN_THREIEN_Msk           (0x1ul << UART_INTEN_THREIEN_Pos)

#define UART_INTEN_RLSIEN_Pos            (2)
#define UART_INTEN_RLSIEN_Msk            (0x1ul << UART_INTEN_RLSIEN_Pos)

#define UART_INTEN_MODEMIEN_Pos          (3)
#define UART_INTEN_MODEMIEN_Msk          (0x1ul << UART_INTEN_MODEMIEN_Pos)

#define UART_INTEN_RXTOIEN_Pos           (4)
#define UART_INTEN_RXTOIEN_Msk           (0x1ul << UART_INTEN_RXTOIEN_Pos)

#define UART_INTEN_BFERRIEN_Pos          (5)
#define UART_INTEN_BFERRIEN_Msk          (0x1ul << UART_INTEN_BFERRIEN_Pos)

#define UART_INTEN_LINIEN_Pos            (8)
#define UART_INTEN_LINIEN_Msk            (0x1ul << UART_INTEN_LINIEN_Pos)

#define UART_INTEN_WKCTSIEN_Pos          (9)
#define UART_INTEN_WKCTSIEN_Msk          (0x1ul << UART_INTEN_WKCTSIEN_Pos)

#define UART_INTEN_WKDATIEN_Pos          (10)
#define UART_INTEN_WKDATIEN_Msk          (0x1ul << UART_INTEN_WKDATIEN_Pos)

#define UART_INTEN_TOCNTEN_Pos             (11)
#define UART_INTEN_TOCNTEN_Msk             (0x1ul << UART_INTEN_TOCNTEN_Pos)

#define UART_INTEN_ATORTSEN_Pos          (12)
#define UART_INTEN_ATORTSEN_Msk          (0x1ul << UART_INTEN_ATORTSEN_Pos)

#define UART_INTEN_ATOCTSEN_Pos          (13)
#define UART_INTEN_ATOCTSEN_Msk          (0x1ul << UART_INTEN_ATOCTSEN_Pos)

#define UART_INTEN_TXPDMAEN_Pos          (14)
#define UART_INTEN_TXPDMAEN_Msk          (0x1ul << UART_INTEN_TXPDMAEN_Pos)

#define UART_INTEN_RXPDMAEN_Pos          (15)
#define UART_INTEN_RXPDMAEN_Msk          (0x1ul << UART_INTEN_RXPDMAEN_Pos)

#define UART_INTEN_ABRIEN_Pos            (18)
#define UART_INTEN_ABRIEN_Msk            (0x1ul << UART_INTEN_ABRIEN_Pos)

#define UART_FIFO_RXRST_Pos              (1)
#define UART_FIFO_RXRST_Msk              (0x1ul << UART_FIFO_RXRST_Pos)

#define UART_FIFO_TXRST_Pos              (2)
#define UART_FIFO_TXRST_Msk              (0x1ul << UART_FIFO_TXRST_Pos)

#define UART_FIFO_RFITL_Pos              (4)
#define UART_FIFO_RFITL_Msk              (0xful << UART_FIFO_RFITL_Pos)

#define UART_FIFO_RXOFF_Pos              (8)
#define UART_FIFO_RXOFF_Msk              (0x1ul << UART_FIFO_RXOFF_Pos)

#define UART_FIFO_RTSTRGLV_Pos           (16)
#define UART_FIFO_RTSTRGLV_Msk           (0xful << UART_FIFO_RTSTRGLV_Pos)

#define UART_LINE_WLS_Pos                (0)
#define UART_LINE_WLS_Msk                (0x3ul << UART_LINE_WLS_Pos)

#define UART_LINE_NSB_Pos                (2)
#define UART_LINE_NSB_Msk                (0x1ul << UART_LINE_NSB_Pos)

#define UART_LINE_PBE_Pos                (3)
#define UART_LINE_PBE_Msk                (0x1ul << UART_LINE_PBE_Pos)

#define UART_LINE_EPE_Pos                (4)
#define UART_LINE_EPE_Msk                (0x1ul << UART_LINE_EPE_Pos)

#define UART_LINE_SPE_Pos                (5)
#define UART_LINE_SPE_Msk                (0x1ul << UART_LINE_SPE_Pos)

#define UART_LINE_BCB_Pos                (6)
#define UART_LINE_BCB_Msk                (0x1ul << UART_LINE_BCB_Pos)

#define UART_MODEM_RTS_Pos               (1)
#define UART_MODEM_RTS_Msk               (0x1ul << UART_MODEM_RTS_Pos)

#define UART_MODEM_RTSACTLV_Pos          (9)
#define UART_MODEM_RTSACTLV_Msk          (0x1ul << UART_MODEM_RTSACTLV_Pos)

#define UART_MODEM_RTSSTS_Pos            (13)
#define UART_MODEM_RTSSTS_Msk            (0x1ul << UART_MODEM_RTSSTS_Pos)

#define UART_MODEMSTS_CTSDETF_Pos        (0)
#define UART_MODEMSTS_CTSDETF_Msk        (0x1ul << UART_MODEMSTS_CTSDETF_Pos)

#define UART_MODEMSTS_CTSSTS_Pos         (4)
#define UART_MODEMSTS_CTSSTS_Msk         (0x1ul << UART_MODEMSTS_CTSSTS_Pos)

#define UART_MODEMSTS_CTSACTLV_Pos       (8)
#define UART_MODEMSTS_CTSACTLV_Msk       (0x1ul << UART_MODEMSTS_CTSACTLV_Pos)

#define UART_FIFOSTS_RXOVIF_Pos          (0)
#define UART_FIFOSTS_RXOVIF_Msk          (0x1ul << UART_FIFOSTS_RXOVIF_Pos)

#define UART_FIFOSTS_ABRDIF_Pos          (1)
#define UART_FIFOSTS_ABRDIF_Msk          (0x1ul << UART_FIFOSTS_ABRDIF_Pos)

#define UART_FIFOSTS_ABRDTOIF_Pos        (2)
#define UART_FIFOSTS_ABRDTOIF_Msk        (0x1ul << UART_FIFOSTS_ABRDTOIF_Pos)

#define UART_FIFOSTS_ADDRDETF_Pos        (3)
#define UART_FIFOSTS_ADDRDETF_Msk        (0x1ul << UART_FIFOSTS_ADDRDETF_Pos)

#define UART_FIFOSTS_PEF_Pos             (4)
#define UART_FIFOSTS_PEF_Msk             (0x1ul << UART_FIFOSTS_PEF_Pos)

#define UART_FIFOSTS_FEF_Pos             (5)
#define UART_FIFOSTS_FEF_Msk             (0x1ul << UART_FIFOSTS_FEF_Pos)

#define UART_FIFOSTS_BIF_Pos             (6)
#define UART_FIFOSTS_BIF_Msk             (0x1ul << UART_FIFOSTS_BIF_Pos)

#define UART_FIFOSTS_RXPTR_Pos           (8)
#define UART_FIFOSTS_RXPTR_Msk           (0x3ful << UART_FIFOSTS_RXPTR_Pos)

#define UART_FIFOSTS_RXEMPTY_Pos         (14)
#define UART_FIFOSTS_RXEMPTY_Msk         (0x1ul << UART_FIFOSTS_RXEMPTY_Pos)

#define UART_FIFOSTS_RXFULL_Pos          (15)
#define UART_FIFOSTS_RXFULL_Msk          (0x1ul << UART_FIFOSTS_RXFULL_Pos)

#define UART_FIFOSTS_TXPTR_Pos           (16)
#define UART_FIFOSTS_TXPTR_Msk           (0x3ful << UART_FIFOSTS_TXPTR_Pos)

#define UART_FIFOSTS_TXEMPTY_Pos         (22)
#define UART_FIFOSTS_TXEMPTY_Msk         (0x1ul << UART_FIFOSTS_TXEMPTY_Pos)

#define UART_FIFOSTS_TXFULL_Pos          (23)
#define UART_FIFOSTS_TXFULL_Msk          (0x1ul << UART_FIFOSTS_TXFULL_Pos)

#define UART_FIFOSTS_TXOVIF_Pos          (24)
#define UART_FIFOSTS_TXOVIF_Msk          (0x1ul << UART_FIFOSTS_TXOVIF_Pos)

#define UART_FIFOSTS_TXEMPTYF_Pos        (28)
#define UART_FIFOSTS_TXEMPTYF_Msk        (0x1ul << UART_FIFOSTS_TXEMPTYF_Pos)

#define UART_INTSTS_RDAIF_Pos            (0)
#define UART_INTSTS_RDAIF_Msk            (0x1ul << UART_INTSTS_RDAIF_Pos)

#define UART_INTSTS_THREIF_Pos           (1)
#define UART_INTSTS_THREIF_Msk           (0x1ul << UART_INTSTS_THREIF_Pos)

#define UART_INTSTS_RLSIF_Pos            (2)
#define UART_INTSTS_RLSIF_Msk            (0x1ul << UART_INTSTS_RLSIF_Pos)

#define UART_INTSTS_MODEMIF_Pos          (3)
#define UART_INTSTS_MODEMIF_Msk          (0x1ul << UART_INTSTS_MODEMIF_Pos)

#define UART_INTSTS_RXTOIF_Pos           (4)
#define UART_INTSTS_RXTOIF_Msk           (0x1ul << UART_INTSTS_RXTOIF_Pos)

#define UART_INTSTS_BERRIF_Pos           (5)
#define UART_INTSTS_BERRIF_Msk           (0x1ul << UART_INTSTS_BERRIF_Pos)

#define UART_INTSTS_WKIF_Pos             (6)
#define UART_INTSTS_WKIF_Msk             (0x1ul << UART_INTSTS_WKIF_Pos)

#define UART_INTSTS_LINIF_Pos            (7)
#define UART_INTSTS_LINIF_Msk            (0x1ul << UART_INTSTS_LINIF_Pos)

#define UART_INTSTS_RDAINT_Pos           (8)
#define UART_INTSTS_RDAINT_Msk           (0x1ul << UART_INTSTS_RDAINT_Pos)

#define UART_INTSTS_THREINT_Pos          (9)
#define UART_INTSTS_THREINT_Msk          (0x1ul << UART_INTSTS_THREINT_Pos)

#define UART_INTSTS_RLSINT_Pos           (10)
#define UART_INTSTS_RLSINT_Msk           (0x1ul << UART_INTSTS_RLSINT_Pos)

#define UART_INTSTS_MODEMINT_Pos         (11)
#define UART_INTSTS_MODEMINT_Msk         (0x1ul << UART_INTSTS_MODEMINT_Pos)

#define UART_INTSTS_RXTOINT_Pos          (12)
#define UART_INTSTS_RXTOINT_Msk          (0x1ul << UART_INTSTS_RXTOINT_Pos)

#define UART_INTSTS_BERRINT_Pos          (13)
#define UART_INTSTS_BERRINT_Msk          (0x1ul << UART_INTSTS_BERRINT_Pos)

#define UART_INTSTS_LININT_Pos           (15)
#define UART_INTSTS_LININT_Msk           (0x1ul << UART_INTSTS_LININT_Pos)

#define UART_INTSTS_CTSWKIF_Pos          (16)
#define UART_INTSTS_CTSWKIF_Msk          (0x1ul << UART_INTSTS_CTSWKIF_Pos)

#define UART_INTSTS_DATWKIF_Pos          (17)
#define UART_INTSTS_DATWKIF_Msk          (0x1ul << UART_INTSTS_DATWKIF_Pos)

#define UART_INTSTS_HWRLSIF_Pos          (18)
#define UART_INTSTS_HWRLSIF_Msk          (0x1ul << UART_INTSTS_HWRLSIF_Pos)

#define UART_INTSTS_HWMODIF_Pos          (19)
#define UART_INTSTS_HWMODIF_Msk          (0x1ul << UART_INTSTS_HWMODIF_Pos)

#define UART_INTSTS_HWTOIF_Pos           (20)
#define UART_INTSTS_HWTOIF_Msk           (0x1ul << UART_INTSTS_HWTOIF_Pos)

#define UART_INTSTS_HWBFERIF_Pos         (21)
#define UART_INTSTS_HWBFERIF_Msk         (0x1ul << UART_INTSTS_HWBFERIF_Pos)

#define UART_INTSTS_HWRLSINT_Pos         (26)
#define UART_INTSTS_HWRLSINT_Msk         (0x1ul << UART_INTSTS_HWRLSINT_Pos)

#define UART_INTSTS_HWMODINT_Pos         (27)
#define UART_INTSTS_HWMODINT_Msk         (0x1ul << UART_INTSTS_HWMODINT_Pos)

#define UART_INTSTS_HWTOINT_Pos          (28)
#define UART_INTSTS_HWTOINT_Msk          (0x1ul << UART_INTSTS_HWTOINT_Pos)

#define UART_INTSTS_HWBEINT_Pos          (29)
#define UART_INTSTS_HWBEINT_Msk          (0x1ul << UART_INTSTS_HWBEINT_Pos)

#define UART_TOUT_TOIC_Pos               (0)
#define UART_TOUT_TOIC_Msk               (0xfful << UART_TOUT_TOIC_Pos)

#define UART_TOUT_DLY_Pos                (8)
#define UART_TOUT_DLY_Msk                (0xfful << UART_TOUT_DLY_Pos)

#define UART_BAUD_BRD_Pos                (0)
#define UART_BAUD_BRD_Msk                (0xfffful << UART_BAUD_BRD_Pos)

#define UART_BAUD_EDIVM1_Pos             (24)
#define UART_BAUD_EDIVM1_Msk             (0xful << UART_BAUD_EDIVM1_Pos)

#define UART_BAUD_BAUDM0_Pos             (28)
#define UART_BAUD_BAUDM0_Msk             (0x1ul << UART_BAUD_BAUDM0_Pos)

#define UART_BAUD_BAUDM1_Pos             (29)
#define UART_BAUD_BAUDM1_Msk             (0x1ul << UART_BAUD_BAUDM1_Pos)

#define UART_IRDA_TXEN_Pos               (1)
#define UART_IRDA_TXEN_Msk               (0x1ul << UART_IRDA_TXEN_Pos)

#define UART_IRDA_TXINV_Pos              (5)
#define UART_IRDA_TXINV_Msk              (0x1ul << UART_IRDA_TXINV_Pos)

#define UART_IRDA_RXINV_Pos              (6)
#define UART_IRDA_RXINV_Msk              (0x1ul << UART_IRDA_RXINV_Pos)

#define UART_ALTCTL_BRKFL_Pos            (0)
#define UART_ALTCTL_BRKFL_Msk            (0xful << UART_ALTCTL_BRKFL_Pos)

#define UART_ALTCTL_LINRXEN_Pos          (6)
#define UART_ALTCTL_LINRXEN_Msk          (0x1ul << UART_ALTCTL_LINRXEN_Pos)

#define UART_ALTCTL_LINTXEN_Pos          (7)
#define UART_ALTCTL_LINTXEN_Msk          (0x1ul << UART_ALTCTL_LINTXEN_Pos)

#define UART_ALTCTL_RS485NMM_Pos         (8)
#define UART_ALTCTL_RS485NMM_Msk         (0x1ul << UART_ALTCTL_RS485NMM_Pos)

#define UART_ALTCTL_RS485AAD_Pos         (9)
#define UART_ALTCTL_RS485AAD_Msk         (0x1ul << UART_ALTCTL_RS485AAD_Pos)

#define UART_ALTCTL_RS485AUD_Pos         (10)
#define UART_ALTCTL_RS485AUD_Msk         (0x1ul << UART_ALTCTL_RS485AUD_Pos)

#define UART_ALTCTL_ADDRDEN_Pos          (15)
#define UART_ALTCTL_ADDRDEN_Msk          (0x1ul << UART_ALTCTL_ADDRDEN_Pos)

#define UART_ALTCTL_ABRIF_Pos            (17)
#define UART_ALTCTL_ABRIF_Msk            (0x1ul << UART_ALTCTL_ABRIF_Pos)

#define UART_ALTCTL_ABRDEN_Pos           (18)
#define UART_ALTCTL_ABRDEN_Msk           (0x1ul << UART_ALTCTL_ABRDEN_Pos)

#define UART_ALTCTL_ABRDBITS_Pos         (19)
#define UART_ALTCTL_ABRDBITS_Msk         (0x3ul << UART_ALTCTL_ABRDBITS_Pos)

#define UART_ALTCTL_ADDRMV_Pos           (24)
#define UART_ALTCTL_ADDRMV_Msk           (0xfful << UART_ALTCTL_ADDRMV_Pos)

#define UART_FUNCSEL_FUNCSEL_Pos         (0)
#define UART_FUNCSEL_FUNCSEL_Msk         (0x3ul << UART_FUNCSEL_FUNCSEL_Pos)

#define UART_LINCTL_SLVEN_Pos            (0)
#define UART_LINCTL_SLVEN_Msk            (0x1ul << UART_LINCTL_SLVEN_Pos)

#define UART_LINCTL_SLVHDEN_Pos          (1)
#define UART_LINCTL_SLVHDEN_Msk          (0x1ul << UART_LINCTL_SLVHDEN_Pos)

#define UART_LINCTL_SLVAREN_Pos          (2)
#define UART_LINCTL_SLVAREN_Msk          (0x1ul << UART_LINCTL_SLVAREN_Pos)

#define UART_LINCTL_SLVDUEN_Pos          (3)
#define UART_LINCTL_SLVDUEN_Msk          (0x1ul << UART_LINCTL_SLVDUEN_Pos)

#define UART_LINCTL_MUTE_Pos             (4)
#define UART_LINCTL_MUTE_Msk             (0x1ul << UART_LINCTL_MUTE_Pos)

#define UART_LINCTL_SENDH_Pos            (8)
#define UART_LINCTL_SENDH_Msk            (0x1ul << UART_LINCTL_SENDH_Pos)

#define UART_LINCTL_IDPEN_Pos            (9)
#define UART_LINCTL_IDPEN_Msk            (0x1ul << UART_LINCTL_IDPEN_Pos)

#define UART_LINCTL_BRKDETEN_Pos         (10)
#define UART_LINCTL_BRKDETEN_Msk         (0x1ul << UART_LINCTL_BRKDETEN_Pos)

#define UART_LINCTL_RXOFF_Pos            (11)
#define UART_LINCTL_RXOFF_Msk            (0x1ul << UART_LINCTL_RXOFF_Pos)

#define UART_LINCTL_BITERREN_Pos         (12)
#define UART_LINCTL_BITERREN_Msk         (0x1ul << UART_LINCTL_BITERREN_Pos)

#define UART_LINCTL_BRKFL_Pos            (16)
#define UART_LINCTL_BRKFL_Msk            (0xful << UART_LINCTL_BRKFL_Pos)

#define UART_LINCTL_BSL_Pos              (20)
#define UART_LINCTL_BSL_Msk              (0x3ul << UART_LINCTL_BSL_Pos)

#define UART_LINCTL_HSEL_Pos             (22)
#define UART_LINCTL_HSEL_Msk             (0x3ul << UART_LINCTL_HSEL_Pos)

#define UART_LINCTL_PID_Pos              (24)
#define UART_LINCTL_PID_Msk              (0xfful << UART_LINCTL_PID_Pos)

#define UART_LINSTS_SLVHDETF_Pos         (0)
#define UART_LINSTS_SLVHDETF_Msk         (0x1ul << UART_LINSTS_SLVHDETF_Pos)

#define UART_LINSTS_SLVHEF_Pos           (1)
#define UART_LINSTS_SLVHEF_Msk           (0x1ul << UART_LINSTS_SLVHEF_Pos)

#define UART_LINSTS_SLVIDPEF_Pos         (2)
#define UART_LINSTS_SLVIDPEF_Msk         (0x1ul << UART_LINSTS_SLVIDPEF_Pos)

#define UART_LINSTS_SLVSYNCF_Pos         (3)
#define UART_LINSTS_SLVSYNCF_Msk         (0x1ul << UART_LINSTS_SLVSYNCF_Pos)

#define UART_LINSTS_BRKDETF_Pos          (8)
#define UART_LINSTS_BRKDETF_Msk          (0x1ul << UART_LINSTS_BRKDETF_Pos)

#define UART_LINSTS_BITEF_Pos            (9)
#define UART_LINSTS_BITEF_Msk            (0x1ul << UART_LINSTS_BITEF_Pos)


/**@}*/ /* UART_CONST */
/**@}*/ /* end of UART register group */


/*---------------------- USB 1.1 Host Controller -------------------------*/
/**
    @addtogroup UHC USB 1.1 Host Controller(UHC)
    Memory Mapped Structure for UHC Controller
@{ */
 
typedef struct
{

    __I  uint32_t HcRev;                 /*!< [0x0000] Host Controller Revision Register                                */
    __IO uint32_t HcControl;             /*!< [0x0004] Host Controller Control Register                                 */
    __IO uint32_t HcComSts;              /*!< [0x0008] Host Controller CMD Status Register                              */
    __IO uint32_t HcIntSts;              /*!< [0x000c] Host Controller Interrupt Status Register                        */
    __IO uint32_t HcIntEn;               /*!< [0x0010] Host Controller Interrupt Enable Register                        */
    __IO uint32_t HcIntDis;              /*!< [0x0014] Host Controller Interrupt Disable Register                       */
    __IO uint32_t HcHCCA;                /*!< [0x0018] Host Controller Communication Area Register                      */
    __IO uint32_t HcPerCED;              /*!< [0x001c] Host Controller Period Current ED Register                       */
    __IO uint32_t HcCtrHED;              /*!< [0x0020] Host Controller Control Head ED Register                         */
    __IO uint32_t HcCtrCED;              /*!< [0x0024] Host Controller Control Current ED Register                      */
    __IO uint32_t HcBlkHED;              /*!< [0x0028] Host Controller Bulk Head ED Register                            */
    __IO uint32_t HcBlkCED;              /*!< [0x002c] Host Controller Bulk Current ED Register                         */
    __IO uint32_t HcDoneH;               /*!< [0x0030] Host Controller Done Head Register                               */
    __IO uint32_t HcFmIntv;              /*!< [0x0034] Host Controller Frame Interval Register                          */
    __I  uint32_t HcFmRem;               /*!< [0x0038] Host Controller Frame Remaining Register                         */
    __I  uint32_t HcFNum;                /*!< [0x003c] Host Controller Frame Number Register                            */
    __IO uint32_t HcPerSt;               /*!< [0x0040] Host Controller Periodic Start Register                          */
    __IO uint32_t HcLSTH;                /*!< [0x0044] Host Controller Low-speed Threshold Register                     */
    __IO uint32_t HcRhDeA;               /*!< [0x0048] Host Controller Root Hub Descriptor A Register                   */
    __IO uint32_t HcRhDeB;               /*!< [0x004c] Host Controller Root Hub Descriptor B Register                   */
    __IO uint32_t HcRhSts;               /*!< [0x0050] Host Controller Root Hub Status Register                         */
    __IO uint32_t HcRhPrt1;              /*!< [0x0054] Host Controller Root Hub Port Status [1\]                        */
         uint32_t RESERVE0[106];

    __IO uint32_t MiscCtrl;              /*!< [0x0200] USB Miscellaneous Control Register                               */
    __IO uint32_t OpModEn;               /*!< [0x0204] USB Operational Mode Enable Register                             */
         uint32_t RESERVE1[893];

    __IO uint32_t VERSION;               /*!< [0x0ffc] USB Host Controller Version Number Register                      */

} UHC_T;

/**
    @addtogroup UHC_CONST UHC Bit Field Definition
    Constant Definitions for UHC Controller
@{ */

#define UHC_HcRev_Rev_Pos                (0)
#define UHC_HcRev_Rev_Msk                (0xfful << UHC_HcRev_Rev_Pos)

#define UHC_HcControl_CtrlBlkRatio_Pos   (0)
#define UHC_HcControl_CtrlBlkRatio_Msk   (0x3ul << UHC_HcControl_CtrlBlkRatio_Pos)

#define UHC_HcControl_PeriEn_Pos         (2)
#define UHC_HcControl_PeriEn_Msk         (0x1ul << UHC_HcControl_PeriEn_Pos)

#define UHC_HcControl_ISOEn_Pos          (3)
#define UHC_HcControl_ISOEn_Msk          (0x1ul << UHC_HcControl_ISOEn_Pos)

#define UHC_HcControl_CtrlEn_Pos         (4)
#define UHC_HcControl_CtrlEn_Msk         (0x1ul << UHC_HcControl_CtrlEn_Pos)

#define UHC_HcControl_BlkEn_Pos          (5)
#define UHC_HcControl_BlkEn_Msk          (0x1ul << UHC_HcControl_BlkEn_Pos)

#define UHC_HcControl_HcFunc_Pos         (6)
#define UHC_HcControl_HcFunc_Msk         (0x3ul << UHC_HcControl_HcFunc_Pos)

#define UHC_HcComSts_HCReset_Pos         (0)
#define UHC_HcComSts_HCReset_Msk         (0x1ul << UHC_HcComSts_HCReset_Pos)

#define UHC_HcComSts_CtrlFill_Pos        (1)
#define UHC_HcComSts_CtrlFill_Msk        (0x1ul << UHC_HcComSts_CtrlFill_Pos)

#define UHC_HcComSts_BlkFill_Pos         (2)
#define UHC_HcComSts_BlkFill_Msk         (0x1ul << UHC_HcComSts_BlkFill_Pos)

#define UHC_HcComSts_SchOverRun_Pos      (16)
#define UHC_HcComSts_SchOverRun_Msk      (0x3ul << UHC_HcComSts_SchOverRun_Pos)

#define UHC_HcIntSts_SchOR_Pos           (0)
#define UHC_HcIntSts_SchOR_Msk           (0x1ul << UHC_HcIntSts_SchOR_Pos)

#define UHC_HcIntSts_WBDnHD_Pos          (1)
#define UHC_HcIntSts_WBDnHD_Msk          (0x1ul << UHC_HcIntSts_WBDnHD_Pos)

#define UHC_HcIntSts_SOF_Pos             (2)
#define UHC_HcIntSts_SOF_Msk             (0x1ul << UHC_HcIntSts_SOF_Pos)

#define UHC_HcIntSts_Resume_Pos          (3)
#define UHC_HcIntSts_Resume_Msk          (0x1ul << UHC_HcIntSts_Resume_Pos)

#define UHC_HcIntSts_FNOF_Pos            (5)
#define UHC_HcIntSts_FNOF_Msk            (0x1ul << UHC_HcIntSts_FNOF_Pos)

#define UHC_HcIntSts_RHSC_Pos            (6)
#define UHC_HcIntSts_RHSC_Msk            (0x1ul << UHC_HcIntSts_RHSC_Pos)

#define UHC_HcIntEn_SchOREn_Pos          (0)
#define UHC_HcIntEn_SchOREn_Msk          (0x1ul << UHC_HcIntEn_SchOREn_Pos)

#define UHC_HcIntEn_WBDHEn_Pos           (1)
#define UHC_HcIntEn_WBDHEn_Msk           (0x1ul << UHC_HcIntEn_WBDHEn_Pos)

#define UHC_HcIntEn_SOFEn_Pos            (2)
#define UHC_HcIntEn_SOFEn_Msk            (0x1ul << UHC_HcIntEn_SOFEn_Pos)

#define UHC_HcIntEn_ResuEn_Pos           (3)
#define UHC_HcIntEn_ResuEn_Msk           (0x1ul << UHC_HcIntEn_ResuEn_Pos)

#define UHC_HcIntEn_FNOFEn_Pos           (5)
#define UHC_HcIntEn_FNOFEn_Msk           (0x1ul << UHC_HcIntEn_FNOFEn_Pos)

#define UHC_HcIntEn_RHSCEn_Pos           (6)
#define UHC_HcIntEn_RHSCEn_Msk           (0x1ul << UHC_HcIntEn_RHSCEn_Pos)

#define UHC_HcIntEn_IntEn_Pos            (31)
#define UHC_HcIntEn_IntEn_Msk            (0x1ul << UHC_HcIntEn_IntEn_Pos)

#define UHC_HcIntDis_SchORDis_Pos        (0)
#define UHC_HcIntDis_SchORDis_Msk        (0x1ul << UHC_HcIntDis_SchORDis_Pos)

#define UHC_HcIntDis_WBDHDis_Pos         (1)
#define UHC_HcIntDis_WBDHDis_Msk         (0x1ul << UHC_HcIntDis_WBDHDis_Pos)

#define UHC_HcIntDis_SOFDis_Pos          (2)
#define UHC_HcIntDis_SOFDis_Msk          (0x1ul << UHC_HcIntDis_SOFDis_Pos)

#define UHC_HcIntDis_ResuDis_Pos         (3)
#define UHC_HcIntDis_ResuDis_Msk         (0x1ul << UHC_HcIntDis_ResuDis_Pos)

#define UHC_HcIntDis_FNOFDis_Pos         (5)
#define UHC_HcIntDis_FNOFDis_Msk         (0x1ul << UHC_HcIntDis_FNOFDis_Pos)

#define UHC_HcIntDis_RHSCDis_Pos         (6)
#define UHC_HcIntDis_RHSCDis_Msk         (0x1ul << UHC_HcIntDis_RHSCDis_Pos)

#define UHC_HcIntDis_IntDis_Pos          (31)
#define UHC_HcIntDis_IntDis_Msk          (0x1ul << UHC_HcIntDis_IntDis_Pos)

#define UHC_HcHCCA_HCCA_Pos              (8)
#define UHC_HcHCCA_HCCA_Msk              (0xfffffful << UHC_HcHCCA_HCCA_Pos)

#define UHC_HcPerCED_PeriCED_Pos         (4)
#define UHC_HcPerCED_PeriCED_Msk         (0xffffffful << UHC_HcPerCED_PeriCED_Pos)

#define UHC_HcCtrHED_CtrlHED_Pos         (4)
#define UHC_HcCtrHED_CtrlHED_Msk         (0xffffffful << UHC_HcCtrHED_CtrlHED_Pos)

#define UHC_HcCtrCED_CtrlCED_Pos         (4)
#define UHC_HcCtrCED_CtrlCED_Msk         (0xffffffful << UHC_HcCtrCED_CtrlCED_Pos)

#define UHC_HcBlkHED_BlkHED_Pos          (4)
#define UHC_HcBlkHED_BlkHED_Msk          (0xffffffful << UHC_HcBlkHED_BlkHED_Pos)

#define UHC_HcBlkCED_BlkCED_Pos          (4)
#define UHC_HcBlkCED_BlkCED_Msk          (0xffffffful << UHC_HcBlkCED_BlkCED_Pos)

#define UHC_HcDoneH_DoneH_Pos            (4)
#define UHC_HcDoneH_DoneH_Msk            (0xffffffful << UHC_HcDoneH_DoneH_Pos)

#define UHC_HcFmIntv_FmInterval_Pos      (0)
#define UHC_HcFmIntv_FmInterval_Msk      (0x3ffful << UHC_HcFmIntv_FmInterval_Pos)

#define UHC_HcFmIntv_FSDPktCnt_Pos       (16)
#define UHC_HcFmIntv_FSDPktCnt_Msk       (0x7ffful << UHC_HcFmIntv_FSDPktCnt_Pos)

#define UHC_HcFmIntv_FmIntvT_Pos         (31)
#define UHC_HcFmIntv_FmIntvT_Msk         (0x1ul << UHC_HcFmIntv_FmIntvT_Pos)

#define UHC_HcFmRem_FmRemain_Pos         (0)
#define UHC_HcFmRem_FmRemain_Msk         (0x3ffful << UHC_HcFmRem_FmRemain_Pos)

#define UHC_HcFmRem_FmRemT_Pos           (31)
#define UHC_HcFmRem_FmRemT_Msk           (0x1ul << UHC_HcFmRem_FmRemT_Pos)

#define UHC_HcFNum_FmNum_Pos             (0)
#define UHC_HcFNum_FmNum_Msk             (0xfffful << UHC_HcFNum_FmNum_Pos)

#define UHC_HcPerSt_PeriStart_Pos        (0)
#define UHC_HcPerSt_PeriStart_Msk        (0x3ffful << UHC_HcPerSt_PeriStart_Pos)

#define UHC_HcLSTH_LST_Pos               (0)
#define UHC_HcLSTH_LST_Msk               (0xffful << UHC_HcLSTH_LST_Pos)

#define UHC_HcRhDeA_DPortNum_Pos         (0)
#define UHC_HcRhDeA_DPortNum_Msk         (0xfful << UHC_HcRhDeA_DPortNum_Pos)

#define UHC_HcRhDeA_PSM_Pos              (8)
#define UHC_HcRhDeA_PSM_Msk              (0x1ul << UHC_HcRhDeA_PSM_Pos)

#define UHC_HcRhDeA_OCPM_Pos             (11)
#define UHC_HcRhDeA_OCPM_Msk             (0x1ul << UHC_HcRhDeA_OCPM_Pos)

#define UHC_HcRhDeA_NOCP_Pos             (12)
#define UHC_HcRhDeA_NOCP_Msk             (0x1ul << UHC_HcRhDeA_NOCP_Pos)

#define UHC_HcRhDeB_PPCM_Pos             (16)
#define UHC_HcRhDeB_PPCM_Msk             (0xfffful << UHC_HcRhDeB_PPCM_Pos)

#define UHC_HcRhSts_LPS_Pos              (0)
#define UHC_HcRhSts_LPS_Msk              (0x1ul << UHC_HcRhSts_LPS_Pos)

#define UHC_HcRhSts_OC_Pos               (1)
#define UHC_HcRhSts_OC_Msk               (0x1ul << UHC_HcRhSts_OC_Pos)

#define UHC_HcRhSts_DRWEn_Pos            (15)
#define UHC_HcRhSts_DRWEn_Msk            (0x1ul << UHC_HcRhSts_DRWEn_Pos)

#define UHC_HcRhSts_LPSC_Pos             (16)
#define UHC_HcRhSts_LPSC_Msk             (0x1ul << UHC_HcRhSts_LPSC_Pos)

#define UHC_HcRhSts_OCIC_Pos             (17)
#define UHC_HcRhSts_OCIC_Msk             (0x1ul << UHC_HcRhSts_OCIC_Pos)

#define UHC_HcRhSts_RWEClr_Pos           (31)
#define UHC_HcRhSts_RWEClr_Msk           (0x1ul << UHC_HcRhSts_RWEClr_Pos)

#define UHC_HcRhPrt1_CC_Pos              (0)
#define UHC_HcRhPrt1_CC_Msk              (0x1ul << UHC_HcRhPrt1_CC_Pos)

#define UHC_HcRhPrt1_PE_Pos              (1)
#define UHC_HcRhPrt1_PE_Msk              (0x1ul << UHC_HcRhPrt1_PE_Pos)

#define UHC_HcRhPrt1_PS_Pos              (2)
#define UHC_HcRhPrt1_PS_Msk              (0x1ul << UHC_HcRhPrt1_PS_Pos)

#define UHC_HcRhPrt1_POC_Pos             (3)
#define UHC_HcRhPrt1_POC_Msk             (0x1ul << UHC_HcRhPrt1_POC_Pos)

#define UHC_HcRhPrt1_PR_Pos              (4)
#define UHC_HcRhPrt1_PR_Msk              (0x1ul << UHC_HcRhPrt1_PR_Pos)

#define UHC_HcRhPrt1_PPS_Pos             (8)
#define UHC_HcRhPrt1_PPS_Msk             (0x1ul << UHC_HcRhPrt1_PPS_Pos)

#define UHC_HcRhPrt1_LSDev_Pos           (9)
#define UHC_HcRhPrt1_LSDev_Msk           (0x1ul << UHC_HcRhPrt1_LSDev_Pos)

#define UHC_HcRhPrt1_CSC_Pos             (16)
#define UHC_HcRhPrt1_CSC_Msk             (0x1ul << UHC_HcRhPrt1_CSC_Pos)

#define UHC_HcRhPrt1_PESC_Pos            (17)
#define UHC_HcRhPrt1_PESC_Msk            (0x1ul << UHC_HcRhPrt1_PESC_Pos)

#define UHC_HcRhPrt1_PSSC_Pos            (18)
#define UHC_HcRhPrt1_PSSC_Msk            (0x1ul << UHC_HcRhPrt1_PSSC_Pos)

#define UHC_HcRhPrt1_POCIC_Pos           (19)
#define UHC_HcRhPrt1_POCIC_Msk           (0x1ul << UHC_HcRhPrt1_POCIC_Pos)

#define UHC_HcRhPrt1_PRSC_Pos            (20)
#define UHC_HcRhPrt1_PRSC_Msk            (0x1ul << UHC_HcRhPrt1_PRSC_Pos)

#define UHC_MiscCtrl_StbyEn_Pos          (27)
#define UHC_MiscCtrl_StbyEn_Msk          (0x1ul << UHC_MiscCtrl_StbyEn_Pos)

#define UHC_OpModEn_DBR16_Pos            (0)
#define UHC_OpModEn_DBR16_Msk            (0x1ul << UHC_OpModEn_DBR16_Pos)

#define UHC_OpModEn_ABORT_Pos            (1)
#define UHC_OpModEn_ABORT_Msk            (0x1ul << UHC_OpModEn_ABORT_Pos)

#define UHC_OpModEn_OCALow_Pos           (3)
#define UHC_OpModEn_OCALow_Msk           (0x1ul << UHC_OpModEn_OCALow_Pos)

#define UHC_OpModEn_PPCALow_Pos          (4)
#define UHC_OpModEn_PPCALow_Msk          (0x1ul << UHC_OpModEn_PPCALow_Pos)

#define UHC_OpModEn_SINTENPDis_Pos       (8)
#define UHC_OpModEn_SINTENPDis_Msk       (0x1ul << UHC_OpModEn_SINTENPDis_Pos)

#define UHC_OpModEn_DisPrt1_Pos          (16)
#define UHC_OpModEn_DisPrt1_Msk          (0x1ul << UHC_OpModEn_DisPrt1_Pos)

#define UHC_VERSION_MINOR_Pos            (0)
#define UHC_VERSION_MINOR_Msk            (0xfffful << UHC_VERSION_MINOR_Pos)

#define UHC_VERSION_SUB_Pos              (16)
#define UHC_VERSION_SUB_Msk              (0xfful << UHC_VERSION_SUB_Pos)

#define UHC_VERSION_MAJOR_Pos            (24)
#define UHC_VERSION_MAJOR_Msk            (0xfful << UHC_VERSION_MAJOR_Pos)

/**@}*/ /* UHC_CONST */
/**@}*/ /* end of UHC register group */


/*---------------------- Universal Serial Bus Controller -------------------------*/
/**
    @addtogroup USB Universal Serial Bus Controller(USB)
    Memory Mapped Structure for USB Controller
@{ */
 
/**
  * @brief USBD endpoints register
  */
typedef struct {
    /**
     * USB_BUFSEG0~7
     * ===================================================================================================
     * Offset: 0x500/0x510/0x520/0x530/0x540/0x550/0x560/0x570  Endpoint 0~7 Buffer Segmentation Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[3:8]   |BUFSEG    |Endpoint Buffer Segmentation
     * |        |          |It is used to indicate the offset address for each endpoint with the USB SRAM starting address The effective starting address of the endpoint is
     * |        |          |USB_SRAM address + { BUFSEG[8:3], 3'b000}
     * |        |          |Where the USB_SRAM address = USBD_BA+0x100h.
     * |        |          |Refer to the section 5.4.4.7 for the endpoint SRAM structure and its description.
     */
    __IO uint32_t BUFSEG;   /*!< Endpoint Buffer Segmentation Register   */

    /**
     * USB_MXPLD0~7
     * ===================================================================================================
     * Offset: 0x504/0x514/0x524/0x534/0x544/0x554/0x564/0x574  Endpoint 0~7 Maximal Payload Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0:8]   |MXPLD     |Maximal Payload
     * |        |          |Define the data length which is transmitted to host (IN token) or the actual data length which is received from the host (OUT token).
     * |        |          |It also used to indicate that the endpoint is ready to be transmitted in IN token or received in OUT token.
     * |        |          |(1) When the register is written by CPU,
     * |        |          |For IN token, the value of MXPLD is used to define the data length to be transmitted and indicate the data buffer is ready.
     * |        |          |For OUT token, it means that the controller is ready to receive data from the host and the value of MXPLD is the maximal data length comes from host.
     * |        |          |(2) When the register is read by CPU,
     * |        |          |For IN token, the value of MXPLD is indicated by the data length be transmitted to host
     * |        |          |For OUT token, the value of MXPLD is indicated the actual data length receiving from host.
     * |        |          |Note: Once MXPLD is written, the data packets will be transmitted/received immediately after IN/OUT token arrived.
     */
    __IO uint32_t MXPLD;    /*!< Endpoint Maximal Payload Register   */

    /**
     * USB_CFG0~7
     * ===================================================================================================
     * Offset: 0x508/0x518/0x528/0x538/0x548/0x558/0x568/0x578  Endpoint 0~7 Configuration Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0:3]   |EPNUM     |Endpoint Number
     * |        |          |These bits are used to define the endpoint number of the current endpoint.
     * |[4]     |ISOCH     |Isochronous Endpoint
     * |        |          |This bit is used to set the endpoint as Isochronous endpoint, no handshake.
     * |        |          |0 = No Isochronous endpoint.
     * |        |          |1 = Isochronous endpoint.
     * |[5:6]   |STATE     |Endpoint STATE
     * |        |          |00 = Endpoint is Disabled.
     * |        |          |01 = Out endpoint.
     * |        |          |10 = IN endpoint.
     * |        |          |11 = Undefined.
     * |[7]     |DSQSYNC   |Data Sequence Synchronization
     * |        |          |0 = DATA0 PID.
     * |        |          |1 = DATA1 PID.
     * |        |          |Note: It is used to specify the DATA0 or DATA1 PID in the following IN token transaction.
     * |        |          |Hardware will toggle automatically in IN token base on the bit.
     * |[9]     |CSTALL    |Clear STALL Response
     * |        |          |0 = Disable the device to clear the STALL handshake in setup stage.
     * |        |          |1 = Clear the device to response STALL handshake in setup stage.
     */
    __IO uint32_t CFG;      /*!< Endpoint Configuration Register   */

    /**
    * USB_CFGP0~7
    * ===================================================================================================
    * Offset: 0x50C/0x51C/0x52C/0x53C/0x54C/0x55C/0x56C/0x57C  Endpoint 0~7 Set Stall and Clear In/Out Ready Control Register
    * ---------------------------------------------------------------------------------------------------
    * |Bits    |Field     |Descriptions
    * | :----: | :----:   | :---- |
    * |[0]     |CLRRDY    |Clear Ready
    * |        |          |When the USB_MXPLD register is set by user, it means that the endpoint is ready to transmit or receive data.
    * |        |          |If the user wants to turn off this transaction before the transaction start, users can set this bit to 1 to turn it off and it will be cleared to 0 automatically.
    * |        |          |For IN token, write ��1' to clear the IN token had ready to transmit the data to USB.
    * |        |          |For OUT token, write ��1' to clear the OUT token had ready to receive the data from USB.
    * |        |          |This bit is write 1 only and is always 0 when it is read back.
    * |[1]     |SSTALL    |Set STALL
    * |        |          |0 = Disable the device to response STALL.
    * |        |          |1 = Set the device to respond STALL automatically.
    */
    __IO uint32_t CFGP;     /*!< Endpoint Set Stall and Clear In/Out Ready Control Register */
} USBD_EP_T;


typedef struct
{
    /**
     * USB_INTEN
     * ===================================================================================================
     * Offset: 0x00  USB Interrupt Enable Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0]     |BUSIEN    |Bus Event Interrupt Enable
     * |        |          |0 = BUS event interrupt Disabled.
     * |        |          |1 = BUS event interrupt Enabled.
     * |[1]     |USBIEN    |USB Event Interrupt Enable
     * |        |          |0 = USB event interrupt Disabled.
     * |        |          |1 = USB event interrupt Enabled.
     * |[2]     |VBDETIEN  |VBUS Detection Interrupt Enable
     * |        |          |0 = Floating detection Interrupt Disabled.
     * |        |          |1 = Floating detection Interrupt Enabled.
     * |[3]     |NEVTWKIEN |USB No-Event-Wake-Up Interrupt Enable
     * |        |          |0 = No-Event-Wake-up Interrupt Disabled.
     * |        |          |1 = No-Event-Wake-up Interrupt Enabled.
     * |[8]     |WKEN      |Wake-Up Function Enable
     * |        |          |0 = USB wake-up function Disabled.
     * |        |          |1 = USB wake-up function Enabled.
     * |[15]    |INNAKEN   |Active NAK Function And Its Status In IN Token
     * |        |          |0 = When device responds NAK after receiving IN token, IN NAK status will not be
     * |        |          |    updated to USBD_EPSTS register, so that the USB interrupt event will not be asserted.
     * |        |          |1 = IN NAK status will be updated to USBD_EPSTS register and the USB interrupt event
     * |        |          |    will be asserted, when the device responds NAK after receiving IN token.
     */
    __IO uint32_t INTEN;                 /*!< [0x0000] USB Device Interrupt Enable                      */

    /**
     * USB_INTSTS
     * ===================================================================================================
     * Offset: 0x04  USB Interrupt Event Status Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0]     |BUSIF     |BUS Interrupt Status
     * |        |          |The BUS event means that there is one of the suspense or the resume function in the bus.
     * |        |          |0 = No BUS event occurred.
     * |        |          |1 = Bus event occurred; check USB_ATTR[3:0] to know which kind of bus event was occurred, cleared by write 1 to USB_INTSTS[0].
     * |[1]     |USBIF     |USB Event Interrupt Status
     * |        |          |The USB event includes the SETUP Token, IN Token, OUT ACK, ISO IN, or ISO OUT events in the bus.
     * |        |          |0 = No USB event occurred.
     * |        |          |1 = USB event occurred, check EPSTS0~7 to know which kind of USB event occurred.
     * |        |          |Cleared by write 1 to USB_INTSTS[1] or EPEVT0~7 and SETUP (USB_INTSTS[31])..
     * |[2]     |VBDETIF   |VBUS Detection Interrupt Status
     * |        |          |0 = There is not attached/detached event in the USB.
     * |        |          |1 = There is attached/detached event in the USB bus and it is cleared by write 1 to USB_INTSTS[2].
     * |[3]     |NEVTWKIF  |Wake-Up Interrupt Status
     * |        |          |0 = No Wake-up event occurred.
     * |        |          |1 = Wake-up event occurred, cleared by write 1 to USB_INTSTS[3].
     * |[16]    |EPEVT0    |Endpoint 0's USB Event Status
     * |        |          |0 = No event occurred on endpoint 0.
     * |        |          |1 = USB event occurred on Endpoint 0, check USB_EPSTS[10:8] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[16] or USB_INTSTS[1].
     * |[17]    |EPEVT1    |Endpoint 1's USB Event Status
     * |        |          |0 = No event occurred on endpoint 1.
     * |        |          |1 = USB event occurred on Endpoint 1, check USB_EPSTS[13:11] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[17] or USB_INTSTS[1].
     * |[18]    |EPEVT2    |Endpoint 2's USB Event Status
     * |        |          |0 = No event occurred on endpoint 2.
     * |        |          |1 = USB event occurred on Endpoint 2, check USB_EPSTS[16:14] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[18] or USB_INTSTS[1].
     * |[19]    |EPEVT3    |Endpoint 3's USB Event Status
     * |        |          |0 = No event occurred on endpoint 3.
     * |        |          |1 = USB event occurred on Endpoint 3, check USB_EPSTS[19:17] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[19] or USB_INTSTS[1].
     * |[20]    |EPEVT4    |Endpoint 4's USB Event Status
     * |        |          |0 = No event occurred on endpoint 4.
     * |        |          |1 = USB event occurred on Endpoint 4, check USB_EPSTS[22:20] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[20] or USB_INTSTS[1].
     * |[21]    |EPEVT5    |Endpoint 5's USB Event Status
     * |        |          |0 = No event occurred on endpoint 5.
     * |        |          |1 = USB event occurred on Endpoint 5, check USB_EPSTS[25:23] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[21] or USB_INTSTS[1].
     * |[22]    |EPEVT6    |Endpoint 6's USB Event Status
     * |        |          |0 = No event occurred on endpoint 6.
     * |        |          |1 = USB event occurred on Endpoint 6, check USB_EPSTS[28:26] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[22] or USB_INTSTS[1].
     * |[23]    |EPEVT7    |Endpoint 7's USB Event Status
     * |        |          |0 = No event occurred on endpoint 7.
     * |        |          |1 = USB event occurred on Endpoint 7, check USB_EPSTS[31:29] to know which kind of USB event was occurred, cleared by write 1 to USB_INTSTS[23] or USB_INTSTS[1].
     * |[31]    |SETUP     |Setup Event Status
     * |        |          |0 = No Setup event.
     * |        |          |1 = SETUP event occurred, cleared by write 1 to USB_INTSTS[31].
     */
    __IO uint32_t INTSTS;                /*!< [0x0004] USB Device Interrupt Event Status                */

    /**
     * USB_FADDR
     * ===================================================================================================
     * Offset: 0x08  USB Device Function Address Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0:6]   |FADDR     |USB Device Function Address
     */
    __IO uint32_t FADDR;                 /*!< [0x0008] USB Device Function Address                      */

    /**
     * USB_EPSTS
     * ===================================================================================================
     * Offset: 0x0C  USB Endpoint Status Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[7]     |OV        |Overrun
     * |        |          |It indicates that the received data is over the maximum payload number or not.
     * |        |          |0 = No overrun.
     * |        |          |1 = Out Data is more than the Max Payload in MXPLD register or the Setup Data is more than 8 Bytes.
     * |[8:10]  |EPSTS0    |Endpoint 0 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[11:13] |EPSTS1    |Endpoint 1 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[14:16] |EPSTS2    |Endpoint 2 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[17:19] |EPSTS3    |Endpoint 3 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[20:22] |EPSTS4    |Endpoint 4 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[23:25] |EPSTS5    |Endpoint 5 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[26:28] |EPSTS6    |Endpoint 6 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     * |[29:31] |EPSTS7    |Endpoint 7 Bus Status
     * |        |          |These bits are used to indicate the current status of this endpoint
     * |        |          |000 = In ACK.
     * |        |          |001 = In NAK.
     * |        |          |010 = Out Packet Data0 ACK.
     * |        |          |110 = Out Packet Data1 ACK.
     * |        |          |011 = Setup ACK.
     * |        |          |111 = Isochronous transfer end.
     */
    __I  uint32_t EPSTS;                 /*!< [0x000c] USB Device Endpoint Status                       */

    /**
     * USB_ATTR
     * ===================================================================================================
     * Offset: 0x10  USB Bus Status and Attribution Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0]     |USBRST    |USB Reset Status
     * |        |          |0 = Bus no reset.
     * |        |          |1 = Bus reset when SE0 (single-ended 0) is presented more than 2.5us.
     * |        |          |Note: This bit is read only.
     * |[1]     |SUSPEND   |Suspend Status
     * |        |          |0 = Bus no suspend.
     * |        |          |1 = Bus idle more than 3ms, either cable is plugged off or host is sleeping.
     * |        |          |Note: This bit is read only.
     * |[2]     |RESUME    |Resume Status
     * |        |          |0 = No bus resume.
     * |        |          |1 = Resume from suspend.
     * |        |          |Note: This bit is read only.
     * |[3]     |TOUT      |Time-Out Status
     * |        |          |0 = No time-out.
     * |        |          |1 = No Bus response more than 18 bits time.
     * |        |          |Note: This bit is read only.
     * |[4]     |PHYEN     |PHY Transceiver Function Enable
     * |        |          |0 = PHY transceiver function Disabled.
     * |        |          |1 = PHY transceiver function Enabled.
     * |[5]     |RWAKEUP   |Remote Wake-Up
     * |        |          |0 = Release the USB bus from K state.
     * |        |          |1 = Force USB bus to K (USB_D+ low, USB_D- high) state, used for remote wake-up.
     * |[7]     |USBEN     |USB Controller Enable
     * |        |          |0 = USB Controller Disabled.
     * |        |          |1 = USB Controller Enabled.
     * |[8]     |DPPUEN    |Pull-Up Resistor On USB_D+ Enable
     * |        |          |0 = Pull-up resistor in USB_D+ pin Disabled.
     * |        |          |1 = Pull-up resistor in USB_D+ pin Enabled.
     * |[10]    |BYTEM     |CPU Access USB SRAM Size Mode Selection
     * |        |          |0 = Word mode: The size of the transfer from CPU to USB SRAM can be Word only.
     * |        |          |1 = Byte mode: The size of the transfer from CPU to USB SRAM can be Byte only.
     */
    __IO uint32_t ATTR;                  /*!< [0x0010] USB Device Bus Status and Attribution            */

    /**
     * USB_VBUSDET
     * ===================================================================================================
     * Offset: 0x14  USB Device VBUS Detection Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0]     |FLDET     |Device VBUS Detected
     * |        |          |0 = Controller is not attached into the USB host.
     * |        |          |1 =Controller is attached into the BUS.
     */
    __I  uint32_t VBUSDET;               /*!< [0x0014] USB Device VBUS Detection                        */

    /**
     * USB_STBUFSEG
     * ===================================================================================================
     * Offset: 0x18  Setup Token Buffer Segmentation Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[3:8]   |STBUFSEG  |Setup Token Buffer Segmentation
     * |        |          |It is used to indicate the offset address for the SETUP token with the USB Device SRAM starting address The effective starting address is
     * |        |          |USB_SRAM address + {STBUFSEG[8:3], 3'b000}
     * |        |          |Where the USB_SRAM address = USBD_BA+0x100h.
     * |        |          |Note: It is used for SETUP token only.
     */
    __IO uint32_t STBUFSEG;              /*!< [0x0018] Setup Token Buffer Segmentation                  */
         uint32_t RESERVE0[29];

    /**
     * USB_SE0
     * ===================================================================================================
     * Offset: 0x90  USB Drive SE0 Control Register
     * ---------------------------------------------------------------------------------------------------
     * |Bits    |Field     |Descriptions
     * | :----: | :----:   | :---- |
     * |[0]     |DRVSE0    |Drive Single Ended Zero In USB Bus
     * |        |          |The Single Ended Zero (SE0) is when both lines (USB_D+ and USB_D-) are being pulled low.
     * |        |          |0 = None.
     * |        |          |1 = Force USB PHY transceiver to drive SE0.
     */
    __IO uint32_t SE0;                   /*!< [0x0090] USB Device Drive SE0 Control                     */
         uint32_t RESERVE1[283];

        USBD_EP_T EP[8];                 /*!< [0x0500] Endpoint Related Configuration                   */
        uint32_t RESERVE2[702];
    __I  uint32_t VERSION;               /*!< [0x0014] USB Version Number                               */        
} USBD_T;

/**
    @addtogroup USB_CONST USB Bit Field Definition
    Constant Definitions for USB Controller
@{ */

#define USBD_INTEN_BUSIEN_Pos             (0)
#define USBD_INTEN_BUSIEN_Msk             (0x1ul << USBD_INTEN_BUSIEN_Pos)

#define USBD_INTEN_USBIEN_Pos             (1)
#define USBD_INTEN_USBIEN_Msk             (0x1ul << USBD_INTEN_USBIEN_Pos)

#define USBD_INTEN_VBDETIEN_Pos           (2)
#define USBD_INTEN_VBDETIEN_Msk           (0x1ul << USBD_INTEN_VBDETIEN_Pos)

#define USBD_INTEN_NEVTWKIEN_Pos          (3)
#define USBD_INTEN_NEVTWKIEN_Msk          (0x1ul << USBD_INTEN_NEVTWKIEN_Pos)

#define USBD_INTEN_WKEN_Pos               (8)
#define USBD_INTEN_WKEN_Msk               (0x1ul << USBD_INTEN_WKEN_Pos)

#define USBD_INTEN_INNAKEN_Pos            (15)
#define USBD_INTEN_INNAKEN_Msk            (0x1ul << USBD_INTEN_INNAKEN_Pos)

#define USBD_INTSTS_BUSIF_Pos             (0)
#define USBD_INTSTS_BUSIF_Msk             (0x1ul << USBD_INTSTS_BUSIF_Pos)

#define USBD_INTSTS_USBIF_Pos             (1)
#define USBD_INTSTS_USBIF_Msk             (0x1ul << USBD_INTSTS_USBIF_Pos)

#define USBD_INTSTS_VBDETIF_Pos           (2)
#define USBD_INTSTS_VBDETIF_Msk           (0x1ul << USBD_INTSTS_VBDETIF_Pos)

#define USBD_INTSTS_NEVTWKIF_Pos          (3)
#define USBD_INTSTS_NEVTWKIF_Msk          (0x1ul << USBD_INTSTS_NEVTWKIF_Pos)

#define USBD_INTSTS_EPEVT0_Pos            (16)
#define USBD_INTSTS_EPEVT0_Msk            (0x1ul << USBD_INTSTS_EPEVT0_Pos)

#define USBD_INTSTS_EPEVT1_Pos            (17)
#define USBD_INTSTS_EPEVT1_Msk            (0x1ul << USBD_INTSTS_EPEVT1_Pos)

#define USBD_INTSTS_EPEVT2_Pos            (18)
#define USBD_INTSTS_EPEVT2_Msk            (0x1ul << USBD_INTSTS_EPEVT2_Pos)

#define USBD_INTSTS_EPEVT3_Pos            (19)
#define USBD_INTSTS_EPEVT3_Msk            (0x1ul << USBD_INTSTS_EPEVT3_Pos)

#define USBD_INTSTS_EPEVT4_Pos            (20)
#define USBD_INTSTS_EPEVT4_Msk            (0x1ul << USBD_INTSTS_EPEVT4_Pos)

#define USBD_INTSTS_EPEVT5_Pos            (21)
#define USBD_INTSTS_EPEVT5_Msk            (0x1ul << USBD_INTSTS_EPEVT5_Pos)

#define USBD_INTSTS_EPEVT6_Pos            (22)
#define USBD_INTSTS_EPEVT6_Msk            (0x1ul << USBD_INTSTS_EPEVT6_Pos)

#define USBD_INTSTS_EPEVT7_Pos            (23)
#define USBD_INTSTS_EPEVT7_Msk            (0x1ul << USBD_INTSTS_EPEVT7_Pos)

#define USBD_INTSTS_SETUP_Pos             (31)
#define USBD_INTSTS_SETUP_Msk             (0x1ul << USBD_INTSTS_SETUP_Pos)

#define USBD_FADDR_FADDR_Pos              (0)
#define USBD_FADDR_FADDR_Msk              (0x7ful << USBD_FADDR_FADDR_Pos)

#define USBD_EPSTS_OV_Pos                 (7)
#define USBD_EPSTS_OV_Msk                 (0x1ul << USBD_EPSTS_OV_Pos)

#define USBD_EPSTS_EPSTS0_Pos             (8)
#define USBD_EPSTS_EPSTS0_Msk             (0x7ul << USBD_EPSTS_EPSTS0_Pos)

#define USBD_EPSTS_EPSTS1_Pos             (11)
#define USBD_EPSTS_EPSTS1_Msk             (0x7ul << USBD_EPSTS_EPSTS1_Pos)

#define USBD_EPSTS_EPSTS2_Pos             (14)
#define USBD_EPSTS_EPSTS2_Msk             (0x7ul << USBD_EPSTS_EPSTS2_Pos)

#define USBD_EPSTS_EPSTS3_Pos             (17)
#define USBD_EPSTS_EPSTS3_Msk             (0x7ul << USBD_EPSTS_EPSTS3_Pos)

#define USBD_EPSTS_EPSTS4_Pos             (20)
#define USBD_EPSTS_EPSTS4_Msk             (0x7ul << USBD_EPSTS_EPSTS4_Pos)

#define USBD_EPSTS_EPSTS5_Pos             (23)
#define USBD_EPSTS_EPSTS5_Msk             (0x7ul << USBD_EPSTS_EPSTS5_Pos)

#define USBD_EPSTS_EPSTS6_Pos             (26)
#define USBD_EPSTS_EPSTS6_Msk             (0x7ul << USBD_EPSTS_EPSTS6_Pos)

#define USBD_EPSTS_EPSTS7_Pos             (29)
#define USBD_EPSTS_EPSTS7_Msk             (0x7ul << USBD_EPSTS_EPSTS7_Pos)

#define USBD_ATTR_USBRST_Pos              (0)
#define USBD_ATTR_USBRST_Msk              (0x1ul << USBD_ATTR_USBRST_Pos)

#define USBD_ATTR_SUSPEND_Pos             (1)
#define USBD_ATTR_SUSPEND_Msk             (0x1ul << USBD_ATTR_SUSPEND_Pos)

#define USBD_ATTR_RESUME_Pos              (2)
#define USBD_ATTR_RESUME_Msk              (0x1ul << USBD_ATTR_RESUME_Pos)

#define USBD_ATTR_TOUT_Pos                (3)
#define USBD_ATTR_TOUT_Msk                (0x1ul << USBD_ATTR_TOUT_Pos)

#define USBD_ATTR_PHYEN_Pos               (4)
#define USBD_ATTR_PHYEN_Msk               (0x1ul << USBD_ATTR_PHYEN_Pos)

#define USBD_ATTR_RWAKEUP_Pos             (5)
#define USBD_ATTR_RWAKEUP_Msk             (0x1ul << USBD_ATTR_RWAKEUP_Pos)

#define USBD_ATTR_USBEN_Pos               (7)
#define USBD_ATTR_USBEN_Msk               (0x1ul << USBD_ATTR_USBEN_Pos)

#define USBD_ATTR_DPPUEN_Pos              (8)
#define USBD_ATTR_DPPUEN_Msk              (0x1ul << USBD_ATTR_DPPUEN_Pos)

#define USBD_ATTR_BYTEM_Pos               (10)
#define USBD_ATTR_BYTEM_Msk               (0x1ul << USBD_ATTR_BYTEM_Pos)

#define USBD_VBUSDET_VBUSDET_Pos          (0)
#define USBD_VBUSDET_VBUSDET_Msk          (0x1ul << USBD_VBUSDET_VBUSDET_Pos)

#define USBD_STBUFSEG_STBUFSEG_Pos        (3)
#define USBD_STBUFSEG_STBUFSEG_Msk        (0x3ful << USBD_STBUFSEG_STBUFSEG_Pos)

#define USBD_SE0_SE0_Pos                  (0)
#define USBD_SE0_SE0_Msk                  (0x1ul << USBD_SE0_SE0_Pos)

#define USBD_BUFSEG_BUFSEG_Pos           (3)
#define USBD_BUFSEG_BUFSEG_Msk           (0x3ful << USBD_BUFSEG_BUFSEG_Pos)

#define USBD_MXPLD_MXPLD_Pos             (0)
#define USBD_MXPLD_MXPLD_Msk             (0x1fful << USBD_MXPLD_MXPLD_Pos)

#define USBD_CFG_EPNUM_Pos               (0)
#define USBD_CFG_EPNUM_Msk               (0xful << USBD_CFG_EPNUM_Pos)

#define USBD_CFG_ISOCH_Pos               (4)
#define USBD_CFG_ISOCH_Msk               (0x1ul << USBD_CFG_ISOCH_Pos)

#define USBD_CFG_STATE_Pos               (5)
#define USBD_CFG_STATE_Msk               (0x3ul << USBD_CFG_STATE_Pos)

#define USBD_CFG_DSQSYNC_Pos             (7)
#define USBD_CFG_DSQSYNC_Msk             (0x1ul << USBD_CFG_DSQSYNC_Pos)

#define USBD_CFG_CSTALL_Pos              (9)
#define USBD_CFG_CSTALL_Msk              (0x1ul << USBD_CFG_CSTALL_Pos)

#define USBD_CFGP_CLRRDY_Pos             (0)
#define USBD_CFGP_CLRRDY_Msk             (0x1ul << USBD_CFGP_CLRRDY_Pos)

#define USBD_CFGP_SSTALL_Pos             (1)
#define USBD_CFGP_SSTALL_Msk             (0x1ul << USBD_CFGP_SSTALL_Pos)

/**@}*/ /* USB_CONST */
/**@}*/ /* end of USB register group */


/*---------------------- Watch Dog Timer Controller -------------------------*/
/**
    @addtogroup WDT Watch Dog Timer Controller(WDT)
    Memory Mapped Structure for WDT Controller
@{ */
 
typedef struct
{

    __IO uint32_t CTL;                   /*!< [0x0000] WDT Control Register                                             */
    __IO uint32_t ALTCTL;                /*!< [0x0004] WDT Alternative Control Register                                 */

} WDT_T;

/**
    @addtogroup WDT_CONST WDT Bit Field Definition
    Constant Definitions for WDT Controller
@{ */

#define WDT_CTL_RSTCNT_Pos               (0)
#define WDT_CTL_RSTCNT_Msk               (0x1ul << WDT_CTL_RSTCNT_Pos)

#define WDT_CTL_RSTEN_Pos                (1)
#define WDT_CTL_RSTEN_Msk                (0x1ul << WDT_CTL_RSTEN_Pos)

#define WDT_CTL_RSTF_Pos                 (2)
#define WDT_CTL_RSTF_Msk                 (0x1ul << WDT_CTL_RSTF_Pos)

#define WDT_CTL_IF_Pos                   (3)
#define WDT_CTL_IF_Msk                   (0x1ul << WDT_CTL_IF_Pos)

#define WDT_CTL_WKEN_Pos                 (4)
#define WDT_CTL_WKEN_Msk                 (0x1ul << WDT_CTL_WKEN_Pos)

#define WDT_CTL_WKF_Pos                  (5)
#define WDT_CTL_WKF_Msk                  (0x1ul << WDT_CTL_WKF_Pos)

#define WDT_CTL_INTEN_Pos                (6)
#define WDT_CTL_INTEN_Msk                (0x1ul << WDT_CTL_INTEN_Pos)

#define WDT_CTL_WDTEN_Pos                (7)
#define WDT_CTL_WDTEN_Msk                (0x1ul << WDT_CTL_WDTEN_Pos)

#define WDT_CTL_TOUTSEL_Pos              (8)
#define WDT_CTL_TOUTSEL_Msk              (0x7ul << WDT_CTL_TOUTSEL_Pos)

#define WDT_CTL_ICEDEBUG_Pos             (31)
#define WDT_CTL_ICEDEBUG_Msk             (0x1ul << WDT_CTL_ICEDEBUG_Pos)

#define WDT_ALTCTL_RSTDSEL_Pos           (0)
#define WDT_ALTCTL_RSTDSEL_Msk           (0x3ul << WDT_ALTCTL_RSTDSEL_Pos)

/**@}*/ /* WDT_CONST */
/**@}*/ /* end of WDT register group */
/*------------- USB Host OHCI Controller (USBH) -----------------------------*/
/** @addtogroup M451_USBH M451 Host OHCI Controller Register (USBH)
  @{
*/
typedef struct {
    __I  uint32_t HcRev;                 /*!< Offset: 0x0000   Host Controller Revision Register                  */
    __IO uint32_t HcControl;             /*!< Offset: 0x0004   Host Controller Control Register                   */
    __IO uint32_t HcComSts;              /*!< Offset: 0x0008   Host Controller Command Status Register            */
    __IO uint32_t HcIntSts;              /*!< Offset: 0x000C   Host Controller Interrupt Status Register          */
    __IO uint32_t HcIntEn;               /*!< Offset: 0x0010   Host Controller Interrupt Enable Register          */
    __IO uint32_t HcIntDis;              /*!< Offset: 0x0014   Host Controller Interrupt Disable Register         */
    __IO uint32_t HcHCCA;                /*!< Offset: 0x0018   Host Controller Communication Area Register        */
    __IO uint32_t HcPerCED;              /*!< Offset: 0x001C   Host Controller Period Current ED Register         */
    __IO uint32_t HcCtrHED;              /*!< Offset: 0x0020   Host Controller Control Head ED Register           */
    __IO uint32_t HcCtrCED;              /*!< Offset: 0x0024   Host Controller Control Current ED Register        */
    __IO uint32_t HcBlkHED;              /*!< Offset: 0x0028   Host Controller Bulk Head ED Register              */
    __IO uint32_t HcBlkCED;              /*!< Offset: 0x002C   Host Controller Bulk Current ED Register           */
    __IO uint32_t HcDoneH;               /*!< Offset: 0x0030   Host Controller Done Head Register                 */
    __IO uint32_t HcFmIntv;              /*!< Offset: 0x0034   Host Controller Frame Interval Register            */
    __I  uint32_t HcFmRem;               /*!< Offset: 0x0038   Host Controller Frame Remaining Register           */
    __I  uint32_t HcFNum;                /*!< Offset: 0x003C   Host Controller Frame Number Register              */
    __IO uint32_t HcPerSt;               /*!< Offset: 0x0040   Host Controller Periodic Start Register            */
    __IO uint32_t HcLSTH;                /*!< Offset: 0x0044   Host Controller Low Speed Threshold Register       */
    __IO  uint32_t HcRhDeA;              /*!< Offset: 0x0048   Host Controller Root Hub Descriptor A Register     */
    __I  uint32_t HcRhDeB;               /*!< Offset: 0x004C   Host Controller Root Hub Descriptor A Register     */
    __IO uint32_t HcRhSts;               /*!< Offset: 0x0050   Host Controller Root Hub Status Register           */
    __IO uint32_t HcRhPrt[2];            /*!< Offset: 0x0054   Host Controller Root Hub Port Status [1]           */
    uint32_t RESERVED0[105];             /*!< Offset: 0x005C ~ 0x01FC   Reserved                                  */
    __IO uint32_t MiscCtrl;              /*!< Offset: 0x0200   USB Miscellaneous Control Register                 */
    __IO uint32_t OpModEn;               /*!< Offset: 0x0204   USB Operational Mode Enable Register               */
} USBH_T;

/********************* Bit definition of HcRev register ***********************/
#define USBH_HcRev_Rev_Pos                0                                              /*!<USBH HcRev: Rev Position */
#define USBH_HcRev_Rev_Msk                (1ul << USBH_HcRev_Rev_Pos)                    /*!<USBH HcRev: Rev Mask */

/********************* Bit definition of HcControl register ***********************/
#define USBH_HcControl_CtrlBlkRatio_Pos    0                                             /*!<USBH HcControl: CtrlBlkRatio Position */
#define USBH_HcControl_CtrlBlkRatio_Msk    (3ul << USBH_HcControl_CtrlBlkRatio_Pos)      /*!<USBH HcControl: CtrlBlkRatio Mask     */
#define USBH_HcControl_PeriEn_Pos          2                                             /*!<USBH HcControl: PeriEn Position       */
#define USBH_HcControl_PeriEn_Msk          (1ul << USBH_HcControl_PeriEn_Pos)            /*!<USBH HcControl: PeriEn Mask           */
#define USBH_HcControl_ISOEn_Pos           3                                             /*!<USBH HcControl: ISOEn Position        */
#define USBH_HcControl_ISOEn_Msk           (1ul << USBH_HcControl_ISOEn_Pos)             /*!<USBH HcControl: ISOEn Mask            */
#define USBH_HcControl_CtrlEn_Pos          4                                             /*!<USBH HcControl: CtrlEn Position       */
#define USBH_HcControl_CtrlEn_Msk          (1ul << USBH_HcControl_CtrlEn_Pos)            /*!<USBH HcControl: CtrlEn Mask           */
#define USBH_HcControl_BlkEn_Pos           5                                             /*!<USBH HcControl: BlkEn Position        */
#define USBH_HcControl_BlkEn_Msk           (1ul << USBH_HcControl_BlkEn_Pos)             /*!<USBH HcControl: BlkEn Mask            */
#define USBH_HcControl_HcFunc_Pos          6                                             /*!<USBH HcControl: HcFunc Position       */
#define USBH_HcControl_HcFunc_Msk          (3ul << USBH_HcControl_HcFunc_Pos)            /*!<USBH HcControl: HcFunc Mask           */
#define USBH_HcControl_IntRoute_Pos        8                                             /*!<USBH HcControl: IntRoute Position     */
#define USBH_HcControl_IntRoute_Msk        (1ul << USBH_HcControl_IntRoute_Pos)          /*!<USBH HcControl: IntRoute Mask         */
#define USBH_HcControl_RWake_Pos           9                                             /*!<USBH HcControl: RWake Position        */
#define USBH_HcControl_RWake_Msk           (1ul << USBH_HcControl_RWake_Pos)             /*!<USBH HcControl: RWake Mask            */
#define USBH_HcControl_RWakeEn_Pos         10                                            /*!<USBH HcControl: RWakeEn Position      */
#define USBH_HcControl_RWakeEn_Msk         (1ul << USBH_HcControl_RWakeEn_Pos)           /*!<USBH HcControl: RWakeEn Mask          */

/********************* Bit definition of HcComSts register ********************/
#define USBH_HcComSts_HCReset_Pos          0                                             /*!<USBH HcComSts: HCReset Position    */
#define USBH_HcComSts_HCReset_Msk          (1ul << USBH_HcComSts_HCReset_Pos)            /*!<USBH HcComSts: HCReset Mask        */
#define USBH_HcComSts_CtrlFill_Pos         1                                             /*!<USBH HcComSts: CtrlFill Position   */
#define USBH_HcComSts_CtrlFill_Msk         (1ul << USBH_HcComSts_CtrlFill_Pos)           /*!<USBH HcComSts: CtrlFill Mask       */
#define USBH_HcComSts_BlkFill_Pos          2                                             /*!<USBH HcComSts: BlkFill Position    */
#define USBH_HcComSts_BlkFill_Msk          (1ul << USBH_HcComSts_BlkFill_Pos)            /*!<USBH HcComSts: BlkFill Mask        */
#define USBH_HcComSts_OCReq_Pos            3                                             /*!<USBH HcComSts: OCReq Position      */
#define USBH_HcComSts_OCReq_Msk            (1ul << USBH_HcComSts_OCReq_Pos)              /*!<USBH HcComSts: OCReq Mask          */
#define USBH_HcComSts_SchOverRun_Pos       16                                            /*!<USBH HcComSts: SchOverRun Position */
#define USBH_HcComSts_SchOverRun_Msk       (3ul << USBH_HcComSts_SchOverRun_Pos)         /*!<USBH HcComSts: SchOverRun Mask     */

/********************* Bit definition of HcIntSts register ********************/
#define USBH_HcIntSts_SchOR_Pos            0                                             /*!<USBH HcIntSts: SchOR Position    */
#define USBH_HcIntSts_SchOR_Msk            (1ul << USBH_HcIntSts_SchOR_Pos)              /*!<USBH HcIntSts: SchOR Mask        */
#define USBH_HcIntSts_WBDnHD_Pos           1                                             /*!<USBH HcIntSts: WBDnHD Position   */
#define USBH_HcIntSts_WBDnHD_Msk           (1ul << USBH_HcIntSts_WBDnHD_Pos)             /*!<USBH HcIntSts: WBDnHD Mask       */
#define USBH_HcIntSts_SOF_Pos              2                                             /*!<USBH HcIntSts: SOF Position      */
#define USBH_HcIntSts_SOF_Msk              (1ul << USBH_HcIntSts_SOF_Pos)                /*!<USBH HcIntSts: SOF Mask          */
#define USBH_HcIntSts_Resume_Pos           3                                             /*!<USBH HcIntSts: Resume Position   */
#define USBH_HcIntSts_Resume_Msk           (1ul << USBH_HcIntSts_Resume_Pos)             /*!<USBH HcIntSts: Resume Mask       */
#define USBH_HcIntSts_UnRecErr_Pos         4                                             /*!<USBH HcIntSts: UnRecErr Position */
#define USBH_HcIntSts_UnRecErr_Msk         (1ul << USBH_HcIntSts_UnRecErr_Pos)           /*!<USBH HcIntSts: UnRecErr Mask     */
#define USBH_HcIntSts_FNOF_Pos             5                                             /*!<USBH HcIntSts: FNOF Position     */
#define USBH_HcIntSts_FNOF_Msk             (1ul << USBH_HcIntSts_FNOF_Pos)               /*!<USBH HcIntSts: FNOF Mask         */
#define USBH_HcIntSts_RHSC_Pos             6                                             /*!<USBH HcIntSts: RHSC Position     */
#define USBH_HcIntSts_RHSC_Msk             (1ul << USBH_HcIntSts_RHSC_Pos)               /*!<USBH HcIntSts: RHSC Mask         */
#define USBH_HcIntSts_OC_Pos               30                                            /*!<USBH HcIntSts: OC Position       */
#define USBH_HcIntSts_OC_Msk               (1ul << USBH_HcIntSts_OC_Pos)                 /*!<USBH HcIntSts: OC Mask           */

/********************* Bit definition of HcIntEn register *********************/
#define USBH_HcIntEn_SchOREn_Pos           0                                             /*!<USBH HcIntEn: SchOREn Position */
#define USBH_HcIntEn_SchOREn_Msk           (1ul << USBH_HcIntEn_SchOREn_Pos)             /*!<USBH HcIntEn: SchOREn Mask     */
#define USBH_HcIntEn_WBDHEn_Pos            1                                             /*!<USBH HcIntEn: WBDHEn Position  */
#define USBH_HcIntEn_WBDHEn_Msk            (1ul << USBH_HcIntEn_WBDHEn_Pos)              /*!<USBH HcIntEn: WBDHEn Mask      */
#define USBH_HcIntEn_SOFEn_Pos             2                                             /*!<USBH HcIntEn: SOFEn Position   */
#define USBH_HcIntEn_SOFEn_Msk             (1ul << USBH_HcIntEn_SOFEn_Pos)               /*!<USBH HcIntEn: SOFEn Mask       */
#define USBH_HcIntEn_ResuEn_Pos            3                                             /*!<USBH HcIntEn: ResuEn Position  */
#define USBH_HcIntEn_ResuEn_Msk            (1ul << USBH_HcIntEn_ResuEn_Pos)              /*!<USBH HcIntEn: ResuEn Mask      */
#define USBH_HcIntEn_URErrEn_Pos           4                                             /*!<USBH HcIntEn: URErrEn Position */
#define USBH_HcIntEn_URErrEn_Msk           (1ul << USBH_HcIntEn_URErrEn_Pos)             /*!<USBH HcIntEn: URErrEn Mask     */
#define USBH_HcIntEn_FNOFEn_Pos            5                                             /*!<USBH HcIntEn: FNOFEn Position  */
#define USBH_HcIntEn_FNOFEn_Msk            (1ul << USBH_HcIntEn_FNOFEn_Pos)              /*!<USBH HcIntEn: FNOFEn Mask      */
#define USBH_HcIntEn_RHSCEn_Pos            6                                             /*!<USBH HcIntEn: RHSCEn Position  */
#define USBH_HcIntEn_RHSCEn_Msk            (1ul << USBH_HcIntEn_RHSCEn_Pos)              /*!<USBH HcIntEn: RHSCEn Mask      */
#define USBH_HcIntEn_OCEn_Pos              30                                            /*!<USBH HcIntEn: OCEn Position    */
#define USBH_HcIntEn_OCEn_Msk              (1ul << USBH_HcIntEn_OCEn_Pos)                /*!<USBH HcIntEn: OCEn Mask        */
#define USBH_HcIntEn_IntEn_Pos             31                                            /*!<USBH HcIntEn: IntEn Position   */
#define USBH_HcIntEn_IntEn_Msk             (1ul << USBH_HcIntEn_IntEn_Pos)               /*!<USBH HcIntEn: IntEn Mask       */

/********************* Bit definition of HcIntDis register ********************/
#define USBH_HcIntDis_SchORDis_Pos         0                                             /*!<USBH HcIntDis: SchORDis Position */
#define USBH_HcIntDis_SchORDis_Msk         (1ul << USBH_HcIntDis_SchORDis_Pos)           /*!<USBH HcIntDis: SchORDis Mask     */
#define USBH_HcIntDis_WBDHDis_Pos          1                                             /*!<USBH HcIntDis: WBDHDis Position  */
#define USBH_HcIntDis_WBDHDis_Msk          (1ul << USBH_HcIntDis_WBDHDis_Pos)            /*!<USBH HcIntDis: WBDHDis Mask      */
#define USBH_HcIntDis_SOFDis_Pos           2                                             /*!<USBH HcIntDis: SOFDis Position   */
#define USBH_HcIntDis_SOFDis_Msk           (1ul << USBH_HcIntDis_SOFDis_Pos)             /*!<USBH HcIntDis: SOFDis Mask       */
#define USBH_HcIntDis_ResuDis_Pos          3                                             /*!<USBH HcIntDis: ResuDis Position  */
#define USBH_HcIntDis_ResuDis_Msk          (1ul << USBH_HcIntDis_ResuDis_Pos)            /*!<USBH HcIntDis: ResuDis Mask      */
#define USBH_HcIntDis_URErrDis_Pos         4                                             /*!<USBH HcIntDis: URErrDis Position */
#define USBH_HcIntDis_URErrDis_Msk         (1ul << USBH_HcIntDis_URErrDis_Pos)           /*!<USBH HcIntDis: URErrDis Mask     */
#define USBH_HcIntDis_FNOFDis_Pos          5                                             /*!<USBH HcIntDis: FNOFDis Position  */
#define USBH_HcIntDis_FNOFDis_Msk          (1ul << USBH_HcIntDis_FNOFDis_Pos)            /*!<USBH HcIntDis: FNOFDis Mask      */
#define USBH_HcIntDis_RHSCDis_Pos          6                                             /*!<USBH HcIntDis: RHSCDis Position  */
#define USBH_HcIntDis_RHSCDis_Msk          (1ul << USBH_HcIntDis_RHSCDis_Pos)            /*!<USBH HcIntDis: RHSCDis Mask      */
#define USBH_HcIntDis_OCDis_Pos            30                                            /*!<USBH HcIntDis: OCDis Position    */
#define USBH_HcIntDis_OCDis_Msk            (1ul << USBH_HcIntDis_OCDis_Pos)              /*!<USBH HcIntDis: OCDis Mask        */
#define USBH_HcIntDis_IntDis_Pos           31                                            /*!<USBH HcIntDis: IntDis Position   */
#define USBH_HcIntDis_IntDis_Msk           (1ul << USBH_HcIntDis_IntDis_Pos)             /*!<USBH HcIntDis: IntDis Mask       */

/********************* Bit definition of HcFmIntv register ********************/
#define USBH_HcFmIntv_FmInterval_Pos       0                                             /*!<USBH HcFmIntv: FmInterval Position */
#define USBH_HcFmIntv_FmInterval_Msk       (0x3ffful << USBH_HcFmIntv_FmInterval_Pos)    /*!<USBH HcFmIntv: FmInterval Mask     */
#define USBH_HcFmIntv_FSDPktCnt_Pos        16                                            /*!<USBH HcFmIntv: FSDPktCnt Position  */
#define USBH_HcFmIntv_FSDPktCnt_Msk        (0x7ffful << USBH_HcFmIntv_FSDPktCnt_Pos)     /*!<USBH HcFmIntv: FSDPktCnt Mask      */
#define USBH_HcFmIntv_FmIntvT_Pos          31                                            /*!<USBH HcFmIntv: FmIntvT Position    */
#define USBH_HcFmIntv_FmIntvT_Msk          (1ul << USBH_HcFmIntv_FmIntvT_Pos)            /*!<USBH HcFmIntv: FmIntvT Mask        */

/********************* Bit definition of HcFmRem register *********************/
#define USBH_HcFmRem_FmRemain_Pos          0                                             /*!<USBH HcFmRem: FmRemain Position */
#define USBH_HcFmRem_FmRemain_Msk          (0x3ffful << USBH_HcFmRem_FmRemain_Pos)       /*!<USBH HcFmRem: FmRemain Mask     */
#define USBH_HcFmRem_FmRemT_Pos            31                                            /*!<USBH HcFmRem: FmRemT Position   */
#define USBH_HcFmRem_FmRemT_Msk            (1ul << USBH_HcFmRem_FmRemT_Pos)              /*!<USBH HcFmRem: FmRemT Mask       */

/********************* Bit definition of HcFmRem register *********************/
#define USBH_HcFNum_FmNum_Pos              0                                             /*!<USBH HcFNum: FmNum Position */
#define USBH_HcFNum_FmNum_Msk              (0xfffful << USBH_HcFNum_FmNum_Pos)           /*!<USBH HcFNum: FmNum Mask     */

/********************* Bit definition of HcPerSt register *********************/
#define USBH_HcPerSt_PeriStart_Pos         0                                             /*!<USBH HcPerSt: PeriStart Position */
#define USBH_HcPerSt_PeriStart_Msk         (0x3ffful << USBH_HcPerSt_PeriStart_Pos)      /*!<USBH HcPerSt: PeriStart Mask     */

/********************* Bit definition of HcLSTH register **********************/
#define USBH_HcLSTH_LST_Pos                0                                             /*!<USBH HcLSTH: LST Position */
#define USBH_HcLSTH_LST_Msk                (0xffful << USBH_HcLSTH_LST_Pos)              /*!<USBH HcLSTH: LST Mask     */

/********************* Bit definition of HcRhDeA register *********************/
#define USBH_HcRhDeA_DPortNum_Pos          0                                             /*!<USBH HcRhDeA: DPortNum Position */
#define USBH_HcRhDeA_DPortNum_Msk          (0xfful << USBH_HcRhDeA_DPortNum_Pos)         /*!<USBH HcRhDeA: DPortNum Mask     */
#define USBH_HcRhDeA_PSM_Pos               8                                             /*!<USBH HcRhDeA: PSM Position      */
#define USBH_HcRhDeA_PSM_Msk               (1ul << USBH_HcRhDeA_PSM_Pos)                 /*!<USBH HcRhDeA: PSM Mask          */
#define USBH_HcRhDeA_NPS_Pos               9                                             /*!<USBH HcRhDeA: NPS Position      */
#define USBH_HcRhDeA_NPS_Msk               (1ul << USBH_HcRhDeA_NPS_Pos)                 /*!<USBH HcRhDeA: NPS Mask          */
#define USBH_HcRhDeA_DevType_Pos           10                                            /*!<USBH HcRhDeA: DevType Position  */
#define USBH_HcRhDeA_DevType_Msk           (1ul << USBH_HcRhDeA_DevType_Pos)             /*!<USBH HcRhDeA: DevType Mask      */
#define USBH_HcRhDeA_OCPM_Pos              11                                            /*!<USBH HcRhDeA: OCPM Position     */
#define USBH_HcRhDeA_OCPM_Msk              (1ul << USBH_HcRhDeA_OCPM_Pos)                /*!<USBH HcRhDeA: OCPM Mask         */
#define USBH_HcRhDeA_NOCP_Pos              12                                            /*!<USBH HcRhDeA: NOCP Position     */
#define USBH_HcRhDeA_NOCP_Msk              (1ul << USBH_HcRhDeA_NOCP_Pos)                /*!<USBH HcRhDeA: NOCP Mask         */
#define USBH_HcRhDeA_PwrGDT_Pos            24                                            /*!<USBH HcRhDeA: PwrGDT Position   */
#define USBH_HcRhDeA_PwrGDT_Msk            (0xfful << USBH_HcRhDeA_PwrGDT_Pos)           /*!<USBH HcRhDeA: PwrGDT Mask       */

/********************* Bit definition of HcRhDeB register *********************/
#define USBH_HcRhDeB_DevRemove_Pos         0                                             /*!<USBH HcRhDeB: DevRemove Position */
#define USBH_HcRhDeB_DevRemove_Msk         (0xfffful << USBH_HcRhDeB_DevRemove_Pos)      /*!<USBH HcRhDeB: DevRemove Mask     */
#define USBH_HcRhDeB_PPCM_Pos              16                                            /*!<USBH HcRhDeB: PPCM Position      */
#define USBH_HcRhDeB_PPCM_Msk              (0xfffful << USBH_HcRhDeB_PPCM_Pos)           /*!<USBH HcRhDeB: PPCM Mask          */

/********************* Bit definition of HcRhSts register *********************/
#define USBH_HcRhSts_LPS_Pos               0                                             /*!<USBH HcRhSts: LPS Position    */
#define USBH_HcRhSts_LPS_Msk               (1ul << USBH_HcRhSts_LPS_Pos)                 /*!<USBH HcRhSts: LPS Mask        */
#define USBH_HcRhSts_OC_Pos                1                                             /*!<USBH HcRhSts: OC Position     */
#define USBH_HcRhSts_OC_Msk                (1ul << USBH_HcRhSts_OC_Pos)                  /*!<USBH HcRhSts: OC Mask         */
#define USBH_HcRhSts_DRWEn_Pos             15                                            /*!<USBH HcRhSts: DRWEn Position  */
#define USBH_HcRhSts_DRWEn_Msk             (1ul << USBH_HcRhSts_DRWEn_Pos)               /*!<USBH HcRhSts: DRWEn Mask      */
#define USBH_HcRhSts_LPSC_Pos              16                                            /*!<USBH HcRhSts: LPSC Position   */
#define USBH_HcRhSts_LPSC_Msk              (1ul << USBH_HcRhSts_LPSC_Pos)                /*!<USBH HcRhSts: LPSC Mask       */
#define USBH_HcRhSts_OCIC_Pos              17                                            /*!<USBH HcRhSts: OCIC Position   */
#define USBH_HcRhSts_OCIC_Msk              (1ul << USBH_HcRhSts_OCIC_Pos)                /*!<USBH HcRhSts: OCIC Mask       */
#define USBH_HcRhSts_RWEClr_Pos            31                                            /*!<USBH HcRhSts: RWEClr Position */
#define USBH_HcRhSts_RWEClr_Msk            (1ul << USBH_HcRhSts_RWEClr_Pos)              /*!<USBH HcRhSts: RWEClr Mask     */

/********************* Bit definition of HcRhPrt1/2 register*******************/
#define USBH_HcRhPrt_CC_Pos                0                                             /*!<USBH HcRhPrt: CC Position    */
#define USBH_HcRhPrt_CC_Msk                (1ul << USBH_HcRhSts_CC_Pos)                  /*!<USBH HcRhPrt: CC Mask        */
#define USBH_HcRhPrt_PE_Pos                1                                             /*!<USBH HcRhPrt: PE Position    */
#define USBH_HcRhPrt_PE_Msk                (1ul << USBH_HcRhSts_PE_Pos)                  /*!<USBH HcRhPrt: PE Mask        */
#define USBH_HcRhPrt_PS_Pos                2                                             /*!<USBH HcRhPrt: PS Position    */
#define USBH_HcRhPrt_PS_Msk                (1ul << USBH_HcRhSts_PS_Pos)                  /*!<USBH HcRhPrt: PS Mask        */
#define USBH_HcRhPrt_POC_Pos               3                                             /*!<USBH HcRhPrt: POC Position   */
#define USBH_HcRhPrt_POC_Msk               (1ul << USBH_HcRhSts_POC_Pos)                 /*!<USBH HcRhPrt: POC Mask       */
#define USBH_HcRhPrt_PR_Pos                4                                             /*!<USBH HcRhPrt: PR Position    */
#define USBH_HcRhPrt_PR_Msk                (1ul << USBH_HcRhSts_PR_Pos)                  /*!<USBH HcRhPrt: PR Mask        */
#define USBH_HcRhPrt_PPS_Pos               8                                             /*!<USBH HcRhPrt: PPS Position   */
#define USBH_HcRhPrt_PPS_Msk               (1ul << USBH_HcRhSts_PPS_Pos)                 /*!<USBH HcRhPrt: PPS Mask       */
#define USBH_HcRhPrt_LSDev_Pos             9                                             /*!<USBH HcRhPrt: LSDev Position */
#define USBH_HcRhPrt_LSDev_Msk             (1ul << USBH_HcRhSts_LSDev_Pos)               /*!<USBH HcRhPrt: LSDev Mask     */
#define USBH_HcRhPrt_CSC_Pos               16                                            /*!<USBH HcRhPrt: CSC Position   */
#define USBH_HcRhPrt_CSC_Msk               (1ul << USBH_HcRhSts_CSC_Pos)                 /*!<USBH HcRhPrt: CSC Mask       */
#define USBH_HcRhPrt_PESC_Pos              17                                            /*!<USBH HcRhPrt: PESC Position  */
#define USBH_HcRhPrt_PESC_Msk              (1ul << USBH_HcRhSts_PESC_Pos)                /*!<USBH HcRhPrt: PESC Mask      */
#define USBH_HcRhPrt_PSSC_Pos              18                                            /*!<USBH HcRhPrt: PSSC Position  */
#define USBH_HcRhPrt_PSSC_Msk              (1ul << USBH_HcRhSts_PSSC_Pos)                /*!<USBH HcRhPrt: PSSC Mask      */
#define USBH_HcRhPrt_POCIC_Pos             19                                            /*!<USBH HcRhPrt: POCIC Position */
#define USBH_HcRhPrt_POCIC_Msk             (1ul << USBH_HcRhSts_POCIC_Pos)               /*!<USBH HcRhPrt: POCIC Mask     */
#define USBH_HcRhPrt_PRSC_Pos              20                                            /*!<USBH HcRhPrt: PRSC Position  */
#define USBH_HcRhPrt_PRSC_Msk              (1ul << USBH_HcRhSts_PRSC_Pos)                /*!<USBH HcRhPrt: PRSC Mask      */

/********************* Bit definition of MiscCtrl register*********************/
#define USBH_MiscCtrl_StbyEn_Pos           27                                            /*!<USBH MiscCtrl: StbyEn Position */
#define USBH_MiscCtrl_StbyEn_Msk           (1ul << USBH_MiscCtrl_StbyEn_Pos)             /*!<USBH MiscCtrl: StbyEn Mask     */

/********************* Bit definition of OpModEn register**********************/
#define USBH_OpModEn_DBR16_Pos             0                                             /*!<USBH OpModEn: DBR16 Position   */
#define USBH_OpModEn_DBR16_Msk             (1ul << USBH_OpModEn_DBR16_Pos)               /*!<USBH OpModEn: DBR16 Mask       */
#define USBH_OpModEn_ABORT_Pos             1                                             /*!<USBH OpModEn: ABORT Position   */
#define USBH_OpModEn_ABORT_Msk             (1ul << USBH_OpModEn_ABORT_Msk)               /*!<USBH OpModEn: ABORT Mask       */
#define USBH_OpModEn_OCALow_Pos            3                                             /*!<USBH OpModEn: OCALow Position  */
#define USBH_OpModEn_OCALow_Msk            (1ul << USBH_OpModEn_OCALow_Pos)              /*!<USBH OpModEn: OCALow Mask      */
#define USBH_OpModEn_PPCLow_Pos            4                                             /*!<USBH OpModEn: PPCLow Position  */
#define USBH_OpModEn_PPCLow_Msk            (1ul << USBH_OpModEn_PPCLow_Pos)              /*!<USBH OpModEn: PPCLow Mask      */
#define USBH_OpModEn_SIEPDis_Pos           8                                             /*!<USBH OpModEn: SIEPDis Position */
#define USBH_OpModEn_SIEPDis_Msk           (1ul << USBH_OpModEn_SIEPDis_Pos)             /*!<USBH OpModEn: SIEPDis Mask     */
#define USBH_OpModEn_DisPrt1_Pos           16                                            /*!<USBH OpModEn: DisPrt1 Position */
#define USBH_OpModEn_DisPrt1_Msk           (1ul << USBH_OpModEn_DisPrt1_Pos)             /*!<USBH OpModEn: DisPrt1 Mask     */
#define USBH_OpModEn_DisPrt2_Pos           17                                            /*!<USBH OpModEn: DisPrt2 Position */
#define USBH_OpModEn_DisPrt2_Msk           (1ul << USBH_OpModEn_DisPrt2_Pos)             /*!<USBH OpModEn: DisPrt2 Mask     */

/*@}*/ /* end of group M451_USBH */


/*---------------------- Window Watchdog Timer -------------------------*/
/**
    @addtogroup WWDT Window Watchdog Timer(WWDT)
    Memory Mapped Structure for WWDT Controller
@{ */
 
typedef struct
{

    __O  uint32_t RLDCNT;                /*!< [0x0000] WWDT Reload Counter Register                                     */
    __IO uint32_t CTL;                   /*!< [0x0004] WWDT Control Register                                            */
    __IO uint32_t STATUS;                /*!< [0x0008] WWDT Status Register                                             */
    __I  uint32_t CNT;                   /*!< [0x000c] WWDT Counter Value Register                                      */

} WWDT_T;

/**
    @addtogroup WWDT_CONST WWDT Bit Field Definition
    Constant Definitions for WWDT Controller
@{ */

#define WWDT_RLDCNT_RLDCNT_Pos           (0)
#define WWDT_RLDCNT_RLDCNT_Msk           (0xfffffffful << WWDT_RLDCNT_RLDCNT_Pos)

#define WWDT_CTL_WWDTEN_Pos              (0)
#define WWDT_CTL_WWDTEN_Msk              (0x1ul << WWDT_CTL_WWDTEN_Pos)

#define WWDT_CTL_INTEN_Pos               (1)
#define WWDT_CTL_INTEN_Msk               (0x1ul << WWDT_CTL_INTEN_Pos)

#define WWDT_CTL_PSCSEL_Pos              (8)
#define WWDT_CTL_PSCSEL_Msk              (0xful << WWDT_CTL_PSCSEL_Pos)

#define WWDT_CTL_CMPDAT_Pos              (16)
#define WWDT_CTL_CMPDAT_Msk              (0x3ful << WWDT_CTL_CMPDAT_Pos)

#define WWDT_CTL_ICEDEBUG_Pos            (31)
#define WWDT_CTL_ICEDEBUG_Msk            (0x1ul << WWDT_CTL_ICEDEBUG_Pos)

#define WWDT_STATUS_WWDTIF_Pos           (0)
#define WWDT_STATUS_WWDTIF_Msk           (0x1ul << WWDT_STATUS_WWDTIF_Pos)

#define WWDT_STATUS_WWDTRF_Pos           (1)
#define WWDT_STATUS_WWDTRF_Msk           (0x1ul << WWDT_STATUS_WWDTRF_Pos)

#define WWDT_CNT_CNTDAT_Pos              (0)
#define WWDT_CNT_CNTDAT_Msk              (0x3ful << WWDT_CNT_CNTDAT_Pos)

/**@}*/ /* WWDT_CONST */
/**@}*/ /* end of WWDT register group */


/**@}*/ /* end of REGISTER group */


/******************************************************************************/
/*                         Peripheral memory map                              */
/******************************************************************************/
/** @addtogroup M451_MemoryMap M451 Memory Mapping
  @{
*/

/* Peripheral and SRAM base address */
#define SRAM_BASE            (0x20000000UL)                              /*!< (SRAM      ) Base Address */
#define PERIPH_BASE          (0x40000000UL)                              /*!< (Peripheral) Base Address */


/* Peripheral memory map */
#define AHBPERIPH_BASE       PERIPH_BASE
#define APBPERIPH_BASE       (PERIPH_BASE + 0x00040000)

/*!< AHB peripherals */
#define GCR_BASE             (AHBPERIPH_BASE + 0x00000)
#define CLK_BASE             (AHBPERIPH_BASE + 0x00200)
#define INT_BASE             (AHBPERIPH_BASE + 0x00300)
#define GPIO_BASE            (AHBPERIPH_BASE + 0x04000)
#define GPIOA_BASE           (AHBPERIPH_BASE + 0x04000)
#define GPIOB_BASE           (AHBPERIPH_BASE + 0x04040)
#define GPIOC_BASE           (AHBPERIPH_BASE + 0x04080)
#define GPIOD_BASE           (AHBPERIPH_BASE + 0x040C0)
#define GPIOE_BASE           (AHBPERIPH_BASE + 0x04100)
#define GPIOF_BASE           (AHBPERIPH_BASE + 0x04140)
#define GPIO_DBCTL_BASE      (AHBPERIPH_BASE + 0x04440)
#define GPIO_PIN_DATA_BASE   (AHBPERIPH_BASE + 0x04800)
#define PDMA_BASE            (AHBPERIPH_BASE + 0x08000)
#define USBH_BASE            (AHBPERIPH_BASE + 0x09000)
#define FMC_BASE             (AHBPERIPH_BASE + 0x0C000)
#define EBI_BASE             (AHBPERIPH_BASE + 0x10000)
#define CRC_BASE             (AHBPERIPH_BASE + 0x31000)

/*!< APB0 peripherals */
#define WDT_BASE             (APBPERIPH_BASE + 0x00000)
#define WWDT_BASE            (APBPERIPH_BASE + 0x00100)
#define TMR01_BASE           (APBPERIPH_BASE + 0x10000)
#define PWM0_BASE            (APBPERIPH_BASE + 0x18000)
#define SPI0_BASE            (APBPERIPH_BASE + 0x20000)
#define SPI2_BASE            (APBPERIPH_BASE + 0x22000)
#define UART0_BASE           (APBPERIPH_BASE + 0x30000)
#define UART2_BASE           (APBPERIPH_BASE + 0x32000)
#define I2C0_BASE            (APBPERIPH_BASE + 0x40000)
#define SC0_BASE             (APBPERIPH_BASE + 0x50000)
#define CAN0_BASE            (APBPERIPH_BASE + 0x60000)
#define USBD_BASE            (APBPERIPH_BASE + 0x80000)
#define TK_BASE              (APBPERIPH_BASE + 0xA2000)
   
/*!< APB1 peripherals */
#define RTC_BASE             (APBPERIPH_BASE + 0x01000)
#define ADC0_BASE            (APBPERIPH_BASE + 0x03000)
#define EADC0_BASE	         (APBPERIPH_BASE + 0x03000)
#define ACMP01_BASE          (APBPERIPH_BASE + 0x05000)
#define DAC_BASE             (APBPERIPH_BASE + 0x07000)
#define OTG_BASE             (APBPERIPH_BASE + 0x0D000)
#define TMR23_BASE           (APBPERIPH_BASE + 0x11000)
#define PWM1_BASE            (APBPERIPH_BASE + 0x19000)
#define SPI1_BASE            (APBPERIPH_BASE + 0x21000)
#define UART1_BASE           (APBPERIPH_BASE + 0x31000)
#define UART3_BASE           (APBPERIPH_BASE + 0x33000)
#define I2C1_BASE            (APBPERIPH_BASE + 0x41000)
/*@}*/ /* end of group M451_MemoryMap */


/******************************************************************************/
/*                         Peripheral declaration                             */
/******************************************************************************/
/** @addtogroup M451_PeripheralDecl M451 Peripheral Declaration
  @{
*/


#define SYS                  ((GCR_T *)   GCR_BASE)
#define CLK                  ((CLK_T *)   CLK_BASE)
#define PA                   ((GPIO_T *)  GPIOA_BASE)
#define PB                   ((GPIO_T *)  GPIOB_BASE)
#define PC                   ((GPIO_T *)  GPIOC_BASE)
#define PD                   ((GPIO_T *)  GPIOD_BASE)
#define PE                   ((GPIO_T *)  GPIOE_BASE)
#define PF                   ((GPIO_T *)  GPIOF_BASE)
#define GPIO                 ((GPIO_DBCTL_T *) GPIO_DBCTL_BASE) 
#define PDMA                 ((PDMA_T *)  PDMA_BASE)
#define USBH                 ((USBH_T *)  USBH_BASE)
#define FMC                  ((FMC_T *)   FMC_BASE)
#define EBI                  ((EBI_T *)   EBI_BASE)
#define CRC                  ((CRC_T *)   CRC_BASE)

#define WDT                  ((WDT_T *)   WDT_BASE) 
#define WWDT                 ((WWDT_T *)  WWDT_BASE) 
#define RTC                  ((RTC_T *)   RTC_BASE) 
//#define ADC                  ((ADC_T *)   ADC0_BASE) 
#define EADC                  ((EADC_T *)   EADC0_BASE) 
#define ACMP01               ((ACMP_T *)  ACMP01_BASE)

#define USBD                 ((USBD_T *)  USBD_BASE)
#define OTG                  ((OTG_T *)   OTG_BASE)
#define TIMER0               ((TIMER_T *) TMR01_BASE) 
#define TIMER1               ((TIMER_T *) (TMR01_BASE + 0x20)) 
#define TIMER2               ((TIMER_T *) TMR23_BASE) 
#define TIMER3               ((TIMER_T *) (TMR23_BASE+ 0x20)) 
#define PWM0                 ((PWM_T *)   PWM0_BASE) 
#define PWM1                 ((PWM_T *)   PWM1_BASE) 
#define DAC	             	 ((DAC_T *)   DAC_BASE) 
#define SPI0                 ((SPI_T *)   SPI0_BASE) 
#define SPI1                 ((SPI_T *)   SPI1_BASE) 
#define SPI2                 ((SPI_T *)   SPI2_BASE) 
#define UART0                ((UART_T *)  UART0_BASE) 
#define UART1                ((UART_T *)  UART1_BASE)
#define UART2                ((UART_T *)  UART2_BASE)
#define UART3                ((UART_T *)  UART3_BASE)
#define I2C0                 ((I2C_T *)   I2C0_BASE)
#define I2C1                 ((I2C_T *)   I2C1_BASE)
#define SC0                  ((SC_T *)    SC0_BASE)
#define CAN0                 ((CAN_T *)   CAN0_BASE)

/* One Bit Mask Definitions */
#define BIT0    0x00000001
#define BIT1    0x00000002
#define BIT2    0x00000004
#define BIT3    0x00000008
#define BIT4    0x00000010
#define BIT5    0x00000020
#define BIT6    0x00000040
#define BIT7    0x00000080
#define BIT8    0x00000100
#define BIT9    0x00000200
#define BIT10   0x00000400
#define BIT11   0x00000800
#define BIT12   0x00001000
#define BIT13   0x00002000
#define BIT14   0x00004000
#define BIT15   0x00008000
#define BIT16   0x00010000
#define BIT17   0x00020000
#define BIT18   0x00040000
#define BIT19   0x00080000
#define BIT20   0x00100000
#define BIT21   0x00200000
#define BIT22   0x00400000
#define BIT23   0x00800000
#define BIT24   0x01000000
#define BIT25   0x02000000
#define BIT26   0x04000000
#define BIT27   0x08000000
#define BIT28   0x10000000
#define BIT29   0x20000000
#define BIT30   0x40000000
#define BIT31   0x80000000

/* Byte Mask Definitions */
#define BYTE0_Msk               (0x000000FF)
#define BYTE1_Msk               (0x0000FF00)
#define BYTE2_Msk               (0x00FF0000)
#define BYTE3_Msk               (0xFF000000)

#define _GET_BYTE0(u32Param)    (((u32Param) & BYTE0_Msk)      )  /*!< Extract Byte 0 (Bit  0~ 7) from parameter u32Param */
#define _GET_BYTE1(u32Param)    (((u32Param) & BYTE1_Msk) >>  8)  /*!< Extract Byte 1 (Bit  8~15) from parameter u32Param */
#define _GET_BYTE2(u32Param)    (((u32Param) & BYTE2_Msk) >> 16)  /*!< Extract Byte 2 (Bit 16~23) from parameter u32Param */
#define _GET_BYTE3(u32Param)    (((u32Param) & BYTE3_Msk) >> 24)  /*!< Extract Byte 3 (Bit 24~31) from parameter u32Param */

#ifndef TRUE
# define TRUE 1
#endif
#ifndef FALSE
# define FALSE 0
#endif


#include "sys.h"
#include "clk.h"
#include "gpio.h"
//#include "i2c.h"
//#include "crc.h"
//#include "ebi.h"
//#include "rtc.h"
//#include "timer.h"
// #include "wdt.h"
// #include "wwdt.h"
// #include "spi.h"
// #include "acmp.h"
// #include "eadc.h"
// #include "dac.h"
// #include "can.h"
#include "usbd.h"
#include "fmc.h"
#include "uart.h"
// #include "pwm.h"
// #include "pdma.h"

typedef volatile unsigned char  vu8;
typedef volatile unsigned long  vu32;
typedef volatile unsigned short vu16;
#define M8(adr)  (*((vu8  *) (adr)))
#define M16(adr) (*((vu16 *) (adr)))
#define M32(adr) (*((vu32 *) (adr)))

#define outpw(port,value)   (*((volatile unsigned int *)(port))=(value))
#define inpw(port)          (*((volatile unsigned int *)(port)))
#define outpb(port,value)   (*((volatile unsigned char *)(port))=(value))
#define inpb(port)          (*((volatile unsigned char *)(port)))
#define outps(port,value)   (*((volatile unsigned short *)(port))=(value))
#define inps(port)          (*((volatile unsigned short *)(port)))

#define outp32(port,value)  (*((volatile unsigned int *)(port))=(value))
#define inp32(port)         (*((volatile unsigned int *)(port)))
#define outp8(port,value)   (*((volatile unsigned char *)(port))=(value))
#define inp8(port)          (*((volatile unsigned char *)(port)))
#define outp16(port,value)  (*((volatile unsigned short *)(port))=(value))
#define inp16(port)         (*((volatile unsigned short *)(port)))

/*@}*/ /* end of group M451_PeripheralDecl */


/******************************************************************************/
/*                Device Specific Constants                                   */
/******************************************************************************/
/** @addtogroup M451_Exported_Constants M451 Exported Constants
  M451 Device Specific Constantss
  @{
*/

/*@}*/ /* end of group M451_Exported_Constants */


/******************************************************************************/
/*                Device Specific Macros                                      */
/******************************************************************************/
/** @addtogroup M451_Exported_Macros M451 Exported Macros
  M451 Device Specific Macros
  @{
*/


/*@}*/ /* end of group M451_Exported_Macros */

/*@}*/ /* end of group M451_Definitions */

#ifdef __cplusplus
}
#endif

#endif  /* __M451SERIES_H__ */

/*** (C) COPYRIGHT 2013 Nuvoton Technology Corp. ***/

