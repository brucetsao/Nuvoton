/******************************************************************************
 * @file     DAC.h
 * @version  V0.10
 * $Revision: 1 $
 * $Date: 14/09/09 4:38p $ 
 * @brief    M451 series DAC driver header file
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/ 
#ifndef __DAC_H__
#define __DAC_H__

/*---------------------------------------------------------------------------------------------------------*/
/* Include related headers                                                                                 */
/*---------------------------------------------------------------------------------------------------------*/
#include "M451Series.h"


#ifdef __cplusplus
extern "C"
{
#endif


/** @addtogroup M451_Device_Driver M451 Device Driver
  @{
*/

/** @addtogroup M451_DAC_Driver DAC Driver
  @{
*/


/** @addtogroup M451_DAC_EXPORTED_CONSTANTS DAC Exported Constants
  @{
*/

/*---------------------------------------------------------------------------------------------------------*/
/*  DAC_CTL Constant Definitions                                                                            */
/*---------------------------------------------------------------------------------------------------------*/
#define DAC_CTL_TRGSEL_SOFTWARE_TRIGGER   (0UL<<DAC_CTL_TRGSEL_Pos)   /*!< Software trigger */
#define DAC_CTL_TRGSEL_STADC_TRIGGER      (1UL<<DAC_CTL_TRGSEL_Pos)   /*!< External pin STDAC trigger */
#define DAC_CTL_TRGSEL_TIMER0_TRIGGER     (2UL<<DAC_CTL_TRGSEL_Pos)   /*!< Timer 0 trigger */
#define DAC_CTL_TRGSEL_TIMER1_TRIGGER     (3UL<<DAC_CTL_TRGSEL_Pos)   /*!< Timer 1 trigger */
#define DAC_CTL_TRGSEL_TIMER2_TRIGGER     (4UL<<DAC_CTL_TRGSEL_Pos)   /*!< Timer 2 trigger */
#define DAC_CTL_TRGSEL_TIMER3_TRIGGER     (5UL<<DAC_CTL_TRGSEL_Pos)   /*!< Timer 3 trigger */
#define DAC_CTL_TRGSEL_PWM0_TRIGGER       (6UL<<DAC_CTL_TRGSEL_Pos)   /*!< PWM0 trigger */
#define DAC_CTL_TRGSEL_PWM1_TRIGGER       (7UL<<DAC_CTL_TRGSEL_Pos)   /*!< PWM1 trigger */

#define DAC_CTL_TENBITEN_12BIT_MODE    (0UL<<DAC_CTL_TENBITEN_Pos)   /*!< 12 bit mode */
#define DAC_CTL_TENBITEN_10BIT_MODE    (1UL<<DAC_CTL_TENBITEN_Pos)   /*!< 10 bit mode */

#define DAC_CTL_LALIGN_RIGHT_ALIGNED   (0UL<<DAC_CTL_LALIGN_Pos)   /*!< Right alignment. */
#define DAC_CTL_LALIGN_LEFT_ALIGNED    (1UL<<DAC_CTL_LALIGN_Pos)   /*!< Left alignment */

#define DAC_CTL_ETRGSEL_LOW_LEVEL     (0UL<<DAC_CTL_LALIGN_Pos)   /*!< Low level trigger */
#define DAC_CTL_ETRGSEL_HIGH_LEVEL    (1UL<<DAC_CTL_LALIGN_Pos)   /*!< High level trigger */
#define DAC_CTL_ETRGSEL_RISIG_EDGE    (2UL<<DAC_CTL_LALIGN_Pos)   /*!< Rising edge trigger */
#define DAC_CTL_ETRGSEL_FALLING_EDGE  (3UL<<DAC_CTL_LALIGN_Pos)   /*!< Falling edge trigger */


/*@}*/ /* end of group M451_DAC_EXPORTED_CONSTANTS */


/*---------------------------------------------------------------------------------------------------------*/
/*  DAC Macro Definitions                                                                                  */
/*---------------------------------------------------------------------------------------------------------*/


/*@}*/ /* end of group M451_DAC_EXPORTED_FUNCTIONS */

/*@}*/ /* end of group M451_DAC_Driver */

/*@}*/ /* end of group M451_Device_Driver */

#ifdef __cplusplus
}
#endif

#endif //__DAC_H__

/*** (C) COPYRIGHT 2013 Nuvoton Technology Corp. ***/
