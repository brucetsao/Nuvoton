/**************************************************************************//**
 * @file     FMC.h
 * @version  V2.1
 * $Revision: 1 $
 * $Date: 14/09/09 4:38p $
 * @brief    M451 Series Flash Memory Controller Driver Header File
 *
 * @note
 * Copyright (C) 2011 Nuvoton Technology Corp. All rights reserved.
 *
 ******************************************************************************/
//#define	__FMC_H__

#ifndef __FMC_H__
#define __FMC_H__

#include "M451Series.h"

#define ISBEN   1

/*---------------------------------------------------------------------------------------------------------*/
/* Define Base Address                                                                                     */
/*---------------------------------------------------------------------------------------------------------*/
#define FMC_APROM_BASE          0x00000000UL    /*!< APROM  Base Address         */  
#define FMC_LDROM_BASE          0x00100000UL    /*!< LDROM  Base Address         */
#define FMC_SPROM_BASE          0x00200000UL    /*!< SPROM  Base Address         */
#define FMC_CONFIG_BASE         0x00300000UL    /*!< CONFIG Base Address         */

#define FMC_CONFIG0_ADDR        (FMC_CONFIG_BASE)       /*!< CONFIG 0 Address */
#define FMC_CONFIG1_ADDR        (FMC_CONFIG_BASE + 4)   /*!< CONFIG 1 Address */


#define FMC_FLASH_PAGE_SIZE     0x800           /*!< Flash Page Size (512 Bytes) */
#define FMC_LDROM_SIZE          0x1000          /*!< LDROM Size (4 kBytes)       */

/*---------------------------------------------------------------------------------------------------------*/
/*  ISPCON constant definitions                                                                            */
/*---------------------------------------------------------------------------------------------------------*/
#define FMC_ISPCON_BS_LDROM     0x2     /*!< ISPCON setting to select to boot from LDROM */
#define FMC_ISPCON_BS_APROM     0x0     /*!< ISPCON setting to select to boot from APROM */

/*---------------------------------------------------------------------------------------------------------*/
/*  ISPCMD constant definitions                                                                            */
/*---------------------------------------------------------------------------------------------------------*/
#define FMC_ISPCMD_READ        0x00     /*!< ISP Command: Read Flash         */
#define FMC_ISPCMD_READ_8      0x40
#define FMC_ISPCMD_READ_E      0x0A
#define FMC_ISPCMD_READ_P      0x09
#define FMC_ISPCMD_PROGRAM     0x21     /*!< ISP Command: Program Flash      */
#define FMC_ISPCMD_WRITE_8    0x61
#define FMC_ISPCMD_PAGE_ERASE  0x22     /*!< ISP Command: Page Erase Flash   */
#define FMC_ISPCMD_ENTER_SK    0x28
#define FMC_ISPCMD_READ_CID    0x0B
#define FMC_ISPCMD_READ_UID    0x04     /*!< ISP Command: Read Unique ID     */
#define FMC_ISPCMD_READ_UID    0x04     /*!< ISP Command: Read Unique ID     */
#define FMC_ISPCMD_VECMAP      0x2e     /*!< ISP Command: Set vector mapping */
#define FMC_ISPCMD_CHECKSUM    0x0d
#define FMC_ISPCMD_CAL_CHECKSUM 0x2d
#define FMC_ISPCMD_MULTI_PROG   0x27



/*---------------------------------------------------------------------------------------------------------*/
/*  FMC Macro Definitions                                                                                  */
/*---------------------------------------------------------------------------------------------------------*/
#define _FMC_ENABLE_ISP()          (FMC->ISPCON |=  FMC_ISPCON_ISPEN_Msk)  /*!< Enable ISP Function  */
#define _FMC_DISABLE_ISP()         (FMC->ISPCON &= ~FMC_ISPCON_ISPEN_Msk)  /*!< Disable ISP Function */
#define _FMC_ENABLE_LD_UPDATE()    (FMC->ISPCON |=  FMC_ISPCON_LDUEN_Msk)  /*!< Enable LDROM Update Function   */
#define _FMC_DISABLE_LD_UPDATE()   (FMC->ISPCON &= ~FMC_ISPCON_LDUEN_Msk)  /*!< Disable LDROM Update Function  */
//#define _FMC_ENABLE_CFG_UPDATE()   (FMC->ISPCON |=  FMC_ISPCON_CFGUEN_Msk) /*!< Enable CONFIG Update Function  */
//#define _FMC_DISABLE_CFG_UPDATE()  (FMC->ISPCON &= ~FMC_ISPCON_CFGUEN_Msk) /*!< Disable CONFIG Update Function */
#define _FMC_ENABLE_AP_UPDATE()    (FMC->ISPCON |=  FMC_ISPCON_APUEN_Msk)  /*!< Enable APROM Update Function   */
#define _FMC_DISABLE_AP_UPDATE()   (FMC->ISPCON &= ~FMC_ISPCON_APUEN_Msk)  /*!< Disable APROM Update Function  */
#define _FMC_ENABLE_LOW_FREQ_OPTIMIZE_MODE()  (FMC->FATCON |=  FMC_FATCON_LFOM_Msk) /*!< Enable Flash Access Low Frequency Optimization Mode when HCLK <= 25MHz */
#define _FMC_DISABLE_LOW_FREQ_OPTIMIZE_MODE() (FMC->FATCON &= ~FMC_FATCON_LFOM_Msk) /*!< Disable Flash Access Low Frequency Optimization Mode */

#define _FMC_SELECT_NEXT_BOOT(x)   (FMC->ISPCON = (FMC->ISPCON & ~FMC_ISPCON_BS_Msk) | (x << FMC_ISPCON_BS_Pos)) /*!< Select Next Booting, x = 0 or 1 */
#define _FMC_GET_BOOT_STATUS()     ((FMC->ISPCON & FMC_ISPCON_BS_Msk)?1:0) /*!< Get MCU Booting Status */



/*---------------------------------------------------------------------------------------------------------*/
/* inline functions                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
/**
 * @brief      Program 32-bit data into specified address of flash
 * 
 * @param[in]  u32addr  Flash address include APROM, LDROM, Data Flash, and CONFIG
 * @param[in]  u32data  32-bit Data to program
 *
 * @details    To program word data into Flash include APROM, LDROM, Data Flash, and CONFIG.
 *             The corresponding functions in CONFIG are listed in FMC section of TRM.
 *
 * @note   
 *             Please make sure that Register Write-Protection Function has been disabled 
 *             before using this function. User can check the status of 
 *             Register Write-Protection Function with DrvSYS_IsProtectedRegLocked().
 */
 
#if(0) 
static __INLINE void FMC_Write(uint32_t u32Addr, uint32_t u32Data)
{
    FMC->ISPCMD = FMC_ISPCMD_PROGRAM;
    FMC->ISPADDR = u32Addr;
    FMC->ISPDAT = u32Data;
    FMC->ISPTRG = 0x1;  
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
}
#endif

static __INLINE void FMC_Write8(uint32_t u32Addr, uint32_t u32Data0, uint32_t u32Data1)
{
    FMC->ISPCMD = FMC_ISPCMD_WRITE_8;
    FMC->ISPADDR = u32Addr;
    FMC->MPDAT0 = u32Data0;
    FMC->MPDAT1 = u32Data1;
    FMC->ISPTRG = 0x1;  
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
}


/**
 * @brief       Read 32-bit Data from specified address of flash
 * 
 * @param[in]   u32addr  Flash address include APROM, LDROM, Data Flash, and CONFIG
 *
 * @return      The data of specified address
 *
 * @details     To read word data from Flash include APROM, LDROM, Data Flash, and CONFIG.
 *
 * @note   
 *              Please make sure that Register Write-Protection Function has been disabled 
 *              before using this function. User can check the status of 
 *              Register Write-Protection Function with DrvSYS_IsProtectedRegLocked().
 */

#if(0)
static __INLINE uint32_t FMC_Read(uint32_t u32Addr)
{ 
    FMC->ISPCMD = FMC_ISPCMD_READ;
    FMC->ISPADDR = u32Addr;
    FMC->ISPDAT = 0;
    FMC->ISPTRG = 0x1;
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
    
    return FMC->ISPDAT;
}
#endif


static __INLINE uint32_t FMC_Read0(uint32_t u32Addr)
{ 
    FMC->ISPCMD = FMC_ISPCMD_READ;
    FMC->ISPADDR = u32Addr;
    FMC->ISPDAT = 0x9;
    FMC->ISPTRG = 0x1;
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
    
    return FMC->ISPDAT;
}

static __INLINE uint32_t FMC_Read1(uint32_t u32Addr)
{ 
    FMC->ISPCMD = FMC_ISPCMD_READ;
    FMC->ISPADDR = u32Addr;
    FMC->ISPDAT = 0xa;
    FMC->ISPTRG = 0x1;
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
    
    return FMC->ISPDAT;
}


/**
 * @brief      Flash page erase
 * 
 * @param[in]  u32addr  Flash address including APROM, LDROM, Data Flash, and CONFIG
 *
 * @details    To do flash page erase. The target address could be APROM, LDROM, Data Flash, or CONFIG. 
 *             The page size is 512 bytes.
 *
 * @note   
 *             Please make sure that Register Write-Protection Function has been disabled 
 *             before using this function. User can check the status of 
 *             Register Write-Protection Function with DrvSYS_IsProtectedRegLocked().
 */
#if(0)
static __INLINE void FMC_Erase(uint32_t u32Addr)
{
    FMC->ISPCMD = FMC_ISPCMD_PAGE_ERASE;
    FMC->ISPADDR = u32Addr;
    FMC->ISPTRG = 0x1;
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
}
#endif
/**
 * @brief       Read Unique ID
 * 
 * @param[in]   u8index  UID index. 0 = UID[0:31], 1 = UID[32:63], 2 = UID[64:95]
 *
 * @return      The 32-bit unique ID data of specified UID index
 *
 * @details     To read out 96-bit Unique ID.
 *
 * @note   
 *              Please make sure that Register Write-Protection Function has been disabled 
 *              before using this function. User can check the status of 
 *              Register Write-Protection Function with DrvSYS_IsProtectedRegLocked().
 */
static __INLINE uint32_t FMC_ReadUID(uint8_t u8Index)
{ 
    FMC->ISPCMD = FMC_ISPCMD_READ_UID;
    FMC->ISPADDR = (u8Index << 2);
    FMC->ISPDAT = 0;
    FMC->ISPTRG = 0x1;
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
    
    return FMC->ISPDAT;
}


static __INLINE void FMC_SetVECMAP(uint32_t u32Addr)
{
    FMC->ISPCMD = FMC_ISPCMD_VECMAP;
    FMC->ISPADDR = u32Addr;
    FMC->ISPTRG = 0x1;  
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
}


static __INLINE uint32_t FMC_GetCheckSum(uint32_t u32Addr, int32_t i32Size)
{
    FMC->ISPCMD = FMC_ISPCMD_CAL_CHECKSUM;
    FMC->ISPADDR = u32Addr;
    FMC->ISPDAT = i32Size;
    FMC->ISPTRG = 0x1;  
#if ISBEN    
    __ISB();
#endif    
    while (FMC->ISPTRG);
    
    FMC->ISPCMD = FMC_ISPCMD_CHECKSUM;
    FMC->ISPTRG = 0x1;  
    while (FMC->ISPTRG);
    
    return FMC->ISPDAT;
}


static __INLINE void FMC_Write256(uint32_t u32Addr, uint32_t *pu32Buf)
{
    int32_t i, idx;
    volatile uint32_t *pu32IspData;
    //int32_t i32Err;
    
    //i32Err = 0;
    idx = 0;
    FMC->ISPCMD = FMC_ISPCMD_MULTI_PROG;
    FMC->ISPADDR = u32Addr;
    
retrigger:
    
    //if(i32Err)
    //    printf("idx=%d  ISPADDR = 0x%08x\n",idx, FMC->ISPADDR);
    
    FMC->MPDAT0 = pu32Buf[idx + 0];
    FMC->MPDAT1 = pu32Buf[idx + 1];
    FMC->MPDAT2 = pu32Buf[idx + 2];
    FMC->MPDAT3 = pu32Buf[idx + 3];
    
    
    
    FMC->ISPTRG = 0x1;  
    
    pu32IspData = &FMC->MPDAT0;
    idx += 4;
    
    for(i=idx;i<256/4;i+=4) // Max data length is 256 bytes (256/4 words)
    {
        
        __set_PRIMASK(1); // Mask interrupt to avoid status check coherence error
        do
        {
            if((FMC->MPSTS & FMC_MPSTS_ISPGO_Msk) == 0)
            {
                __set_PRIMASK(0);
                //printf("%d %x\n", i, FMC->MPADDR);
                FMC->ISPADDR = FMC->MPADDR & (~0xful);
                idx = (FMC->ISPADDR - u32Addr) / 4;
                //i32Err = -1;
                goto retrigger;
            }
        }while(FMC->MPSTS & (3 << FMC_MPSTS_D0_Pos));
        
        // Update new data for D0
        pu32IspData[0] = pu32Buf[i  ];
        pu32IspData[1] = pu32Buf[i+1];
        
        do
        {
            if((FMC->MPSTS & FMC_MPSTS_ISPGO_Msk) == 0)
            {
                __set_PRIMASK(0);
                //printf("%d %x\n", i, FMC->MPADDR);
                FMC->ISPADDR = FMC->MPADDR & (~0xful);
                idx = (FMC->ISPADDR - u32Addr) / 4;
                //i32Err = -1;
                goto retrigger;
            }
        }while(FMC->MPSTS & (3 << FMC_MPSTS_D2_Pos));
        
        // Update new data for D2
        pu32IspData[2] = pu32Buf[i+2];
        pu32IspData[3] = pu32Buf[i+3];
        __set_PRIMASK(0);
    }
    
    while(FMC->ISPSTS & FMC_ISPSTS_ISPGO_Msk);
}




#endif

