/******************************************************************************
 * @file     sc.h
 * @version  V0.10
 * $Revision: 1 $
 * $Date: 14/09/09 4:38p $ 
 * @brief    NUC400 series Smart Card driver header file
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/ 

#ifndef __SC_H__
#define __SC_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "NUC400Series.h"
#include "system_NUC400Series.h"


/** @addtogroup NUC400_FUNC NUC400 Function Interface
  * @{
  */

/** @addtogroup SYS_FUNC Smart card Device Function Interface
  * @{
  */

/*---------------------------------------------------------------------------------------------------------*/
/*  CTL constants definitions                                                                              */
/*---------------------------------------------------------------------------------------------------------*/
#define SC_CTL_CON_SEL_DIRECT_CON	((uint32_t)0x00000000)			/*!<Convention Select */
#define SC_CTL_CON_SEL_INVERSE_CON	((uint32_t)0x00000030)			/*!<Convention Select */
#define SC_CTL_RX_FTRI_LEV_1BYTE	((uint32_t)0x00000000)			/*!<RX Buffer Trigger Level 1 byte*/
#define SC_CTL_RX_FTRI_LEV_2BYTES	((uint32_t)0x00000040)			/*!<RX Buffer Trigger Level 2 bytes*/
#define SC_CTL_RX_FTRI_LEV_3BYTES	((uint32_t)0x00000080)			/*!<RX Buffer Trigger Level 3 bytes*/
#define SC_CTL_TMR_SEL_24_BITS		((uint32_t)0x00002000)			/*!<Timer Selection. Enable internal 24 bits timer */
#define SC_CTL_TMR_SEL_24_8_BITS	((uint32_t)0x00004000)			/*!<Timer Selection. Enable internal 24 bits timer and 8 bits internal timer */
#define SC_CTL_TMR_SEL_24_8_8_BITS	((uint32_t)0x00006000)			/*!<Timer Selection. Enable internal 24 bits timer and two 8 bits timers */
#define SC_CTL_CD_DEB_SEL_IN_384_REMOVAL_128 ((uint32_t)0x00000000)			/*!<Card Detect De-Bounce Select Register. Card insert once per 384 engine clocks and de-bounce sample card removal once per 128 engine clocks.*/
#define SC_CTL_CD_DEB_SEL_IN_192_REMOVAL_64	 ((uint32_t)0x01000000)			/*!<Card Detect De-Bounce Select Register. Card insert once per 192 engine clocks and de-bounce sample card removal once per 64 engine clocks. */
#define SC_CTL_CD_DEB_SEL_IN_96_REMOVAL_32	 ((uint32_t)0x02000000)			/*!<Card Detect De-Bounce Select Register. Card insert once per 96 engine clocks and de-bounce sample card removal once per 32 engine clocks. */
#define SC_CTL_CD_DEB_SEL_IN_48_REMOVAL_16	 ((uint32_t)0x03000000)			/*!<Card Detect De-Bounce Select Register. Card insert once per 48 engine clocks and de-bounce sample card removal once per 16 engine clocks. */

/*---------------------------------------------------------------------------------------------------------*/
/*  ALTCTL constants definitions                                                                             */
/*---------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------------------------*/
/*  UACTL constants definitions                                                                             */
/*---------------------------------------------------------------------------------------------------------*/
#define SC_UACTL_DATA_LEN_8_BITS	((uint32_t)0x00000000)			/*!<Data Length 8 bits */
#define SC_UACTL_DATA_LEN_7_BITS	((uint32_t)0x00000010)			/*!<Data Length 7 bits */
#define SC_UACTL_DATA_LEN_6_BITS	((uint32_t)0x00000020)			/*!<Data Length 6 bits */
#define SC_UACTL_DATA_LEN_5_BITS	((uint32_t)0x00000030)			/*!<Data Length 5 bits */


/*---------------------------------------------------------------------------------------------------------*/
/*  SC_TMR0/1/2 Internal Timer Control Mode constants definitions                                          */
/*---------------------------------------------------------------------------------------------------------*/
#define SC_TMR_MODE0_DC				    ((uint32_t)0x00000000)	/*!<Timer0/1/2 Operation Mode 0. 
                                                                    Down Counter start from trigger timer and end to TMR_CNT equal to 0.*/
#define SC_TMR_MODE1_TIMER_DC_S_TO		((uint32_t)0x01000000)	/*!<Timer0/1/2 Operation Mode 1. 
                                                                    Down Counter start from first start bit and end to time-out.*/
#define SC_TMR_MODE1_DC_S_TO		    ((uint32_t)0x01000000)	/*!<Timer0/1/2 Operation Mode 1. 
                                                                    Down Counter start from first start bit and end to time-out.*/
#define SC_TMR_MODE2_DC_RX_S_TO		    ((uint32_t)0x02000000)	/*!<Timer0/1/2 Operation Mode 2. 
                                                                    Down Counter start from first reception start bit and end to time-out.*/
#define SC_TMR_MODE3_DC_INITIAL_END	    ((uint32_t)0x03000000)	/*!<Timer0/1/2 Operation Mode 3. 
                                                                    Down Counter start from asserting SC_RST and end to time-out*/
#define SC_TMR_MODE4_DC_RELOAD			((uint32_t)0x04000000)	/*!<Timer0/1/2 Operation Mode 4. 
                                                                    Down Counter start from trigger timer and end to TMR_CNT equal to 0 
                                                                    if DC count to 0, timer will reload and re-count*/
#define SC_TMR_MODE5_DC_RELOAD_S_TO	    ((uint32_t)0x05000000)	/*!<Timer0/1/2 Operation Mode 5. 
                                                                    Down Counter start from first start bit and end to time-out 
                                                                    if DC count to 0, timer will reload and re-count*/
#define SC_TMR_MODE6_DC_RELOAD_RX_S_TO	((uint32_t)0x06000000)	/*!<Timer0/1/2 Operation Mode 6.  
                                                                    Down Counter start from first reception start bit and end to time-out
                                                                    if DC count to 0, timer will reload and re-count. */
#define SC_TMR_MODE7_DC_RELOAD_S_S		((uint32_t)0x07000000)	/*!<Timer0/1/2 Operation Mode 7.  
                                                                    Down Counter start from first start bit and end to next start bit
                                                                    if DC does NOT count to 0 and receive the first start bit, timer will reload and re-count.*/
#define SC_TMR_MODE8_UC				    ((uint32_t)0x08000000)	/*!<Timer0/1/2 Operation Mode 8.
                                                                    Up Counter start from trigger timer and end to stop timer.*/
#define SC_TMR_MODEF_DC_RELOAD_C_S   ((uint32_t)0x0F000000)     /*!<Timer0/1/2 Operation Mode 9.
                                                                    Down Counter start from triggering timer, then reload and recount
                                                                    if DC does NOT count to 0 and receive the first start bit. */

/** @addtogroup NANO1xx_SMARTCARD_EXPORTED_CONSTANTS SMARTCARD Exported Constants
  @{
*/
#define SC_CARD_NUM         6      // we have 6 interfaces

#define SC_OFST	         (0x1000)

#define SC_MAXIMUM_ATR_CODES        4
#define SC_MAXIMUM_ATR_LENGTH       33
/* Do activation & de-activation & warm-rest with manual sequence */
// If defined SC_SEQ_MANUAL, SC_InitialEndTest(); will be failed.
//#define SC_SEQ_MANUAL


/*---------------------------------------------------------------------------------------------------------*/
/*  Smart Card Internal Timer number constants definitions                                                 */
/*---------------------------------------------------------------------------------------------------------*/
#define SC_TIMER0   8       /*!< Smart Card Internal Timer 0 */
#define SC_TIMER1	16      /*!< Smart Card Internal Timer 1 */ 
#define SC_TIMER2   32      /*!< Smart Card Internal Timer 2 */

/*---------------------------------------------------------------------------------------------------------*/
/* Clock Stop Level                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
#define SC_CLK_PIN_STOP_NOT_SUPPORT     0
#define SC_CLK_PIN_STOP_LOW             1
#define SC_CLK_PIN_STOP_HIGH            2
#define SC_CLK_PIN_STOP_NO_PREFE        3

#define SC_MIN_BUFFER_SIZE                  271// 288
#define SC_ATR_ERR_UNRECOGNIZED_MEDIA		-150
#define SC_ATR_ERR_INVALID_PARAMETER		-149
#define SC_ATR_ERR_INVALID_TCK				-148

#define SC_PROTOCOL_T0_OK					0			/* Command OK  */
#define SC_PROTOCOL_T0_ICC_ERROR			-1000		/* ICC comunication error */
#define SC_PROTOCOL_T0_ERROR				-1001		/* T=0 Protocol Error */

#define SC_PROTOCOL_PPS_INVALID			-147

#define SC_PROTOCOL_UNDEFINED		0x00000000  // There is no active protocol.
#define SC_PROTOCOL_T0				0x00000001  // T=0 is the active protocol.
#define SC_PROTOCOL_T1				0x00000002  // T=1 is the active protocol.
#define SC_PROTOCOL_T15				0x00008000  // T=15 is the active protocol.
#define SC_PROTOCOL_RAW				0x00010000  // Raw is the active protocol.

#define SC_STAUS_UNKNOWN			0x0001	/*!< Card status is Unknown state */
#define SC_STAUS_ABSENT			    0x0002	/*!< Card status is absent */
#define SC_STAUS_PRESENT			0x0004	/*!< Card status is present */
#define SC_STAUS_SWALLOWED		    0x0008	/*!< Card status is not powered */
#define SC_STAUS_POWERED			0x0010	/*!< Card status is powered */
#define SC_STAUS_NEGOTIABLE		    0x0020	/*!< Card status is ready for PTS */
#define SC_STAUS_SPECIFIC		    0x0040	/*!< Card status is PTS has been set */

#define SC_T1_BLOCK_MAX_SIZE		259
#define SC_T1_BLOCK_INF_MAX_SIZE	254

/* PCBs */
#define SC_T1_BLOCK_I                0x00
#define SC_T1_BLOCK_R                0x80
#define SC_T1_BLOCK_S                0xC0
//
// constants for the T=1 i/o function
//
#define SC_T1_INIT				0
#define SC_T1_START			    1
#define SC_T1_I_BLOCK			2
#define SC_T1_R_BLOCK			3
#define SC_T1_RESTART			4

#define SC_T1_BLOCK_S_RESYNCH_REQ		0xC0
#define SC_T1_BLOCK_S_RESYNCH_RES		0xE0
#define SC_T1_BLOCK_S_IFS_REQ			0xC1
#define SC_T1_BLOCK_S_IFS_RES			0xE1
#define SC_T1_BLOCK_S_ABORT_REQ			0xC2
#define SC_T1_BLOCK_S_ABORT_RES			0xE2
#define SC_T1_BLOCK_S_WTX_REQ			0xC3
#define SC_T1_BLOCK_S_WTX_RES			0xE3
#define SC_T1_BLOCK_S_VPP_ERR			0xE4


#define SC_PROTOCOL_T1_OK					0          		/* Command OK  */
#define SC_PROROCOL_T1_P_ERR_NOTICE		    2000			/* T=1 Parity Error Notice */
#define SC_PROTOCOL_T1_ICC_ERROR			-2000       	/* ICC comunication error */
#define SC_PROTOCOL_T1_ERROR				-2001       	/* T=1 Protocol Error */
#define SC_T1_ABORT_RECEIVED				-2002
#define SC_T1_RESYNCH_RECEIVED			    -2003
#define SC_T1_VPP_ERROR_RECEIVED			-2004
#define SC_T1_WTXRES_RECEIVED				-2005
#define SC_T1_IFSRES_RECEIVED				-2006
#define SC_T1_ABORTRES_RECEIVED			    -2007

//
// Information field size the lib uses
//
#define SC_T1_IFSD             254

//
// Maximum attempts to resend a block in T1
//
#define SC_T1_MAX_RETRIES      2

//
// Bit that indenticates if there are more data to send
//
#define SC_T1_MORE_DATA        0x20

//
// T1 Error values
//
#define SC_T1_ERROR_CHKSUM		-1002
#define SC_T1_ERROR_OTHER		-1003
#define SC_T1_ERROR_LENGTH		-1004

//
// Error detection bit as defined by ISO 
//
#define SC_T1_CRC_CHECK        1

//
// Character waiting integer default value as definded by ISO
//
#define SC_T1_CWI_DEFAULT      13

//
// Block waiting integer default value as definded by ISO
//
#define SC_T1_BWI_DEFAULT      4

//
// Receiving an ATR shall have a duration of less than or equal to initial etus
//
#define SC_ATR_TOTAL_TIME		20050


#define SC_ERR_ID        0xffff2000

#define SC_MAX_ATR_LEN					(33)
#define SC_MAX_BUF_LEN					(500)
#define SC_MAX_CMD_LEN					(262)	/* header : 5, data : 256(max), le : 1, plus all 262 */


/* iso7816 operation class */
#define SC_ISO_OPERATIONCLASS_AUTO			(0x00)
#define SC_ISO_OPERATIONCLASS_A				(0x01)
#define SC_ISO_OPERATIONCLASS_B				(0x02)
#define SC_ISO_OPERATIONCLASS_C				(0x03)

// Current card operation in ISR
#define SC_OP_NOP					(0x00)
#define SC_OP_ATR_READ			    (0x01)
#define SC_OP_READ					(0x02)
#define SC_OP_WRITE				    (0x03)

// status successful
#define SC_STATUS_SUCCESS               0

// error code 
#define SC_ERR_CARD_REMOVED			-120
#define SC_ERR_OVER_RUN				-119
#define SC_ERR_PARITY_ERROR			-118
#define SC_ERR_NO_STOP				-117
#define SC_ERR_SILENT_BYTE			-116
#define SC_ERR_CMD				    -115
#define SC_ERR_UNSUPPORTEDCARD		-114
#define SC_ERR_READ					-113
#define SC_ERR_WRITE			    -112
#define SC_ERR_TIME0OUT            	-111
#define SC_ERR_TIME1OUT            	-110
#define SC_ERR_TIME2OUT            	-109
#define SC_ERR_AUTOCONVENTION    	-108
#define SC_ERR_BGTIMEOUT		   	-107


// These are the error code actually returns to user application
#define SC_EIO							(1| SC_ERR_ID)
#define SC_ENODEV						(2| SC_ERR_ID)
#define SC_ENOMEM						(3| SC_ERR_ID)
#define SC_EBUSY						(4| SC_ERR_ID)
#define SC_ENOTTY						(5| SC_ERR_ID)
#define SC_EPROTOCOL					(6| SC_ERR_ID)  
#define SC_EPARAMETER					(7| SC_ERR_ID)



/* ATRIB = A(nswer) T(o) R(eset) I(nterface) B(yte) */
#define SC_ATR_INTERFACE_BYTE_TA		0	/* Interface byte TAi */
#define SC_ATR_INTERFACE_BYTE_TB		1	/* Interface byte TBi */
#define SC_ATR_INTERFACE_BYTE_TC		2	/* Interface byte TCi */
#define SC_ATR_INTERFACE_BYTE_TD		3	/* Interface byte TDi */

// Reset type
#define SC_COLDRESET                (0x1)
#define SC_WARMRESET                (0x2)

#define SC_GET_ONE_BYTE()		                ((SC->RBR & 0xff))
#define SC_PUT_ONE_BYTE(data)		            (SC->THR = data)


/*---------------------------------------------------------------------------------------------------------*/
/*  Define parameter checking                                                                              */
/*---------------------------------------------------------------------------------------------------------*/
#define SC_CHECK_SC_PORT(port)				((port==SC0) || (port==SC1) || (port==SC2))


/*---------------------------------------------------------------------------------------------------------*/
/*  Define EMV checking                                                                              */
/*---------------------------------------------------------------------------------------------------------*/
//#define SC_EMV_ATR_CHECK		1		/* 1: Enable to check integrity of ATR for EMV */

//#define SC_DEBUG_ENABLE_ENTER_LEAVE
//#define SC_IST_DEBUG				/* IST information check in SC.c */
//#define SC_ATR_DEBUG				/* ATR information check in SC.c */
//#define SC_RD_DEBUG				/* Send/Receive check in SC_Reader.c */
//#define SC_T1_DEBUG				/* T1 protocol check in SC_Protocol.c */

#ifdef SC_DEBUG_ENABLE_ENTER_LEAVE
#define SC_ENTER()					printf("[%-20s] : Enter...\n", __func__)
#define SC_LEAVE()					printf("[%-20s] : Leave...\n", __func__)
#else
#define SC_ENTER()
#define SC_LEAVE()
#endif


#ifdef SC_ATR_DEBUG
#define SC_DEBUG     printf
#else
#define SC_DEBUG(...)
#endif


#ifdef SC_IST_DEBUG
#define SC_ISTDEBUG     printf
#else
#define SC_ISTDEBUG(...)
#endif


#ifdef SC_RD_DEBUG
#define SC_RDDEBUG     printf
#else
#define SC_RDDEBUG(...)
#endif


#ifdef SC_T1_DEBUG
#define SC_T1DEBUG     printf
#else
#define SC_T1DEBUG(...)
#endif


/** This union is used for data type conversion */
typedef union {
    
    struct {

        unsigned long   l0;

    } l;

    struct {

        uint8_t   b0;
        uint8_t   b1;
        uint8_t   b2;
        uint8_t   b3;
    } b;

} S_SC_LENGTH;

/*@}*/ /* end of group NANO1xx_SMARTCARD_EXPORTED_CONSTANTS */


typedef struct {

    // Number of data bytes in this request
    int32_t   Lc;

    // Number of expected bytes from the card
    int32_t   Le;

} S_SC_T0_DATA;


typedef struct {

    // Current information field size that can be transmitted
    uint8_t   IFSC;

    // Current information field size we can receive
    uint8_t   IFSD;

	// Record if received I-block was sent correctly from ICC
	uint8_t   IBLOCK_REC;

    // The 'number' of received I-Blocks
    uint8_t   RSN;

    // The 'number' of sent I-Blocks as defined in ISO 7816-3
    uint8_t   SSN;

    //
    // Waiting time extension requested by the smart card
    // This value should be used by the driver to extend block waiting time.
    //
    uint8_t   Wtx;

} S_SC_T1_DATA;

/** This struct is used by the lib for T1 I/O */
typedef struct {  
    uint8_t   Nad;
    uint8_t   Pcb;
    uint8_t   Len;
    uint8_t *  Inf;
} S_SC_T1_BLOCK_FRAME;

/** Clock rate conversion table according to ISO */
typedef struct {

    const unsigned long F;
    const unsigned long fs; 

} S_SC_CLOCK_RATE_CONVERSION;

/**
 * Bit rate adjustment factor
 * The layout of this table has been slightly modified due to
 * the unavailibility of floating point math support in the kernel.
 * The value D has beed devided into a numerator and a divisor.
 */
typedef struct {
    const unsigned long DNumerator;
    const unsigned long DDivisor;
} S_SC_BIT_RATE_ADJUSTMENT;

/**
 * The clock rate conversion table itself.
 * All R(eserved)F(or Future)U(se) fields MUST be 0
 */
static S_SC_CLOCK_RATE_CONVERSION ClockRateConversion[] = {

        { 372,  4000000     }, 
        { 372,  5000000     }, 
        { 558,  6000000     }, 
        { 744,  8000000     }, 
        { 1116, 12000000    }, 
        { 1488, 16000000    },
        { 1860, 20000000    },
        { 0,    0            },
        { 0,    0            },
        { 512,  5000000     },
        { 768,  7500000     },
        { 1024, 10000000    },
        { 1536, 15000000    },
        { 2048, 20000000    },
        { 0,    0            },
        { 0,    0            }
};      

/**
 * The bit rate adjustment table itself.
 * All R(eserved)F(or)U(se) fields MUST be 0
 */
static S_SC_BIT_RATE_ADJUSTMENT BitRateAdjustment[] = {

    { 0,    0   },
    { 1,    1   },
    { 2,    1   },
    { 4,    1   },
    { 8,    1   },
    { 16,   1   },
    { 32,   1   },
    { 64,   1   },
    { 12,   1   },
    { 20,   1   },
    { 0,    0   },
    { 0,    0   },
    { 0,    0   },
    { 0,    0   },
    { 0,    0   },
    { 0,    0   }
};


/**
 * This struct holds information for the card currently in use
 * The driver must store a received ATR into the ATR struct which is
 * part of this struct. The lib will get all other information
 * out of the ATR.
 */
typedef struct{

    bool InversConvention;  ///< Flag that indicates that the current card uses invers convention
    unsigned long   etu;    ///< Calculated etu in micro-second unit ; etu = F/D * 1/f
      
    /**
     * Answer To Reset string returned by card.
     * Use OsData->SpinLock to access this member
     */
    struct {

        uint8_t Buffer[64];
        uint8_t Length;

    } ATR;

    struct {

        uint8_t Buffer[16];
        uint8_t Length;

    } HistoricalChars;

    // !!! DO NOT MODIFY ANY OF THE BELOW VALUES
    // OTHERWISE THE LIBRARY WON'T WORK PROPERLY

    uint8_t Fl;     ///< Clock rate conversion
    uint8_t Dl;     ///< Bit rate adjustment
    uint8_t II;     ///< Maximum programming current
    uint8_t P;      ///< Programming voltage in .1 Volts
    uint8_t N;      ///< Extra guard time in etu

    unsigned long GT;   ///< Calculated guard time in micro seconds

    struct {
		unsigned long Supported;    ///< This is a bit mask of the supported protocols
		unsigned long Selected;     ///< The currently selected protocol

    } Protocol;

    /** T=0 specific data */
    struct {
        uint8_t WI;         ///< Waiting integer
        unsigned long WT;   ///< Waiting time in micro seconds

    } T0;

    /** T=1 specific data */
    struct {
        uint8_t IFSC;       ///< Information field size of card
        
        uint8_t CWI;        ///< Character waiting integer
        uint8_t BWI;        ///< Block waiting integer

        uint8_t EDC;        ///< Error detection code

        unsigned long CWT;  ///< Character and block waiting time in micro seconds
        unsigned long BWT;  ///< Character and block waiting time in micro seconds

        unsigned long BGT;  ///< Block guarding time in micro seconds

    } T1;

} S_SC_SCARD_CARD_CAPABILITIES;

/**
  * @brief  SmartCard Data Structure definition
  */
typedef struct 
{
	SC_T *base;
	volatile uint32_t op_state;		/* 0 - everything goes well, 1 - some error occured */
	volatile int32_t errno;
	volatile uint32_t openflag;
	volatile uint32_t clock;			/* frequence in KHz */
	uint32_t clock_stop_level;
	volatile uint32_t etu; 			/* in millisecond */
	volatile uint32_t voltage;
	volatile int8_t ActivePowerPin;		/* 1: active High 0: active Low */

    /** Capabilities of the current inserted card */
    S_SC_SCARD_CARD_CAPABILITIES CardCapabilities;

    /**
     * Current state of reader (card present/removed/activated)
     * Use OsData->SpinLock to access this member
     * (mandatory)
     * use for PPS
     */
    unsigned long   CurrentState;

	uint8_t *snd_buf, *rcv_buf;  
	volatile int32_t snd_pos, snd_len;
    volatile int32_t rcv_len, rcv_pos;
	volatile int32_t rcv_cnt;  // cnt is current received data number in write stage read index in read stage
	volatile uint32_t bCardRemoved /* , bCardChanged */;
	int8_t pps_complete;

    S_SC_T0_DATA T0;    ///< Data for T=0
    S_SC_T1_DATA T1;    ///< Data for T=1

    uint8_t uart;
}S_SC_DEV_T;


typedef void (SC_PFN_CALLBACK)(void);
  

//  function prototypes: DrvSMARTCARD.c
void SC_TimerINTEnable(S_SC_DEV_T *dev, uint32_t no);
void SC_TimerINTDisable(S_SC_DEV_T *dev, uint32_t no);
void SC_TimerCountSet(S_SC_DEV_T *dev, uint32_t no, uint32_t op_mode, uint32_t cnt);
void SC_WaitFirstReceivedData(S_SC_DEV_T *dev, uint32_t no, uint32_t op_mode, uint32_t cnt);
void SC_TimerStop(S_SC_DEV_T *dev, uint32_t no);
void SC_TimerAllStop(S_SC_DEV_T *dev);
void SC_TimerStart(S_SC_DEV_T *dev, uint32_t no);
void SC_TimerSelect(S_SC_DEV_T *dev, uint32_t type);
int32_t SC_WarmReset(S_SC_DEV_T *dev);
int32_t SC_DoPPS(S_SC_DEV_T *dev, int32_t f, int32_t d, int32_t t);
void SC_DeactivationCmd(S_SC_DEV_T *dev);
void SC_ActivationCmd(S_SC_DEV_T *dev);
void SC_WarmResetCmd(S_SC_DEV_T *dev);
void SC_SetGuardTime(S_SC_DEV_T *dev);
void SC_SetBlockGuardTime(S_SC_DEV_T *dev, uint32_t bgt);
void SC_StartBlockGuardTime( S_SC_DEV_T *dev );
void SC_StopBlockGuardTime( S_SC_DEV_T *dev );
void SC_ClearFIFO(S_SC_DEV_T *dev);
uint8_t * SC_ErrMsg(long errno);
int32_t SC_CheckCardPresent(SC_T *portno);
int32_t SC_ColdReset(S_SC_DEV_T *dev);
void SC_SetClockState(S_SC_DEV_T *dev, int8_t onoff);
void SC_ClockStopLevel(S_SC_DEV_T *dev);
void SC_VoltageConfig(S_SC_DEV_T *dev);
void SC_SetReaderParameter(S_SC_DEV_T *dev);
int32_t SC_PowerActiveLevel(SC_T *portno, int8_t active);
int32_t SC_IgnoreCardAbsent(SC_T *portno);
int32_t SC_CardDetectEdge(SC_T *portno, int8_t edge);

int32_t SC_UpdateCardCapabilities(S_SC_DEV_T *dev);
#if 0
//  SC_Reader.c
int32_t CBT1Transmit( S_SC_DEV_T *dev, uint8_t *buf, uint32_t len, uint8_t *outbuf, uint32_t *outlen );
int32_t CBT0Transmit( S_SC_DEV_T *dev, uint8_t *buf, uint32_t len, uint8_t *outbuf, uint32_t *outlen );
int32_t CBRawTransmit( S_SC_DEV_T *dev, uint8_t *buf, uint32_t txlen, uint32_t rxlen, uint8_t *outbuf, uint32_t *outlen );
int32_t SC_Write(SC_T *portno, uint8_t *buf, uint32_t len, uint8_t *outbuf, uint32_t *outlen );
#endif

int32_t SC_Init(SC_T *portno);
int32_t SC_Open(SC_T *portno);
int32_t SC_Close(SC_T *portno);
int32_t SC_GetATRBuffer(SC_T *portno, uint8_t *buf, int16_t length);
int32_t SC_InstallCallBack(SC_T *portno, SC_PFN_CALLBACK pfncallback);

void AllSc_NVIC_EnableIRQ(void);
void AllSc_NVIC_DisableIRQ(void);


/**
  * @} End of Smart card Device Function Interface
  */

/**
  * @} End of NUC400 Function Interface
  */

#endif		/* __SC_H__ */

/*** (C) COPYRIGHT 2011 Nuvoton Technology Corp. ***/



