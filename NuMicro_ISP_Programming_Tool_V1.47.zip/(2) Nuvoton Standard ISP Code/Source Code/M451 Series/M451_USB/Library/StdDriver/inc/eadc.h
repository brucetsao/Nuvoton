/******************************************************************************
 * @file     EADC.h
 * @version  V0.10
 * $Revision: 1 $
 * $Date: 14/09/09 4:38p $ 
 * @brief    M451 series EADC driver header file
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/ 
#ifndef __EADC_H__
#define __EADC_H__

/*---------------------------------------------------------------------------------------------------------*/
/* Include related headers                                                                                 */
/*---------------------------------------------------------------------------------------------------------*/
#include "M451Series.h"


#ifdef __cplusplus
extern "C"
{
#endif


/** @addtogroup M451_Device_Driver M451 Device Driver
  @{
*/

/** @addtogroup M451_EADC_Driver EADC Driver
  @{
*/


/** @addtogroup M451_EADC_EXPORTED_CONSTANTS EADC Exported Constants
  @{
*/

/*---------------------------------------------------------------------------------------------------------*/
/*  EADC_CTL Constant Definitions                                                                            */
/*---------------------------------------------------------------------------------------------------------*/
#define EADC_CTL_DIFFEN_SINGLE_END      (0UL<<EADC_CTL_DIFFEN_Pos)   /*!< Single-end input mode      */
#define EADC_CTL_DIFFEN_DIFFERENTIAL    (1UL<<EADC_CTL_DIFFEN_Pos)   /*!< Differential input mode    */
    
#define EADC_CTL_DMOF_STRAIGHT_BINARY   (0UL<<ADC_CR_DMOF_Pos)     /*!< Select the straight binary format as the output format of the conversion result   */
#define EADC_CTL_DMOF_TWOS_COMPLEMENT   (1UL<<ADC_CR_DMOF_Pos)     /*!< Select the 2's complement format as the output format of the conversion result    */

#define EADC_CTL_SMPTSEL1   (0UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 1 ADC clock sampling time */
#define EADC_CTL_SMPTSEL2   (1UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 2 ADC clock sampling time */
#define EADC_CTL_SMPTSEL3   (2UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 3 ADC clock sampling time */
#define EADC_CTL_SMPTSEL4   (3UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 4 ADC clock sampling time */
#define EADC_CTL_SMPTSEL5   (4UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 5 ADC clock sampling time */
#define EADC_CTL_SMPTSEL6   (5UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 6 ADC clock sampling time */
#define EADC_CTL_SMPTSEL7   (6UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 7 ADC clock sampling time */
#define EADC_CTL_SMPTSEL8   (7UL<<EADC_CTL_SMPTSEL_Pos)   /*!< 8 ADC clock sampling time */

/*---------------------------------------------------------------------------------------------------------*/
/* EADC_SCTL Constant Definitions                                                                           */
/*---------------------------------------------------------------------------------------------------------*/
#define EADC_SCTL_CHSEL(x)     ((x) << EADC_SCTL_CHSEL_Pos)       /*!< A/D SAMPLE Channel Selection */
#define EADC_SCTL_TRGDLYDIV(x) ((x) << EADC_SCTL_TRGDLYDIV_Pos)   /*!< A/D SAMPLE Start Of Conversion Trigger Delay Clock Divider Selection */
#define EADC_SCTL_TRGDLYCNT(x) ((x) << EADC_SCTL_TRGDLYCNT_Pos)   /*!< A/D SAMPLE Start Of Conversion Trigger Delay Time */

#define EADC_SCTL_TRGSEL_SOFTWARE_TRIGGER (0UL<<EADC_SCTL_TRGSEL_Pos)     /*!< Software trigger */
#define EADC_SCTL_TRGSEL_STADC_TRIGGER    (1UL<<EADC_SCTL_TRGSEL_Pos)      /*!< Software trigger */
#define EADC_SCTL_TRGSEL_ADINT0_TRIGGER   (2UL<<EADC_SCTL_TRGSEL_Pos)      /*!< STADC pin input trigger */
#define EADC_SCTL_TRGSEL_ADINT1_TRIGGER   (3UL<<EADC_SCTL_TRGSEL_Pos)      /*!< ADC ADINT0 interrupt EOC pulse trigger */
#define EADC_SCTL_TRGSEL_TIMER0_TRIGGER   (4UL<<EADC_SCTL_TRGSEL_Pos)      /*!< ADC ADINT1 interrupt EOC pulse trigger */
#define EADC_SCTL_TRGSEL_TIMER1_TRIGGER   (5UL<<EADC_SCTL_TRGSEL_Pos)      /*!< Timer0 overflow pulse trigger */
#define EADC_SCTL_TRGSEL_TIMER2_TRIGGER   (6UL<<EADC_SCTL_TRGSEL_Pos)      /*!< Timer1 overflow pulse trigger */
#define EADC_SCTL_TRGSEL_TIMER3_TRIGGER   (7UL<<EADC_SCTL_TRGSEL_Pos)      /*!< Timer2 overflow pulse trigger */
#define EADC_SCTL_TRGSEL_PWM0TG0_TRIGGER  (8UL<<EADC_SCTL_TRGSEL_Pos)      /*!< Timer3 overflow pulse trigger */
#define EADC_SCTL_TRGSEL_PWM0TG1_TRIGGER  (9UL<<EADC_SCTL_TRGSEL_Pos)      /*!< PWM0TG0 trigger */
#define EADC_SCTL_TRGSEL_PWM0TG2_TRIGGER  (0xAUL<<EADC_SCTL_TRGSEL_Pos)    /*!< PWM0TG1 trigger */
#define EADC_SCTL_TRGSEL_PWM0TG3_TRIGGER  (0xBUL<<EADC_SCTL_TRGSEL_Pos)    /*!< PWM0TG2 trigger */
#define EADC_SCTL_TRGSEL_PWM0TG4_TRIGGER  (0xCUL<<EADC_SCTL_TRGSEL_Pos)    /*!< PWM0TG3 trigger */
#define EADC_SCTL_TRGSEL_PWM0TG5_TRIGGER  (0xDUL<<EADC_SCTL_TRGSEL_Pos)    /*!< PWM0TG4 trigger */
#define EADC_SCTL_TRGSEL_PWM1TG0_TRIGGER  (0xEUL<<EADC_SCTL_TRGSEL_Pos)    /*!< PWM0TG5 trigger */
#define EADC_SCTL_TRGSEL_PWM1TG1_TRIGGER  (0xFUL<<EADC_SCTL_TRGSEL_Pos)    /*!< PWM1TG0 trigger */
#define EADC_SCTL_TRGSEL_PWM1TG2_TRIGGER  (0x10UL<<EADC_SCTL_TRGSEL_Pos)   /*!< PWM1TG1 trigger */
#define EADC_SCTL_TRGSEL_PWM1TG3_TRIGGER  (0x11UL<<EADC_SCTL_TRGSEL_Pos)   /*!< PWM1TG2 trigger */
#define EADC_SCTL_TRGSEL_PWM1TG4_TRIGGER  (0x12UL<<EADC_SCTL_TRGSEL_Pos)   /*!< PWM1TG3 trigger */
#define EADC_SCTL_TRGSEL_PWM1TG5_TRIGGER  (0x13UL<<EADC_SCTL_TRGSEL_Pos)   /*!< PWM1TG4 trigger */

#define EADC_SCTL_SPLTEXT(x) ((x) << EADC_SCTL_SPLTEXT_Pos)       /*!< ADC Sampling Time Extend */

/*---------------------------------------------------------------------------------------------------------*/
/* EADC_CMP Constant Definitions                                                                           */
/*---------------------------------------------------------------------------------------------------------*/
#define EADC_CMP_CMPCOND_LESS_THAN          (0UL<<EADC_CMP_CMPCOND_Pos)   /*!< Comparison Data */
#define EADC_CMP_CMPCOND_GREATER_OR_EQUAL   (1UL<<EADC_CMP_CMPCOND_Pos)   /*!< Comparison Data */
#define EADC_CMP_CMPSPL(x)   ((x) << EADC_CMP_CMPSPL_Pos)   /*!< Compare SAMPLE Selection */
#define EADC_CMP_CMPMCNT(x)  ((x) << EADC_CMP_CMPMCNT_Pos)  /*!< Compare Match Count */
#define EADC_CMP_CMPDAT(x)   ((x) << EADC_CMP_CMPDAT_Pos)   /*!< Comparison Data */


/*@}*/ /* end of group M451_EADC_EXPORTED_CONSTANTS */


/*---------------------------------------------------------------------------------------------------------*/
/*  EADC Macro Definitions                                                                                  */
/*---------------------------------------------------------------------------------------------------------*/


/*@}*/ /* end of group M451_EADC_EXPORTED_FUNCTIONS */

/*@}*/ /* end of group M451_EADC_Driver */

/*@}*/ /* end of group M451_Device_Driver */

#ifdef __cplusplus
}
#endif

#endif //__EADC_H__

/*** (C) COPYRIGHT 2013 Nuvoton Technology Corp. ***/
