/******************************************************************************
 * @file     main.c
 * @brief    M451 series ISP example source file
 * @version  2.0.0
 * @date     22, March, 2013
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#include <stdio.h>
#include "M451Series.h"
#include "string.h"
#include "ISP_USER.h"
#include "hid_transfer.h"	

#define DetectPin   PB6
#define BOOL		uint8_t
//#define	printf(...)	

uint8_t bUsbDataReady;

void SysTimerDelay(uint32_t us);

uint32_t USB_EpAFun(uint8_t *buff)
{
	
	uint8_t *ptr;
	
	ptr = (uint8_t *)(USBD_BUF_BASE + USBD_GET_EP_BUF_ADDR(EP2));
	
	USBD_MemCopy(ptr, buff , EP2_MAX_PKT_SIZE);

	USBD_SET_PAYLOAD_LEN(EP2, EP2_MAX_PKT_SIZE);

   	return 0;
}

/*--------------------------------------------------------------------------*/
void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/

    /* Enable Internal RC 22.1184MHz clock and external XTAL clock*/
    CLK->PWRCTL |= CLK_PWRCTL_HIRCEN_Msk | CLK_PWRCTL_HXTEN_Msk;

    /* Waiting for Internal RC clock ready */
    while((CLK->STATUS & CLK_STATUS_HIRCSTB_Msk) == 0);
    /* Waiting for external XTAL clock ready */    
    while((CLK->STATUS & CLK_STATUS_HXTSTB_Msk) == 0);

    /* Set Flash Access Delay */
    FMC->FTCTL |= FMC_FTCTL_FOM_Msk;
 
    /* Enable and apply new PLL setting. */
    CLK->PLLCTL = 0x0000402E;//144Mhz

    /* Wait for PLL clock stable */
    while((CLK->STATUS & CLK_STATUS_PLLSTB_Msk) == 0);

    /* Apply new Divider */
    CLK->CLKDIV0 = (1 << CLK_CLKDIV0_HCLKDIV_Pos) | (2 << CLK_CLKDIV0_USBDIV_Pos);

    /* Switch HCLK to new HCLK source */
    CLK->CLKSEL0 = (CLK->CLKSEL0 & (~CLK_CLKSEL0_HCLKSEL_Msk)) | CLK_CLKSEL0_HCLKSEL_PLL;

    /* Update System Core Clock */
    SystemCoreClock = 72000000;
    PllClock = 144000000;
    CyclesPerUs = 72;

    /* Enable module clock */
    CLK->APBCLK0 |= CLK_APBCLK0_USBDCKEN_Msk;
    SYS->USBPHY = SYS_USBPHY_LDO33EN_Msk;
}

/*---------------------------------------------------------------------------------------------------------*/
/*  Main Function                                                                                          */
/*---------------------------------------------------------------------------------------------------------*/
int32_t main(void)
{
	/* Unlock protected registers */
	SYS_UnlockReg();	
	
	SYS_Init();
	
	CLK->AHBCLK |= CLK_AHBCLK_ISPCKEN_Msk;
	FMC->ISPCTL |= FMC_ISPCTL_ISPEN_Msk;

	g_apromSize = GetApromSize();
	GetDataFlashInfo(&g_dataFlashAddr , &g_dataFlashSize); 	

//	outp32(0X40004040,0xdfffffff);	//PB14 GPIO_MODE_OUTPUT
//	outp32(0X40004048,0x0000ffff);	//PB14 IS High

	
    if(DetectPin == 0)
    {
        USBD_Open(&gsInfo, NULL, NULL);
        USBD_Start();
        NVIC_EnableIRQ(USBD_IRQn);
    }


    while(1)
    {	
    if((DetectPin == 0) && (bUsbDataReady == TRUE))
    {
        ParseCmd((uint8_t *)usb_rcvbuf, EP3_MAX_PKT_SIZE);
        USB_EpAFun((uint8_t *)&response_buff[0]);

        //printf("USB process!\n");
        bUsbDataReady = FALSE;
		}
	
		//change to APROM			
		if(DetectPin)//GPIO high
		//if((SysTick->CTRL & (1 << 16)) != 0)//timeout, then goto APROM
		{
			outpw(&SYS->RSTSTS, 3);//clear bit
			outpw(&FMC->ISPCTL, inpw(&FMC->ISPCTL) & 0xFFFFFFFC);
			outpw(&SCB->AIRCR, (V6M_AIRCR_VECTKEY_DATA | V6M_AIRCR_SYSRESETREQ));

			/* Trap the CPU */
			while(1);
		}
	}
}

/*** (C) COPYRIGHT 2013 Nuvoton Technology Corp. ***/

