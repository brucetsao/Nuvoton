#include "stdafx.h"
#include "NuvoISPDlg.h"


#include "Config_Dialog/UserConfigM051.h"
#include "Config_Dialog/UserConfigM051CN.h"
#include "Config_Dialog/UserConfigNano100.h"
#include "Config_Dialog/UserConfigNano112.h"
#include "Config_Dialog/UserConfigNUC100.h"
#include "Config_Dialog/UserConfigNUC122.h"
#include "Config_Dialog/UserConfigNUC123.h"
#include "Config_Dialog/UserConfigNUC200.h"
#include "Config_Dialog/UserConfigMT500.h"
#include "Config_Dialog/UserConfigMINI51AN.h"
#include "Config_Dialog/UserConfigMINI51BN.h"
#include "Config_Dialog/UserConfigMINI51DE.h"
#include "Config_Dialog/UserConfigNUC470.h"
#include "Config_Dialog/UserConfigNUC451.h"
#include "Config_Dialog/UserConfigNUC1312AE.h"
#include "Config_Dialog/UserConfigISD9xxx.h"
#include "Config_Dialog/UserConfigMINI51X.h"
#include "UserConfigDefault.h"

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     GetChipInfo                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �q�t�m�ɤ�����ԲӴ�����T                                                              */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::GetChipInfo()
{
    wchar_t * pEnd;
    CString strLoad;
    CString strTmp;
    CString sPath = m_strCurExePath + CString(_T("config.ini"));
    TCHAR buffer[MAX_PATH] = {0};
    DWORD ret = 0;

    if(!m_sMyChipType.uChipID)
        return FALSE;


    /* Using Data Base from ConfigDlg.dll */
    {
        HMODULE hDllLib = LoadLibrary(_T("ConfigDlg.dll"));

        LPFUNPOINT   lpProc;
        if(NULL != hDllLib) {
            lpProc = (LPFUNPOINT)GetProcAddress(hDllLib, ("ConfigDlg") );
            if(NULL != lpProc)
                ret = lpProc(m_sMyChipType.uChipID, 0, &m_sMyChipType);
            FreeLibrary(hDllLib);
        }
    }

    if(ret) {
        m_ChipSerial = ret;
        goto _UI_PROJECT_SETTING;
    }

#if 0	// For user manual, using NUC123SD4AN as example
	m_sMyChipType.uChipID = 0x55667788;
    m_sMyChipType.uFlashSize = 68 * 1024;
    m_sMyChipType.uRamSize = 20 * 1024;
	_tcscpy_s(m_sMyChipType.cChipName,_T("NUC123SD4AN"));
	       
	//((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->SetCheck(0);
	//((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->SetCheck(1);
	goto _UI_PROJECT_SETTING;

#endif

    /* Using Data Base from config.ini */
    strTmp.Format(_T("0x%08X"),m_sMyChipType.uChipID);
    GetPrivateProfileString(strTmp,_T("FLASH_SIZE"),_T(""),buffer,MAX_PATH,sPath);
    if(buffer[0]==0)
        return FALSE;
    //m_sMyChipType.uFlashSize = _tcstoul(buffer, NULL, 10) * 1024;
    //m_sMyChipType.uFlashSize = wcstod(buffer,&pEnd) * 1024;
    m_sMyChipType.uFlashSize = _tcstod(buffer,&pEnd) * 1024;


    GetPrivateProfileString(strTmp,_T("RAM_SIZE"),_T(""),buffer,MAX_PATH,sPath);
    if(buffer[0]==0)
        return FALSE;
    //m_sMyChipType.uRamSize = _tcstoul(buffer, NULL, 10) * 1024;
    //m_sMyChipType.uRamSize = wcstod(buffer,&pEnd) * 1024;
    m_sMyChipType.uRamSize = _tcstod(buffer,&pEnd) * 1024;

    GetPrivateProfileString(strTmp,_T("NAME_STRING"),_T("Unknown"),m_sMyChipType.cChipName,MAX_PATH,sPath);
    /*
    	if(!wcsncmp(m_sMyChipType.cChipName,_T("M05"),3))
    	{
    		m_ChipSerial = SERIAL_M05X;
    	}

    	else */
    if(!wcsncmp(m_sMyChipType.cChipName,_T("NANO1"),5)) {
        m_ChipSerial = SERIAL_NANO1XX;
    } else if (!wcsncmp(m_sMyChipType.cChipName,_T("NUC4"),4) ||
               !wcsncmp(m_sMyChipType.cChipName,_T("MT6"),3)) {
        m_ChipSerial = SERIAL_NUC470;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("MINI51"),6)) {
        m_ChipSerial = SERIAL_MINI5X;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("NUC1"),4) && !wcsncmp(m_sMyChipType.cChipName + wcslen(m_sMyChipType.cChipName) - 2,_T("DN"),2)) {
        m_ChipSerial = SERIAL_NUC100D;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("NUC2"),4)) {
        m_ChipSerial = SERIAL_NUC200A;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("M451"),4)) {
        m_ChipSerial = SERIAL_NUCM451;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("M452"),4)) {
        m_ChipSerial = SERIAL_NUCM452;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("M453"),4)) {
        m_ChipSerial = SERIAL_NUCM453;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("M451M"),5)) {
        m_ChipSerial = SERIAL_NUCM451M;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("NUC029LAN"),9)) {
        m_ChipSerial = SERIAL_NUC029LAN;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("NUC029TAN"),9)) {
        m_ChipSerial = SERIAL_NUC029TAN;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("NUC029FDE"),9)) {
        m_ChipSerial = SERIAL_NUC029FDE;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("NUC131"),6)) {
        m_ChipSerial = SERIAL_NUC131;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("M0518"),5)) {
        m_ChipSerial = SERIAL_M0518;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("ISD9"),4)) {
        m_ChipSerial = SERIAL_ISD9XXX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("MINI51XZAE"),10)) {
        m_ChipSerial = SERIAL_MINI5XX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("MINI52XZAE"),10)) {
        m_ChipSerial = SERIAL_MINI5XX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("MINI54XZAE"),10)) {
        m_ChipSerial = SERIAL_MINI5XX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("Mini51XLAE"),10)) {
        m_ChipSerial = SERIAL_MINI5XX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("Mini52XLAE"),10)) {
        m_ChipSerial = SERIAL_MINI5XX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("Mini54XLAE"),10)) {
        m_ChipSerial = SERIAL_MINI5XX;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("M05"),3)) { //�קK��M0518�d�V�A����᭱�P�_
        m_ChipSerial = SERIAL_M05X;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("Mini"),4)) {
        m_ChipSerial = SERIAL_MINI5X;
    } else if(!wcsncmp(m_sMyChipType.cChipName,_T("MINI"),4)) {
        m_ChipSerial = SERIAL_MINI5X;
    }

_UI_PROJECT_SETTING:


    if ((m_ChipSerial == SERIAL_M05X) ||                           /* M051 series        */
            ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010200)  ||   /* NUC102 ver. A      */
            ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00012200)) {    /* NUC122 ver. A      */
        // Hide Config1
        ((CWnd *)GetDlgItem(IDC_TXT_CONFIG1))->ShowWindow(SW_HIDE);   // CFLi 0521 for test
        ((CWnd *)GetDlgItem(IDC_CONFIG1_TEXT))->ShowWindow(SW_HIDE);
    } else {
        ((CWnd *)GetDlgItem(IDC_TXT_CONFIG1))->ShowWindow(SW_SHOW);
        ((CWnd *)GetDlgItem(IDC_CONFIG1_TEXT))->ShowWindow(SW_SHOW);
    }

    if (bIsConfigLoad) {
        if ((m_hexConfig0_last == 0) || (m_hexConfig1_last == 0) || IsCFG01Invalid(m_hexConfig0_last, m_hexConfig1_last)) {
            strTmp.Format(_T("Invalid config value in project file,\nCF0=0x%08X, CF1=0x%08X\n\nUse on-chip config instead\n"),m_hexConfig0_last,m_hexConfig1_last);
            MessageBox(strTmp,_T("Error"),MB_OK);
            m_hexConfig0_last = m_hexConfig0_saved;
            m_hexConfig1_last = m_hexConfig1_saved;
        }
        return TRUE;
    }

    sPath = m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"));

    GetPrivateProfileString(CString(_T("NU_PATH")),_T("NU_APROM"),_T(""),buffer,MAX_PATH,sPath);

    ret = GetFileAttributes(buffer);
    if( (ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY)) {
        //MessageBox(_T("No such file!"),_T("Error"),MB_OK);
    } else {
        m_strCodeFilePath.Format(_T("%s"),buffer);
    }

    GetPrivateProfileString(CString(_T("NU_PATH")),_T("NU_LDROM"),_T(""),buffer,MAX_PATH,sPath);
    ret = GetFileAttributes(buffer);
    if( (ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY)) {
        //MessageBox(_T("No such file!"),_T("Error"),MB_OK);
    } else {
        m_strDataFilePath.Format(_T("%s"),buffer);
    }

#ifdef CHECKSUM_SAVE_ENABLE
    /*Check if checksum saving enabled*/
    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_CHECKSUM"),_T(""),buffer,MAX_PATH,sPath);
    if(wcstoul(buffer, NULL, 10) !=1) {
        ((CButton *)GetDlgItem(IDC_CHECK_SAVE_CHECKSUM))->SetCheck(BST_UNCHECKED);
        ISP_RESERVED_SIZE = 0;

    } else {
        ((CButton *)GetDlgItem(IDC_CHECK_SAVE_CHECKSUM))->SetCheck(BST_CHECKED);
        ISP_RESERVED_SIZE = 8; //Checksum+Len = 8bytes
    }
#endif

    /*Check last config value*/
    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTCONFIG0"),_T(""),buffer,MAX_PATH,sPath);
    m_hexConfig0_last = _tcstoul(buffer, NULL, 16);
    m_hexConfig0_last_saved = m_hexConfig0_last;

    // 0114 CFLi for M451 config0[16] bug
    //if ((m_ChipSerial == SERIAL_NUCM451) || (m_ChipSerial == SERIAL_NUCM452) || (m_ChipSerial == SERIAL_NUCM453) || (m_ChipSerial == SERIAL_NUCM451M)) {
    if (m_ChipSerial == SERIAL_M45X) {	
        m_hexConfig0_last &= ~(1 << 16);
        m_hexConfig0_last_saved = m_hexConfig0_last;
    } else if((m_ChipSerial == SERIAL_NANO1XX) && ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00111200) || ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00110200)) { // NANO112 CWDT[31]
        m_hexConfig0_last |= (1 << 31);
        m_hexConfig0_last_saved = m_hexConfig0_last;
    }


    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTCONFIG1"),_T(""),buffer,MAX_PATH,sPath);
    m_hexConfig1_last = _tcstoul(buffer, NULL, 16);
    m_hexConfig1_last_saved = m_hexConfig1_last;


    if ((m_hexConfig0_last == 0) || (m_hexConfig1_last == 0) || IsCFG01Invalid(m_hexConfig0_last, m_hexConfig1_last)) {
        if (MyDevFound) {
            strTmp.Format(_T("Invalid last config value:\nCF0=0x%08X, CF1=0x%08X\n\nUse on-chip config instead\n"),m_hexConfig0_last,m_hexConfig1_last);
            MessageBox(strTmp,_T("Error"),MB_OK);
            m_hexConfig0_last = m_hexConfig0_saved;
            m_hexConfig1_last = m_hexConfig1_saved;
        }
    }
    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTOPMODE"),_T(""),buffer,MAX_PATH,sPath);
    m_uBurnMode_last = _tcstoul(buffer, NULL, 10);
    m_uBurnMode_last_saved = m_uBurnMode_last;
    return TRUE;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     DataFlashType_II                                                             	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Data flash type check                                                                     */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Data Flash is optional.                                                           */
/*               FALSE : Data Flash is fixed 4 KB size.                                                    */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::DataFlashType_II()
{

	TRACE(_T("DataFlashType_II\n"));

    if (((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010300)   ||   /* NUC103 ver. A      */
            ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010500)   ||   /* NUC105 ver. A      */
            ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00012300)   ||   /* NUC123 ver. A      */
            (m_ChipSerial == SERIAL_NUC103BN) ||                        /* NUC103, NUC105, NUC123 ver. B      */
            ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10013100)   ||   /* NUC131      */
            ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10051800)) {     /* M0518      */
        if (m_hexConfig0 & (1<<2))
            return FALSE;				// DFVSEN=1; Data flash size is fixed 4 KBytes
        else
            return TRUE;				// DFVSEN=0; variable data flash size
    }

    if ((m_sMyChipType.uChipID & 0xFFFF0000) == 0x00110000)    /* NANO series        */
//  ((m_sMyChipType.uChipID & 0xFFFF0F00) == 0x30010000)   ||    /* NUC100 DN          */
            //((m_sMyChipType.uChipID & 0xFFFF0F00) == 0x00020000)   ||    /* NUC200 ver. A      */
            //((m_sMyChipType.uChipID & 0xFFFF0F00) == 0x10020000))        /* NUC200 ver. B      */
        return TRUE;

    if ((m_sMyChipType.uFlashSize == 0x20000) ||
            (m_ChipSerial == SERIAL_NANO1XX) ||
            (m_ChipSerial == SERIAL_MINI5X) ||
//  (m_ChipSerial == SERIAL_NUC100D) ||
            //(m_ChipSerial == SERIAL_NUC200A) ||
            //(m_ChipSerial == SERIAL_NUCM451)  ||
            //(m_ChipSerial == SERIAL_NUCM452)  ||
            //(m_ChipSerial == SERIAL_NUCM453)  ||
            //(m_ChipSerial == SERIAL_NUCM451M)  ||
            (m_ChipSerial == SERIAL_M45X) ||
            (m_ChipSerial == SERIAL_NUC029FDE) ||
            (m_ChipSerial == SERIAL_NUC470)    ||
            (m_ChipSerial == SERIAL_MINI5XX) ||
            (m_ChipSerial == SERIAL_NM1200) ||
            (m_ChipSerial == SERIAL_ISD9XXX))     /* ISD series        */
        return TRUE;

    return FALSE;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonSetting                                                              	   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �I����Setting�����s���^�����                                                             */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

void CNuvoISPDlg::OnBnClickedButtonSetting()
{
    // TODO: �b���K�[����q���B�z�{���X

    int ret = 0;
    int Conifg[4] = {0};
    Conifg[0] = m_hexConfig0;
    Conifg[1] = m_hexConfig1;

    /* Using Configuration Dialog from ConfigDlg.dll */
    {
        HMODULE hDllLib = LoadLibrary(_T("ConfigDlg.dll"));

        LPFUNPOINT   lpProc;
        if(NULL != hDllLib) {
            lpProc = (LPFUNPOINT)GetProcAddress(hDllLib, ("ConfigDlg") );
            if(NULL != lpProc)
                ret = lpProc(m_sMyChipType.uChipID, Conifg, 0);
            FreeLibrary(hDllLib);
        }
    }

    if(ret) {
        m_hexConfig0 = Conifg[0];
        m_hexConfig1 = Conifg[1];
        UpdateSizeInfo(FALSE);
        return;
    }

    /* Using Configuration Dialog from NuvoISP.exe */
    CString strTmp;

#ifdef DEBUG_EMULATE
    m_sMyChipType.uChipID = 0x00111201;
    m_sMyChipType.uFlashSize = 0x10000;
#endif

    if (((m_sMyChipType.uChipID & 0xFFFFF000) == 0x00005000) ||
            ((m_sMyChipType.uChipID & 0xFFFFF000) == 0x10005000)) {
        // M051AN, M051BN
        CUserConfigM051 settingDlg;

        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = 0xFFFFFFFF;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFF000) == 0x20005000) ||
               ((m_sMyChipType.uChipID & 0xFFFFF000) == 0x30005000) ||
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00295A00) ||
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00295804)) {
        // M051DN, NUC029LAN, NUC029TAN, M051DE
        CUserConfigM051CN settingDlg;

        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = 0xFFFFFFFF;
            UpdateSizeInfo(FALSE);
        }
    } else if ((m_sMyChipType.uChipID & 0xFFFFF000) == 0x00205000) {    /* MINI51AN           */
        CUserConfigMINI51AN settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if ((m_sMyChipType.uChipID & 0xFFFFF000) == 0x10205000) {    /* MINI51BN           */
        CUserConfigMINI51BN settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFF000) == 0x20205000) ||
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00295415)) {	/* MINI51DE, NUC029FAE     */
        CUserConfigMINI51DE settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if ((m_sMyChipType.uChipID & 0xFFFF0000) == 0x00110000) {
        /* NANO Series        */
        if (((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00111200) ||
                ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00110200)) {
            /* NANO112, NANO102   */
            CUserConfigNano112 settingDlg;
            settingDlg.m_hexConfig0 = m_hexConfig0;
            settingDlg.m_hexConfig1 = m_hexConfig1;
            settingDlg.m_uChipID    = m_sMyChipType.uChipID;
            settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

            if (settingDlg.DoModal() == IDOK) {
                m_hexConfig0 = settingDlg.m_hexConfig0;
                m_hexConfig1 = settingDlg.m_hexConfig1;
                UpdateSizeInfo(FALSE);
            }
        } else {										              /* NANO1XX            */
            CUserConfigNano100 settingDlg;
            settingDlg.m_hexConfig0 = m_hexConfig0;
            settingDlg.m_hexConfig1 = m_hexConfig1;
            settingDlg.m_uChipID    = m_sMyChipType.uChipID;
            settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

            if (settingDlg.DoModal() == IDOK) {
                m_hexConfig0 = settingDlg.m_hexConfig0;
                m_hexConfig1 = settingDlg.m_hexConfig1;
                UpdateSizeInfo(FALSE);
            }
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFF0000) == 0x00040000)  || /* NUC470             */
               ((m_sMyChipType.uChipID & 0xFFFF0000) == 0x00060000)) {
        CUserConfigNUC470 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_hexConfig2 = m_hexConfig2;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            m_hexConfig2 = settingDlg.m_hexConfig2;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010200)  || /* NUC102 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00012200)) {    /* NUC122 ver. A      */
        CUserConfigNUC122 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = 0xFFFFFFFF;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010300)  || /* NUC103 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010500)  ||   /* NUC105 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00012300))      /* NUC123 ver. A      */

    {
        CUserConfigNUC123 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFF0F00) == 0x30010000)  ||  /* NUC100 DN          */
               ((m_sMyChipType.uChipID & 0xFFFF0F00) == 0x00020000)  ||    /* NUC200 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFF0F00) == 0x10020000)  ||  /* NUC200 ver. B      */
			   (m_ChipSerial == SERIAL_NUC200A)) /* ConfigDlg.dll */
	{     
        CUserConfigNUC200 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if ((m_sMyChipType.uChipID & 0xFFFF0000) == 0x10350000) {    /* MT500, FC8238      */
        CUserConfigMT500 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010000)  || /* NUC100 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10010000)  ||   /* NUC100 ver. B      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x20010000)  ||   /* NUC100 ver. C      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010100)  ||   /* NUC101 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10010100)  ||   /* NUC101 ver. B      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x20010100)  ||   /* NUC101 ver. C      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00012000)  ||   /* NUC120 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10012000)  ||   /* NUC120 ver. B      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x20012000)  ||   /* NUC120 ver. C      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00013000)  ||   /* NUC130 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10013000)  ||   /* NUC130 ver. B      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x20013000)  ||   /* NUC130 ver. C      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00014000)  ||   /* NUC140 ver. A      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x10014000)  ||   /* NUC140 ver. B      */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x20014000)) {    /* NUC140 ver. C      */
        CUserConfigNUC100 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00845100)  || /* M451   */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00945100)  ||   /* M451   */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00845200)  ||   /* M452   */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00845700)  ||   /* M4LED  */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00945200)  ||   /* M452   */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00845300)  ||   /* M453   */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00945300)  ||   /* M453   */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00845000)  ||   /* M451M  */
               ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00945000)) {    /* M451M  */
        CUserConfigNUC451 settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }

    } else if (((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10013100)  || /* NUC131LD2AE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10013103)  ||   /* NUC131LC2AE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10013110)  ||   /* NUC131SD2AE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10013113)  ||   /* NUC131SC2AE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10051800)  ||   /* M0518LD2AE  */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10051803)  ||   /* M0518LC2AE  */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10051810)  ||   /* M0518SD2AE  */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x10051813)) {    /* M0518SC2AE  */
        UserConfigNUC1312AE settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }

    } else if ((m_sMyChipType.uChipID & 0xFFF00000) == 0x1d000000) {    /* ISD9xxx           */
        CUserConfigISD9xxx settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if (((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00505102)  || /* Mini51XZAE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00505203)  ||   /* Mini52XZAE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00505403)  ||   /* Mini54XZAE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00505100)  ||   /* Mini51XLAE */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00505200)  ||   /* Mini52XLAE  */
               ((m_sMyChipType.uChipID & 0xFFFFFFFF) == 0x00505400)) {    /* Mini54XLAE  */
        UserConfigMINI51X settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else if (m_ChipSerial == SERIAL_MINI5X) {
        CUserConfigMINI51DE settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
        settingDlg.m_uChipID    = m_sMyChipType.uChipID;
        settingDlg.m_uFlashSize = m_sMyChipType.uFlashSize;

        if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
            UpdateSizeInfo(FALSE);
        }
    } else {
        UserConfigDefault settingDlg;
        settingDlg.m_hexConfig0 = m_hexConfig0;
        settingDlg.m_hexConfig1 = m_hexConfig1;
		 
		if (settingDlg.DoModal() == IDOK) {
            m_hexConfig0 = settingDlg.m_hexConfig0;
            m_hexConfig1 = settingDlg.m_hexConfig1;
			strTmp.Format(_T("%08X"),m_hexConfig0);
			SetDlgItemText(IDC_TXT_CONFIG0,strTmp);
			strTmp.Format(_T("%08X"),m_hexConfig1);
			SetDlgItemText(IDC_TXT_CONFIG1,strTmp);
        }
    }
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateChipInfo                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��s������T                                                                              */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::UpdateChipInfo()
{
    // CCTu
    if(m_sMyChipType.uChipID == 0x550505) {
        m_ChipSerial = SERIAL_NUC505;
        m_sMyChipType.uFlashSize = 0x200000;				// 2MB
        m_sMyChipType.uRamSize = 0x20000;					// 128KB
        m_sMyChipType.uCodeFlashSize = (m_sMyChipType.uFlashSize >> 1) - 0x4000;
        m_sMyChipType.uDataFlashStartAddr = m_sMyChipType.uFlashSize >> 1;
        m_sMyChipType.uDataFlashSize = m_sMyChipType.uFlashSize >> 1;
        SetDlgItemText(IDC_TXT_PARTNO_INFO,_T("RAM: 128KB    SPI Flash: 2MB"));
        SetDlgItemText(IDC_EDIT_APROM_BASE_ADDR,_T("4000"));
        SetDlgItemText(IDC_EDIT_DATA_BASE_ADDR,_T("100000"));
        GetDlgItem(IDC_EDIT_DATA_BASE_ADDR)->EnableWindow(TRUE);

        bIsChipLocked = FALSE;
        GetDlgItem(IDC_BUTTON_SETTING)->ShowWindow(SW_HIDE);
        GetDlgItem(IDC_COMBO_CONFIG_SEL)->ShowWindow(SW_HIDE);
        GetDlgItem(IDC_RADIO_ERASE)->ShowWindow(SW_HIDE);
        GetDlgItem(IDC_CHECK_CONFIG_START)->ShowWindow(SW_HIDE);

        GetDlgItem(IDC_TXT_CONFIG0)->SetWindowTextW(_T("NA"));
        GetDlgItem(IDC_TXT_CONFIG1)->SetWindowTextW(_T("NA"));
        //m_sMyChipType.cChipName = _T("NUC505");
        //SetDlgItemText(IDC_EDIT_PART_NO,m_sMyChipType.cChipName);
        SetDlgItemText(IDC_EDIT_PART_NO,_T("NUC505"));

        return TRUE;
    } else {
        GetDlgItem(IDC_BUTTON_SETTING)->ShowWindow(SW_SHOW);
        GetDlgItem(IDC_COMBO_CONFIG_SEL)->ShowWindow(SW_SHOW);
        SetDlgItemText(IDC_EDIT_APROM_BASE_ADDR,_T("NA"));
        SetDlgItemText(IDC_EDIT_DATA_BASE_ADDR,_T("NA"));

    }

    CString strTmpDbg;
//�ھ�ID�o��Flash�j�p
#if 0
    if( GetChipInfo() == FALSE ) {
        m_sMyChipType.uFlashSize = 0;
        m_sMyChipType.uRamSize = 0;

        strTmpDbg.Format(_T("Invalid chip ID: %08X"), m_sMyChipType.uChipID);
        MessageBox(strTmpDbg,_T("Error"),MB_OK);
        return FALSE;

    }
#else
    if( GetChipInfo() == FALSE ) {
        m_sMyChipType.uFlashSize = 16 * 1024;
        m_sMyChipType.uRamSize = 0;
        _tcscpy_s(m_sMyChipType.cChipName,_T("Unknown"));
		m_ChipSerial = SERIAL_UNKNOWN;

        m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
        m_sMyChipType.uDataFlashSize = 0;
        m_sMyChipType.uDataFlashStartAddr = m_hexConfig1;
        // m_hexConfig1 = 0x1F000;

        SetDlgItemText(IDC_EDIT_PART_NO,m_sMyChipType.cChipName);

        strTmpDbg.Format(_T("RAM: %d Bytes    APROM: %d Bytes    DataFlash: %d Bytes"),m_sMyChipType.uRamSize,
                     m_sMyChipType.uCodeFlashSize,m_sMyChipType.uDataFlashSize);
        SetDlgItemText(IDC_TXT_PARTNO_INFO,strTmpDbg);

        strTmpDbg.Format(_T("%08X"),m_hexConfig0);
        SetDlgItemText(IDC_TXT_CONFIG0,strTmpDbg);
        strTmpDbg.Format(_T("%08X"),m_hexConfig1);
        SetDlgItemText(IDC_TXT_CONFIG1,strTmpDbg);		
        // strTmpDbg.Format(_T("Invalid chip ID: %08X"), m_sMyChipType.uChipID);
        // MessageBox(strTmpDbg,_T("Error"),MB_OK);
        return TRUE;

    }
#endif

    if (DataFlashType_II() == TRUE) {
        if (m_hexConfig0 & 1) { //Disable Data Flash;
            m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashStartAddr = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashSize = 0;
        } else if (((m_hexConfig0 & 1) == 0) && ((m_hexConfig1 <= 0) ||
                   (m_hexConfig1 > m_sMyChipType.uFlashSize) ||
                   (m_hexConfig1 % 512 != 0))) {
            m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashStartAddr = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashSize = 0;
            m_hexConfig0 |= 1;
            m_hexConfig1 = m_sMyChipType.uFlashSize;
        } else {
            m_sMyChipType.uCodeFlashSize = m_hexConfig1;
            m_sMyChipType.uDataFlashStartAddr = m_hexConfig1;
            m_sMyChipType.uDataFlashSize = m_sMyChipType.uFlashSize - m_hexConfig1;
        }
    } else {
        m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
        m_sMyChipType.uDataFlashSize = 4*1024;
        m_sMyChipType.uDataFlashStartAddr = 0x1F000;
        m_hexConfig1 = 0x1F000;
    }

    SetDlgItemText(IDC_EDIT_PART_NO,m_sMyChipType.cChipName);

    strTmpDbg.Format(_T("RAM: %d Bytes    APROM: %d Bytes    DataFlash: %d Bytes"),m_sMyChipType.uRamSize,
                     m_sMyChipType.uCodeFlashSize,m_sMyChipType.uDataFlashSize);
    SetDlgItemText(IDC_TXT_PARTNO_INFO,strTmpDbg);

    if (!bIsChipLocked) {
        strTmpDbg.Format(_T("Flash size:[%d] \r\nCode flash:[%d] \r\nData flash:[%d]"),
                         m_sMyChipType.uFlashSize,m_sMyChipType.uCodeFlashSize,m_sMyChipType.uDataFlashSize);
        AddToInfOut(strTmpDbg,0,1);
    }
    return TRUE;
}
