/*-----------------------------------------------------------------------------
 *  Nuvoton M0/M4 Chips
 *----------------------------------------------------------------------------*/
#define SERIAL_UNKNOWN			0
#define SERIAL_NUC1XX			1
#define SERIAL_M05X				2
#define SERIAL_NANO1XX			3
#define SERIAL_MINI5X			4
#define SERIAL_NUC100D			5
#define SERIAL_NUC200A			6
#define SERIAL_NUC470			7

#if 0
#define SERIAL_NUCM451			8
#define SERIAL_NUCM452			9
#define SERIAL_NUCM453			10
#define SERIAL_NUCM451M			11
#else
#define SERIAL_M45X				8
#define SERIAL_NUCM451			SERIAL_M45X
#define SERIAL_NUCM452			SERIAL_M45X
#define SERIAL_NUCM453			SERIAL_M45X
#define SERIAL_NUCM451M			SERIAL_M45X
#endif

#define SERIAL_NUC029LAN		12
#define SERIAL_NUC029TAN		13
#define SERIAL_NUC029FDE		14
#define SERIAL_NUC131		    15 
#define SERIAL_M0518			16
#define SERIAL_ISD9XXX			17
#define SERIAL_MINI5XX			18
#define SERIAL_NUC505			19
#define SERIAL_NM1500			20
#define SERIAL_NM1200			21
#define SERIAL_NUC103BN			22

typedef struct{
	UINT uIndex;
	UINT uChipID;
	UINT uRamSize;
	TCHAR cChipName[128];
	UINT uFlashSize;
	UINT uCodeFlashSize;
	UINT uDataFlashSize;
	UINT uDataFlashStartAddr;
	//Any more...

}MY_CHIP_TYPE;

