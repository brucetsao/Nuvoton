// UserConfigDefault.cpp : ��@��
//

#include "stdafx.h"
#include "UserConfigDefault.h"


// UserConfigDefault ��ܤ��

IMPLEMENT_DYNAMIC(UserConfigDefault, CDialog)

UserConfigDefault::UserConfigDefault(CWnd* pParent /*=NULL*/)
	: CDialog(UserConfigDefault::IDD, pParent)
{

}

UserConfigDefault::~UserConfigDefault()
{
}

void UserConfigDefault::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
}


BEGIN_MESSAGE_MAP(UserConfigDefault, CDialog)
	ON_BN_CLICKED(IDOK, &UserConfigDefault::OnBnClickedOk)
END_MESSAGE_MAP()

BOOL UserConfigDefault::OnInitDialog()
{
	CDialog::OnInitDialog();
	CString strTmp;
	strTmp.Format(_T("%X"), m_hexConfig0);
	m_ctlConfig0.SetWindowText(strTmp);
	strTmp.Format(_T("%X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(strTmp);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void UserConfigDefault::OnBnClickedOk()
{
	m_hexConfig0 = m_ctlConfig0.GetValue();
	m_hexConfig1 = m_ctlConfig1.GetValue();
	OnOK();
}

// UserConfigDefault �T���B�z�`��
