// HexEdit.cpp : implementation file
//

#include "stdafx.h"
#include "HexEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHexEdit
BEGIN_MESSAGE_MAP(CHexEdit, CEdit)
	//{{AFX_MSG_MAP(CHexEdit)
	ON_WM_CHAR()
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHexEdit message handlers
//void CHexEdit::OnContextMenu(CWnd* pWnd, CPoint point)
//{
//
//}

CHexEdit::CHexEdit()
{
	bInit = FALSE;
	m_maxLength = 8;
	m_value = 0;
}

CHexEdit::~CHexEdit()
{
}


DWORD CHexEdit::GetValue()
{
	CString str;
	GetWindowText(str);
	TCHAR *pEnd;
	m_value = ::_tcstoul(str, &pEnd, 16);
	return(m_value);
}

int CHexEdit::GetMaxLength()
{
	return(m_maxLength);
}


int CHexEdit::SetMaxLength(int lengthValue)
{
	if (lengthValue <= 0 || lengthValue > 8)
		return(-1);
	else
	{
		m_maxLength = lengthValue;
		LimitText(m_maxLength);
		return(lengthValue);
	}
}

void CHexEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if ( (nChar >= '0') && (nChar <= '9') ||
			(nChar >= 'a') && (nChar <= 'f') ||
			(nChar >= 'A') && (nChar <= 'F') ||
			(nChar == VK_BACK) )
	{
		CEdit::OnChar(nChar, nRepCnt, nFlags);
	}
}


BOOL CHexEdit::PreTranslateMessage(MSG* pMsg) 
{
	if (m_hWnd != 0 && !bInit)
	{
		bInit = TRUE;
		LimitText(m_maxLength);
	}
	return CEdit::PreTranslateMessage(pMsg);
}
