#pragma once
#include "resource.h"
#include "HexEdit.h"
#include "afxwin.h"
#include "afxcmn.h"

// UserConfigDefault ��ܤ��

class UserConfigDefault : public CDialog
{
	DECLARE_DYNAMIC(UserConfigDefault)

public:
	UserConfigDefault(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~UserConfigDefault();
	virtual BOOL OnInitDialog();

	DWORD m_hexConfig0;
	DWORD m_hexConfig1;

	CHexEdit m_ctlConfig0;
	CHexEdit m_ctlConfig1;
	afx_msg void OnBnClickedOk();
// ��ܤ�����
	enum { IDD = IDD_DIALOG_CONFIG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
};
