
// NuvoISPDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"

#include "NuvoISP.h"

#ifdef WINUSB_NUVO_DFU
// Include WinUSB headers
#include <winusb.h>
#include <Usb100.h>
#include <Setupapi.h>
#endif


//#define MSG_TAB_ENABLE 1 //For debug
//#define CHECKSUM_SAVE_ENABLE 1


#define MAX_PACKET 				64
#define FILE_BUFFER				2048
#define MAX_BIN_FILE_SIZE 		(512*1024)


#define BUFSIZE 1024 //max size of incoming data buffer
#define MAXADDRSTR 16

#define DEFAULT_PORT (67) 


/*-----------------------------------------------------------------------------
 *  ISP Commands
 *----------------------------------------------------------------------------*/
#define CMD_SET_CAN_ID			0x000000BB
#define CMD_GET_VERSION     	0x000000A6
#define CMD_UPDATE_APROM		0x000000A0
#define CMD_SYNC_PACKNO			0x000000A4
#define CMD_UPDATE_CONFIG   	0x000000A1
#define CMD_UPDATE_DATAFLASH 	0x000000C3
//#define CMD_UPDATE_DATA1		0x000000C2
//#define CMD_UPDATE_DATA2		0x000000C3
#define CMD_READ_CHECKSUM 		0x000000C8
#define CMD_ERASE_ALL 	    	0x000000A3
#define CMD_GET_APPINFO     	0x000000A8

#define CMD_READ_CONFIG     	0x000000A2
#define CMD_APROM_SIZE      	0x000000AA
#define CMD_GET_DEVICEID    	0x000000B1

#define CMD_WRITE_CHECKSUM  	0x000000C9
#define CMD_GET_FLASHMODE   	0x000000CA
#define CMD_RUN_APROM       	0x000000AB
#define CMD_RUN_LDROM       	0x000000AC

#define CMD_RESEND_PACKET   	0x000000FF
#define CMD_CONNECT         	0x000000AE
#define CMD_DISCONNECT      	0x000000AF

#define PORT_USB 				1
#define PORT_COM 				2
#define PORT_EMAC               3

#define MODE_APROM 				1
#define MODE_LDROM 				2

/*-----------------------------------------------------------------------------
 *  Nuvoton M0/M4 Chips
 *----------------------------------------------------------------------------*/
#define SERIAL_NUC1XX			1
#define SERIAL_M05X				2
#define SERIAL_NANO1XX			3
#define SERIAL_MINI5X			4
#define SERIAL_NUC100D			5
#define SERIAL_NUC200A			6
#define SERIAL_NUC470			7
#define SERIAL_NUCM451			8
#define SERIAL_NUCM452			9
#define SERIAL_NUCM453			10
#define SERIAL_NUCM451M			11
#define SERIAL_NUC029LAN		12
#define SERIAL_NUC029TAN		13
#define SERIAL_NUC029FDE		14
#define SERIAL_NUC131		    15 
#define SERIAL_M0518			16
#define SERIAL_ISD9XXX			17
#define SERIAL_MINI5XX			18


/*-----------------------------------------------------------------------------
 *  Error Code
 *----------------------------------------------------------------------------*/
#define ERR_CODE_LOST_PACKET    -1
#define ERR_CODE_CHECKSUM_ERROR -2
#define ERR_CODE_TIME_OUT       -3
#define ERR_CODE_COM_ERROR_OPEN	-4


/*-----------------------------------------------------------------------------
 *  Project file 
 *----------------------------------------------------------------------------*/
#define PRJ_BIN_OFFSET			1024
#define PRJ_APROM_BIN			"APRM"
#define PRJ_DATA_BIN			"DATF"

/*-----------------------------------------------------------------------------
 *  Mass Production Mode status
 *----------------------------------------------------------------------------*/
#define MP_STATUS_WAIT			0
#define MP_STATUS_CONNECTING	1
#define MP_STATUS_WRITING		2
#define MP_STATUS_PASS			3
#define MP_STATUS_CONN_FAIL		4
#define MP_STATUS_WRITE_FAIL	5



/*-----------------------------------------------------------------------------
 *  Data Structures 
 *----------------------------------------------------------------------------*/

typedef struct{
	    INT  nCmdTotalNum;
        INT  nCmdNum;
		DWORD aCmdList[10];//�ݳB�z��CMD�C��
}MY_CMD_LIST;

typedef struct{
	UINT uIndex;
	UINT uChipID;
	UINT uRamSize;
	TCHAR cChipName[128];
	UINT uFlashSize;
	UINT uCodeFlashSize;
	UINT uDataFlashSize;
	UINT uDataFlashStartAddr;
	//Any more...

}MY_CHIP_TYPE;

typedef struct{
	UINT uCodeFileType; // 0:bin 1:hex
	UINT uCodeFileStartAddr; //hex only
    UINT uCodeFileSize;
	UINT16 uCodeFileCheckSum;
	FILETIME   ftLastCodeFileWriteTime;


	UINT uDataFileType;
	UINT uDataFileStartAddr;
	UINT uDataFileSize;
	UINT16 uDataFileCheckSum;
	FILETIME   ftLastDataFileWriteTime;
}MY_FILE_INFO_TYPE;

// CNuvoISPDlg dialog
class CNuvoISPDlg : public CDialog
{
// Construction
public:
	CNuvoISPDlg(CWnd* pParent = NULL);	// standard constructor
	~CNuvoISPDlg(void){
     DeleteObject(m_editHbr);
	}

// Dialog Data
	enum { IDD = IDD_NUVOISP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonOpenDevice();
	BOOL OpenDeviceUsb();
#ifdef WINUSB_NUVO_DFU
	BOOL OpenDeviceUsb_DFU();
#endif
	BOOL OpenDeviceCom(CString strComNum);
	BOOL OpenDeviceEthernet();
	CButton m_button_open;
	CEdit m_text_message;

	void AddToInfOut(CString InStr, BOOL AddTime, BOOL NewLine);
	void AddToInfOut(char *p, BOOL AddTime, BOOL NewLine);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	CString itos(INT value, INT radix=10);
	afx_msg void OnBnClickedButtonBurnAprom();
	UINT ScanPCCom();
	BOOL CmdToDo(DWORD cmd);

	CString lastConfigFilePath;
    
    
private:

	//�ΨӫO�s��쪺�]�Ƹ��|
	CString MyDevPathName;
	//�ΨӫO�s�]�ƬO�_�w�g���
	BOOL MyDevFound;

	UINT LastErrorNum;

	//�w�q�ܼƥΨӫO�sVID�BPID�B������
	DWORD MyVid,MyPid,MyPvn;

	//�ΨӫO�sŪ�ƾڪ��]�Ʊ���X
	HANDLE hUsbHandle;
	//�ΨӫO�scom ����X
    HANDLE hCom;

#ifdef WINUSB_NUVO_DFU
	WINUSB_INTERFACE_HANDLE  hWinUSBHandle;
#endif
	
	//�o�e���i���w�İϡA1�줸�ճ��iID+8�줸�ճ��i��ơC
	UCHAR WriteReportBuffer[256];
	UCHAR FileBuffer[FILE_BUFFER];

	//�������i���w�İϡA1�줸�ճ��iID+8�줸�ճ��i��ơC
	UCHAR ReadReportBuffer[256];


	//�ɳ̤j128k,�]�AHex�নBin����
	//UCHAR CodeFileBuffer[MAX_BIN_FILE_SIZE];
	//UCHAR DataFileBuffer[MAX_BIN_FILE_SIZE];

	unsigned short gcksum;


	//���b�o�e��ƪ��лx
	BOOL DataInSending;
	//���VŪ���i�u�{������
    CWinThread * pReadReportThread;
    //���V�g���i�u�{������
    CWinThread * pWriteReportThread;

	//�o�e���i�Ϊ�OVERLAPPED�C
	OVERLAPPED WriteOverlapped;
	//�������i�Ϊ�OVERLAPPED�C
	OVERLAPPED ReadOverlapped;

	//�Τ��ܥ��}USB�٬OCOM
	UINT uCurPortSelected;
    
	 
	CString m_strCurExePath;
	CString m_strCodeFilePath;
	CString m_strCodeFilePath_saved;
	CString m_strDataFilePath;
	CString m_strDataFilePath_saved;

	CString m_strWindowsAppDataPath;

	DWORD m_hexConfig0;
	DWORD m_hexConfig1;
	DWORD m_hexConfig2;
	DWORD m_hexConfig0_saved;
	DWORD m_hexConfig1_saved;
	DWORD m_hexConfig2_saved;
	DWORD m_hexConfig0_last; //�O�s�bini���ت��t�m
	DWORD m_hexConfig1_last;
	DWORD m_hexConfig2_last;
	DWORD m_hexConfig0_last_saved;
	DWORD m_hexConfig1_last_saved;
	DWORD m_hexConfig2_last_saved;


	CString m_strConnectPort_last_saved;

	BYTE m_IspVersion;
	BOOL m_bIsFirstInit;

	DWORD m_uBurnMode;
	DWORD m_uBurnMode_last; //�W�����N���覡
	DWORD m_uBurnMode_last_saved; 

	DWORD m_curCmd;
	MY_CMD_LIST m_sMyCmdList;
	MY_CHIP_TYPE m_sMyChipType;
	MY_FILE_INFO_TYPE m_sMyFileInfo;

	BOOL bCodeFlagErrorColorEnable;
	BOOL bDataFlagErrorColorEnable;
	UINT uTxtFontColor;
	BOOL bIsChipLocked;

	CFont m_Font;
	CFont m_Font_ShowData;
	CRect m_MainRect; 

	DWORD ISP_RESERVED_SIZE; //CMD_WRITE_CHECKSUM �\��}�Үɬ�8,�_�h��0
	UINT m_FlashMode;
	UINT m_ChipSerial;

	CString m_sTitleString;

	BOOL bDetecting;
	BOOL bDetectingSaved;

	
	BOOL bIsConfigLoad;
	BOOL bIsCanInterface;
	
	BOOL m_bIsProjectFileLoaded;	// Project file is loaded.
	BOOL m_bIsMPModeEnabled;		// Mass Production mode is enabled
	CString m_ProjectFilePath;
	int  m_MP_Mode_Status;

	HBRUSH  m_editHbr;

private:
	BOOL ReadData(BOOL bUSB);
	BOOL WriteData(BOOL bUSB);
	BOOL WriteDataTest();
	unsigned short Checksum (unsigned char *buf, int len);
	BOOL CmdGetCheckSum(BOOL bUSB, int start, int len, unsigned short *cksum);
	BOOL CmdSetCheckSum(BOOL bUSB, unsigned short checksum, int len);
	friend UINT TransferThread(LPVOID pParam);
	void CheckFileSize(UINT8 index);
	BOOL GetChipInfo();
	BOOL DataFlashType_II();
	BOOL GetFileInfo(LPCTSTR filename,BOOL bCodeFile,MY_FILE_INFO_TYPE *fileInfo);
#ifdef PORJ_SAVE_ALL
	BOOL GetFileInfoFromConfig(LPCTSTR filename, MY_FILE_INFO_TYPE *fileInfo);
#endif
	BOOL HexToBin(LPCTSTR filename,UINT nMaxBufSize,BOOL bCodeFile,MY_FILE_INFO_TYPE *fileInfo);
	CString CreateBlank(INT num);
	void ShowBinFile(UCHAR *fileBuf,BOOL bCodeFile,UINT fileSize);
	unsigned long HexStringToDec(TCHAR *buf, UINT len);
	int m_nHotKeyID[10];

public:

    // UDP
	sockaddr_in sin , Recv_addr; 

	BOOL enabled;
	int sockaddrlen;
	int recv_len;
	SOCKET sclient;
	WORD socketVersion;  
	WSADATA wsaData;



    OVERLAPPED Overlapped;
    
    


	LPSTR ConvertErrorCodeToString(DWORD ErrorCode);
	BOOL CmdWriteAndReadOne(int DevInterface, DWORD cmd);
	BOOL CmdSetCanId(int DevInterface);
	BOOL CmdSyncPackno(int DevInterface);
	int InterfaceSelect();
	BOOL UpdateConfig(int DevInterface);
	BOOL CmdChipConnection(int DevInterface);
	BOOL EraseAllChip(int DevInterface);
	BOOL UpdateChipInfo();	
	void UpdateSizeInfo(BOOL bCheckChangeFirst);
	BOOL DetectDevice(int DevInterface);
	void RunApRom(int DevInterface);
	void SaveBurnMode(CString filename);
	BOOL GetConnectionType(CString filename);
	void LoadProjectFile(CString filename);
	BOOL ChangeBurenMode(DWORD mode);

	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonClose();
	CProgressCtrl m_writeProgress;
//	afx_msg void OnBnClickedOk();

	afx_msg void OnBnClickedButtonSetting();
	afx_msg void OnBnClickedButtonUpdateConfig();
	CComboBox m_ctrComBox;
    afx_msg LRESULT  OnDeviceChange(WPARAM  nEventType, LPARAM  dwData );
	CEdit m_ctlEditCodeFile;
	CEdit m_ctlEditDataFile;
	afx_msg void OnBnClickedButtonCodeFile();
	afx_msg void OnBnClickedButtonDataFile();
	CComboBox m_ctlConfigSel;
//	afx_msg void OnCbnSelchangeComboPartNo();
	afx_msg void OnCbnSelchangeComboCom();
	afx_msg void OnEnChangeEdit4();
	afx_msg void OnEnChangeEditCodeSum();
	CTabCtrl m_tab;
	CRichEditCtrl m_text_aprom;
	CRichEditCtrl m_text_dataflash;
	afx_msg void OnTcnSelchangeTabFileHex(NMHDR *pNMHDR, LRESULT *pResult);
//	afx_msg void OnEnKillfocusEditPartNo();
//	afx_msg void OnEnChangeEditPartNo();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnBnClickedRadioNvm();
	afx_msg void OnBnClickedCheckConfigStart();
	afx_msg void OnBnClickedRadioAprom();
	afx_msg void OnBnClickedRadioApromNvm();
	afx_msg void OnBnClickedRadioErase();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnBnClickedCheckSaveChecksum();
	afx_msg LONG OnHotKey(WPARAM wParam, LPARAM lParam);
	afx_msg void OnCbnSelchangeComboConfigSel();
	afx_msg void OnFileOpenIsp();
	afx_msg void OnFileSaveIsp();
	afx_msg void OnAboutVersion();
	afx_msg void OnBnClickedCheckCan();
	afx_msg void OnEnChangeEditApromBaseAddr();
	afx_msg void OnEnChangeEditMessage();
	

	
	afx_msg void OnBnClickedRadioDevusb();
	afx_msg void OnBnClickedRadioDevcom();
};
