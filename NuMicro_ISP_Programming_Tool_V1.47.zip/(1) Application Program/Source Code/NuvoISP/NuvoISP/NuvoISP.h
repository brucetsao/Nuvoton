
// NuvoISP.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"				// main symbols

//#define DEBUG_EMULATE

//#define IS_MP_VER				// if defined, is mass production version

#define PORJ_SAVE_ALL

//#define WINUSB_NUVO_DFU

/*----------------------------------------------------------
 *  Customization
 *---------------------------------------------------------*/
//#define FOR_CORETRONIC


#define CONFIG0_DEFAULT_VALUE 0xFFFFFF7F
#define CONFIG1_DEFAULT_VALUE 0x1F000


// CNuvoISPApp:
// See NuvoISP.cpp for the implementation of this class
//

class CNuvoISPApp : public CWinApp
{
public:
	CNuvoISPApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CNuvoISPApp theApp;