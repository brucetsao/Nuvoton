
// NuvoISPDlg.cpp : implementation file
//

#include "stdafx.h"
#include <strsafe.h>

#include <winsock2.h>
#include <ws2tcpip.h>
#include <conio.h>

#include "NuvoISP.h"
#include "NuvoISPDlg.h"

#include "Config_Dialog/HelpUARTPin.h"
#include "dbt.h"

#include "NuvoISPCmd.h"

#ifdef PORJ_SAVE_ALL
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <share.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#endif

#ifdef WINUSB_NUVO_DFU

// Linked libraries
#pragma comment (lib , "setupapi.lib" )
#pragma comment (lib , "winusb.lib" )

// Constant for {AA75740D-F7C8-4417-99D1-28C11E23B70F}
static const GUID DFU_DEVICE_INTERFACE =
{ 0xaa75740d, 0xf7c8, 0x4417, { 0x99, 0xd1, 0x28, 0xc1, 0x1e, 0x23, 0xb7, 0x0f } };

#endif	// WINUSB_NUVO_DFU

extern "C" {
#include "hidsdi.h"
#include "setupapi.h"
}

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace std;

/*
  �Ψӵ��U�]�Ƴq���ƥ�Ϊ��s�������C
  �n�ϥθӵ��c��A�ݭn�bStdAfx.h���N�W�[�y�y#define WINVER 0x0500
*/
DEV_BROADCAST_DEVICEINTERFACE DevBroadcastDeviceInterface;


static int g_debug = 0;
static BOOL bActivateExitNow=TRUE;
static DWORD g_ErrorCode = 0;
CString strWhichCom;

CNuvoISPDlg *pDlg;


UCHAR CodeFileBuffer[MAX_BIN_FILE_SIZE];
UCHAR DataFileBuffer[MAX_BIN_FILE_SIZE];


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ConvertErrorCodeToString                                                              	   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ഫ���~�N�X���r��                           										   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 ErrorCode	   	  	  -[in]   ���~�N�X                                                     */
/* Returns:                                                                                                */
/*               ���~�N�X�����r��                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
LPSTR CNuvoISPDlg::ConvertErrorCodeToString(DWORD ErrorCode)
{
    HLOCAL LocalAddress=NULL;
    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_IGNORE_INSERTS|FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,ErrorCode,0,(PTSTR)&LocalAddress,0,NULL);

    return (LPSTR)LocalAddress;
}





/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ScanPCCom                                                                         	       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �q���U�������y�t�ΩҦ�����f�]�ơA�å[��U�ԥ\�����         							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               ���y�쪺��f�]�Ƽƥ�                                                                      */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
UINT CNuvoISPDlg::ScanPCCom()
{

    UINT nComNum = 0;
    HKEY hKEY;
    LONG hResult = ::RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("HARDWARE\\DEVICEMAP\\SERIALCOMM"), 0, KEY_READ, &hKEY);

    if(hResult != ERROR_SUCCESS) { //�p�G�L�k���}hKEY,�h����{��������
        //AfxMessageBox("���~�G�L�k���}�������U����");
        return  0 ;
    }

    TCHAR strInf[30];
    DWORD type_1 = REG_SZ;
    DWORD cbData_1 = 10;
    DWORD aa=30, num = 0, a1, a2, a3, a4, a5, a6, a7;

    hResult = ::RegQueryInfoKey(hKEY, strInf, &a7, NULL, &a3, &a1, &a2, &num, &a4, &a5, &a6, NULL);

    if(hResult != ERROR_SUCCESS) { //�p�G�L�k���}hKEY,�h����{��������
        //AfxMessageBox("���~�G�L�k���}�������U����");
        RegCloseKey(hKEY);
        return   0;
    }

    BYTE portName[30];
    CString csr;
    for(DWORD i = 0 ; i < num ; i++) {
        aa = 30 ;
        cbData_1 = 30;
        hResult = ::RegEnumValue(hKEY, i, strInf, &aa, NULL, &type_1, portName, &cbData_1);
        if((hResult != ERROR_SUCCESS)&&(hResult != ERROR_MORE_DATA)) { //�p�G�L�k���}hKEY,�h����{��������
            //AfxMessageBox("���~�G�L�k����������U����");
            continue;
        }
        csr.Format(_T("%s"), portName);
        m_ctrComBox.AddString(csr);
        nComNum++;

    }
    RegCloseKey(hKEY);

#if 0
    if(nComNum > 0) {
        csr.Format(_T("Find %d ports"),nComNum);
        AddToInfOut(csr,0,1);
    }

#endif
    return nComNum;
}




/*---------------------------------------------------------------------------------------------------------*/
/* Function:     AddToInfOut                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �N��J�r��K�[���T�奻��                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 InStr	   	  	  -[in]   ��J�r��ACString����                                          */
/*				 AddTime	   	  -[in]   �O�_�K�[�ɶ���T:TURE/FALSE                                      */
/*				 NewLine	   	  -[in]   �O�_�j���:TURE/FALSE                                          */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::AddToInfOut(CString InStr, BOOL AddTime, BOOL NewLine)
{
    CString str,str1;
    CHAR SysTime[10];
    //UINT nLineNumber;


    //nLineNumber=((CEdit*)GetDlgItem(IDC_EDIT_MESSAGE))->GetLineCount();
    str = InStr; //zmsong add

    //�ݭn�K�[�ɶ���T
    if(AddTime==TRUE) {
        _strtime_s(SysTime);
        str1=SysTime;
        str1=_T(" (")+str1+_T(")");
        str+=str1;
    }

    //�ݭn����
    if(NewLine==TRUE) {
        str+=_T("\r\n");

    }

    //�]�m�s���奻
    //SetDlgItemText(IDC_EDIT_MESSAGE,str); //zmsong del

    ((CEdit*)GetDlgItem(IDC_EDIT_MESSAGE))->SetSel(-1,-1); //zmsong add
    ((CEdit*)GetDlgItem(IDC_EDIT_MESSAGE))->ReplaceSel(str); //zmosng add
}


/*
  �����W�z��ơA�J�f�ѼƤ��@��
*/
void CNuvoISPDlg::AddToInfOut(char *p, BOOL AddTime, BOOL NewLine)
{
    CString str;
    str.Format(_T("%s"),p);
    AddToInfOut(str,AddTime,NewLine);
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     Checksum                                                              	                   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �p�⵹�w�r�ꪺChecksum��                           								       */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 buf	   	  	  -[in]   ��J�r��                                                       */
/*				 len	   	      -[in]   �r�����                                                       */
/* Returns:                                                                                                */
/*               checksum��                                                                                */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
unsigned short CNuvoISPDlg::Checksum (unsigned char *buf, int len)
{
    int i;
    unsigned short c;

    for (c=0, i=0; i < len; i++) {
        c += buf[i];
    }
    return (c);
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ReadData                                                              	                   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �qUSB/��f/Ethernet Ū����ơAŪ������Ʃ�b�T�w����m:ReadReportBuffer                 */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 DevInterface	   	  	  -[in]   �s���������O���@��                                      */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::ReadData(int DevInterface)
{
    BOOL Result;
    unsigned long nRead;
    UINT LastError, len;
    CString Str;
    unsigned short lcksum;
    HANDLE hRead;
    UCHAR *pBuf;
//	DWORD waitRet;
    static int debugcn;
    UINT uWaitProgress;
    DWORD tick1,tick2,timeout;
    UINT curPacketNo=0;
    int i;
    COMSTAT ComStat;
    DWORD dwErrorFlags;

    g_ErrorCode = 0;

    if (DevInterface == PORT_USB) {
        len = MAX_PACKET+1;
        hRead = hUsbHandle;
    } else {
        len = MAX_PACKET;
        hRead = hCom;
    }
    memset(ReadReportBuffer,0,sizeof(ReadReportBuffer));
    ResetEvent(ReadOverlapped.hEvent);
    ReadOverlapped.Offset = 0;
    ReadOverlapped.OffsetHigh = 0;

#if 0	// ychuang, 2012.12.09 - to shorten time-out
    if (((m_curCmd == CMD_UPDATE_APROM) || (m_curCmd == CMD_UPDATE_DATAFLASH) ||
    (m_curCmd == CMD_ERASE_ALL)) && (g_packno==4))
        timeout = 5500; //ms  (256 * 20ms = 5120 ms)
    else
        timeout = 1000;
#else
    //Time out
    if ((m_curCmd == CMD_UPDATE_DATAFLASH) ||
    (m_curCmd == CMD_UPDATE_APROM) ||
    (m_curCmd == CMD_ERASE_ALL)) 			// need longer time to wait flash erase
        timeout = 20000; //ms
    else
        timeout = 5000;
#endif

    if((m_ChipSerial == SERIAL_NUC505) && (timeout == 20000))
        timeout = 50000;

    if (bDetectingSaved) {
        timeout = 20;
    }

//Progress
    if (m_curCmd == CMD_UPDATE_CONFIG)
        uWaitProgress = 160;
    else if ((m_curCmd == CMD_UPDATE_APROM) || (m_curCmd == CMD_UPDATE_DATAFLASH) ||
    (m_curCmd == CMD_ERASE_ALL))
        uWaitProgress = 500;

    tick1 = ::GetTickCount();

    if(DevInterface == PORT_EMAC) {
        recvfrom(sclient, (char *)ReadReportBuffer, len, 0, (struct sockaddr*)&Recv_addr, &recv_len);
        //recvfrom(sclient, (char *)pBuf, len, 0, (struct sockaddr*)&Recv_addr, &recv_len);
        g_packno++;
        return TRUE;
    }


    while(1) {
        pBuf = ReadReportBuffer;
        if (DevInterface == PORT_COM)
            ClearCommError(hRead,&dwErrorFlags,&ComStat);

#ifdef WINUSB_NUVO_DFU
        if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
            WINUSB_SETUP_PACKET SetupPacket;

            len = 64;
            ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
            //Create the setup packet
            SetupPacket.RequestType = 0xA1;
            SetupPacket.Request = 0x2;			// DFU_UPLOAD
            SetupPacket.Value = 0;				// wBlockNum
            SetupPacket.Index = 0; 				// Interface
            SetupPacket.Length = 64;
            nRead = 0;
            Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, pBuf+1, 64, &nRead, 0);
            if (nRead != 64)
                Result = FALSE;
        } else {
            Result = ReadFile(hRead,
            pBuf,
            len,
            &nRead,
            &ReadOverlapped);
        }

        if (Result == FALSE) {
            LastError = GetLastError();

            if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE))
                LastError = ERROR_IO_PENDING;

            if (LastError == ERROR_IO_PENDING) {
                ResetEvent(ReadOverlapped.hEvent);

                do {
                    if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
                        WINUSB_SETUP_PACKET SetupPacket;

                        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
                        //Create the setup packet
                        SetupPacket.RequestType = 0xA1;
                        SetupPacket.Request = 0x2;			// DFU_UPLOAD
                        SetupPacket.Value = 0;				// wBlockNum
                        SetupPacket.Index = 0; 				// Interface
                        SetupPacket.Length = 64;
                        nRead = 0;
                        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, pBuf+1, 64, &nRead, 0);
                        if (nRead != 64)
                            Result = FALSE;
                    } else {
                        Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
                    }

                    if (Result)
                        break;
#else
        Result = ReadFile(hRead,
        pBuf,
        len,
        &nRead,
        &ReadOverlapped);
        if (Result == FALSE) {
            LastError = GetLastError();
            if (LastError == ERROR_IO_PENDING) {
                ResetEvent(ReadOverlapped.hEvent);

                do {
                    Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
                    if (Result)
                        break;
#endif
                    //Progress
                    if ((m_curCmd == CMD_UPDATE_CONFIG) && (g_packno == 4)) {
                        //20% - 100%
                        m_writeProgress.SetPos(uWaitProgress/8);
                        uWaitProgress ++;
                        if (uWaitProgress >= 800)
                            uWaitProgress = 800;

                        SleepEx(10,TRUE);
                    } else if (((m_curCmd == CMD_UPDATE_APROM) ||
                    (m_curCmd == CMD_UPDATE_DATAFLASH) ||
                    (m_curCmd == CMD_ERASE_ALL)) &&
                    (g_packno==4)) {
                        if (m_writeProgress.GetPos() != uWaitProgress/30)
                            m_writeProgress.SetPos(uWaitProgress/100); //5% - 20%
                        uWaitProgress ++;
                        if (uWaitProgress >= 2000)
                            uWaitProgress = 2000;

                        SleepEx(10,TRUE);
                    }

                    //Time out
                    tick2 = ::GetTickCount();
                    if ((tick2 - tick1) > timeout) {
                        if (DevInterface == PORT_COM)
                            PurgeComm( hCom, PURGE_RXABORT | PURGE_RXCLEAR );

                        if (!bDetectingSaved) {
                            //if(!bUSB)//clyu
                            //	PurgeComm( hCom, /*PURGE_RXABORT |*/ PURGE_RXCLEAR );
                            AddToInfOut(_T("Time out[Read PENDING]"),1,1);
                            MessageBox(_T("Time out!"),_T("Error"),MB_OK);
                        }
                        g_ErrorCode = ERR_CODE_TIME_OUT;
                        return FALSE;
                    }

                } while (Result == FALSE);
#if 0
                if( (m_curCmd == CMD_GET_VERSION) || (m_curCmd == CMD_SYNC_PACKNO) )
                    waitRet = WaitForSingleObject(ReadOverlapped.hEvent,  2000);//unit ms//INFINITE
                else
                    waitRet = WaitForSingleObject(ReadOverlapped.hEvent,  20000);//unit ms//INFINITE
                ResetEvent(ReadOverlapped.hEvent);
                //clear the error
                SetLastError(0);
                if(waitRet == WAIT_TIMEOUT) {
                    pDlg->AddToInfOut(_T("Device no response"),1,1);
                    return FALSE;
                }
#endif

            } else if (LastError != 0) {
                pDlg->AddToInfOut(pDlg->itos(debugcn,10)+_T("Failed to read data,error code:")+pDlg->itos(LastError,10),1,1);
                if (DevInterface == PORT_COM) { //Reset
                    if(!OpenDeviceCom(strWhichCom)) {
                        g_ErrorCode = ERR_CODE_COM_ERROR_OPEN;
                        SetLastError(0);
                        return FALSE;
                    }
                }
                return FALSE;
            }
        }


#ifdef WINUSB_NUVO_DFU
        if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
            nRead = 64;
        } else {
            ResetEvent(ReadOverlapped.hEvent);
            Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
        }
#else
        ResetEvent(ReadOverlapped.hEvent);
        Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
#endif

        // 2013.08.11 - Y.C.Huang
        // May read zero bytes data
        if ((Result == TRUE) && (nRead == 0))
            continue;

        if (Result == TRUE) {
            if (nRead < len) {
                pDlg->AddToInfOut(_T("Wrong size:")+pDlg->itos(nRead,10) + _T(" ") + pDlg->itos(len,10),1,1);//ReadOverlapped.InternalHigh
                g_ErrorCode = ERR_CODE_LOST_PACKET;
                g_packno++;
                return FALSE;

                //test
                //ResetEvent(ReadOverlapped.hEvent);
                //pBuf += nRead;
                //len -= nRead;
                //continue;

            }
        } else {
            LastError=GetLastError();
            pDlg->AddToInfOut(_T("GetOverlappedResult error")+pDlg->itos(LastError,10),1,1);
            return FALSE;
        }

        if (DevInterface == PORT_USB) {
            //len = MAX_PACKET+1;//test
            memcpy(&lcksum, pBuf+1, 2);
            pBuf += 5;
        } else {
            //len = MAX_PACKET; //test
            memcpy(&lcksum, pBuf, 2);
            pBuf += 4;
        }

        memcpy(&curPacketNo, pBuf, 4);
        if (curPacketNo != g_packno) {
//Progress
            if ( (( m_curCmd == CMD_UPDATE_CONFIG)||( m_curCmd == CMD_ERASE_ALL)) && (g_packno == 4) ) {
                //20% - 100%
                m_writeProgress.SetPos(uWaitProgress/8);
                uWaitProgress ++;
                if(uWaitProgress >= 800)
                    uWaitProgress = 800;

            } else if ( (( m_curCmd == CMD_UPDATE_APROM) || (m_curCmd == CMD_UPDATE_DATAFLASH)) && (g_packno==4) ) {
                if (m_writeProgress.GetPos() != uWaitProgress/30)
                    m_writeProgress.SetPos(uWaitProgress/100); //5% - 20%
                uWaitProgress ++;
                if (uWaitProgress >= 2000)
                    uWaitProgress = 2000;

            }

            tick2 = ::GetTickCount();
            if( (tick2 - tick1) > timeout ) {
                if (DevInterface == PORT_COM)
                    PurgeComm( hCom, PURGE_RXABORT | PURGE_RXCLEAR );

                if (!bDetectingSaved) {
                    AddToInfOut(_T("Time out[Read]"),1,1);
                    MessageBox(_T("Time out!"),_T("Error"),MB_OK);
                }
                g_ErrorCode = ERR_CODE_TIME_OUT;
                return FALSE;
            } else
                continue;
        } else {
            if(lcksum != gcksum) {
                Str=_T("Checksum error:");
                for(i=len-1; i>=0; i--) {
                    Str+=pDlg->itos(ReadReportBuffer[i],16).Right(2)+_T(" ");
                }
                Str+=_T("gcksum=")+pDlg->itos(gcksum,16).Right(4)+_T(" ");

                pDlg->AddToInfOut(Str,FALSE,TRUE);
                g_ErrorCode = ERR_CODE_CHECKSUM_ERROR;
                g_packno++;
                return FALSE;
            }

            if( ( m_curCmd == CMD_UPDATE_APROM) && (g_packno==4) )
                AddToInfOut(_T("Erase success,sending next packet..."),1,1);



            g_packno++;
            break;
        }
    }
    debugcn++;

    return TRUE;
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     WriteData                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��USB/��f/Ethernet�g�J��ơA�ݼg�J��Ʀ�m��:WriteReportBuffer                          */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 DevInterface	   	  	  -[in]   �s���������O���@��                                      */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

BOOL CNuvoISPDlg::WriteData(int DevInterface)
{
    BOOL Result;
    unsigned long written;
    UINT LastError, len;
    CString Str;
    HANDLE hWrite;
    UCHAR	*pBuf;
    DWORD waitRet;
    COMSTAT ComStat;
    DWORD dwErrorFlags;

    ResetEvent(WriteOverlapped.hEvent);
    WriteOverlapped.Offset = 0;
    WriteOverlapped.OffsetHigh = 0;
    g_ErrorCode = 0;

    if (DevInterface == PORT_USB) {
        pBuf = WriteReportBuffer;
        len = MAX_PACKET+1;
        hWrite = hUsbHandle;
    } else {
        pBuf = WriteReportBuffer + 1;
        len = MAX_PACKET;
        hWrite = hCom;
    }

    gcksum = Checksum(WriteReportBuffer+1, MAX_PACKET);

    if (DevInterface == PORT_COM)
        ClearCommError(hWrite,&dwErrorFlags,&ComStat);

    if(DevInterface == PORT_EMAC) {
        sendto(sclient, (const char*)pBuf, len,0,(struct sockaddr*)&sin, len);
        return TRUE;
    }

#ifdef WINUSB_NUVO_DFU
    if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
        WINUSB_SETUP_PACKET SetupPacket;
        UCHAR	status_buff[6];
        ULONG 	cbSent = 0;

        pBuf = WriteReportBuffer+1;
        len = MAX_PACKET;

        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
        //Create the setup packet
        SetupPacket.RequestType = 0x21;
        SetupPacket.Request = 0x1;			// DFU_DNLOAD
        SetupPacket.Value = 0;				// wBlockNum
        SetupPacket.Index = 0; 				// Interface
        SetupPacket.Length = len;
        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, pBuf, len, &cbSent, 0);
        if (!Result)
            return FALSE;

        /*
         *  DFU_GETSTATUS to make DFU device enter dfuDNLOAD_IDLE state
         */
        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
        //Create the setup packet
        SetupPacket.RequestType = 0xA1;
        SetupPacket.Request = 0x3;			// DFU_GETSTATUS
        SetupPacket.Value = 0;
        SetupPacket.Index = 0; 				// Interface
        SetupPacket.Length = 6;
        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, &status_buff[0], 6, &cbSent, 0);
        if (!Result)
            return FALSE;

        /*
         *  Send 0 bytes DFU_DNLOAD to complete it.
         */
        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
        //Create the setup packet
        SetupPacket.RequestType = 0x21;
        SetupPacket.Request = 0x1;			// DFU_DNLOAD
        SetupPacket.Value = 1;				// wBlockNum
        SetupPacket.Index = 0; 				// Interface
        SetupPacket.Length = 0;
        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, NULL, 0, NULL, 0);
        if (!Result)
            return FALSE;

        return TRUE;
    } else
#endif	// WINUSB_NUVO_DFU

        Result=WriteFile(hWrite,
        pBuf,
        len,
        &written,
        &WriteOverlapped);
    if (Result == 0) {
        LastError=GetLastError();
        if (LastError==ERROR_IO_PENDING) {
            waitRet = WaitForSingleObject(WriteOverlapped.hEvent, 1000 ); // 1sec
            if(waitRet == WAIT_TIMEOUT) {
                AddToInfOut(_T("Timeout[Write PENDING]"),1,1);
                if (DevInterface == PORT_COM)
                    PurgeComm( hCom, PURGE_TXABORT | PURGE_TXCLEAR );

                return FALSE;
            }

            ResetEvent(WriteOverlapped.hEvent);
            //clear the error
            SetLastError(0);
        } else if (LastError != 0) {
            pDlg->AddToInfOut(pDlg->itos(g_debug,10)+_T("Failed to write data,error code:")+pDlg->itos(LastError,10),1,1);
            if (DevInterface == PORT_COM) { //Reset COM
                //PurgeComm( hCom, PURGE_TXABORT | PURGE_TXCLEAR );
                if(!OpenDeviceCom(strWhichCom)) {
                    g_ErrorCode = ERR_CODE_COM_ERROR_OPEN;
                    SetLastError(0);
                    return FALSE;
                }

            }
            //ExceptionHandle(wndHandle, LastError);
            return FALSE;
        }
    }
    //FlushFileBuffers(hWrite);

    //pDlg->AddToInfOut(pDlg->itos(g_debug,10) + _T(" write success"),1,1);
    g_debug++;

    return TRUE;

}




CNuvoISPDlg::CNuvoISPDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CNuvoISPDlg::IDD, pParent)
{
// CNuvoISPDlg dialog
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    //��l���ܼ�
    MyDevPathName=_T("");
    MyDevFound=FALSE;
    MyVid=8888;
    MyPid=0006;
    MyPvn=0100;

    hUsbHandle = INVALID_HANDLE_VALUE;
    hCom = INVALID_HANDLE_VALUE;
#ifdef WINUSB_NUVO_DFU
    hWinUSBHandle = INVALID_HANDLE_VALUE;
#endif
    DataInSending=FALSE;
    m_curCmd = 0;
    bCodeFlagErrorColorEnable = FALSE;
    bDataFlagErrorColorEnable = FALSE;
    bIsChipLocked = FALSE;

    memset(&m_sMyFileInfo,0,sizeof(MY_FILE_INFO_TYPE));
    memset(&m_sMyChipType,0,sizeof(MY_CHIP_TYPE));
    //lstrcpy(m_sMyChipType.cChipName,_T("Unknown"));
    _tcscpy_s(m_sMyChipType.cChipName,_T("Unknown"));
	
    uTxtFontColor = 0;
    bDetecting = FALSE;

    m_editHbr = CreateSolidBrush(RGB(0,0,0));



}



void CNuvoISPDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_BUTTON_OPEN_DEVICE, m_button_open);
    DDX_Control(pDX, IDC_EDIT_MESSAGE, m_text_message);
    DDX_Control(pDX, IDC_PROGRESS1, m_writeProgress);
    DDX_Control(pDX, IDC_COMBO_COM, m_ctrComBox);
    DDX_Control(pDX, IDC_EDIT_CODE_FILE, m_ctlEditCodeFile);
    DDX_Control(pDX, IDC_EDIT_DATA_FILE, m_ctlEditDataFile);
    DDX_Control(pDX, IDC_COMBO_CONFIG_SEL, m_ctlConfigSel);
    DDX_Control(pDX, IDC_TAB_FILE_HEX, m_tab);
    DDX_Control(pDX, IDC_RICHEDIT_APROM, m_text_aprom);
    DDX_Control(pDX, IDC_RICHEDIT_FLASHDATA, m_text_dataflash);
}

BEGIN_MESSAGE_MAP(CNuvoISPDlg, CDialog)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    //}}AFX_MSG_MAP
    ON_BN_CLICKED(IDC_BUTTON_OPEN_DEVICE, &CNuvoISPDlg::OnBnClickedButtonOpenDevice)
    ON_WM_SHOWWINDOW()
    ON_BN_CLICKED(IDC_BUTTON_BURN_APROM, &CNuvoISPDlg::OnBnClickedButtonBurnAprom)
    ON_WM_CTLCOLOR()
    ON_BN_CLICKED(IDC_BUTTON_SETTING, &CNuvoISPDlg::OnBnClickedButtonSetting)
    ON_MESSAGE(WM_DEVICECHANGE, &CNuvoISPDlg::OnDeviceChange)
    ON_BN_CLICKED(IDC_BUTTON_CODE_FILE, &CNuvoISPDlg::OnBnClickedButtonCodeFile)
    ON_BN_CLICKED(IDC_BUTTON_DATA_FILE, &CNuvoISPDlg::OnBnClickedButtonDataFile)
    ON_CBN_SELCHANGE(IDC_COMBO_COM, &CNuvoISPDlg::OnCbnSelchangeComboCom)
    ON_EN_CHANGE(IDC_EDIT4, &CNuvoISPDlg::OnEnChangeEdit4)
    ON_EN_CHANGE(IDC_EDIT_CODE_SUM, &CNuvoISPDlg::OnEnChangeEditCodeSum)
    ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_FILE_HEX, &CNuvoISPDlg::OnTcnSelchangeTabFileHex)
    //ON_EN_CHANGE(IDC_EDIT_PART_NO, &CNuvoISPDlg::OnEnChangeEditPartNo)
    ON_WM_SYSCOMMAND()
    ON_BN_CLICKED(IDC_RADIO_NVM, &CNuvoISPDlg::OnBnClickedRadioNvm)
    ON_BN_CLICKED(IDC_CHECK_CONFIG_START, &CNuvoISPDlg::OnBnClickedCheckConfigStart)
    ON_BN_CLICKED(IDC_RADIO_APROM, &CNuvoISPDlg::OnBnClickedRadioAprom)
    ON_BN_CLICKED(IDC_RADIO_APROM_NVM, &CNuvoISPDlg::OnBnClickedRadioApromNvm)
    ON_BN_CLICKED(IDC_RADIO_ERASE, &CNuvoISPDlg::OnBnClickedRadioErase)
    ON_WM_SETCURSOR()
    ON_WM_ACTIVATE()
    ON_BN_CLICKED(IDC_CHECK_SAVE_CHECKSUM, &CNuvoISPDlg::OnBnClickedCheckSaveChecksum)
    ON_MESSAGE(WM_HOTKEY, OnHotKey)
    ON_CBN_SELCHANGE(IDC_COMBO_CONFIG_SEL, &CNuvoISPDlg::OnCbnSelchangeComboConfigSel)
    ON_COMMAND(ID_FILE_OPEN_ISP, &CNuvoISPDlg::OnFileOpenIsp)
    ON_COMMAND(ID_FILE_SAVE_ISP, &CNuvoISPDlg::OnFileSaveIsp)
    ON_COMMAND(ID_ABOUT_VERSION, &CNuvoISPDlg::OnAboutVersion)
    ON_BN_CLICKED(IDC_CHECK_CAN, &CNuvoISPDlg::OnBnClickedCheckCan)
    ON_EN_CHANGE(IDC_EDIT_APROM_BASE_ADDR, &CNuvoISPDlg::OnEnChangeEditApromBaseAddr)
    ON_EN_CHANGE(IDC_EDIT_MESSAGE, &CNuvoISPDlg::OnEnChangeEditMessage)
	ON_BN_CLICKED(IDC_RADIO_DEVUSB, &CNuvoISPDlg::OnBnClickedRadioDevUsb)
	ON_BN_CLICKED(IDC_RADIO_DEVEMAC, &CNuvoISPDlg::OnBnClickedRadioDevEmac)
    ON_BN_CLICKED(IDC_RADIO_DEVCOM, &CNuvoISPDlg::OnBnClickedRadioDevCom)
END_MESSAGE_MAP()



BOOL CNuvoISPDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);			// Set big icon
    SetIcon(m_hIcon, FALSE);		// Set small icon

    // TODO: Add extra initialization here
    // SetWindowText(DLG_CAPTION);

    m_IspVersion = 0;
    m_bIsFirstInit = TRUE;
    MyDevFound=FALSE;
    m_ChipSerial = SERIAL_NUC1XX;
    ISP_RESERVED_SIZE = 0;

    m_hexConfig0_last_saved = 0;
    m_hexConfig1_last_saved = 0;
    m_uBurnMode_last_saved = 0;
    m_strConnectPort_last_saved.Empty();

#ifdef IS_MP_VER
    CString  strCaption;
    GetWindowText(strCaption);
    strCaption += " (MP)";
    SetWindowText(strCaption);

#ifdef FOR_CORETRONIC
    GetWindowText(strCaption);
    strCaption += " for Coretronic";
    SetWindowText(strCaption);
#endif
#endif

    TCHAR chPath[MAX_PATH]; //������e���|
    GetModuleFileName(NULL,(LPWCH)chPath,MAX_PATH);
    m_strCurExePath.Format((const wchar_t *)_T("%s"),chPath);
    int nPos=m_strCurExePath.ReverseFind('\\');
    m_strCurExePath=m_strCurExePath.Left(nPos+1);

    if( m_strCurExePath.IsEmpty() ) {
        AddToInfOut(_T("Failed to get current path!"),1,1);
    }

    bIsConfigLoad = FALSE;

    m_bIsProjectFileLoaded = FALSE;
    m_bIsMPModeEnabled = FALSE;
    m_MP_Mode_Status = MP_STATUS_WAIT;
    GetDlgItem(IDC_TXT_MP_STATUS)->SetWindowText(_T(""));
    GetDlgItem(IDC_TXT_MP_STATUS)->ShowWindow(SW_HIDE);

    //���AppData���|
    ::SHGetSpecialFolderPath(NULL, chPath,  CSIDL_APPDATA, FALSE);
    m_strWindowsAppDataPath.Format((const wchar_t *)_T("%s\\"),chPath);


    //�q�{���|
    DWORD ret;
    TCHAR buffer[MAX_PATH] = {0};
    CString sPath = m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"));
    GetPrivateProfileString(CString(_T("NU_PATH")),_T("NU_APROM"),_T(""),buffer,MAX_PATH,sPath);

    ret = GetFileAttributes(buffer);
    if( (ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY)) {
        m_strCodeFilePath.Empty();
    } else {
        m_strCodeFilePath.Format(_T("%s"),buffer);
    }

    GetPrivateProfileString(CString(_T("NU_PATH")),_T("NU_LDROM"),_T(""),buffer,MAX_PATH,sPath);
    ret = GetFileAttributes(buffer);
    if( (ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY)) {
        m_strDataFilePath.Empty();
    } else {
        m_strDataFilePath.Format(_T("%s"),buffer);
    }

    //if (!m_strCurExePath.IsEmpty()) {
    //    m_strCodeFilePath = m_strCurExePath + CString("code.bin");
    //    m_strDataFilePath = m_strCurExePath + CString("data.bin");
    //} else {
    //    m_strCodeFilePath.Empty();
    //    m_strDataFilePath.Empty();
    //}



    //�n�O����
    RegisterHotKey(GetSafeHwnd(),m_nHotKeyID[0], MOD_CONTROL, 'M'); //Ctrl+M


    //��l��CMD list
    m_sMyCmdList.nCmdNum = 0;
    m_sMyCmdList.nCmdTotalNum = 0;

    //�j�r��
    m_Font.CreateFontW(25,0,0,0,100,FALSE,FALSE,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_SWISS,_T("Arial"));
    GetDlgItem(IDC_TXT_CONNECT_STATUS)->SetFont(&m_Font,FALSE);
    GetDlgItem(IDC_TXT_DETECT_POINT)->SetFont(&m_Font,FALSE);
    GetDlgItem(IDC_TXT_RESULT)->SetFont(&m_Font,FALSE);

    //���e�r��
    m_Font_ShowData.CreateFontW(15,0,0,0,100,FALSE,FALSE,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FIXED_PITCH,_T("Courier New"));
    m_text_message.SetFont(&m_Font_ShowData,FALSE);


    CHARFORMAT2 cf;
    ZeroMemory(&cf, sizeof(CHARFORMAT2));
    cf.cbSize = sizeof(CHARFORMAT2);
    cf.dwMask = CFM_BOLD | CFM_COLOR | CFM_FACE |
    CFM_ITALIC | CFM_SIZE | CFM_UNDERLINE;
    //cf.dwEffects = CFE_BOLD;
    cf.yHeight = 13*13;//��r����
    cf.crTextColor = RGB(255,0,0); //��r�C��
    //lstrcpy(cf.szFaceName ,_T("Courier New"));//�]�m�r��
    _tcscpy_s(cf.szFaceName ,_T("Courier New"));//�]�m�r��
    m_text_aprom.SetDefaultCharFormat(cf);
    m_text_aprom.SetBackgroundColor(FALSE,RGB(162,255,190));

    cf.crTextColor = RGB(0,0,255); //��r�C��
    m_text_dataflash.SetDefaultCharFormat(cf);
    m_text_dataflash.SetBackgroundColor(FALSE,RGB(255,255,230));

    //m_text_aprom.LimitText(512*1024);
    //m_text_dataflash.LimitText(512*1024);
    m_text_message.SetLimitText(128*1024);

    //((CEdit *)GetDlgItem(IDC_EDIT_PART_NO))->SetLimitText(10);


    GetClientRect(&m_MainRect);
#if 1
    CString tmpStr;
    tmpStr.Format(_T("width:%d height:%d"),m_MainRect.Width(),m_MainRect.Height());
    AddToInfOut(tmpStr,1,1);
#endif

    return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNuvoISPDlg::OnPaint()
{
    if (IsIconic()) {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    } else {
        //���Logo
        //CDialog::OnPaint();
        CPaintDC   dc(this);   //Device context
        CDC   dcMem;
        dcMem.CreateCompatibleDC(&dc);

        CBitmap   bmpBackground;
        bmpBackground.LoadBitmap(IDB_BITMAP_LOGO);
        BITMAP   bitmap;
        bmpBackground.GetBitmap(&bitmap);

        CBitmap   *pbmpOld=dcMem.SelectObject(&bmpBackground);

        //��dcMem������dc��������m
        dc.StretchBlt(0,0,m_MainRect.Width(),bitmap.bmHeight,&dcMem,0,0,
        bitmap.bmWidth,bitmap.bmHeight,SRCCOPY);  //bitmap.bmHeight = 44
        dcMem.SelectObject(pbmpOld);
    }
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CNuvoISPDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}




/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OpenDeviceCom                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ���}���w����f�]��                                                                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 strComNum	   	  	  -[in]   ��f���r��                                                 */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::OpenDeviceCom(CString strComNum)
{

    COMMTIMEOUTS CommTimeOuts ; //�w�q�W�ɵ��c�A�ö�g�ӵ��c
    DCB dcb;                    //�w�q��Ʊ�������c

    memset(&CommTimeOuts, 0, sizeof(CommTimeOuts));
    memset(&dcb, 0, sizeof(dcb));
    if (bDetecting)
        CommTimeOuts.ReadIntervalTimeout = 20;//ms
    else
        CommTimeOuts.ReadIntervalTimeout = 200;
    //CommTimeOuts.ReadTotalTimeoutConstant = 25000; //25sec
    //CommTimeOuts.WriteTotalTimeoutConstant = 25000;
    strComNum=_T("\\\\.\\")+strComNum;

    if(hCom!=INVALID_HANDLE_VALUE) {
        CloseHandle(hCom);
        hCom=INVALID_HANDLE_VALUE;
    }

    hCom =CreateFile(strComNum, GENERIC_READ | GENERIC_WRITE, // ���\Ū�g
    0,						// ����������0
    NULL,					// no security attrs
    OPEN_EXISTING,         //�]�m���ͤ覡
    FILE_FLAG_OVERLAPPED,  // �ڭ̷ǳƨϥΫD�P�B�q�H
    NULL);
    if(hCom == INVALID_HANDLE_VALUE) {
        LastErrorNum = GetLastError();
        CString tmp;
        tmp.Format(_T("%d"),LastErrorNum);
        AddToInfOut(_T("Failed to open ")+strComNum+_T(";Error code:")+tmp,1,1);
        AddToInfOut(ConvertErrorCodeToString(LastErrorNum),0,1);
        return FALSE;
    } else {
        AddToInfOut(strComNum+_T(" opened!"),1,1);
        DataInSending=FALSE;

        GetCommState(hCom, &dcb ) ;              //Ū��f��Ӫ��ѼƳ]�m
        dcb.BaudRate =115200;                     //Baudrate;
        dcb.ByteSize =8;
        dcb.Parity = NOPARITY;
        dcb.StopBits = ONESTOPBIT ;
        dcb.fBinary = TRUE ;
        dcb.fParity = FALSE;
        dcb.fDtrControl = 0;
        SetCommState(hCom, &dcb ) ;              //��f�Ѽưt�m
        SetCommMask(hCom, EV_RXCHAR|EV_TXEMPTY );//�]�m�ƥ��X�ʪ�����
        SetupComm( hCom, 1024,128) ;             //�]�m��J,��X�w�İϪ��j�p
        SetCommTimeouts( hCom, &CommTimeOuts ) ; //�]�mŪ�g�ާ@�Ҥ��\���W��

        PurgeComm( hCom, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR
        | PURGE_RXCLEAR );               //�M���b��J�B��X�w�İ�

        strComNum.Format(_T("BaudRate:%d"),dcb.BaudRate);
        AddToInfOut(strComNum,1,1);

    }
    return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OpenDeviceUsb                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ���}USB�]��                                                                               */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::OpenDeviceUsb()
{
    //�w�q�@��GUID�����c��HidGuid�ӫO�sHID�]�ƪ�������GUID�C
    GUID HidGuid;
    //�w�q�@��DEVINFO������XhDevInfoSet�ӫO�s����쪺�]�Ƹ�T���X����X�C
    HDEVINFO hDevInfoSet;
    //�w�qMemberIndex�A���ܷ��e�j����ĴX�ӳ]�ơA0���ܲĤ@�ӳ]�ơC
    DWORD MemberIndex;
    //DevInterfaceData�A�ΨӫO�s�]�ƪ��X�ʤ�����T
    SP_DEVICE_INTERFACE_DATA DevInterfaceData;
    //�w�q�@��BOOL�ܼơA�O�s��ƽեάO�_��^���\
    BOOL Result;
    //�w�q�@��RequiredSize���ܼơA�Ψӱ����ݭn�O�s�ԲӸ�T���w�Ī��סC
    DWORD RequiredSize;
    //�w�q�@�ӫ��V�]�ƸԲӸ�T�����c����СC
    PSP_DEVICE_INTERFACE_DETAIL_DATA	pDevDetailData;
    //�w�q�@�ӥΨӫO�s���}�]�ƪ�����X�C
    HANDLE hDevHandle;
    //�w�q�@��HIDD_ATTRIBUTES�����c���ܼơA�O�s�]�ƪ��ݩʡC
    HIDD_ATTRIBUTES DevAttributes;

    //��l�Ƴ]�ƥ����
    MyDevFound=FALSE;


    //��l��USB����X���L�ı���X�C
    hUsbHandle=INVALID_HANDLE_VALUE;

    //��DevInterfaceData���c�骺cbSize��l�Ƭ����c��j�p
    DevInterfaceData.cbSize=sizeof(DevInterfaceData);
    //��DevAttributes���c�骺Size��l�Ƭ����c��j�p
    DevAttributes.Size=sizeof(DevAttributes);


    //�ե�HidD_GetHidGuid������HID�]�ƪ�GUID�A�ëO�s�bHidGuid���C
    HidD_GetHidGuid(&HidGuid);

    //�ھ�HidGuid������]�Ƹ�T���X�C�䤤Flags�ѼƳ]�m��
    //DIGCF_DEVICEINTERFACE|DIGCF_PRESENT�A�e�̪��ܨϥΪ�GUID��
    //������GUID�A��̪��ܥu�C�|���b�ϥΪ��]�ơA�]���ڭ̳o�إu
    //�d��w�g�s���W���]�ơC��^������X�O�s�bhDevinfo���C�`�N�]��
    //��T���X�b�ϥΧ�����A�n�ϥΨ��SetupDiDestroyDeviceInfoList
    //�P���A���M�|�y���O���鬪�|�C
    hDevInfoSet=SetupDiGetClassDevs(&HidGuid,
    NULL,
    NULL,
    DIGCF_DEVICEINTERFACE|DIGCF_PRESENT);


    //m_text_message.SetWindowTextW(_T("Finding the device..."));
    //�M���]�ƶ��X���C�ӳ]�ƶi��C�|�A�ˬd�O�_�O�ڭ̭n�䪺�]��
    //�����ڭ̫��w���]�ơA�Ϊ̳]�Ƥw�g�d�䧹���ɡA�N�h�X�d��C
    //�������V�Ĥ@�ӳ]�ơA�Y�NMemberIndex�m��0�C
    MemberIndex=0;
    while(1) {
        //�ե�SetupDiEnumDeviceInterfaces�b�]�Ƹ�T���X������s����
        //MemberIndex���]�Ƹ�T�C
        Result=SetupDiEnumDeviceInterfaces(hDevInfoSet,
        NULL,
        &HidGuid,
        MemberIndex,
        &DevInterfaceData);

        //�p�G�����T���ѡA�h�����]�Ƥw�g�d�䧹���A�h�X�j��C
        if(Result==FALSE) break;

        //�NMemberIndex���V�U�@�ӳ]��
        MemberIndex++;

        //�p�G�����T���\�A�h�~������ӳ]�ƪ��ԲӸ�T�C�b����]��
        //�ԲӸ�T�ɡA�ݭn�����D�O�s�ԲӸ�T�ݭn�h�j���w�İϡA�o�q�L
        //�Ĥ@���եΨ��SetupDiGetDeviceInterfaceDetail������C�o��
        //���ѽw�İϩM���׳���NULL���ѼơA�ô��Ѥ@�ӥΨӫO�s�ݭn�h�j
        //�w�İϪ��ܼ�RequiredSize�C
        Result=SetupDiGetDeviceInterfaceDetail(hDevInfoSet,
        &DevInterfaceData,
        NULL,
        NULL,
        &RequiredSize,
        NULL);

        //�M��A���t�@�Ӥj�p��RequiredSize�w�İϡA�ΨӫO�s�]�ƸԲӸ�T�C
        pDevDetailData=(PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(RequiredSize);
        if(pDevDetailData==NULL) { //�p�G�O���餣���A�h������^�C
            MessageBox(_T("No enough memory!"));
            SetupDiDestroyDeviceInfoList(hDevInfoSet);
            return FALSE;
        }

        //�ó]�mpDevDetailData��cbSize�����c�骺�j�p�]�`�N�u�O���c��j�p�A
        //���]�A�᭱�w�İϡ^�C
        pDevDetailData->cbSize=sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        //�M��A���ե�SetupDiGetDeviceInterfaceDetail��ƨ�����]�ƪ�
        //�ԲӸ�T�C�o���եγ]�m�ϥΪ��w�İϥH�νw�İϤj�p�C
        Result=SetupDiGetDeviceInterfaceDetail(hDevInfoSet,
        &DevInterfaceData,
        pDevDetailData,
        RequiredSize,
        NULL,
        NULL);

        //�N�]�Ƹ��|�ƻs�X�ӡA�M��P�����ӽЪ��O����C
        MyDevPathName=pDevDetailData->DevicePath;
        free(pDevDetailData);

        //�p�G�եΥ��ѡA�h�d��U�@�ӳ]�ơC
        if(Result==FALSE) continue;

        //�p�G�եΦ��\�A�h�ϥΤ��aŪ�g�X�ݪ�CreateFile���
        //������]�ƪ��ݩʡA�]�AVID�BPID�B���������C
        //���@�ǿW���]�ơ]�ҦpUSB��L�^�A�ϥ�Ū�X�ݤ覡�O�L�k���}���A
        //�ӨϥΤ��aŪ�g�X�ݪ��榡�~�i�H���}�o�ǳ]�ơA�q������]�ƪ��ݩʡC
        hDevHandle=CreateFile(MyDevPathName,
        NULL,
        FILE_SHARE_READ|FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL);

        //�p�G���}���\�A�h����]���ݩʡC
        if(hDevHandle!=INVALID_HANDLE_VALUE) {
            //����]�ƪ��ݩʨëO�s�bDevAttributes���c�餤
            Result=HidD_GetAttributes(hDevHandle,
            &DevAttributes);

            //������襴�}���]��
            CloseHandle(hDevHandle);

            //������ѡA�d��U�@��
            if(Result==FALSE) continue;

            //�p�G������\�A�h�N�ݩʤ���VID�BPID�H�γ]�ƪ������P�ڭ̻ݭn��
            //�i�����A�p�G���@�P���ܡA�h�������N�O�ڭ̭n�䪺�]�ơC
            //	if(DevAttributes.VendorID==MyVid) //�p�GVID�۵�
            //		if(DevAttributes.ProductID==MyPid) //�åBPID�۵�
            //	if(DevAttributes.VersionNumber==MyPvn) //�åB�]�ƪ������۵�

            if(DevAttributes.VendorID==0x0416 &&
            DevAttributes.ProductID==0xA316) {
                //MyDevFound=TRUE; //�]�m�]�Ƥw�g���
                //AddToInfOut("�]�Ƥw�g���");

                //����N�O�ڭ̭n�䪺�]�ơA���O�ϥ�Ū�g�覡���}���A�ëO�s�䱱��X
                //�åB��ܬ��D�P�B�X�ݤ覡�C
                //Ū�覡���}�]��
                hUsbHandle=CreateFile(MyDevPathName,
                GENERIC_READ|GENERIC_WRITE,
                FILE_SHARE_READ|FILE_SHARE_WRITE,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,
                NULL);
                if (hUsbHandle==INVALID_HANDLE_VALUE) {
                    AddToInfOut(_T("Failed to access the USB device!"),1,1);
                    continue;
                }

                //MyDevFound=TRUE; //�]�m�]�Ƥw�g���
                AddToInfOut(_T("USB found!"),1,1);
                Result = TRUE;
                DataInSending=FALSE; //�i�H�o�e���

                //���Ĳ�o�ƥ�A��Ū���i�u�{��_�B��C�]���b�o���e�èS���ե�
                //Ū�ƾڪ���ơA�]�N���|�ް_�ƥ󪺲��͡A�ҥH�ݭn�����Ĳ�o�@
                //���ƥ�A��Ū���i�u�{��_�B��C
                //	SetEvent(ReadOverlapped.hEvent);


                //���]�ơA�h�X�j��C���{���u�˴��@�ӥؼг]�ơA�d����N�h�X
                //�d��F�C�p�G�A�ݭn�N�Ҧ����ؼг]�Ƴ��C�X�Ӫ��ܡA�i�H�]�m�@��
                //�}�C�A����N�O�s�b�}�C���A����Ҧ��]�Ƴ��d�䧹���~�h�X�d��
                break;
            }
        }
        //�p�G���}���ѡA�h�d��U�@�ӳ]��
        else continue;
    }

    if(!Result)
        AddToInfOut(_T("Not found"),1,1);

    //�ե�SetupDiDestroyDeviceInfoList��ƾP���]�Ƹ�T���X
    SetupDiDestroyDeviceInfoList(hDevInfoSet);
    return Result;

}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OpenDeviceEthernet                                                              	       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ���}UDP�]��                                                                               */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::OpenDeviceEthernet()
{
    enabled = TRUE;
    sockaddrlen = sizeof(sin);
    recv_len = sizeof(Recv_addr);

    socketVersion = MAKEWORD(2,2);

    BOOL Result;
    int debug_SendAndRecv;
    struct timeval timeout;
    struct fd_set readfds;

    if(WSAStartup(socketVersion, &wsaData) != 0) {
        WSACleanup();
        return 0;
    }

    sclient = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    Recv_addr.sin_family = AF_INET;
    Recv_addr.sin_port = htons(DEFAULT_PORT);
    Recv_addr.sin_addr.S_un.S_addr = INADDR_ANY;

    sin.sin_family = AF_INET;

    sin.sin_port = htons(DEFAULT_PORT);
    sin.sin_addr.S_un.S_addr = inet_addr("255.255.255.255");


    if(setsockopt(sclient, SOL_SOCKET, SO_BROADCAST, (char*)&enabled, sizeof(BOOL)) < 0) {
        AddToInfOut(_T("Failed to access the Ethernet device!"),1,1);
        closesocket(sclient);
        WSACleanup();
        return 1;
    }


    char buffer[1024];
    memset(buffer,'\0', sizeof(buffer));
    buffer[0] = 174;
    buffer[3] = 1;

    while(1) {
        FD_ZERO(&readfds);
        FD_SET(sclient,&readfds);
        timeout.tv_sec = 1;  // Timeout 1 sec
        timeout.tv_usec = 0;
        debug_SendAndRecv = sendto(sclient,buffer,sizeof(buffer),0,(struct sockaddr*)&sin, sockaddrlen);
        select(sclient+1,&readfds,NULL,NULL,&timeout);

        if(FD_ISSET(sclient,&readfds)) {
            memset(buffer,'\0', sizeof(buffer));

            debug_SendAndRecv = recvfrom(sclient, buffer, sizeof(buffer), 0, (struct sockaddr*)&Recv_addr, &recv_len);
            if(debug_SendAndRecv < 0) {
                AddToInfOut(_T("Not found"),1,1);
                OnBnClickedButtonClose();
                closesocket(sclient);
                return 0;
            } else {
                AddToInfOut(_T("Ethernet connected!"),1,1);
                Result = TRUE;

                closesocket(sclient);
                break;
            }

        } else {
            //printf("timeout ,left time %d s ,%d usec\n",tv.tv_sec,tv.tv_usec);
            AddToInfOut(_T("timeout : Not found"),1,1);
            OnBnClickedButtonClose();
            closesocket(sclient);
            WSAGetLastError();
            return 0;

        }
    }

    sclient = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    sin.sin_port = htons(DEFAULT_PORT);
    sin.sin_addr.S_un.S_addr = inet_addr(inet_ntoa(Recv_addr.sin_addr));//inet_addr("192.168.0.101");
    sin.sin_family = AF_INET;

    //DataInSending=FALSE; //�i�H�o�e���

    return Result;


}

#ifdef WINUSB_NUVO_DFU

BOOL CNuvoISPDlg::OpenDeviceUsb_DFU()
{
    BOOL 		bResult;
    HDEVINFO 	hDeviceInfo;
    ULONG 		requiredLength = 0;
    LPTSTR 		lpDevicePath = NULL;
    DWORD 		index = 0;
    ULONG 		cbSent = 0;
    WINUSB_SETUP_PACKET SetupPacket;
    UCHAR		status_buff[6];
    SP_DEVINFO_DATA DeviceInfoData;
    SP_DEVICE_INTERFACE_DATA deviceInterfaceData;
    PSP_DEVICE_INTERFACE_DETAIL_DATA pInterfaceDetailData = NULL;

    MyDevFound = FALSE;
    hUsbHandle = INVALID_HANDLE_VALUE;
    hWinUSBHandle = INVALID_HANDLE_VALUE;

    // Get information about all the installed devices for the specified
    // device interface class.
    hDeviceInfo = SetupDiGetClassDevs(
        &DFU_DEVICE_INTERFACE,
        NULL,
        NULL,
        DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

    if (hDeviceInfo == INVALID_HANDLE_VALUE) {
        // ERROR
        printf("Error SetupDiGetClassDevs: %d.\n", GetLastError());
        bResult = FALSE;
        goto done;
    }

    //Enumerate all the device interfaces in the device information set.
    DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    for (index = 0; SetupDiEnumDeviceInfo(hDeviceInfo, index, &DeviceInfoData); index++) {
        //Reset for this iteration
        if (lpDevicePath) {
            LocalFree(lpDevicePath);
        }
        if (pInterfaceDetailData) {
            LocalFree(pInterfaceDetailData);
        }

        deviceInterfaceData.cbSize = sizeof(SP_INTERFACE_DEVICE_DATA);

        //Get information about the device interface.
        bResult = SetupDiEnumDeviceInterfaces(
            hDeviceInfo,
            &DeviceInfoData,
            &DFU_DEVICE_INTERFACE,
            0,
            &deviceInterfaceData);

        // Check if last item
        if (GetLastError () == ERROR_NO_MORE_ITEMS) {
            break;
        }

        //Check for some other error
        if (!bResult) {
            printf("Error SetupDiEnumDeviceInterfaces: %d.\n", GetLastError());
            goto done;
        }

        //Interface data is returned in SP_DEVICE_INTERFACE_DETAIL_DATA
        //which we need to allocate, so we have to call this function twice.
        //First to get the size so that we know how much to allocate
        //Second, the actual call with the allocated buffer

        bResult = SetupDiGetDeviceInterfaceDetail(
            hDeviceInfo,
            &deviceInterfaceData,
            NULL, 0,
            &requiredLength,
            NULL);


        //Check for some other error
        if (!bResult) {
            if ((ERROR_INSUFFICIENT_BUFFER==GetLastError()) && (requiredLength>0)) {
                //we got the size, allocate buffer
                pInterfaceDetailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)LocalAlloc(LPTR, requiredLength);

                if (!pInterfaceDetailData) {
                    // ERROR
                    printf("Error allocating memory for the device detail buffer.\n");
                    goto done;
                }
            } else {
                printf("Error SetupDiEnumDeviceInterfaces: %d.\n", GetLastError());
                goto done;
            }
        }

        //get the interface detailed data
        pInterfaceDetailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        //Now call it with the correct size and allocated buffer
        bResult = SetupDiGetDeviceInterfaceDetail(
            hDeviceInfo,
            &deviceInterfaceData,
            pInterfaceDetailData,
            requiredLength,
            NULL,
            &DeviceInfoData);

        //Check for some other error
        if (!bResult) {
            printf("Error SetupDiGetDeviceInterfaceDetail: %d.\n", GetLastError());
            goto done;
        }

        //copy device path

        size_t nLength = wcslen (pInterfaceDetailData->DevicePath) + 1;
        lpDevicePath = (TCHAR *) LocalAlloc (LPTR, nLength * sizeof(TCHAR));
        StringCchCopy(lpDevicePath, nLength, pInterfaceDetailData->DevicePath);
        lpDevicePath[nLength-1] = 0;

        printf("Device path:  %s\n", lpDevicePath);
    }

    if (!lpDevicePath) {
        //Error.
        printf("Error %d.", GetLastError());
        goto done;
    }

    //Open the device
    hUsbHandle = CreateFile (
        lpDevicePath,
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        FILE_FLAG_OVERLAPPED,
        NULL);

    if (hUsbHandle == INVALID_HANDLE_VALUE) {
        //Error.
        printf("Error %d.", GetLastError());
        bResult = FALSE;
        goto done;
    }

    bResult = WinUsb_Initialize(hUsbHandle, &hWinUSBHandle);
    if (!bResult) {
        //Error.
        printf("WinUsb_Initialize Error %d.", GetLastError());
        CloseHandle(hUsbHandle);
        hUsbHandle = INVALID_HANDLE_VALUE;
        hWinUSBHandle = INVALID_HANDLE_VALUE;
        goto done;
    }

    /*
     *  Send a DFU_DETACH request to make DFU device enter DFU idle stae.
     */
    ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
    SetupPacket.RequestType = 0x21;
    SetupPacket.Request = 0x0;			// DFU_DETACH
    SetupPacket.Value = 0;				// wTimeout
    SetupPacket.Index = 0; 				// Interface
    SetupPacket.Length = 0;
    WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, NULL, 0, &cbSent, 0);

    /*
     *  DFU_GETSTATUS to make DFU device enter dfuDNLOAD_IDLE state
     */
    ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
    SetupPacket.RequestType = 0xA1;
    SetupPacket.Request = 0x3;			// DFU_GETSTATUS
    SetupPacket.Value = 0;
    SetupPacket.Index = 0; 				// Interface
    SetupPacket.Length = 6;
    bResult = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, &status_buff[0], 6, &cbSent, 0);
    if (bResult) {
        if (status_buff[4] == 10) {
            /*
             *  DFU_CLRSTATUS to ask DFU device leave dfuERROR state
             */
            ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
            SetupPacket.RequestType = 0x21;
            SetupPacket.Request = 0x4;			// DFU_CLRSTATUS
            SetupPacket.Value = 0;
            SetupPacket.Index = 0; 				// Interface
            SetupPacket.Length = 0;
            WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, NULL, 0, &cbSent, 0);
        }
    }

    return TRUE;

done:
    LocalFree(lpDevicePath);
    LocalFree(pInterfaceDetailData);
    bResult = SetupDiDestroyDeviceInfoList(hDeviceInfo);

    return FALSE;
}
#endif


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     DetectDevice                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �����O�_���]�Ƴq�L��f�s����PC                                                            */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::DetectDevice(int DevInterface)
{
    BOOL 			bResult;
    COMMTIMEOUTS 	CommTimeOuts ;
    DWORD 			tick1, tick2;
    int				com_retry = 0;

    if (DevInterface != PORT_COM)
        return TRUE;
    else {
        memset(&CommTimeOuts, 0, sizeof(CommTimeOuts));
        CommTimeOuts.ReadIntervalTimeout = 20;//ms
        SetCommTimeouts( hCom, &CommTimeOuts ) ;
    }

    if (m_bIsMPModeEnabled == FALSE) {
        uTxtFontColor = 1; //����r��
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->SetWindowTextW(_T("Stop"));
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(TRUE);
    } else
        uTxtFontColor = 3;
    SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T("Detecting"));
    GetDlgItem(IDC_TXT_DETECT_POINT)->ShowWindow(TRUE);

    bDetecting = TRUE;
    tick1 = ::GetTickCount();

    // �b�����аeCMD_CONNECT�A����s�����\�~�|���X while (bDetecting)
    while (bDetecting) {
        bDetectingSaved = TRUE;

        bResult = CmdWriteAndReadOne(DevInterface, CMD_CONNECT);
        g_packno = 1;

        if (bResult)
            break;
        else if(g_ErrorCode == ERR_CODE_COM_ERROR_OPEN) {
            MessageBox(_T("Failed to open ")+strWhichCom,_T("Error"),MB_OK);
            break;
        }

        tick2 = ::GetTickCount();

        if((tick2 - tick1) >= 3000) {
            SetDlgItemText(IDC_TXT_DETECT_POINT,_T(""));
            tick1 = tick2;
        } else if((tick2 - tick1)  >= 2500)
            SetDlgItemText(IDC_TXT_DETECT_POINT,_T("....."));
        else if((tick2 - tick1)  >= 2000)
            SetDlgItemText(IDC_TXT_DETECT_POINT,_T("...."));
        else if((tick2 - tick1)  >= 1500)
            SetDlgItemText(IDC_TXT_DETECT_POINT,_T("..."));
        else if((tick2 - tick1)  >= 1000)
            SetDlgItemText(IDC_TXT_DETECT_POINT,_T(".."));
        else if((tick2 - tick1)  >= 500)
            SetDlgItemText(IDC_TXT_DETECT_POINT,_T("."));

        //SleepEx(200,TRUE);

    }

    bDetecting = FALSE;
    bDetectingSaved = FALSE;
    GetDlgItem(IDC_TXT_DETECT_POINT)->ShowWindow(FALSE);
    SetDlgItemText(IDC_TXT_DETECT_POINT,_T(""));

    CommTimeOuts.ReadIntervalTimeout = 200;//ms
    SetCommTimeouts( hCom, &CommTimeOuts ) ;

    GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(FALSE);

    return bResult;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonOpenDevice                                                               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �I���s�����s�ɪ��^����ơA��Ʒ|�ھکҿ諸�쵲�覡��ܥ��}��f��USB�]��                   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedButtonOpenDevice()
{
    //��l�Ƴ]�ƥ����
    BOOL Result;

    DataInSending = FALSE;
    bDetectingSaved = FALSE;

    // Stop Detecting Device
    if (bDetecting) {
        bDetecting = FALSE;
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(FALSE);
        return;
    }

    if (MyDevFound) {
        OnBnClickedButtonClose();
        return;
    }

    GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(FALSE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->EnableWindow(FALSE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->EnableWindow(FALSE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->EnableWindow(FALSE);
    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_UNCHECKED);
    m_ctrComBox.EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_CAN)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);

    //�P�_�Τ���USB�٬OCOM�Ҧ�
    if( ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->GetCheck() == BST_CHECKED ) {
        uCurPortSelected = PORT_USB;
        AddToInfOut(_T("Searching USB..."),1,1);
        Result = OpenDeviceUsb();
#ifdef WINUSB_NUVO_DFU
        if (Result == FALSE)
            Result = OpenDeviceUsb_DFU();
#endif
    } else if( ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->GetCheck() == BST_CHECKED ) {
        uCurPortSelected = PORT_COM;
        m_ctrComBox.GetLBText(m_ctrComBox.GetCurSel(), strWhichCom);
        AddToInfOut(_T("Opening ")+strWhichCom,1,1);
        Result = OpenDeviceCom(strWhichCom);
    } else if( ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->GetCheck() == BST_CHECKED ) {
        uCurPortSelected = PORT_EMAC;
        AddToInfOut(_T("Searching Ethernet..."),1,1);
        Result = OpenDeviceEthernet();
    }


    if (Result)
        CmdToDo(CMD_GET_FWVER);
    else {
        AddToInfOut(_T("Connect fail!"),1,1);
        if (m_bIsMPModeEnabled == FALSE) {
            GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(TRUE);
        }
        ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->EnableWindow(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->EnableWindow(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->EnableWindow(TRUE);
        if(((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->GetCheck()) {
            m_ctrComBox.EnableWindow(TRUE);
            GetDlgItem(IDC_CHECK_CAN)->EnableWindow(FALSE);
            GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
        } else {
            m_ctrComBox.EnableWindow(FALSE);
            GetDlgItem(IDC_CHECK_CAN)->EnableWindow(TRUE);
            GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(TRUE);
        }
        MyDevFound = FALSE;

        if (!m_bIsFirstInit) {
#ifdef IS_MP_VER
            m_MP_Mode_Status = MP_STATUS_CONN_FAIL;
            SetDlgItemText(IDC_TXT_MP_STATUS,_T("Connect FAILED"));
#else
            if (uCurPortSelected == PORT_COM)
                MessageBox(_T("Failed to open ")+strWhichCom,_T("Error"),MB_OK);
            else if(uCurPortSelected == PORT_USB)
                MessageBox(_T("No such USB device"),_T("Error"),MB_OK);
            else if(uCurPortSelected == PORT_EMAC)
                MessageBox(_T("No Ethernet"),_T("Error"),MB_OK);
            else
                MessageBox(_T("Unknown error"),_T("Error"),MB_OK);
#endif
        }

        //���}Message��
#ifdef MSG_TAB_ENABLE
        m_tab.SetCurSel(2);
        m_text_aprom.ShowWindow(FALSE);
        m_text_dataflash.ShowWindow(FALSE);
        m_text_message.ShowWindow(TRUE);
#endif
    }

    return;

}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     TransferThread                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��ƶǿ骺�u�{��ơA�i�H�b��O�B�z���Ū�g                                                */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 pParam	   	  	  -[in]   �u�{�Ѽ�                                                         */
/* Returns:                                                                                                */
/*               ���`���p����Ƥ���^                                                                      */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
UINT TransferThread(LPVOID pParam)
{
    BOOL Result;
    UINT nCurProgress = 0;
    CString Str;
    unsigned long readcn, sendcn, sendPacketSize, cmdData;
    unsigned short get_cksum;
    CNuvoISPDlg *pMainDlg = (CNuvoISPDlg *)pParam;
    int DevInterface;

    //�X�֪���code�Mflash��T
    UCHAR *tranBuf;
    UINT   tranBufStartAddr;
    UINT   tranBufSize;
    UINT16 tranBufCheckSum;

    while(1) {
        if (pMainDlg->DataInSending==TRUE) {
            if( pMainDlg->InterfaceSelect() == PORT_USB)
                DevInterface = PORT_USB;
            else if( pMainDlg->InterfaceSelect() == PORT_COM)
                DevInterface = PORT_COM;
            else
                DevInterface = PORT_EMAC;

//��� ���e/�`�@����

            if(pMainDlg->m_sMyCmdList.nCmdTotalNum) {
                Str.Format(_T("%d/%d"),pMainDlg->m_sMyCmdList.nCmdTotalNum-pMainDlg->m_sMyCmdList.nCmdNum+1,pMainDlg->m_sMyCmdList.nCmdTotalNum);
                pMainDlg->SetDlgItemText(IDC_TXT_CMD_NUM,Str);
            }

            if (pMainDlg->m_curCmd == CMD_UPDATE_CONFIG) {
                pDlg->AddToInfOut(_T("To do CMD_UPDATE_CONFIG"),1,1);
                Result = pMainDlg->UpdateConfig(DevInterface);
                pMainDlg->DataInSending=FALSE;

                if (Result == FALSE) {
                    pMainDlg->AddToInfOut(_T("Update fail!"),1,1);
                    pMainDlg->uTxtFontColor = 1; //����r��
                    pMainDlg->SetDlgItemText(IDC_TXT_RESULT,_T("Fail"));
                    pMainDlg->m_writeProgress.SetPos(0);
                    pMainDlg->m_sMyCmdList.nCmdNum = 1; //�����Ѿl��CMD
                } else {
                    pMainDlg->AddToInfOut(_T("Update success!"),1,1);
                    //pMainDlg->uTxtFontColor = 2; //���r��
                    //pMainDlg->SetDlgItemText(IDC_TXT_RESULT,_T("PASS"));
                    pMainDlg->m_writeProgress.SetPos(100);
                    if (!(pMainDlg->m_hexConfig0 & (1<<1))) { //Chip locked
                        pMainDlg->bIsChipLocked = TRUE;
                    }

                    pMainDlg->m_hexConfig0_saved = pMainDlg->m_hexConfig0;
                    pMainDlg->m_hexConfig1_saved = pMainDlg->m_hexConfig1;

                    //��f�ǿ��,���ݤ@�|��100%�i�ױ���ݨ�C
                    if (DevInterface == PORT_COM)
                        SleepEx(500,TRUE);
                }

                //goto next;
                goto out;

            } else if(pMainDlg->m_curCmd == CMD_ERASE_ALL) {
                pDlg->AddToInfOut(_T("To do CMD_ERASE_ALL"),1,1);
                Result = pMainDlg->EraseAllChip(DevInterface);
                if(Result == TRUE) {
                    pMainDlg->bIsChipLocked = FALSE;
                    //Erase���_�w�]��
                    //pMainDlg->m_hexConfig0 = CONFIG0_DEFAULT_VALUE;
                    //pMainDlg->m_hexConfig1 = CONFIG1_DEFAULT_VALUE;

                    //v1.40��令�qFWŪ�t�m��
                    if(DevInterface == PORT_USB) {
                        memcpy(&pMainDlg->m_hexConfig0, pMainDlg->ReadReportBuffer+9, 4);
                        memcpy(&pMainDlg->m_hexConfig1, pMainDlg->ReadReportBuffer+13, 4);
                    } else { //PORT_COM / Ethernet
                        memcpy(&pMainDlg->m_hexConfig0, pMainDlg->ReadReportBuffer+8, 4);
                        memcpy(&pMainDlg->m_hexConfig1, pMainDlg->ReadReportBuffer+12, 4);
                    }
                    pMainDlg->m_hexConfig0_saved = pMainDlg->m_hexConfig0;
                    pMainDlg->m_hexConfig1_saved = pMainDlg->m_hexConfig1;
                    pMainDlg->UpdateSizeInfo(FALSE);
                }
                goto out;
            } else if (pMainDlg->m_curCmd == CMD_GET_FWVER) {
                pDlg->AddToInfOut(_T("To do CMD_GET_VERSION"),1,1);
                Result = pMainDlg->CmdChipConnection(DevInterface);
                pMainDlg->DataInSending=FALSE;
                if (Result == FALSE) {
                    //pMainDlg->AddToInfOut(_T("Connect fail!"),1,1);
                } else {
                    pMainDlg->AddToInfOut(_T("Connect success!"),1,1);
                    if (pMainDlg->m_bIsMPModeEnabled == TRUE)
                        pMainDlg->OnBnClickedButtonBurnAprom();
                }

                pDlg->SendMessage(WM_SETCURSOR, 0, 0);
                continue;
            }

            else if(pMainDlg->m_curCmd == CMD_UPDATE_APROM) {
                pDlg->AddToInfOut(_T("To do CMD_UPDATE_APROM"),1,1);
                tranBuf = CodeFileBuffer; //pMainDlg->CodeFileBuffer;
                tranBufStartAddr = pMainDlg->m_sMyFileInfo.uCodeFileStartAddr;
                tranBufSize = pMainDlg->m_sMyFileInfo.uCodeFileSize;
                tranBufCheckSum = pMainDlg->m_sMyFileInfo.uCodeFileCheckSum;
            } else if(pMainDlg->m_curCmd == CMD_UPDATE_DATAFLASH) {
                pDlg->AddToInfOut(_T("To do CMD_UPDATE_DATAFLASH"),1,1);
                tranBuf = DataFileBuffer; //pMainDlg->DataFileBuffer;
                tranBufStartAddr = pMainDlg->m_sMyFileInfo.uDataFileStartAddr;
                tranBufSize = pMainDlg->m_sMyFileInfo.uDataFileSize;
                tranBufCheckSum = pMainDlg->m_sMyFileInfo.uDataFileCheckSum;
            } else {
                pMainDlg->AddToInfOut(_T("Unknown CMD!"),1,1);
                Result = FALSE;
                goto out;

            }


            Result = pMainDlg->CmdSyncPackno(DevInterface);
            if(Result == FALSE) {
                pDlg->AddToInfOut(_T("Send sync packno cmd fail"),1,1);
                pMainDlg->m_writeProgress.SetPos(0);
                goto out;
            }
            pDlg->AddToInfOut(_T("Send sync packno cmd OK"),1,1);
            pMainDlg->m_writeProgress.SetPos(5);

            /** send updata aprom command**/
            memset(pMainDlg->WriteReportBuffer, 0, MAX_PACKET+1);
            cmdData = pMainDlg->m_curCmd;
            memcpy(pMainDlg->WriteReportBuffer+1, &cmdData, 4);
            memcpy(pMainDlg->WriteReportBuffer+5, &g_packno, 4);
            g_packno++;


            if(!pMainDlg->bIsChipLocked)
                pDlg->AddToInfOut(_T("Start address:")+pMainDlg->itos(tranBufStartAddr,16) + _T("Size:")+pMainDlg->itos(tranBufSize,16),1,1);


            memcpy(pMainDlg->WriteReportBuffer+9, &tranBufStartAddr, 4);
            memcpy(pMainDlg->WriteReportBuffer+13, &tranBufSize, 4);

            readcn = tranBufSize;
            sendcn = MAX_PACKET - 16;
            if(sendcn > readcn)
                sendcn = readcn;
            memcpy(pMainDlg->WriteReportBuffer+17, tranBuf, sendcn);


            pDlg->AddToInfOut(_T("Sending first packet...it will take a long time"),1,1);
            //send CMD
            Result = pMainDlg->WriteData(DevInterface);
            if(Result == FALSE)
                goto out;

            Result = pMainDlg->ReadData(DevInterface);
            if(Result == FALSE)
                goto out;

            nCurProgress = (sendcn*100)/tranBufSize;
            if(nCurProgress>100)
                nCurProgress = 100;


            if(nCurProgress < 20) //�Ĥ@��CMD�ήɸ���,����5% - 20%
                nCurProgress = 20;

            pMainDlg->m_writeProgress.SetPos(nCurProgress);


            pDlg->AddToInfOut(_T("Sending next packets..."),1,1);
            while(sendcn < readcn) { //�ǰe�Ѿl���
                pMainDlg->WriteReportBuffer[0] = 0x00;
                cmdData = 0x00000000;//continue


                memcpy(pMainDlg->WriteReportBuffer+1, &cmdData, 4);
                memcpy(pMainDlg->WriteReportBuffer+5, &g_packno, 4);
                g_packno++;

                if((readcn - sendcn) < (MAX_PACKET-8)) { //�Ѿl����MAX_PACKET-8�����o�X�h
                    memcpy(pMainDlg->WriteReportBuffer+9, tranBuf+sendcn, readcn - sendcn);
                    sendPacketSize = readcn - sendcn;
                    sendcn = readcn;
                } else {
                    memcpy(pMainDlg->WriteReportBuffer+9, tranBuf+sendcn, MAX_PACKET-8);
                    sendPacketSize = MAX_PACKET-8;
                    sendcn += MAX_PACKET-8;
                }
                Result = pMainDlg->WriteData(DevInterface);
                if(Result == FALSE)
                    goto out;
                Result = pMainDlg->ReadData(DevInterface);
                if(Result == FALSE) {
                    if( (g_ErrorCode == ERR_CODE_LOST_PACKET)||(g_ErrorCode == ERR_CODE_CHECKSUM_ERROR) ) {
                        pDlg->AddToInfOut(_T("Resend this packet"),1,1);
                        Result = pMainDlg->CmdWriteAndReadOne(DevInterface, CMD_RESEND_PACKET);
                        if(Result == FALSE)
                            goto out;

                        sendcn -= sendPacketSize;
                        continue;
                    } else
                        goto out;
                }


                //20% - 100%��������
                nCurProgress = (sendcn*100)/tranBufSize;
                nCurProgress = (nCurProgress*80)/100;
                nCurProgress += 20;

                if(nCurProgress > 100) //����U�@
                    nCurProgress = 100;
                if(pMainDlg->m_writeProgress.GetPos() != nCurProgress)
                    pMainDlg->m_writeProgress.SetPos(nCurProgress);

                //SleepEx(1,TRUE);
            }


//Check sum again
            if (pMainDlg->m_IspVersion<0x23)
                Result = pMainDlg->CmdGetCheckSum(DevInterface, tranBufStartAddr, tranBufSize, &get_cksum); //FW 2.3�H��������R�O
            else {

                if (DevInterface == PORT_USB)
                    memcpy(&get_cksum, pMainDlg->ReadReportBuffer+9, 2);
                else
                    memcpy(&get_cksum, pMainDlg->ReadReportBuffer+8, 2);
            }

            if(Result == TRUE) {
                if(tranBufCheckSum == get_cksum) {
                    Result = TRUE;
                    Str.Format(_T("Compare checksum value again:0x%X,it's right!"),get_cksum);
                    pDlg->AddToInfOut(Str,1,1);

                    if((pDlg->ISP_RESERVED_SIZE)&&(pMainDlg->m_curCmd == CMD_UPDATE_APROM)) { //Save checksum function enabled
                        pDlg->AddToInfOut(_T("Set checksum..."),1,1);
                        Result = pMainDlg->CmdSetCheckSum(DevInterface, tranBufCheckSum, tranBufSize);//Write checksum value
                    }

                } else {
                    Result = FALSE;
                    Str.Format(_T("Get a wrong checksum value:%X"),get_cksum);
                    pDlg->AddToInfOut(Str,1,1);
                }
            } else
                pDlg->AddToInfOut(_T("Get checksum error"),1,1);


out:


            if (Result == TRUE) {
                pMainDlg->AddToInfOut(_T("Send success"),1,1);
                pMainDlg->uTxtFontColor = 2; //���r��
                pMainDlg->SetDlgItemText(IDC_TXT_RESULT,_T("PASS"));
                pMainDlg->m_writeProgress.SetPos(100);
                if (pMainDlg->m_bIsMPModeEnabled == TRUE) {
                    pMainDlg->m_MP_Mode_Status = MP_STATUS_PASS;
                    pMainDlg->SetDlgItemText(IDC_TXT_MP_STATUS,_T("PASS"));
                    pMainDlg->OnBnClickedButtonClose();
                }
            } else {
                ::MessageBeep(MB_ICONERROR);
                Str.Format(_T("Send fail:progress=%d%%"),nCurProgress);
                pDlg->AddToInfOut(Str,1,1);
                pMainDlg->uTxtFontColor = 1; //����r��
                pMainDlg->SetDlgItemText(IDC_TXT_RESULT,_T("Fail"));
                pMainDlg->m_sMyCmdList.nCmdNum = 1; //�����Ѿl��CMD

                if (pMainDlg->m_bIsMPModeEnabled == TRUE) {
                    pMainDlg->m_MP_Mode_Status = MP_STATUS_WRITE_FAIL;
                    pMainDlg->SetDlgItemText(IDC_TXT_MP_STATUS,_T("Write FAILED"));
                    pMainDlg->OnBnClickedButtonClose();
                }
            }

//next:
//�B�z�U�@��CMD
            pMainDlg->DataInSending=FALSE;


            pMainDlg->m_sMyCmdList.nCmdNum--;
            if(pMainDlg->m_sMyCmdList.nCmdNum > 0) {
                pDlg->AddToInfOut(_T("\r\n \r\nNext CMD..."),1,1);
                Result = pMainDlg->CmdToDo(pMainDlg->m_sMyCmdList.aCmdList[pMainDlg->m_sMyCmdList.nCmdNum-1]);
                if(Result == FALSE)
                    pMainDlg->DataInSending=FALSE;

            } else {
                //��s�ƹ����b�Y��
                pDlg->SendMessage(WM_SETCURSOR, 0, 0);
                (CButton *)(pDlg->GetDlgItem(IDC_CHECK_SAVE_CHECKSUM))->EnableWindow(TRUE);
            }


        } else
            SleepEx(10,TRUE);

        if (pMainDlg->m_bIsMPModeEnabled == TRUE) {
            if (pMainDlg->GetDlgItem(IDC_EDIT_MESSAGE)->IsWindowVisible())
                pMainDlg->GetDlgItem(IDC_EDIT_MESSAGE)->ShowWindow(SW_HIDE);
        }
    }
    pDlg->AddToInfOut(_T("Error:Transfer thread exit!"),1,1);
    return 0;
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnShowWindow                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��l�Ƥ����U���󪬺A                                                                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bShow	   	  	  -[in]   �O�_���                                                         */
/*				 nStatus	   	  -[in]   ���A�Ѽ�                                                         */
/* Returns:                                                                                                */
/*               ���`���p����Ƥ���^                                                                      */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
    GUID HidGuid;
    UINT nComNum;
    CString tmpStr;

    CDialog::OnShowWindow(bShow, nStatus);

    // TODO: �b���B�K�[�����B�z�{���X
    GetWindowText(m_sTitleString);

    //�s�����A
    if (m_bIsMPModeEnabled == TRUE) {
        SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T(""));
    } else {
        uTxtFontColor = 1; //����r��
        SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T("Disconnected"));
    }


    //�ɸ��|�]�Ĥ@�����}�q�{���|�^
    m_ctlEditCodeFile.SetWindowText(m_strCodeFilePath.Left(m_strCodeFilePath.ReverseFind('\\') + 1));
    m_ctlEditDataFile.SetWindowText(m_strDataFilePath.Left(m_strDataFilePath.ReverseFind('\\') + 1));


    //�ɸ�T
    SetDlgItemText(IDC_EDIT_CODE_SIZE,_T(""));
    SetDlgItemText(IDC_EDIT_CODE_SUM,_T(""));
    SetDlgItemText(IDC_EDIT_DATA_SIZE,_T(""));
    SetDlgItemText(IDC_EDIT_DATA_SUM,_T(""));



    //�q�{Program APROM
    ((CButton *)GetDlgItem(IDC_RADIO_APROM))->SetCheck(TRUE);

    //�q�{����config
    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_UNCHECKED);

    //�q�{����CAN
    ((CButton *)GetDlgItem(IDC_CHECK_CAN))->SetCheck(BST_UNCHECKED);
    GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
    bIsCanInterface = FALSE;

    nComNum = ScanPCCom();

    if( nComNum == 0 )
        AddToInfOut(CString(_T("Failed to list COM ports")),1,1);
    else {
        m_ctrComBox.SetCurSel(0);
    }

    //�q�t�m��Ū�W���ާ@�Ҧ�
    if(FALSE == GetConnectionType(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))) ) {
#ifdef FOR_CORETRONIC
        //�q�{COM�Ҧ�
        ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->SetCheck(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->SetCheck(FALSE);
        m_ctrComBox.EnableWindow(TRUE);
        uCurPortSelected = PORT_COM;
#else
        //�q�{USB�Ҧ�
        ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->SetCheck(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->SetCheck(FALSE);
        m_ctrComBox.EnableWindow(FALSE);
        uCurPortSelected = PORT_USB;
#endif
        GetDlgItem(IDC_CHECK_CAN)->EnableWindow(TRUE);
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(TRUE);
    }

    m_hexConfig0 = CONFIG0_DEFAULT_VALUE;
    m_hexConfig1 = CONFIG1_DEFAULT_VALUE;

    //m_ctlConfigSel.AddString(_T("- Get config -"));
    m_ctlConfigSel.AddString(_T("Last config"));
    m_ctlConfigSel.AddString(_T("On-chip config"));
    m_ctlConfigSel.SetCurSel(0);


    SetDlgItemText(IDC_TXT_CONFIG0,_T("FFFFFFFF"));
    SetDlgItemText(IDC_TXT_CONFIG1,_T("FFFFFFFF"));

    SetDlgItemText(IDC_TXT_PARTNO_INFO,_T("RAM: N/A    APROM: N/A    DataFlash: N/A"));

    //�i�ױ��d��
    m_writeProgress.SetRange(0,100);

    //�q�{�T��@�ǫ��s
    GetDlgItem(IDC_BUTTON_CODE_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_DATA_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_CODE_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_DATA_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
    GetDlgItem(IDC_RICHEDIT_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_TAB_FILE_HEX)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_NVM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_APROM_NVM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_ERASE)->EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_BURN_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_PROGRESS1)->EnableWindow(FALSE);

    GetDlgItem(IDC_EDIT_CODE_SIZE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_CODE_SUM)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_DATA_SUM)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_PART_NO)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_SAVE_CHECKSUM)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_APPID)->EnableWindow(FALSE);

    GetDlgItem(IDC_TXT_DETECT_POINT)->SetWindowTextW(_T(""));
    GetDlgItem(IDC_TXT_DETECT_POINT)->ShowWindow(FALSE);


    //Tab
    m_tab.InsertItem(0,_T("APROM"));
    m_tab.InsertItem(1,_T("DataFlash"));

#ifdef MSG_TAB_ENABLE
    m_tab.InsertItem(2,_T("Message"));
#endif

    //�q�{���}APROM��Edit control
    m_text_aprom.ShowWindow(TRUE);
    m_text_dataflash.ShowWindow(FALSE);
    m_text_message.ShowWindow(FALSE);

//	m_text_aprom.SetWindowTextW(_T("Test APROM\r\n"));
//	m_text_dataflash.SetWindowTextW(_T("Test Dataflash\r\n"));
//	m_text_message.SetWindowTextW(_T("Test Msg"));





    //��l�Ƽg���i�ɥΪ�Overlapped���c��
    //�����q�]�m��0
    WriteOverlapped.Offset=0;
    WriteOverlapped.OffsetHigh=0;
    //�Ыؤ@�Өƥ�A���ѵ�WriteFile�ϥΡA��WriteFile�����ɡA
    //�|�]�m�Өƥ�Ĳ�o���A�C
    WriteOverlapped.hEvent=CreateEvent(NULL,TRUE,FALSE,NULL);

    //��l��Ū���i�ɥΪ�Overlapped���c��
    //�����q�]�m��0
    ReadOverlapped.Offset=0;
    ReadOverlapped.OffsetHigh=0;
    //�Ыؤ@�Өƥ�A���ѵ�ReadFile�ϥΡA��ReadFile�����ɡA
    //�|�]�m�Өƥ�Ĳ�o���A�C
    ReadOverlapped.hEvent=CreateEvent(NULL,TRUE,FALSE,NULL);

    pDlg = this;


    //�Ыؼg���i���u�{�]�B�󱾰_���A�^
    pWriteReportThread=AfxBeginThread(TransferThread,
    this,
    THREAD_PRIORITY_NORMAL,
    0,
    CREATE_SUSPENDED,
    NULL);
    //�p�G�Ыئ��\�A�h��_�ӽu�{���B��
    if(pWriteReportThread!=NULL) {
        pWriteReportThread->ResumeThread();
    }

    //���HID�]�ƪ�������GUDI
    HidD_GetHidGuid(&HidGuid);
    //�]�mDevBroadcastDeviceInterface���c��A�Ψӵ��U�]�Ƨ��ܮɪ��q��
    DevBroadcastDeviceInterface.dbcc_size=sizeof(DevBroadcastDeviceInterface);
    DevBroadcastDeviceInterface.dbcc_devicetype=DBT_DEVTYP_DEVICEINTERFACE;
    DevBroadcastDeviceInterface.dbcc_classguid=HidGuid;
    //���U�]�Ƨ��ܮɦ���q��
    RegisterDeviceNotification(m_hWnd,
    &DevBroadcastDeviceInterface,
    DEVICE_NOTIFY_WINDOW_HANDLE);

    m_bIsFirstInit = FALSE;

    AddToInfOut(_T("PATH:")+lastConfigFilePath,1,1);
    if (!lastConfigFilePath.IsEmpty())
        LoadProjectFile(lastConfigFilePath);
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     itos                                                              	                       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ഫ�Q���i��/�Q�i��Ʀr�ڬ��r��                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 value	   	  	  -[in]   ���ഫ�ƭ�                                                       */
/*				 radix	   	  	  -[in]   �i��: 16,10                                                      */
/* Returns:                                                                                                */
/*               �ƭȹ������r��                                                                          */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
CString CNuvoISPDlg::itos(INT value, INT radix)
{
    static CString Str;

    Str.Empty();
    if(radix==16) {
        Str.Format(_T("0x%08x"),value);
    } else {
        Str.Format(_T("%d"),value);
    }
    Str.MakeUpper();
    return Str;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdToDo                                                              	                   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �Ұʽu�{�A�B�z�^���R�O                                                                    */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 cmd	   	  	  -[in]   �ݳB�z�R�O                                                       */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdToDo(DWORD cmd)
{

    //�p�G�]�ƨS�����A�h��^����
    if( (MyDevFound==FALSE)&&(cmd!=CMD_GET_FWVER) ) {
        AddToInfOut(_T("Device not found"),1,1);
        return FALSE;
    }

    //�p�G����X�L�ġA�h�������}�]�ƥ���
    if( ((hUsbHandle==INVALID_HANDLE_VALUE) && (uCurPortSelected == PORT_USB))
    || ((hCom==INVALID_HANDLE_VALUE) && (uCurPortSelected == PORT_COM)) ) {
        AddToInfOut(_T("Invalid device!"),1,1);
        return FALSE;
    }


    //�p�G��Ƥ��b�o�e���A�h��^����
    if(DataInSending==TRUE) {
        AddToInfOut(_T("Data in sending,try later!"),1,1);
        return FALSE;
    }

    SetDlgItemText(IDC_TXT_RESULT,_T(""));

    g_packno = 1;
    g_debug = 0;

    m_curCmd = cmd;
    DataInSending=TRUE;
    m_writeProgress.SetPos(0);

    return TRUE;

}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonBurnAprom                                                                */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI�W�I����Start�����s�ɪ��^����ơA��Ʒ|�۰ʥͦ������R�O�A�M��Ұʽu�{�B�z               */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void  CNuvoISPDlg::OnBnClickedButtonBurnAprom()
{
    //TODO
    //�ˬd���P�Ҧ��U�������ɬO�_�s�b
    //�������Ҧ���ĵ�i
    DWORD ret;
    unsigned long baseAddr = 0;

    if (m_bIsMPModeEnabled == TRUE) {
        if (MyDevFound == FALSE) {
            m_MP_Mode_Status = MP_STATUS_CONNECTING;
            GetDlgItem(IDC_TXT_MP_STATUS)->SetWindowText(_T(""));
            OnBnClickedButtonOpenDevice();
            return;
        }
    }

    m_ctlEditCodeFile.GetWindowText(m_strCodeFilePath);
    m_ctlEditDataFile.GetWindowText(m_strDataFilePath);

    m_sMyCmdList.nCmdNum = 0;

    // CCTu 0217
    if(m_ChipSerial == SERIAL_NUC505) {
        ((CButton *)GetDlgItem(IDC_RADIO_ERASE))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(FALSE);
    }


    //Data
    if ((((CButton *)GetDlgItem(IDC_RADIO_NVM))->GetCheck() == BST_CHECKED) ||
    (((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->GetCheck() == BST_CHECKED)   )

    {
        // CCTu 0217
        if(m_ChipSerial == SERIAL_NUC505) {
            CString tmpStr;
            GetDlgItemText(IDC_EDIT_DATA_BASE_ADDR, tmpStr);
            baseAddr = _tcstol(tmpStr, NULL, 16);
            m_sMyFileInfo.uDataFileStartAddr = baseAddr;
            m_sMyChipType.uDataFlashStartAddr = 0x5000;; // 20KB
            if(baseAddr < 0x5000) {
                MessageBox(_T("Start from a wrong data address! (< 0x5000)"),_T("Error"),MB_OK);
                return;
            }
            m_sMyChipType.uDataFlashSize = m_sMyChipType.uFlashSize - m_sMyFileInfo.uDataFileStartAddr;
        }

        if (m_bIsProjectFileLoaded == FALSE) {
            ret = GetFileAttributes(m_strDataFilePath);

            if ((ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY) || (m_sMyFileInfo.uDataFileSize == 0)) {
                MessageBox(_T("No data file!"),_T("Error"),MB_OK);
                return;
            }

            if (m_sMyFileInfo.uDataFileSize > m_sMyChipType.uDataFlashSize) {
                MessageBox(_T("Data size is too big!"),_T("Error"),MB_OK);
                return;
            }
        }

        if(m_sMyFileInfo.uDataFileStartAddr < m_sMyChipType.uDataFlashStartAddr) { //�}�l�a�}���b�i�Ϊ�Dataflash�a�}����
            MessageBox(_T("Start from a wrong data address!"),_T("Error"),MB_OK);
            return;
        }

        if(m_ChipSerial == SERIAL_NUC505)
            bDataFlagErrorColorEnable = FALSE;

        m_sMyCmdList.nCmdNum ++;
        m_sMyCmdList.aCmdList[m_sMyCmdList.nCmdNum-1] = CMD_UPDATE_DATAFLASH;
    }

    //Config
    if(((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->GetCheck() == BST_CHECKED) {
        m_sMyCmdList.nCmdNum ++;
        m_sMyCmdList.aCmdList[m_sMyCmdList.nCmdNum-1] = CMD_UPDATE_CONFIG;
    }


    //Code
    if ((((CButton *)GetDlgItem(IDC_RADIO_APROM))->GetCheck() == BST_CHECKED) ||
    (((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->GetCheck() == BST_CHECKED)   ) {

        if(m_ChipSerial == SERIAL_NUC505) {
            if(((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->GetCheck() == BST_CHECKED)
                m_sMyChipType.uCodeFlashSize = baseAddr - 0x4000;
            else
                m_sMyChipType.uCodeFlashSize = MAX_BIN_FILE_SIZE;
        }

        if (m_bIsProjectFileLoaded == FALSE) {
            ret = GetFileAttributes(m_strCodeFilePath);
            if( (ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY) || (m_sMyFileInfo.uCodeFileSize == 0) ) {
                MessageBox(_T("No APROM file!"),_T("Error"),MB_OK);
                return;
            }
            if (m_sMyFileInfo.uCodeFileSize > (m_sMyChipType.uCodeFlashSize-ISP_RESERVED_SIZE)) {
                MessageBox(_T("APROM size is too big!"),_T("Error"),MB_OK);
                return;
            }
        }

        if(m_sMyFileInfo.uCodeFileStartAddr+m_sMyFileInfo.uCodeFileSize > (m_sMyChipType.uCodeFlashSize-ISP_RESERVED_SIZE)) { //�V�ɶW�LCodeFlash�̤j��,�A�Ω�hex�˴�
            MessageBox(_T("APROM buffer extends past max available address!"),_T("Error"),MB_OK);
            return;
        }

        if(m_ChipSerial == SERIAL_NUC505)
            bCodeFlagErrorColorEnable = FALSE;

        m_sMyCmdList.nCmdNum ++;
        m_sMyCmdList.aCmdList[m_sMyCmdList.nCmdNum-1] = CMD_UPDATE_APROM;
    }

    //Erase All
    if (((CButton *)GetDlgItem(IDC_RADIO_ERASE))->GetCheck() == BST_CHECKED) {
        m_sMyCmdList.nCmdNum ++;
        m_sMyCmdList.aCmdList[m_sMyCmdList.nCmdNum-1] = CMD_ERASE_ALL;
    }

    m_sMyCmdList.nCmdTotalNum = m_sMyCmdList.nCmdNum;

    if(m_sMyCmdList.nCmdTotalNum == 0) {
        MessageBox(_T("Nothing to do"),_T("Message"),MB_OK);
        return;
    }


    (CButton *)GetDlgItem(IDC_CHECK_SAVE_CHECKSUM)->EnableWindow(FALSE);

    //���B�z�̫�@��CMD,�M��u�W�{�اP�_�O�_���ѾlCMD�ݭn�B�z
    CmdToDo(m_sMyCmdList.aCmdList[m_sMyCmdList.nCmdNum-1]);

}

HBRUSH CNuvoISPDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
    HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

    // TODO:  �b����� DC �������ݩ�

    // TODO:  �p�G�q�{�����O�һݵe���A�h��^�t�@�ӵe��
    if (pWnd->GetDlgCtrlID() == IDC_EDIT_MESSAGE) {

        pDC->SetTextColor(RGB(255,255,255)); //��r�C��
        pDC->SetBkColor(RGB(0, 0, 0)); //��r�I��
        //hbr=CreateSolidBrush(RGB(0,0,0)); //�s��حI��,�n����H�H�H
        return m_editHbr;

    } else if((pWnd->GetDlgCtrlID() == IDC_EDIT_CODE_SIZE)&& (bCodeFlagErrorColorEnable) ) {
        pDC->SetTextColor(RGB(255,0,0)); //�X���ɬ������r

    } else if((pWnd->GetDlgCtrlID() == IDC_EDIT_DATA_SIZE)&& (bDataFlagErrorColorEnable) ) {
        pDC->SetTextColor(RGB(255,0,0)); //�X���ɬ������r

    } else if((pWnd->GetDlgCtrlID() == IDC_TXT_CONNECT_STATUS)||(pWnd->GetDlgCtrlID() == IDC_TXT_DETECT_POINT)) {
        if(uTxtFontColor == 1)
            pDC->SetTextColor(RGB(255,0,0)); //�X���ɬ������r
        else if (uTxtFontColor == 2)
            pDC->SetTextColor(RGB(73,200,73)); //���
    } else if(pWnd->GetDlgCtrlID() == IDC_TXT_RESULT) {
        if(uTxtFontColor == 1)
            pDC->SetTextColor(RGB(255,0,0)); //�X���ɬ������r
        else if(uTxtFontColor == 2)
            pDC->SetTextColor(RGB(73,200,73)); //���
        else
            pDC->SetTextColor(RGB(255,255,255)); //black

    }
#ifdef IS_MP_VER
    else if(pWnd->GetDlgCtrlID() == IDC_TXT_MP_STATUS) {
        CFont Font;
        CString css;
        CClientDC dc(this);

        switch (m_MP_Mode_Status) {
        case MP_STATUS_WAIT:
        case MP_STATUS_CONNECTING:
        case MP_STATUS_WRITING:
            pDC->SetTextColor(RGB(255,255,255)); //black
            break;

        case MP_STATUS_PASS:
            pDC->SetTextColor(RGB(73,200,73)); //���
            break;

        case MP_STATUS_CONN_FAIL:
        case MP_STATUS_WRITE_FAIL:
            pDC->SetTextColor(RGB(255,0,0)); //�X���ɬ������r
            break;
        }

        VERIFY(Font.CreatePointFont(350, _T("Arial"), &dc));
        //Font.CreatePointFont(350,css);
        pDC->SelectObject(&Font);
    }
#endif
    return hbr;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonClose                                                                    */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI�W�I����Disconnect�����s�ɪ��^����ơA��Ʒ|�����]�ơA�]�m���s���A                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedButtonClose()
{
    // TODO: �b���K�[����q���B�z�{���X
    BOOL bResult;

    //�O�s���e�ާ@�O����ini��
    SaveBurnMode(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua")));
    if(uCurPortSelected != PORT_EMAC) {
        //�p�GŪ�ƾڪ�����X���O�L�ı���X�A�h������
        if (hUsbHandle != INVALID_HANDLE_VALUE) {
//#ifndef IS_MP_VER
            if (MyDevFound)
                RunApRom(PORT_USB);
//#endif

            bResult = CloseHandle(hUsbHandle);
            hUsbHandle=INVALID_HANDLE_VALUE;
#ifdef WINUSB_NUVO_DFU
            if (hWinUSBHandle != INVALID_HANDLE_VALUE) {
                WinUsb_Free(hWinUSBHandle);
                hWinUSBHandle = INVALID_HANDLE_VALUE;
            }
#endif
        }

        if (hCom != INVALID_HANDLE_VALUE) {
            if (MyDevFound)
                RunApRom(PORT_COM);
            PurgeComm( hCom, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR
            | PURGE_RXCLEAR );
            bResult = CloseHandle(hCom);
            //if(bResult == FALSE)
            //MessageBox(_T("Failed to close COM handler"),_T("Error"),MB_OK);
            hCom=INVALID_HANDLE_VALUE;
        }
    } else {
        if (MyDevFound)
            RunApRom(PORT_EMAC);

        closesocket(sclient);
    }

    if (m_bIsMPModeEnabled) {
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->SetWindowTextW(_T("Connect"));
        goto next1;
    }
    //�q�{�T��@�ǫ��s
    GetDlgItem(IDC_BUTTON_CODE_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_DATA_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_CODE_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_DATA_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
    GetDlgItem(IDC_RICHEDIT_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_TAB_FILE_HEX)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_NVM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_APROM_NVM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_ERASE)->EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_BURN_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_PROGRESS1)->EnableWindow(FALSE);

    GetDlgItem(IDC_EDIT_CODE_SIZE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_CODE_SUM)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_DATA_SUM)->EnableWindow(FALSE);
    GetDlgItem(IDC_EDIT_PART_NO)->EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_SAVE_CHECKSUM)->EnableWindow(FALSE);

    GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->SetWindowTextW(_T("Connect"));
    GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(TRUE);

    ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->EnableWindow(TRUE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->EnableWindow(TRUE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->EnableWindow(TRUE);

    m_ctlConfigSel.EnableWindow(FALSE);

    if (((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->GetCheck()) {
        if (m_bIsMPModeEnabled == FALSE)
            m_ctrComBox.EnableWindow(TRUE);
        GetDlgItem(IDC_CHECK_CAN)->EnableWindow(FALSE);
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
    } else {
        m_ctrComBox.EnableWindow(FALSE);
        GetDlgItem(IDC_CHECK_CAN)->EnableWindow(TRUE);
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(TRUE);
    }

next1:

    DataInSending=FALSE;
    bDetecting = FALSE;
    bDetectingSaved = FALSE;
    g_packno = 1;
    g_debug = 0;


    //���m�i�ױ�
    m_writeProgress.SetPos(0);

    //�]�m�]�ƪ��A�������
    MyDevFound=FALSE;
    bIsConfigLoad = FALSE;

    //�M�Ť奻��X��,���������T
    SetDlgItemText(IDC_EDIT_MESSAGE,_T(""));

    //SetDlgItemText(IDC_RICHEDIT_APROM,_T(""));
    //SetDlgItemText(IDC_RICHEDIT_FLASHDATA,_T(""));
    //AddToInfOut(_T("Close the device!"),1,1);

    //��ܳ]�ƪ����A
    //SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T(""));

    if (m_bIsMPModeEnabled == TRUE) {
        uTxtFontColor = 3;
        SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T(""));
    } else {
        uTxtFontColor = 1; //����r��
        SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T("Disconnected"));
    }

    m_sMyCmdList.nCmdNum = 0;
    m_sMyCmdList.nCmdTotalNum = 0;

    //�M���W���N�g���A
    SetDlgItemText(IDC_TXT_RESULT,_T(""));
    SetDlgItemText(IDC_TXT_CMD_NUM,_T(""));
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     InterfaceSelect                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ˬd���e�s���Ҧ�                                                                          */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               PORT_USB  : USB�Ҧ�                                                                */
/*               PORT_COM : �DUSB�Ҧ�(��f�Ҧ�)                                                          */
/*               PORT_COM : Ethernet�Ҧ�(EMAC)                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
int CNuvoISPDlg::InterfaceSelect()
{
    if( uCurPortSelected == PORT_USB)
        return PORT_USB;
    else if( uCurPortSelected == PORT_COM)
        return PORT_COM;
    else
        return PORT_EMAC;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     GetConnectionType                                                              	       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �q�t�m�ɤ�����s���覡���ѼơA�����Ψ���e�����W                                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 filename	   	  	  -[in]   �t�m�ɸ��|                                                 */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::GetConnectionType(CString filename)
{

    CString strWhichCom;
    TCHAR buffer[MAX_PATH] = {0};
    INT index;

    if(!filename.CompareNoCase(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))))
        m_strConnectPort_last_saved.Empty();


    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTPORT"),_T(""),buffer,MAX_PATH,filename);

#ifdef FOR_CORETRONIC
    if (0)
#else
    if (wcsncmp(buffer,_T("USB"),3) == 0)
#endif
    {
        m_ctrComBox.EnableWindow(FALSE);
        GetDlgItem(IDC_CHECK_CAN)->EnableWindow(TRUE);
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->SetCheck(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->SetCheck(FALSE);
        if(!filename.CompareNoCase(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))))
            m_strConnectPort_last_saved.Format(_T("USB"));
    } else if (wcsncmp(buffer,_T("COM"),3) == 0) {
        if (!MyDevFound) {
            if (m_bIsMPModeEnabled == FALSE)
                m_ctrComBox.EnableWindow(TRUE);
            GetDlgItem(IDC_CHECK_CAN)->EnableWindow(FALSE);
            GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
        }
        ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->SetCheck(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->SetCheck(FALSE);

#ifndef IS_MP_VER	// If not MP version, search for the preferred COM port from list.
        m_ctrComBox.SetCurSel(0);

        for(index=0; index<m_ctrComBox.GetCount(); index++) {
            m_ctrComBox.GetLBText(index, strWhichCom);
            //if(wcsncmp(buffer,strWhichCom,m_ctrComBox.GetLBTextLen(index)>wcslen(buffer)?m_ctrComBox.GetLBTextLen(index):wcslen(buffer)) == 0)
            if(wcscmp(buffer,strWhichCom) == 0) {
                m_ctrComBox.SetCurSel(index);
                if (!filename.CompareNoCase(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))))
                    m_strConnectPort_last_saved = strWhichCom;
                return TRUE;
            }
        }
#endif

        return FALSE;
    } else {
        m_ctrComBox.EnableWindow(FALSE);
        GetDlgItem(IDC_CHECK_CAN)->EnableWindow(TRUE);
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(TRUE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->SetCheck(FALSE);
        ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->SetCheck(TRUE);
        if(!filename.CompareNoCase(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))))
            m_strConnectPort_last_saved.Format(_T("EMAC"));
    }
    return TRUE;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdChipConnection                                                              	       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �s���U����ɵo�e�����R�O���������T                                                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdChipConnection(int DevInterface)
{

    BOOL Result;
    unsigned long cmdData;
    CString tmpStr;
    DWORD ret;

//Detecting
//CMD_CONNECT
    AddToInfOut(_T("Detecting..."),1,1);
    Result = DetectDevice(DevInterface);
    if(Result == FALSE)
        goto fail;

    AddToInfOut(_T("ISP device detected!"),1,1);
    SleepEx(100,TRUE); //Waitting ISP Firmware Working


//first:
//CMD_SET_CAN_ID
    if(bIsCanInterface) {
        Result = CmdSetCanId(DevInterface);
        if(Result == FALSE) {
            MessageBox(_T("USB write error"),_T("Error"),MB_OK);
            goto fail;
        }
    }
//CMD_SYNC_PACKNO
    AddToInfOut(_T("Getting flash mode..."),1,1);
    Result = CmdSyncPackno(DevInterface);
    if(Result == FALSE) {
        Result = CmdSyncPackno(DevInterface);
        if(Result == FALSE)
            goto fail;
    }

//CMD_GET_VERSION
    AddToInfOut(_T("Getting ISP version..."),1,1);
    Result = CmdSyncPackno(DevInterface);
    if(Result == FALSE)
        goto fail;

    Result = CmdWriteAndReadOne(DevInterface, CMD_GET_FWVER);
    if (Result == FALSE)
        goto fail;

    if (DevInterface == PORT_USB)
        memcpy(&m_IspVersion,ReadReportBuffer+9,1); //ISP version
    else
        memcpy(&m_IspVersion,ReadReportBuffer+8,1);

    if (m_IspVersion == 0) //ISP FW version
        goto fail;

    if (m_IspVersion > FW_VER_NUM) {
        tmpStr.Format(_T("Firmware version problem!\nCurrent FW version V%x.%x is newer than V%x.%x\n\nContinue?"),m_IspVersion>>4,m_IspVersion&0xF, FW_VER_NUM>>4,FW_VER_NUM&0xF);

        if (IDCANCEL == MessageBox(tmpStr,_T("Warning"),MB_OKCANCEL) )
            goto fail;
    }

    tmpStr.Format(_T("F/W Ver:%x.%x"),m_IspVersion>>4,m_IspVersion&0xF);
    pDlg->AddToInfOut(tmpStr,1,1);
    SetDlgItemText(IDC_TXT_FW_NO,tmpStr);

//CMD_GET_DEVICEID
    AddToInfOut(_T("Getting device ID..."),1,1);
    Result = CmdWriteAndReadOne(DevInterface, CMD_GET_DEVICEID);
    if(Result == FALSE)
        goto fail;

    if (DevInterface == PORT_USB)
        memcpy(&m_sMyChipType.uChipID,ReadReportBuffer+9,4); //Device ID
    else
        memcpy(&m_sMyChipType.uChipID,ReadReportBuffer+8,4);

#ifdef DEBUG_EMULATE
    m_sMyChipType.uChipID = 0x00111201;
    m_sMyChipType.uFlashSize = 0x10000;
#endif

    tmpStr.Format(_T("Device ID:%08X"),m_sMyChipType.uChipID);
    pDlg->AddToInfOut(tmpStr,1,1);

    if (m_sMyChipType.uChipID == 0)
        goto fail;
    //tmpStr.Format(_T("0x%08X"),m_sMyChipType.uChipID);
    //SetDlgItemText(IDC_EDIT_PART_NO,tmpStr);

//CMD_READ_CONFIG
    AddToInfOut(_T("Getting Config..."),1,1);
    Result = CmdWriteAndReadOne(DevInterface, CMD_READ_CONFIG);
    if(Result == FALSE)
        goto fail;

    if (DevInterface == PORT_USB) {
        memcpy(&m_hexConfig0_saved,ReadReportBuffer+9,4); //Config0
        memcpy(&m_hexConfig1_saved,ReadReportBuffer+13,4); //Config0
    } else { // PORT_COM & PORT_EMAC
        memcpy(&m_hexConfig0_saved,ReadReportBuffer+8,4); //Config0
        memcpy(&m_hexConfig1_saved,ReadReportBuffer+12,4); //Config0
    }

    m_hexConfig0 = m_hexConfig0_saved;
    m_hexConfig1 = m_hexConfig1_saved;

//Check if locked
    if(m_hexConfig0 & (1<<1))
        bIsChipLocked = FALSE;
    else
        bIsChipLocked = TRUE;

    //bIsChipLocked = TRUE; //test

    if(bIsChipLocked) {
        pDlg->AddToInfOut(_T("Chip is locked"),1,1);
        //SetDlgItemText(IDC_TXT_CONFIG0,_T(""));
        //SetDlgItemText(IDC_TXT_CONFIG1,_T(""));
    }

    tmpStr.Format(_T("Config0:%08X \r\nConfig1:%08X"),m_hexConfig0_saved,m_hexConfig1_saved);
    pDlg->AddToInfOut(tmpStr,0,1);


    tmpStr.Format(_T("%08X"),m_hexConfig0);
    SetDlgItemText(IDC_TXT_CONFIG0,tmpStr);
    tmpStr.Format(_T("%08X"),m_hexConfig1);
    SetDlgItemText(IDC_TXT_CONFIG1,tmpStr);

    Result = UpdateChipInfo();
    if (Result == FALSE)
        goto fail;

#if 1
//FW2.3�H��i�H�ۦ汴��APROM size
    if ((Result) && (m_IspVersion < 0x23)) {
        AddToInfOut(_T("Sending APROM size..."),0,0);
        m_curCmd = CMD_APROM_SIZE;
        memset(WriteReportBuffer, 0, MAX_PACKET+1);
        cmdData = CMD_APROM_SIZE;
        memcpy(WriteReportBuffer+1, &cmdData, 4);
        memcpy(WriteReportBuffer+5, &g_packno, 4);
        memcpy(WriteReportBuffer+9, &m_sMyChipType.uFlashSize, 4);
        g_packno++;

        Result = WriteData(DevInterface);
        if (Result == FALSE) {
            AddToInfOut(_T("False"),1,1);
            goto fail;
        }

        Result = ReadData(DevInterface);
        if (Result)
            AddToInfOut(_T("OK"),1,1);
        else {
            AddToInfOut(_T("False"),1,1);
            goto fail;
        }
    }
#endif

//�s�����s�ܦ��_�}�s��
    if (m_bIsMPModeEnabled == FALSE) {
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->SetWindowTextW(_T("Disconnect"));
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(TRUE);
    }

    if (m_bIsMPModeEnabled == TRUE) {
//		int  wait_loop;

        GetDlgItem(IDC_EDIT_CODE_SUM)->EnableWindow(TRUE);
        GetDlgItem(IDC_EDIT_DATA_SUM)->EnableWindow(TRUE);
        //GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);

        //GetDlgItem(IDC_TAB_FILE_HEX)->EnableWindow(TRUE);
        //GetDlgItem(IDC_RICHEDIT_APROM)->EnableWindow(TRUE);
        GetDlgItem(IDC_PROGRESS1)->EnableWindow(TRUE);

        MyDevFound=TRUE;

        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUTTON_BURN_APROM)->EnableWindow(TRUE);

        LoadProjectFile(m_ProjectFilePath);
        GetDlgItem(IDC_TXT_MP_STATUS)->SetWindowText(_T(""));

        return TRUE;
    }

    GetDlgItem(IDC_BUTTON_CODE_FILE)->EnableWindow(TRUE);
    GetDlgItem(IDC_BUTTON_DATA_FILE)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_CODE_FILE)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_DATA_FILE)->EnableWindow(TRUE);
    GetDlgItem(IDC_TAB_FILE_HEX)->EnableWindow(TRUE);
    GetDlgItem(IDC_RICHEDIT_APROM)->EnableWindow(TRUE);
    GetDlgItem(IDC_RADIO_APROM)->EnableWindow(TRUE);
    GetDlgItem(IDC_RADIO_NVM)->EnableWindow(TRUE);
    GetDlgItem(IDC_RADIO_APROM_NVM)->EnableWindow(TRUE);
    GetDlgItem(IDC_RADIO_ERASE)->EnableWindow(TRUE);
    GetDlgItem(IDC_BUTTON_BURN_APROM)->EnableWindow(TRUE);
    if( (((CButton *)GetDlgItem(IDC_RADIO_NVM))->GetCheck() == BST_CHECKED) ||
    (((CButton *)GetDlgItem(IDC_RADIO_ERASE))->GetCheck() == BST_CHECKED) )

    {
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(FALSE);
        GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(FALSE);
    } else
        GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
    GetDlgItem(IDC_PROGRESS1)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_CODE_SIZE)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_CODE_SUM)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_DATA_SUM)->EnableWindow(TRUE);
    GetDlgItem(IDC_CHECK_SAVE_CHECKSUM)->EnableWindow(TRUE);
    GetDlgItem(IDC_EDIT_APPID)->EnableWindow(TRUE);

    m_ctlConfigSel.EnableWindow(TRUE);


    uTxtFontColor = 2; //���r��
    SetDlgItemText(IDC_TXT_CONNECT_STATUS,_T("Connected"));
    MyDevFound=TRUE;

//�p�G�s�����\,�h���ե��}�W������
    ret = GetFileAttributes(m_strDataFilePath);
    if (!((ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY))) {
        m_ctlEditDataFile.SetWindowText(m_strDataFilePath);;
        Result = GetFileInfo(m_strDataFilePath, FALSE, &m_sMyFileInfo);

        CheckFileSize(2);

        if (Result)
            ShowBinFile(DataFileBuffer,FALSE,m_sMyFileInfo.uDataFileSize);
        else
            m_text_dataflash.SetWindowText(_T(""));
    }


    ret = GetFileAttributes(m_strCodeFilePath);
    if (!((ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY))) {
        m_ctlEditCodeFile.SetWindowText(m_strCodeFilePath);;
        Result = GetFileInfo(m_strCodeFilePath, TRUE, &m_sMyFileInfo);


        CheckFileSize(1);//����ɤj�p�M����flash�j�p�A�æbUI�W���
        if (Result)
            ShowBinFile(CodeFileBuffer,TRUE,m_sMyFileInfo.uCodeFileSize);
        else
            m_text_aprom.SetWindowText(_T(""));
    }

//�ާ@�����
    ChangeBurnMode(m_uBurnMode_last);

    return TRUE;


fail:
    //AddToInfOut(_T("Connect fail!"),1,1);

    if (m_bIsMPModeEnabled == FALSE) {
        GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(TRUE);
    }
    ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->EnableWindow(TRUE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->EnableWindow(TRUE);
    ((CButton *)GetDlgItem(IDC_RADIO_DEVEMAC))->EnableWindow(TRUE);

    if(((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->GetCheck())
        m_ctrComBox.EnableWindow(TRUE);
    else
        m_ctrComBox.EnableWindow(FALSE);


    MyDevFound=FALSE;
    OnBnClickedButtonClose();

    //���}Message��
#ifdef MSG_TAB_ENABLE
    m_tab.SetCurSel(2);
    m_text_aprom.ShowWindow(FALSE);
    m_text_dataflash.ShowWindow(FALSE);
    m_text_message.ShowWindow(TRUE);
#endif


    return FALSE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ChangeBurnMode                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ھڰt�m��TŪ�X����T�A���ܷ��e�N���Ҧ�                                                  */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 mode	   	  	  -[in]   �N���Ҧ��G1--APROM,2--Data,3--APROM+Data,4--Erase                */
/*				                                    11--APROM+config,13--APROM+Data+config                 */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::ChangeBurnMode(DWORD mode)
{

    CString strTemp;

    TRACE(_T("ChangeBurnMode=%d\r\n"), mode);

    //�ާ@�����
    ((CButton *)GetDlgItem(IDC_RADIO_APROM))->SetCheck(BST_UNCHECKED);
    ((CButton *)GetDlgItem(IDC_RADIO_NVM))->SetCheck(BST_UNCHECKED);
    ((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->SetCheck(BST_UNCHECKED);
    ((CButton *)GetDlgItem(IDC_RADIO_ERASE))->SetCheck(BST_UNCHECKED);
    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(FALSE);

//	if(bIsChipLocked)
//	{
//		((CButton *)GetDlgItem(IDC_RADIO_ERASE))->SetCheck(BST_CHECKED);
//		OnBnClickedRadioErase();
//		m_ctlConfigSel.SetCurSel(1);
//	}
//	else
    {
        //��ܤW���ާ@�ﶵ

        if(mode == 1) { //APROM
            ((CButton *)GetDlgItem(IDC_RADIO_APROM))->SetCheck(BST_CHECKED);
            OnBnClickedRadioAprom();
            if ( ((DataFlashType_II() == TRUE) &&
            ((m_hexConfig0_last != m_hexConfig0_saved) ||
            (((m_hexConfig0_last & 1) == 0) && (m_hexConfig1_last != m_hexConfig1_saved))))
            ||
            ((DataFlashType_II() == FALSE) &&
            ((m_hexConfig0_last >> 1) != (m_hexConfig0_saved >> 1))))

            {
                if (MyDevFound) {
                    GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
                    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
                }
                ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            }
            m_hexConfig0 = m_hexConfig0_last;
            m_hexConfig1 = m_hexConfig1_last;
            UpdateSizeInfo(FALSE);
            m_ctlConfigSel.SetCurSel(0);

        } else if(mode == 2) { //Data
            ((CButton *)GetDlgItem(IDC_RADIO_NVM))->SetCheck(BST_CHECKED);
            OnBnClickedRadioNvm();
            m_ctlConfigSel.SetCurSel(1);
            return TRUE;
        } else if(mode == 3) { //APROM+Data
            ((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->SetCheck(BST_CHECKED);
            OnBnClickedRadioApromNvm();
            if (((DataFlashType_II() == TRUE) &&
            ((m_hexConfig0_last != m_hexConfig0_saved) ||
            (((m_hexConfig0_last & 1) == 0) &&
            (m_hexConfig1_last != m_hexConfig1_saved)))) ||
            ((DataFlashType_II() == FALSE) &&
            ((m_hexConfig0_last >> 1) != (m_hexConfig0_saved >> 1)))) {
                if (MyDevFound) {
                    GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
                    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
                }
                ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            }
            m_hexConfig0 = m_hexConfig0_last;
            m_hexConfig1 = m_hexConfig1_last;
            UpdateSizeInfo(FALSE);
            m_ctlConfigSel.SetCurSel(0);
        } else if(mode == 4) { //erase
            ((CButton *)GetDlgItem(IDC_RADIO_ERASE))->SetCheck(BST_CHECKED);
            OnBnClickedRadioErase();
            m_ctlConfigSel.SetCurSel(1);
            return TRUE;
        } else if(mode == 11) { //APROM+config
            ((CButton *)GetDlgItem(IDC_RADIO_APROM))->SetCheck(BST_CHECKED);
            OnBnClickedRadioAprom();
            if(MyDevFound) {
                GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
                GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
            }
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            m_hexConfig0 = m_hexConfig0_last;
            m_hexConfig1 = m_hexConfig1_last;
            UpdateSizeInfo(FALSE);
            m_ctlConfigSel.SetCurSel(0); //Last config

        } else if(mode == 13) { //APROM+data+config
            ((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->SetCheck(BST_CHECKED);
            OnBnClickedRadioApromNvm();
            if(MyDevFound) {
                GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
                GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
            }
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            m_hexConfig0 = m_hexConfig0_last;
            m_hexConfig1 = m_hexConfig1_last;
            UpdateSizeInfo(FALSE);
            m_ctlConfigSel.SetCurSel(0);

        } else {
            ((CButton *)GetDlgItem(IDC_RADIO_APROM))->SetCheck(BST_CHECKED);
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(FALSE);
            OnBnClickedRadioAprom();
            m_ctlConfigSel.SetCurSel(1);
        }

        if (IsCFG01Invalid(m_hexConfig0_saved, m_hexConfig1_saved)) {
            if (MyDevFound) {
                strTemp.Format(_T("Invalid config value:\nCF0=0x%08X, CF1=0x%08X\n\nUse last config instead\n"),m_hexConfig0_saved,m_hexConfig1_saved);
                MessageBox(strTemp,_T("Error"),MB_OK);
                GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
                GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);

            }
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            m_hexConfig0 = m_hexConfig0_last;
            m_hexConfig1 = m_hexConfig1_last;
            UpdateSizeInfo(FALSE);
            m_ctlConfigSel.SetCurSel(0);
        }
    }

    return TRUE;

}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedRadioUsb                                                                       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �]�ƪ��A���ܮɪ��B�z���                                                                  */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
LRESULT  CNuvoISPDlg::OnDeviceChange(WPARAM  nEventType, LPARAM dwData)
{
    PDEV_BROADCAST_DEVICEINTERFACE pdbi;
    CString DevPathName;

    //dwData�O�@�ӫ��VDEV_BROADCAST_DEVICEINTERFACE���c�骺���СA
    //�b�ӵ��c�餤�O�s�F�]�ƪ������B���|�W���ѼơC�q�L��ڭ̫��w�]��
    //�����|�W����A�Y�i�H�P�_�O�_�O�ڭ̫��w���]�ƩޤU�Ϊ̴��J�F�C
    pdbi=(PDEV_BROADCAST_DEVICEINTERFACE)dwData;

    switch(nEventType) { //�Ѽ�nEventType���O�s�ۨƥ�����
        //�]�Ƴs���ƥ�
    case DBT_DEVICEARRIVAL:
        if(pdbi->dbcc_devicetype==DBT_DEVTYP_DEVICEINTERFACE) {
            DevPathName=pdbi->dbcc_name; //�O�s�o�ͪ��A���ܪ��]�ƪ����|�W
            //����O�_�O�ڭ̫��w���]��
            if( (MyDevPathName.CompareNoCase(DevPathName)==0) && (InterfaceSelect() == PORT_USB)) {
                OnBnClickedButtonOpenDevice();
                //AddToInfOut(_T("Device connected"),1,1);
            }
        }
        return TRUE;

        //�]�ƩޥX�ƥ�
    case DBT_DEVICEREMOVECOMPLETE:
        if(pdbi->dbcc_devicetype==DBT_DEVTYP_DEVICEINTERFACE) {
            DevPathName=pdbi->dbcc_name; //�O�s�o�ͪ��A���ܪ��]�ƪ����|�W
            //����O�_�O�ڭ̫��w���]��
            if(MyDevPathName.CompareNoCase(DevPathName)==0) {
                AddToInfOut(_T("Plug out"),1,1);
                //�]�ƳQ�ޥX�A���������]�ơ]�p�G�B�󥴶}���A���ܡ^�A����ާ@
                if(InterfaceSelect() == PORT_USB) {
                    OnBnClickedButtonClose();
                }
            }
        }
        return TRUE;

    default:
        return TRUE;
    }
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CreateBlank                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ͦ��@�w�ƶq���Ů�r��                                                                  */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 num	   	  	  -[in]   �Ů�ƶq                                                         */
/* Returns:                                                                                                */
/*               �Ů�r��                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
CString CNuvoISPDlg::CreateBlank(INT num)
{
    CString blank;
    blank.Empty();
    for(INT i=0; i<num; i++)
        blank+=_T("   ");

    return blank;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ShowBinFile                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �奻�ؤ���ܤG�i���ƩM���ASCII�X                                                       */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 fileBuf	   	  	  -[in]   ��ܸ�ƪ���}                                               */
/*				 bCodeFile	   	  	  -[in]   �O�_���N�X���: TURE--Code, FALSE--Data                      */
/*				 fileSize	   	  	  -[in]   ��ܸ�Ƥj�p                                                 */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::ShowBinFile(UCHAR *fileBuf,BOOL bCodeFile,UINT fileSize)
{

    CRichEditCtrl *CurShowEdit;
    UINT index = 0;
    CString tmpStr,tmpLine;
    CString tmpStrASCII,tmpLineASCII;
    UINT startAddr;

    CString strToShow; //�w�s�X��Ashow,�����t��
    UINT nLineNum = 0;

    if (m_bIsMPModeEnabled == TRUE) {
        return;
    }

    if (bCodeFile) {
        CurShowEdit = &m_text_aprom;
        startAddr = m_sMyFileInfo.uCodeFileStartAddr;
    } else {
        CurShowEdit = &m_text_dataflash;
        startAddr = m_sMyFileInfo.uDataFileStartAddr;

    }

    CurShowEdit->SetWindowText(_T("")); //�M��

    //tmpLine.Format(_T("%08X  "),0);
    //if(bIsChipLocked)
    //	tmpLine.Format(_T("FFFFFFFF  "));//locked���A�����æ�}
    //else
    tmpLine.Format(_T("%08X  "),startAddr);
    tmpLineASCII.Format(_T("; "));
    strToShow.Empty();
    for(index=0; index<fileSize; index++) {
        tmpStr.Format(_T("%02X "),fileBuf[index]);
        if((fileBuf[index]>=0x7F) || (fileBuf[index]<=31)) //���i��ܦr��
            tmpStrASCII = _T(".");
        else
            tmpStrASCII.Format(_T("%c"),fileBuf[index]);


        tmpLine += tmpStr;
        tmpLineASCII += tmpStrASCII;

        if(( (index+1)%16 == 0 ) || (index == (fileSize-1)) ) {
            if((index+1)%16 == 0 ) {
                strToShow += tmpLine+tmpLineASCII+_T("\r\n");
                nLineNum++;
            } else {
                strToShow += tmpLine+CreateBlank(16-(fileSize%16))+tmpLineASCII+_T("\r\n");//�����@��ΪŮ�ɻ�
                nLineNum++;
            }
            tmpLine.Empty();
            tmpLineASCII.Empty();
            //if(bIsChipLocked)
            //   tmpLine.Format(_T("FFFFFFFF  "));//locked���A�����æ�}
            //else
            tmpLine.Format(_T("%08X  "),startAddr+index+1);
            tmpLineASCII.Format(_T("; "));
        }

        if( (nLineNum == 50)||(index == fileSize-1) ) {
            CurShowEdit->SetSel(-1,-1);
            CurShowEdit->ReplaceSel(strToShow);
            strToShow.Empty();
            nLineNum = 0;
        }

    }
    CurShowEdit->SetSel(0,0);
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     HexStringToDec                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �N�r���ഫ���Q���i����                                                                */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 buf	   	  	  -[in]   �r���}                                                       */
/*				 len	   	  	  -[in]   �r�����                                                       */
/* Returns:                                                                                                */
/*               �Q���i��ƾ�                                                                              */
/*---------------------------------------------------------------------------------------------------------*/
unsigned long CNuvoISPDlg::HexStringToDec(TCHAR *buf, UINT len)
{
    TCHAR hexString[16]= {0};
    memcpy(hexString,buf,len*sizeof(hexString[0]));

    return _tcstoul(hexString, NULL, 16);

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     HexToBin                                                              	                   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Hex�榡�ഫ���G�i��Bin�榡                                                                */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 filename	   	  	  -[in]   Hex���a�}                                                  */
/*				 nMaxBufSize	   	  -[in]   �̤j����                                                     */
/*				 bCodeFile	   	  	  -[in]   �O�_��Code                                                   */
/*				 fileInfo	   	  	  -[out]  ��X�����ɸ�T                                             */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::HexToBin(LPCTSTR filename,UINT nMaxBufSize,BOOL bCodeFile,MY_FILE_INFO_TYPE *fileInfo)
{
//���o��Hex�y�z�����_�l�a�}�MSize

    int nRecordType, nRecordLen;
    UINT nRecordAddr;
    bool bEndOfField;
    CString strBuffer;
    TCHAR *Buffer;
    TCHAR *pRecordData;
    BYTE cCalCheckSum, cRecordCheckSum;
    UCHAR cFillByte = 0x00;
    UCHAR *TargetBuf;//���Vcode��data�����buf

    UINT curMode = 0;
    UINT highOffset = 0;
    BOOL bInitAddr = TRUE;


    UINT startAddr = 0;
    UINT maxAddr = 0;
    UINT lastlen = 0;//�̰���}���檺��ƪ���

    CStdioFile file;
    if( file.Open(filename,CFile::modeRead) == NULL )
        return FALSE;


    bEndOfField = false;
    UINT nReadSize = 0;

    while( bEndOfField == false) {
        if( file.ReadString(strBuffer) == NULL )
            break;

        Buffer = strBuffer.GetBuffer();

        if ( Buffer[0] != _T(':') ) {
            // An field format error.
            goto out;
        }
        // Get record's data length.
        nRecordLen = HexStringToDec( Buffer + 1, 2 );
        // Get record's start address.
        nRecordAddr = HexStringToDec( Buffer + 3, 4 );
        // Get Record's type.
        nRecordType = HexStringToDec( Buffer + 7, 2 );
        // Get the first data's address within record.
        pRecordData = Buffer + 9;
        switch( nRecordType ) {
        case 00:
            if(curMode == 0x2) { //�X�i�Ҧ��ɥ[�W���찾���q
                nRecordAddr = (highOffset<<4) + nRecordAddr;
            } else if(curMode == 0x4) {
                nRecordAddr = (highOffset<<16) + nRecordAddr;
            }

            if(bInitAddr) {
                startAddr = nRecordAddr;
                maxAddr = nRecordAddr;
                lastlen = nRecordLen;
                bInitAddr = FALSE;

            }


            if( nRecordAddr<startAddr)
                startAddr = nRecordAddr;
            if( nRecordAddr>maxAddr ) {
                maxAddr = nRecordAddr;
                lastlen = nRecordLen;
            }


            break;
        case 01:
            bEndOfField = true;

            break;
        case 02: //�X�i�q�a�}
            curMode = 0x02;
            highOffset = HexStringToDec( pRecordData, 4 );

            break;
        case 04: //�X�i�u�ʦ�}
            curMode = 0x04;
            highOffset = HexStringToDec( pRecordData, 4 );

            break;
        default:
            break;
        }

        strBuffer.ReleaseBuffer();

    }

    if (bCodeFile) {
        fileInfo->uCodeFileType = 1;//hex
        fileInfo->uCodeFileStartAddr = startAddr;
        fileInfo->uCodeFileSize = maxAddr-startAddr+lastlen;
        TargetBuf = CodeFileBuffer;
    } else {
        fileInfo->uDataFileType = 1;
        fileInfo->uDataFileStartAddr = startAddr;
        fileInfo->uDataFileSize = maxAddr-startAddr+lastlen;
        TargetBuf = DataFileBuffer;
    }

    if(!bEndOfField)
        goto out;

//goto out;


//�ĤG�B�A�ഫ���
    bEndOfField = false;
    curMode = 0;
    highOffset = 0;
    ::memset( TargetBuf, cFillByte, nMaxBufSize );//��l�Ƭ�00
    file.SeekToBegin();
    while( bEndOfField == false) {
        if( file.ReadString(strBuffer) == NULL )
            break;

        Buffer = strBuffer.GetBuffer();

        if ( Buffer[0] != _T(':') ) {
            // An field format error.
            goto out;
        }
        // Get record's data length.
        nRecordLen = HexStringToDec( Buffer + 1, 2 );
        // Get record's start address.
        nRecordAddr = HexStringToDec( Buffer + 3, 4 );
        // Get Record's type.
        nRecordType = HexStringToDec( Buffer + 7, 2 );
        // Get the first data's address within record.
        pRecordData = Buffer + 9;
        switch( nRecordType ) {
        case 00:
            cCalCheckSum = (BYTE)nRecordLen +
            ((BYTE)(nRecordAddr>>8) + (BYTE)nRecordAddr) +
            (BYTE)nRecordType;

            if(curMode == 0x2) { //�X�i�Ҧ��ɥ[�W���찾���q
                nRecordAddr = (highOffset<<4) + nRecordAddr;
            } else if(curMode == 0x4) {
                nRecordAddr = (highOffset<<16) + nRecordAddr;
            }

            break;
        case 01:
            bEndOfField = true;
            strBuffer.ReleaseBuffer();

            goto out;
        case 02: //�X�i�q�a�}
            curMode = 0x02;
            highOffset = HexStringToDec( pRecordData, 4 );
            strBuffer.ReleaseBuffer();

            continue;
        case 04: //�X�i�u�ʦ�}
            curMode = 0x04;
            highOffset = HexStringToDec( pRecordData, 4 );
            strBuffer.ReleaseBuffer();

            continue;
        default:

            strBuffer.ReleaseBuffer();
            continue;
        }



        if ( (nRecordAddr-startAddr) >= nMaxBufSize )
            break;
        else if( (nRecordAddr-startAddr+nRecordLen) > nMaxBufSize )
            break;

        BYTE cData;
        int nValidDataLen, i;


        nValidDataLen = nRecordLen;

        // Read data from record.
        for( i = 0; i < nValidDataLen; i++ ) {
            cData = (BYTE)HexStringToDec( pRecordData, 2 );
            TargetBuf[nRecordAddr-startAddr] = cData;
            cCalCheckSum += cData;
            nRecordAddr ++;
            pRecordData += 2;
        }

        cCalCheckSum = -cCalCheckSum; // 2'complement
        // Get Check sum from record.
        cRecordCheckSum = (BYTE)HexStringToDec( pRecordData, 2 );
        if ( cRecordCheckSum != cCalCheckSum ) {
            MessageBox(_T("Check sum error!"),_T("Error"),MB_OK);
            break;
        }

        strBuffer.ReleaseBuffer();

    }



out:
    file.Close();

    return bEndOfField;


}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     GetFileInfo                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ����ݿN���ɸ�T                                                                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 filename	   	  	  -[in]   Hex���a�}                                                  */
/*				 bCodeFile	   	  	  -[in]   �O�_��Code                                                   */
/*				 fileInfo	   	  	  -[out]  ��X�����ɸ�T                                             */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::GetFileInfo(LPCTSTR filename, BOOL bCodeFile, MY_FILE_INFO_TYPE *fileInfo)
{
    HANDLE hFileHandle = INVALID_HANDLE_VALUE;
    BOOL Result=FALSE;
    unsigned long totallen=0,readcn=0;
    unsigned short lcksum; //16 bit checksum
    CString postfix = filename;//�ھڧ��X�W�ϧOhex�Mbin
    UCHAR * buf;

    if(bCodeFile) {
        fileInfo->uCodeFileCheckSum = 0;
        fileInfo->uCodeFileSize = 0;
    } else {
        fileInfo->uDataFileCheckSum = 0;
        fileInfo->uDataFileSize = 0;
    }

    unsigned long baseAddr = 0;
    CString tmpStr;
    WIN32_FIND_DATA   ffd   ;
    HANDLE   hFind = FindFirstFile(filename, &ffd);
    FindClose(hFind);
    if (bCodeFile)
        fileInfo->ftLastCodeFileWriteTime = ffd.ftLastWriteTime;
    else
        fileInfo->ftLastDataFileWriteTime = ffd.ftLastWriteTime;
    bActivateExitNow = FALSE;

    postfix = postfix.Right(postfix.GetLength()-postfix.ReverseFind('.')-1);
    if (!postfix.CompareNoCase(_T("hex"))) {
        Result = HexToBin(filename,MAX_BIN_FILE_SIZE,bCodeFile,fileInfo);
        //tmpStr.Format(_T("Result:%d; size:%d; Start:%X"),Result,fileInfo->uCodeFileSize,fileInfo->uCodeFileStartAddr);
        //AfxMessageBox(tmpStr);
        if ((bCodeFile && (fileInfo->uCodeFileSize > MAX_BIN_FILE_SIZE)) ||
        ((!bCodeFile) && (fileInfo->uDataFileSize > MAX_BIN_FILE_SIZE)) ) {
            MessageBox(_T("File size is too big"),_T("Error"),MB_OK);
            return FALSE;
        }
        if (Result == FALSE)
            return FALSE;

        if (bCodeFile)
            fileInfo->uCodeFileCheckSum = Checksum(CodeFileBuffer, fileInfo->uCodeFileSize);
        else
            fileInfo->uDataFileCheckSum = Checksum(DataFileBuffer, fileInfo->uDataFileSize);

    } else {

        hFileHandle=CreateFile(filename,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL);
        if (hFileHandle==INVALID_HANDLE_VALUE)
            return FALSE;

        totallen = GetFileSize(hFileHandle, NULL);

        if ((m_ChipSerial == SERIAL_NANO1XX) ||
        (m_ChipSerial == SERIAL_NUC100D) ||
        (m_ChipSerial == SERIAL_NUC200A) ||
        (m_ChipSerial == SERIAL_NUC505)  ||
        (m_ChipSerial == SERIAL_NUC470)) {
            GetDlgItem(IDC_EDIT_APROM_BASE_ADDR)->EnableWindow(FALSE);
            GetDlgItemText(IDC_EDIT_APROM_BASE_ADDR, tmpStr);
            baseAddr = _tcstol(tmpStr, NULL, 16);
        } else {
            GetDlgItem(IDC_EDIT_APROM_BASE_ADDR)->EnableWindow(FALSE);
            baseAddr = 0;
        }

        if (bCodeFile) {
            fileInfo->uCodeFileType = 0;//bin
            fileInfo->uCodeFileStartAddr = baseAddr;//0;//clyu
            fileInfo->uCodeFileSize = totallen;
            buf = CodeFileBuffer;
        } else {
            fileInfo->uDataFileType = 0;
            fileInfo->uDataFileStartAddr = m_sMyChipType.uDataFlashStartAddr;
            fileInfo->uDataFileSize = totallen;
            buf = DataFileBuffer;
        }

        if(totallen > MAX_BIN_FILE_SIZE) {
            MessageBox(_T("File size is too big"),_T("Error"),MB_OK);
            return FALSE;
        }

        Result = ReadFile(hFileHandle,
        buf,
        MAX_BIN_FILE_SIZE,
        &readcn,
        NULL);

        if( (Result == TRUE) && (readcn !=totallen) ) {
            CloseHandle(hFileHandle);
            return FALSE;
        } else if(Result == FALSE) {
            CloseHandle(hFileHandle);
            return FALSE;
        }
        lcksum = Checksum(buf, readcn);
        if(bCodeFile)
            fileInfo->uCodeFileCheckSum = lcksum;
        else
            fileInfo->uDataFileCheckSum = lcksum;
    }

    CloseHandle(hFileHandle);

    return TRUE;
}


#ifdef PORJ_SAVE_ALL
/*---------------------------------------------------------------------------------------------------------*/
/* Function:     GetFileInfoFromConfig                                                              	   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �q Project File ����ݿN���ɸ�T                                                         */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 filename	   	  	  -[in]   Project file path                                            */
/*				 fileInfo	   	  	  -[out]  ��X�����ɸ�T                                               */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::GetFileInfoFromConfig(LPCTSTR filename, MY_FILE_INFO_TYPE *fileInfo)
{
    int		fd;
    BOOL 	Result = FALSE;
    unsigned long ap_totallen=0, data_totallen=0, readcn=0;
    unsigned short lcksum; //16 bit checksum
    CString tmpStr;
    char 	four_id[4];

    unsigned long baseAddr;
    WIN32_FIND_DATA   ffd;
    HANDLE   hFind = FindFirstFile(filename, &ffd);
    FindClose(hFind);

    fileInfo->ftLastCodeFileWriteTime = ffd.ftLastWriteTime;
    fileInfo->ftLastDataFileWriteTime = ffd.ftLastWriteTime;
    bActivateExitNow = FALSE;

    if (_wsopen_s(&fd, filename, _O_RDONLY | _O_BINARY, _SH_DENYNO, _S_IREAD | _S_IWRITE)) {
        TRACE(_T("FAILED to open project file! ...\r\n"));
        return FALSE;
    }

    _lseek(fd, PRJ_BIN_OFFSET, SEEK_SET);

    if (_read(fd, four_id, 4) != 4) {			// read PRJ_APROM_BIN
        _close(fd);
        return FALSE;
    }

    if (memcmp(four_id, PRJ_APROM_BIN, 4)) {	// check PRJ_APROM_BIN
        // Magic code was not found. It shoudl be old project file.
        _close(fd);
        return FALSE;
    }

    if (_read(fd, &baseAddr, 4) != 4) {		// get AP execution address
        _close(fd);
        return FALSE;
    }

    if (_read(fd, &ap_totallen, 4) != 4) {	// get AP image size
        _close(fd);
        return FALSE;
    }

    if (ap_totallen) {						// read AP image
        fileInfo->uCodeFileType = 0;			// bin
        fileInfo->uCodeFileStartAddr = baseAddr;
        fileInfo->uCodeFileSize = ap_totallen;
        if (_read(fd, CodeFileBuffer, ap_totallen) != ap_totallen) {
            TRACE(_T("uCodeFileSize=%d, ap_totallen=%d\r\n"), fileInfo->uCodeFileSize, ap_totallen);
            _close(fd);
            return FALSE;
        }
        lcksum = Checksum(CodeFileBuffer, ap_totallen);
        fileInfo->uCodeFileCheckSum = lcksum;

        CheckFileSize(1);						//����ɤj�p�M����flash�j�p�A�æbUI�W���
        ShowBinFile(CodeFileBuffer, TRUE, m_sMyFileInfo.uCodeFileSize);

        // clear APROM file path, because the APROM image is from project file
        m_strCodeFilePath.Empty();
        m_ctlEditCodeFile.SetWindowText(m_strCodeFilePath);

        tmpStr.Format(_T("0x%04X"), fileInfo->uCodeFileCheckSum);
        SetDlgItemText(IDC_EDIT_CODE_SUM, tmpStr);
        GetDlgItem(IDC_EDIT_CODE_SUM)->EnableWindow(TRUE);

        bCodeFlagErrorColorEnable = FALSE;
        GetDlgItem(IDC_EDIT_CODE_SIZE)->EnableWindow(TRUE);
    }

    if (_read(fd, four_id, 4) != 4) {			// read ID - PRJ_DATA_BIN
        _close(fd);
        return FALSE;
    }

    if (memcmp(four_id, PRJ_DATA_BIN, 4)) {	// check ID - PRJ_DATA_BIN
        _close(fd);
        return FALSE;
    }

    if (_read(fd, &data_totallen, 4) != 4) {	// get Data image size
        _close(fd);
        return FALSE;
    }

    if (data_totallen) {						// read Data image
        fileInfo->uDataFileType = 0;
        fileInfo->uDataFileStartAddr = m_sMyChipType.uDataFlashStartAddr;
        fileInfo->uDataFileSize = data_totallen;
        if (_read(fd, DataFileBuffer, data_totallen) != data_totallen) {
            _close(fd);
            return FALSE;
        }
        lcksum = Checksum(DataFileBuffer, data_totallen);
        fileInfo->uDataFileCheckSum = lcksum;

        CheckFileSize(2);						//����ɤj�p�M����flash�j�p�A�æbUI�W���
        ShowBinFile(DataFileBuffer, FALSE, m_sMyFileInfo.uDataFileSize);

        // clear DATA file path, because the APROM image is from project file
        m_strDataFilePath.Empty();
        m_ctlEditDataFile.SetWindowText(m_strDataFilePath);

        tmpStr.Format(_T("0x%04X"), fileInfo->uDataFileCheckSum);
        SetDlgItemText(IDC_EDIT_DATA_SUM, tmpStr);
        GetDlgItem(IDC_EDIT_DATA_SUM)->EnableWindow(TRUE);

        bDataFlagErrorColorEnable = FALSE;
        GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
    }

    _close(fd);

    m_bIsProjectFileLoaded = TRUE;
    m_ProjectFilePath = filename;

#ifdef IS_MP_VER
    m_bIsMPModeEnabled = TRUE;
    m_MP_Mode_Status = MP_STATUS_WAIT;

    GetDlgItem(IDC_BUTTON_CODE_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_DATA_FILE)->EnableWindow(FALSE);
    GetDlgItem(IDC_COMBO_CONFIG_SEL)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_APROM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_NVM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_APROM_NVM)->EnableWindow(FALSE);
    GetDlgItem(IDC_RADIO_ERASE)->EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(FALSE);

    GetDlgItem(IDC_BUTTON_OPEN_DEVICE)->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_BURN_APROM)->EnableWindow(TRUE);

    GetDlgItem(IDC_EDIT_MESSAGE)->ShowWindow(SW_HIDE);
    GetDlgItem(IDC_TAB_FILE_HEX)->ShowWindow(SW_HIDE);
    GetDlgItem(IDC_RICHEDIT_APROM)->ShowWindow(SW_HIDE);
    GetDlgItem(IDC_RICHEDIT_FLASHDATA)->ShowWindow(SW_HIDE);

    GetDlgItem(IDC_TXT_MP_STATUS)->SetWindowText(_T(""));
    GetDlgItem(IDC_TXT_MP_STATUS)->ShowWindow(SW_SHOWNORMAL);
    GetDlgItem(IDC_TXT_MP_STATUS)->RedrawWindow();
#endif

    TRACE(_T("Code size is %d %d\r\n"), fileInfo->uCodeFileSize, m_sMyFileInfo.uCodeFileSize);
    TRACE(_T("Data size is %d %d\r\n"), fileInfo->uDataFileSize, m_sMyFileInfo.uDataFileSize);
    TRACE(_T("GetFileInfoFromConfig OK.\r\n"));

    return TRUE;
}
#endif



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonCodeFile                                                                 */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Code�� �ﶵ�ɪ��^�����                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedButtonCodeFile()
{
    // TODO: �b���K�[����q���B�z�{���X
    HANDLE hFileHandle = INVALID_HANDLE_VALUE;
    unsigned long totallen=0,readcn=0;
    UINT lcksum=0;
    BOOL Result=FALSE;
    CString tmpStr;
    CString sPath = m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"));

    TCHAR szFilters[] = TEXT("Bin Files (*.bin)|*.bin|Intel Hex Files (*.hex)|*.hex|All Files (*.*)|*.*||");

    CFileDialog dlg (TRUE, TEXT("bin"), TEXT("code.bin"), OFN_FILEMUSTEXIST| OFN_READONLY, szFilters, this);


    CString strCurPath = m_strCodeFilePath;
    strCurPath = strCurPath.Left(strCurPath.ReverseFind('\\') + 1);
    dlg.m_ofn.lpstrInitialDir = strCurPath;

    if (IDOK == dlg.DoModal()) {
        m_strCodeFilePath = dlg.GetPathName();
        m_ctlEditCodeFile.SetWindowText(m_strCodeFilePath);;
        Result = GetFileInfo(m_strCodeFilePath, TRUE, &m_sMyFileInfo);


        CheckFileSize(1);//����ɤj�p�M����flash�j�p�A�æbUI�W���
        if(Result)
            ShowBinFile(CodeFileBuffer,TRUE,m_sMyFileInfo.uCodeFileSize);
        else
            m_text_aprom.SetWindowText(_T(""));

        m_tab.SetCurSel(0);
        m_text_aprom.ShowWindow(TRUE);
        m_text_dataflash.ShowWindow(FALSE);
        m_text_message.ShowWindow(FALSE);

        //save to ini file
        WritePrivateProfileStringW(CString(_T("NU_PATH")),_T("NU_APROM"),m_strCodeFilePath,sPath);



    }
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonDataFile                                                                 */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Data�� �ﶵ�ɪ��^�����                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedButtonDataFile()
{
    // TODO: �b���K�[����q���B�z�{���X
    HANDLE hFileHandle = INVALID_HANDLE_VALUE;
    unsigned long totallen=0,readcn=0;
    UINT lcksum=0;
    BOOL Result=FALSE;
    CString tmpStr;
    CString sPath = m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"));

    TCHAR szFilters[] = TEXT("Bin Files (*.bin)|*.bin|Intel Hex Files (*.hex)|*.hex|All Files (*.*)|*.*||");

    CFileDialog dlg (TRUE, TEXT("bin"), TEXT("data.bin"), OFN_FILEMUSTEXIST| OFN_READONLY, szFilters, this);


    CString strCurPath = m_strDataFilePath;
    strCurPath = strCurPath.Left(strCurPath.ReverseFind('\\') + 1);
    dlg.m_ofn.lpstrInitialDir = strCurPath;

    if (IDOK == dlg.DoModal()) {
        m_strDataFilePath = dlg.GetPathName();
        m_ctlEditDataFile.SetWindowText(m_strDataFilePath);;
        Result = GetFileInfo(m_strDataFilePath,FALSE,&m_sMyFileInfo);

        CheckFileSize(2);

        if(Result)
            ShowBinFile(DataFileBuffer,FALSE,m_sMyFileInfo.uDataFileSize);
        else
            m_text_dataflash.SetWindowText(_T(""));

        m_tab.SetCurSel(1);
        m_text_aprom.ShowWindow(FALSE);
        m_text_dataflash.ShowWindow(TRUE);
        m_text_message.ShowWindow(FALSE);

        //save to ini file
        WritePrivateProfileStringW(CString(_T("NU_PATH")),_T("NU_LDROM"),m_strDataFilePath,sPath);
    }
}







/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CheckFileSize                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ˬd��J�ɤj�p�O�_�X�k                                                                  */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 index	   	  	  -[in]   �ﶵ:1--code file,2--data file,3--check all                      */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::CheckFileSize(UINT8 index)
{
    CString tmpStr;

    //��s�ɤj�p�ˬd��T
    if ((index == 1) || (index == 3)) {
        if (m_sMyFileInfo.uCodeFileSize > (m_sMyChipType.uCodeFlashSize-ISP_RESERVED_SIZE)) {
            bCodeFlagErrorColorEnable = TRUE;
            SetDlgItemText(IDC_EDIT_CODE_SUM,_T(""));
        } else {
            bCodeFlagErrorColorEnable = FALSE;
            if(m_sMyFileInfo.uCodeFileCheckSum) {
                tmpStr.Format(_T("0x%04X"),m_sMyFileInfo.uCodeFileCheckSum);
                SetDlgItemText(IDC_EDIT_CODE_SUM,tmpStr);
            } else
                SetDlgItemText(IDC_EDIT_CODE_SUM,_T(""));
        }
        if ((index == 3) && (m_sMyFileInfo.uCodeFileSize == 0))
            SetDlgItemText(IDC_EDIT_CODE_SIZE,_T(""));
        else {
            tmpStr.Format(_T("%d Bytes"),m_sMyFileInfo.uCodeFileSize);
            SetDlgItemText(IDC_EDIT_CODE_SIZE,tmpStr);
        }
    }

    if ((index == 2) || (index == 3)) {
        if(m_sMyFileInfo.uDataFileSize > m_sMyChipType.uDataFlashSize) {
            bDataFlagErrorColorEnable = TRUE;
            SetDlgItemText(IDC_EDIT_DATA_SUM,_T(""));
        } else {
            bDataFlagErrorColorEnable = FALSE;
            if(m_sMyFileInfo.uDataFileCheckSum) {
                tmpStr.Format(_T("0x%04X"),m_sMyFileInfo.uDataFileCheckSum);
                SetDlgItemText(IDC_EDIT_DATA_SUM,tmpStr);
            } else
                SetDlgItemText(IDC_EDIT_DATA_SUM,_T(""));
        }

        if((index==3) && (m_sMyFileInfo.uDataFileSize==0))
            SetDlgItemText(IDC_EDIT_DATA_SIZE,_T(""));
        else {
            tmpStr.Format(_T("%d Bytes"),m_sMyFileInfo.uDataFileSize);
            SetDlgItemText(IDC_EDIT_DATA_SIZE,tmpStr);
        }


    }

    //�M���W���N�g���A
    SetDlgItemText(IDC_TXT_RESULT,_T(""));
    SetDlgItemText(IDC_TXT_CMD_NUM,_T(""));
}



void CNuvoISPDlg::OnCbnSelchangeComboCom()
{
    // TODO: �b���K�[����q���B�z�{���X

}

void CNuvoISPDlg::OnEnChangeEdit4()
{
    // TODO:  �p�G�ӱ���O RICHEDIT ����A���N��
    // �o�e���q���A���D���g CDialog::OnInitDialog()
    // ��ƨýե� CRichEditCtrl().SetEventMask()�A
    // �P�ɱN ENM_CHANGE �лx���Ρ��B���B�n���C

    // TODO:  �b���K�[����q���B�z�{���X
}

void CNuvoISPDlg::OnEnChangeEditCodeSum()
{
    // TODO:  �p�G�ӱ���O RICHEDIT ����A���N��
    // �o�e���q���A���D���g CDialog::OnInitDialog()
    // ��ƨýե� CRichEditCtrl().SetEventMask()�A
    // �P�ɱN ENM_CHANGE �лx���Ρ��B���B�n���C

    // TODO:  �b���K�[����q���B�z�{���X
}

void CNuvoISPDlg::OnTcnSelchangeTabFileHex(NMHDR *pNMHDR, LRESULT *pResult)
{

    CString tmpStr;
    int CurSel = m_tab.GetCurSel();

    //tmpStr.Format(_T("Tab%d"),CurSel);
    //AfxMessageBox(tmpStr);

    switch(CurSel) {
    case 0:
        m_text_aprom.ShowWindow(TRUE);
        m_text_dataflash.ShowWindow(FALSE);
        m_text_message.ShowWindow(FALSE);
        break;

    case 1:
        m_text_aprom.ShowWindow(FALSE);
        m_text_dataflash.ShowWindow(TRUE);
        m_text_message.ShowWindow(FALSE);
        break;

    case 2:
        m_text_aprom.ShowWindow(FALSE);
        m_text_dataflash.ShowWindow(FALSE);
        m_text_message.ShowWindow(TRUE);
        break;



    default:
        break;
    }


    *pResult = 0;
}

void CNuvoISPDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    // TODO: �b���K�[�����B�z�{���X�M/�νեιw�]��

    if(nID == SC_CLOSE) {

        OnBnClickedButtonClose();
        UnregisterHotKey(GetSafeHwnd(),m_nHotKeyID[0]);
        UnregisterHotKey(GetSafeHwnd(),m_nHotKeyID[1]);

    }
    CDialog::OnSysCommand(nID, lParam);
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateSizeInfo                                                                            */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��s�ɤj�p��T                                                                          */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bCheckChangeFirst	   	  	  -[in]   ����O�_config�Ȧ����                               */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::UpdateSizeInfo(BOOL bCheckChangeFirst)
{

    CString strTmpDbg;

    if (!MyDevFound)
        return;


    // CCTu
    if(m_ChipSerial == SERIAL_NUC505) {







    }



    //�p�GConfig�Ȥ��e���L�ק�(�P���e�w�餤���Ȥ��P)�A�h�ק�L�ġA�έ�l�ȶi����
    if (bCheckChangeFirst) {
        if ((m_hexConfig0 == m_hexConfig0_saved)&&(m_hexConfig1 == m_hexConfig1_saved))
            return;

        m_hexConfig0 = m_hexConfig0_saved;
        m_hexConfig1 = m_hexConfig1_saved;
    }

    if (DataFlashType_II() == TRUE) {
        if (m_hexConfig0 & 1) {  //Disable Data Flash;
            m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashStartAddr = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashSize = 0;
        } else if (((m_hexConfig0 & 1) == 0) &&
        ((m_hexConfig1>m_sMyChipType.uFlashSize) ||
        (m_hexConfig1 % 512 != 0))) {
            m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashStartAddr = m_sMyChipType.uFlashSize;
            m_sMyChipType.uDataFlashSize = 0;
            m_hexConfig0 |= 1;
            m_hexConfig1 = m_sMyChipType.uFlashSize-4*1024; //0x1F000;
        } else {
            m_sMyChipType.uCodeFlashSize = m_hexConfig1;
            m_sMyChipType.uDataFlashStartAddr = m_hexConfig1;
            m_sMyChipType.uDataFlashSize = m_sMyChipType.uFlashSize - m_hexConfig1;

            if ((m_sMyFileInfo.uDataFileType == 0) && (m_sMyFileInfo.uDataFileSize) &&
            (m_sMyFileInfo.uDataFileCheckSum)) { //bin
                m_sMyFileInfo.uDataFileStartAddr = m_sMyChipType.uDataFlashStartAddr;
                ShowBinFile(DataFileBuffer,FALSE,m_sMyFileInfo.uDataFileSize);//��show Data,�D�n�O�_�l��}�ܤ�
            }
        }
    } else {
        m_sMyChipType.uCodeFlashSize = m_sMyChipType.uFlashSize;
        m_sMyChipType.uDataFlashSize = 4*1024;
        m_sMyChipType.uDataFlashStartAddr = 0x1F000;
        m_hexConfig1 = 0x1F000;
        /*
         *  There's no CONFIG1 ...
         */
        if ((m_ChipSerial == SERIAL_M05X) ||                           /* M051 series        */
        ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00010200)  ||   /* NUC102 ver. A      */
        ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00012200))      /* NUC122 ver. A      */
            m_hexConfig1 = 0xFFFFFFFF;
    }
    strTmpDbg.Format(_T("RAM: %d Bytes    APROM: %d Bytes    DataFlash: %d Bytes"),m_sMyChipType.uRamSize,
    m_sMyChipType.uCodeFlashSize,m_sMyChipType.uDataFlashSize);
    SetDlgItemText(IDC_TXT_PARTNO_INFO,strTmpDbg);

    strTmpDbg.Format(_T("%08X"),m_hexConfig0);
    SetDlgItemText(IDC_TXT_CONFIG0,strTmpDbg);
    strTmpDbg.Format(_T("%08X"),m_hexConfig1);
    SetDlgItemText(IDC_TXT_CONFIG1,strTmpDbg);

    CheckFileSize(3);
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedButtonDataFile                                                                 */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Data�� �ﶵ�ɪ��^�����                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedRadioNvm()
{
    // TODO: �b���K�[����q���B�z�{���X

    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_UNCHECKED);
    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);

    if (m_bIsMPModeEnabled == TRUE)
        return;

    UpdateSizeInfo(TRUE);
    m_ctlConfigSel.SetCurSel(1);
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedCheckConfigStart                                                               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Config�� �ﶵ�ɪ��^�����                                                         */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedCheckConfigStart()
{
    // TODO: �b���K�[����q���B�z�{���X
    CString strTemp;
#if 0
    if(bIsChipLocked) {
        MessageBox(_T("Chip has been locked\r\nIf you want to run programming,please \"Erase All\" first."),_T("Information"),MB_OK);
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_UNCHECKED);
        ((CButton *)GetDlgItem(IDC_RADIO_APROM))->SetCheck(BST_UNCHECKED);
        ((CButton *)GetDlgItem(IDC_RADIO_NVM))->SetCheck(BST_UNCHECKED);
        ((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->SetCheck(BST_UNCHECKED);
        ((CButton *)GetDlgItem(IDC_RADIO_ERASE))->SetCheck(BST_CHECKED);

        OnBnClickedRadioErase();
        return;
    }
#endif

    if( ((CButton *)GetDlgItem(IDC_RADIO_ERASE))->GetCheck() == BST_CHECKED )
        OnBnClickedRadioErase();


    if( ((CButton *)GetDlgItem(IDC_RADIO_NVM))->GetCheck() == BST_CHECKED ) {
        MessageBox(_T("Invalid operation"),_T("Warning"),MB_OK);
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_UNCHECKED);
        return;
    }


    if( ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->GetCheck() == BST_CHECKED ) {
        GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
    } else {
        if (IsCFG01Invalid(m_hexConfig0_saved, m_hexConfig1_saved)) {
            strTemp.Format(_T("On-chip config needs to be updated!\nCF0=0x%08X CF1=0x%08X\n"),m_hexConfig0_saved,m_hexConfig1_saved);
            MessageBox(strTemp,_T("Warning"),MB_OK);
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_CHECKED);
            return;
        }
        GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
        UpdateSizeInfo(TRUE);
        m_ctlConfigSel.SetCurSel(1);
    }
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedCheckConfigStart                                                               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Aprom�� �ﶵ�ɪ��^�����                                                          */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedRadioAprom()
{
    // TODO: �b���K�[����q���B�z�{���X

    if (MyDevFound) {
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->EnableWindow(TRUE);
        if (IsCFG01Invalid(m_hexConfig0_saved, m_hexConfig1_saved)) {
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_CHECKED);
            GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);
        }
    }
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedCheckConfigStart                                                               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Aprom+data�� �ﶵ�ɪ��^�����                                                     */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedRadioApromNvm()
{
    // TODO: �b���K�[����q���B�z�{���X

    if (MyDevFound) {
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->EnableWindow(TRUE);
        if (IsCFG01Invalid(m_hexConfig0_saved, m_hexConfig1_saved)) {
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_CHECKED);
            GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);

        }
    }
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedCheckConfigStart                                                               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�EraseAll�� �ﶵ�ɪ��^�����                                                       */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedRadioErase()
{
    // TODO: �b���K�[����q���B�z�{���X
    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(BST_UNCHECKED);
    ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->EnableWindow(FALSE);
    GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);
    m_ctlConfigSel.SetCurSel(1);
}

BOOL CNuvoISPDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
    // TODO: �b���K�[�����B�z�{���X�M/�νեιw�]��

    if(DataInSending) {
        ::SetCursor(LoadCursor(NULL,IDC_WAIT));
        return TRUE;
    }


    return CDialog::OnSetCursor(pWnd, nHitTest, message);
}

BOOL CNuvoISPDlg::PreTranslateMessage(MSG* pMsg)
{
    //�|�檬�ƹ��ɸT��k���I��
    if((pMsg->message   ==   WM_LBUTTONDOWN)&&DataInSending&&(!bDetecting)) {
        return TRUE;
    }
    if((pMsg->message   ==   WM_LBUTTONUP)&&DataInSending&&(!bDetecting)) {
        return TRUE;
    }

    return CDialog::PreTranslateMessage(pMsg);

}


void CNuvoISPDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
    WIN32_FIND_DATA   ffd   ;
    HANDLE   hFind;
    DWORD Result;
    BOOL bCodeChanged = FALSE;

    CDialog::OnActivate(nState, pWndOther, bMinimized);

    if (nState == WA_ACTIVE) {
//check code file
        if ((bActivateExitNow==TRUE)||(MyDevFound==FALSE)) //ACTIVE���A���ɷ|�o�n�X�M�A�o���קK���ƾާ@
            return;

        hFind = FindFirstFile(m_strCodeFilePath,&ffd);
        if (hFind == INVALID_HANDLE_VALUE) {
            bActivateExitNow = TRUE;
            goto next;
        } else
            FindClose(hFind);

        if ((m_bIsProjectFileLoaded == FALSE) &&
        (CompareFileTime(&ffd.ftLastWriteTime,&m_sMyFileInfo.ftLastCodeFileWriteTime) !=0)) {
            TRACE(_T("Code File changed,reload now"));
            bActivateExitNow = TRUE;
            bCodeChanged = TRUE;
            m_ctlEditCodeFile.SetWindowText(m_strCodeFilePath);;
            Result = GetFileInfo(m_strCodeFilePath,TRUE,&m_sMyFileInfo);

            CheckFileSize(1);//����ɤj�p�M����flash�j�p�A�æbUI�W���
            if(Result)
                ShowBinFile(CodeFileBuffer, TRUE, m_sMyFileInfo.uCodeFileSize);
            else
                m_text_aprom.SetWindowText(_T(""));

            m_tab.SetCurSel(0);
            m_text_aprom.ShowWindow(TRUE);
            m_text_dataflash.ShowWindow(FALSE);
            m_text_message.ShowWindow(FALSE);
        }

next:
        hFind=   FindFirstFile(m_strDataFilePath,&ffd);
        if (hFind == INVALID_HANDLE_VALUE) {
            bActivateExitNow = TRUE;
            return;
        } else
            FindClose(hFind);
//check data file
        if ((m_bIsProjectFileLoaded == FALSE) &&
        (CompareFileTime(&ffd.ftLastWriteTime,&m_sMyFileInfo.ftLastDataFileWriteTime) != 0)) {
            TRACE(_T("Data File changed,reload now"));
            bActivateExitNow = TRUE;
            m_ctlEditDataFile.SetWindowText(m_strDataFilePath);;
            Result = GetFileInfo(m_strDataFilePath, FALSE, &m_sMyFileInfo);

            CheckFileSize(2);

            if (Result)
                ShowBinFile(DataFileBuffer,FALSE,m_sMyFileInfo.uDataFileSize);
            else
                m_text_dataflash.SetWindowText(_T(""));

            m_tab.SetCurSel(1);
            m_text_aprom.ShowWindow(FALSE);
            m_text_dataflash.ShowWindow(TRUE);
            m_text_message.ShowWindow(FALSE);

        }

        TRACE(_T("active\n"));

    } else if(nState == WA_INACTIVE) {
        TRACE(_T("inactive\n"));
    }
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedCheckSaveChecksum                                                              */
/*                                                                                                         */
/* Description:                                                                                            */
/*               UI��ܡ�Save�� �ﶵ�ɪ��^�����                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedCheckSaveChecksum()
{

#ifdef CHECKSUM_SAVE_ENABLE
    // TODO: �b���K�[����q���B�z�{���X
    CString sPath = m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"));


    //save to ini file
    if(((CButton *)GetDlgItem(IDC_CHECK_SAVE_CHECKSUM))->GetCheck() == BST_CHECKED) {
        WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_CHECKSUM"),CString(_T("1")),sPath);
        ISP_RESERVED_SIZE = 8;
    } else {
        WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_CHECKSUM"),CString(_T("0")),sPath);
        ISP_RESERVED_SIZE = 0;
    }

    CheckFileSize(1);
#endif

}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     SaveBurnMode                                                                              */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �O�s���e�ާ@�Ҧ���t�m��                                                                */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 filename	   	  	  -[in]   �t�m�ɦ줸�}                                                 */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::SaveBurnMode(CString filename)
{

    CString sTemp;
    CString sPath = filename;
    BOOL bWriteFlag = TRUE; //Always save to project file.


    //get current burning mode
    if(((CButton *)GetDlgItem(IDC_RADIO_APROM))->GetCheck() == BST_CHECKED) {
        m_uBurnMode = 1;
        if(((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->GetCheck() == BST_CHECKED)
            m_uBurnMode = 11;
    } else if(((CButton *)GetDlgItem(IDC_RADIO_NVM))->GetCheck() == BST_CHECKED)
        m_uBurnMode = 2;
    else if(((CButton *)GetDlgItem(IDC_RADIO_APROM_NVM))->GetCheck() == BST_CHECKED) {
        m_uBurnMode = 3;
        if(((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->GetCheck() == BST_CHECKED)
            m_uBurnMode = 13;
    } else if(((CButton *)GetDlgItem(IDC_RADIO_ERASE))->GetCheck() == BST_CHECKED)
        m_uBurnMode = 4;
    else
        m_uBurnMode = 1;

    //Check file path
    if(!filename.CompareNoCase(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua")))) {
        bWriteFlag = FALSE;
    }


    //save to ini file
    sTemp.Format(_T("0x%08X"),m_hexConfig0);
    if( (m_hexConfig0_last_saved != m_hexConfig0) || (bWriteFlag))
        WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_LASTCONFIG0"),sTemp,sPath);

    sTemp.Format(_T("0x%08X"),m_hexConfig1);
    if( (m_hexConfig1_last_saved != m_hexConfig1) || (bWriteFlag) )
        WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_LASTCONFIG1"),sTemp,sPath);

    sTemp.Format(_T("%d"),m_uBurnMode);
    if( (m_uBurnMode_last_saved != m_uBurnMode) || (bWriteFlag) )
        WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_LASTOPMODE"),sTemp,sPath);

    if( ((CButton *)GetDlgItem(IDC_RADIO_DEVUSB))->GetCheck() == BST_CHECKED ) {
        if((m_strConnectPort_last_saved.CompareNoCase(_T("USB"))) || (bWriteFlag) ) {
            WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_LASTPORT"),_T("USB"),sPath);
            m_strConnectPort_last_saved.Format(_T("USB"));
        }
    } else if( ((CButton *)GetDlgItem(IDC_RADIO_DEVCOM))->GetCheck() == BST_CHECKED ) {
        if(m_ctrComBox.GetCurSel() < 0) { // avoid no COM detected error  CFLi
            m_ctrComBox.SetCurSel(0);
            //m_ctrComBox.AddString(_T("COM1"));
        } else
            m_ctrComBox.GetLBText(m_ctrComBox.GetCurSel(), sTemp);

        if((m_strConnectPort_last_saved.CompareNoCase(sTemp)) || (bWriteFlag) ) {
            WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_LASTPORT"),sTemp,sPath);
            m_strConnectPort_last_saved = sTemp;
        }
    } else { // EMAC
        if((m_strConnectPort_last_saved.CompareNoCase(_T("EMAC"))) || (bWriteFlag) ) {
            WritePrivateProfileStringW(CString(_T("NU_SYS")),_T("NU_LASTPORT"),_T("EMAC"),sPath);
            m_strConnectPort_last_saved.Format(_T("EMAC"));
        }
    }

}

LONG CNuvoISPDlg::OnHotKey(WPARAM wParam, LPARAM lParam)
{
    UINT fuModifiers = (UINT)LOWORD(lParam);
    UINT uVirtKey = (UINT)HIWORD(lParam);

    if( MOD_CONTROL == fuModifiers && 'M' == uVirtKey) {
        //AfxMessageBox(_T("Ctrl + M"));
        if(m_tab.GetItemCount() == 3) {
            m_tab.DeleteItem(2);
            m_tab.SetCurSel(0);
            m_text_aprom.ShowWindow(TRUE);
            m_text_dataflash.ShowWindow(FALSE);
            m_text_message.ShowWindow(FALSE);

        } else {
            m_tab.InsertItem(2,_T("Message"));
            m_tab.SetCurSel(2);
            m_text_aprom.ShowWindow(FALSE);
            m_text_dataflash.ShowWindow(FALSE);
            m_text_message.ShowWindow(TRUE);
        }
    }

    return 0;

}

void CNuvoISPDlg::OnCbnSelchangeComboConfigSel()
{
    // TODO: �b���K�[����q���B�z�{���X

    INT nCurConfigSel;
    nCurConfigSel = m_ctlConfigSel.GetCurSel();

    if(((CButton *)GetDlgItem(IDC_RADIO_NVM))->GetCheck() == BST_CHECKED)
        return;
    if(((CButton *)GetDlgItem(IDC_RADIO_ERASE))->GetCheck() == BST_CHECKED)
        return;

    if(nCurConfigSel == 0) { //Last Config
        if( (m_hexConfig0 == m_hexConfig0_last)&&(m_hexConfig1 == m_hexConfig1_last) )
            return;

        if (((DataFlashType_II() == TRUE) &&
        ((m_hexConfig0_last != m_hexConfig0_saved) ||
        (((m_hexConfig0_last & 1) == 0) &&
        (m_hexConfig1_last != m_hexConfig1_saved)))) ||
        ((DataFlashType_II() == FALSE) &&
        ((m_hexConfig0_last >> 1) != (m_hexConfig0_saved >> 1)))) {
            GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);

        }

        m_hexConfig0 = m_hexConfig0_last;
        m_hexConfig1 = m_hexConfig1_last;
        UpdateSizeInfo(FALSE);
    } else if(nCurConfigSel == 1) { //On-chip Config
        GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
        ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(FALSE);
        GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(FALSE);

        if( (m_hexConfig0 == m_hexConfig0_saved)&&(m_hexConfig1 == m_hexConfig1_saved) )
            return;

        m_hexConfig0 = m_hexConfig0_saved;
        m_hexConfig1 = m_hexConfig1_saved;
        UpdateSizeInfo(FALSE); //���~���ȷ|�ȥ�

        if( (m_hexConfig0!=m_hexConfig0_saved)||(m_hexConfig1!=m_hexConfig1_saved) ) {
            GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);

        }
    }

}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadProjectFile                                                                           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Ū���t�m��                                                                              */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 filename	   	  	  -[in]   �t�m�ɦ줸�}                                                 */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::LoadProjectFile(CString filename)
{
    CString sPath = filename;;
    CString strTmpDbg;
    BOOL Result;
    DWORD ret;
    TCHAR buffer[MAX_PATH] = {0};

    strTmpDbg = sPath.Right(sPath.GetLength() - sPath.ReverseFind('.'));
    if (strTmpDbg.CompareNoCase(_T(".isp"))) {
        MessageBox(_T("Not an ISP project file"),_T("Error"),MB_OK);
        return;
    }

    GetConnectionType(sPath);
    GetPrivateProfileString(CString(_T("NU_PATH")),_T("NU_APROM"),_T(""),buffer,MAX_PATH,sPath);

    ret = GetFileAttributes(buffer);
    if ((ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY)) {
#ifndef PORJ_SAVE_ALL
        MessageBox(_T("No such code file! Please check your project setting."),_T("Error"),MB_OK);
#endif
        m_strCodeFilePath = m_strCurExePath;
    } else {
        m_strCodeFilePath.Format(_T("%s"),buffer);
        m_ctlEditCodeFile.SetWindowText(m_strCodeFilePath);;
        Result = GetFileInfo(m_strCodeFilePath, TRUE, &m_sMyFileInfo);

        //Save code file path
        WritePrivateProfileStringW(CString(_T("NU_PATH")),_T("NU_APROM"),m_strCodeFilePath,(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))));

        CheckFileSize(1);   //����ɤj�p�M����flash�j�p�A�æbUI�W���
        if (Result)
            ShowBinFile(CodeFileBuffer, TRUE, m_sMyFileInfo.uCodeFileSize);
        else
            m_text_aprom.SetWindowText(_T(""));
    }

    GetPrivateProfileString(CString(_T("NU_PATH")),_T("NU_LDROM"),_T(""),buffer,MAX_PATH,sPath);
    ret = GetFileAttributes(buffer);
    if( (ret == INVALID_FILE_ATTRIBUTES) || (ret & FILE_ATTRIBUTE_DIRECTORY)) {
#ifndef PORJ_SAVE_ALL
        MessageBox(_T("No such data file! Please check your project setting."),_T("Error"),MB_OK);
#endif
        m_strDataFilePath = m_strCurExePath;
    } else {
        m_strDataFilePath.Format(_T("%s"),buffer);
        m_ctlEditDataFile.SetWindowText(m_strDataFilePath);;
        Result = GetFileInfo(m_strDataFilePath, FALSE, &m_sMyFileInfo);

        //Save code file path
        WritePrivateProfileStringW(CString(_T("NU_PATH")),_T("NU_LDROM"),m_strDataFilePath,(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua"))));

        CheckFileSize(2);

        if (Result)
            ShowBinFile(DataFileBuffer,FALSE,m_sMyFileInfo.uDataFileSize);
        else
            m_text_dataflash.SetWindowText(_T(""));
    }

#ifdef CHECKSUM_SAVE_ENABLE
    /*Check if checksum saving enabled*/
    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_CHECKSUM"),_T(""),buffer,MAX_PATH,sPath);
    if(_tcstoul(buffer, NULL, 10) !=1) {
        ((CButton *)GetDlgItem(IDC_CHECK_SAVE_CHECKSUM))->SetCheck(BST_UNCHECKED);
        ISP_RESERVED_SIZE = 0;

    } else {
        ((CButton *)GetDlgItem(IDC_CHECK_SAVE_CHECKSUM))->SetCheck(BST_CHECKED);
        ISP_RESERVED_SIZE = 8; //Checksum+Len = 8bytes
    }
#endif

    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTOPMODE"),_T(""),buffer,MAX_PATH,sPath);
    m_uBurnMode_last = _tcstoul(buffer, NULL, 10);
    ChangeBurnMode(m_uBurnMode_last);


    /*Load saved config value*/
    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTCONFIG0"),_T(""),buffer,MAX_PATH,sPath);
    m_hexConfig0_last = wcstoul(buffer, NULL, 16);

    // 0114 CFLi for M451 config0[16] bug
    //if ((m_ChipSerial == SERIAL_NUCM451) || (m_ChipSerial == SERIAL_NUCM452) || (m_ChipSerial == SERIAL_NUCM453) || (m_ChipSerial == SERIAL_NUCM451M))
    if (m_ChipSerial == SERIAL_M45X)
        m_hexConfig0_last &= ~(1 << 16);
    else if((m_ChipSerial == SERIAL_NANO1XX) && ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00111200) || ((m_sMyChipType.uChipID & 0xFFFFFF00) == 0x00110200))  // NANO112 CWDT[31]
        m_hexConfig0_last |= (1 << 31);

    GetPrivateProfileString(CString(_T("NU_SYS")),_T("NU_LASTCONFIG1"),_T(""),buffer,MAX_PATH,sPath);
    m_hexConfig1_last = wcstoul(buffer, NULL, 16);

#if 1
    if ((m_hexConfig0_last == 0) || (m_hexConfig1_last == 0) ||
    ((MyDevFound) &&
    IsCFG01Invalid(m_hexConfig0_last, m_hexConfig1_last))) { //���~���Ѽ�
        if (MyDevFound) {
            strTmpDbg.Format(_T("Invalid config value in project file.\nCF0=0x%08X, CF1=0x%08X\n\nUse on-chip config instead\n"),m_hexConfig0_last,m_hexConfig1_last);
            MessageBox(strTmpDbg,_T("Error"),MB_OK);
            m_hexConfig0_last = m_hexConfig0_saved;
            m_hexConfig1_last = m_hexConfig1_saved;
        }

    }

#endif

    m_hexConfig0 = m_hexConfig0_last;
    m_hexConfig1 = m_hexConfig1_last;

#ifdef PORJ_SAVE_ALL
    GetFileInfoFromConfig(filename, &m_sMyFileInfo);
#endif

    if (MyDevFound) {
        UpdateSizeInfo(FALSE);
        /* cfli 1110 */
        if( (m_hexConfig0!=m_hexConfig0_saved)||(m_hexConfig1!=m_hexConfig1_saved) ) {
            GetDlgItem(IDC_CHECK_CONFIG_START)->EnableWindow(TRUE);
            ((CButton *)GetDlgItem(IDC_CHECK_CONFIG_START))->SetCheck(TRUE);
            GetDlgItem(IDC_BUTTON_SETTING)->EnableWindow(TRUE);

        }
    } else {

        //SetDlgItemText(IDC_TXT_PARTNO_INFO,_T("RAM: N/A    APROM: N/A    DataFlash: N/A"));

        strTmpDbg.Format(_T("%08X"),m_hexConfig0);
        SetDlgItemText(IDC_TXT_CONFIG0,strTmpDbg);
        strTmpDbg.Format(_T("%08X"),m_hexConfig1);
        SetDlgItemText(IDC_TXT_CONFIG1,strTmpDbg);
    }
    bIsConfigLoad = TRUE;
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnFileOpenIsp                                                                             */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ����t�m�ɦ줸�}��ܤ��                                                                    */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnFileOpenIsp()
{

    CString sPath;
    CString strTmpDbg;
//	TCHAR buffer[MAX_PATH] = {0};
    TCHAR szFilters[] = TEXT("ISP Project (*.isp)|*.isp|All Files (*.*)|*.*||");

//   if(MyDevFound == FALSE)
//	{
//		MessageBox(_T("Device not connected!"),_T("Error"),MB_OK);
//       return;
//	}


    CFileDialog dlg (TRUE, TEXT("isp"), TEXT("config"), OFN_FILEMUSTEXIST| OFN_READONLY, szFilters, this);

    if (lastConfigFilePath.IsEmpty())
        dlg.m_ofn.lpstrInitialDir = m_strCurExePath;
    else
        dlg.m_ofn.lpstrInitialDir = lastConfigFilePath.Left(lastConfigFilePath.ReverseFind('\\') + 1);

    if (IDOK == dlg.DoModal()) {
        sPath = dlg.GetPathName();
        lastConfigFilePath = sPath;

        LoadProjectFile(sPath);
    }
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnFileSaveIsp                                                                             */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �O�s�t�m�ɦ줸�}��ܤ��                                                                    */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnFileSaveIsp()
{
    CString sPath;
    TCHAR buffer[MAX_PATH] = {0};
    TCHAR szFilters[] = TEXT("ISP Project (*.isp)|*.isp|All Files (*.*)|*.*||");

    CFileDialog dlg (FALSE, TEXT("isp"), TEXT("config"), OFN_FILEMUSTEXIST| OFN_READONLY, szFilters, this);

    if (lastConfigFilePath.IsEmpty())
        dlg.m_ofn.lpstrInitialDir = m_strCurExePath;
    else
        dlg.m_ofn.lpstrInitialDir = lastConfigFilePath.Left(lastConfigFilePath.ReverseFind('\\') + 1);

    if (dlg.DoModal() != IDOK)
        return;

    sPath = dlg.GetPathName();
    lastConfigFilePath = sPath;

    SaveBurnMode(sPath);

    //Save code file path
    WritePrivateProfileStringW(CString(_T("NU_PATH")),_T("NU_APROM"),m_strCodeFilePath,sPath);
    WritePrivateProfileStringW(CString(_T("NU_PATH")),_T("NU_LDROM"),m_strDataFilePath,sPath);

#ifdef PORJ_SAVE_ALL
    int		fd, zero = 0;

    if (_wsopen_s(&fd, sPath, _O_RDWR | _O_APPEND | _O_BINARY, _SH_DENYNO, _S_IREAD | _S_IWRITE)) {
        TRACE(_T("FAILED to open project file! ...\r\n"));
        return;
    }
    _chsize(fd, PRJ_BIN_OFFSET);

    TRACE(_T("Code size is 0x%x.\r\n"), m_sMyFileInfo.uCodeFileSize);
    TRACE(_T("Data size is 0x%x.\r\n"), m_sMyFileInfo.uDataFileSize);

    _lseek(fd, PRJ_BIN_OFFSET, SEEK_SET);

    _write(fd, PRJ_APROM_BIN, 4);
    _write(fd, &zero, 4);				// execution address 0
    _write(fd, &m_sMyFileInfo.uCodeFileSize, 4);
    if (m_sMyFileInfo.uCodeFileSize)
        _write(fd, CodeFileBuffer, m_sMyFileInfo.uCodeFileSize);

    TRACE(_T("Data binary offset is 0x%x.\r\n"), _tell(fd));

    _write(fd, PRJ_DATA_BIN, 4);
    _write(fd, &m_sMyFileInfo.uDataFileSize, 4);
    if (m_sMyFileInfo.uDataFileSize)
        _write(fd, DataFileBuffer, m_sMyFileInfo.uDataFileSize);

    _close(fd);
#endif
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnAboutVersion                                                                            */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��ܪ�����T��ܤ��                                                                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnAboutVersion()
{
    // TODO: �b���K�[�R�O�B�z�{���X
#ifdef FOR_CORETRONIC
    MessageBox(_T("\n    ISP Tool V1.45 (MP) for Coretronic     \n\n"),_T("About"),MB_OK);
#elif defined(IS_MP_VER)
    MessageBox(_T("\n    ISP Tool V1.45 (MP)     \n\n"),_T("About"),MB_OK);
#else
    MessageBox(ABOUT_MSG, _T("About"),MB_OK);
#endif
}

void CNuvoISPDlg::OnBnClickedCheckCan()
{
    // TODO: �b���K�[����q���B�z�{���X
    if( ((CButton *)GetDlgItem(IDC_CHECK_CAN))->GetCheck() == BST_CHECKED ) {
        bIsCanInterface = TRUE;
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(TRUE);
    } else {
        bIsCanInterface = FALSE;
        GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
    }
}

void CNuvoISPDlg::OnEnChangeEditApromBaseAddr()
{
    // TODO:  �b���K�[����q���B�z�{���X
    unsigned long baseAddr = 0;
    CString tmpStr;

    if(m_sMyFileInfo.uCodeFileType == 0) { //bin file
        GetDlgItemText(IDC_EDIT_APROM_BASE_ADDR, tmpStr);
        baseAddr = _tcstol(tmpStr, NULL, 16);

        m_sMyFileInfo.uCodeFileStartAddr = baseAddr;
    }
}


void CNuvoISPDlg::OnEnChangeEditMessage()
{
    // TODO:  �p�G�o�O RICHEDIT ����A����N���|
    // �ǰe���i���A���D�z�мg CDialog::OnInitDialog()
    // �禡�M�I�s CRichEditCtrl().SetEventMask()
    // ���㦳 ENM_CHANGE �X�� ORed �[�J�B�n�C

    // TODO:  �b���[�J����i���B�z�`���{���X
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedRadioDevUsb                                                                       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �Ŀ�UI�W"USB"�ﶵ�ɪ��^�����                                                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                */
/* Returns:                                                                                                */
/*               �L                                                                                */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedRadioDevUsb()
{
    // TODO: Add your control notification handler code here
    m_ctrComBox.EnableWindow(FALSE);

    CHelpUARTPin settingDlg(IDB_HELP_USB_PIN_BITMAP, _T("Hardware Connection for ISP through USB"));

    settingDlg.DoModal();
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedRadioDevEmac                                                                       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �Ŀ�UI�W"EMAC"�ﶵ�ɪ��^�����                                                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                */
/* Returns:                                                                                                */
/*               �L                                                                                */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::OnBnClickedRadioDevEmac()
{
	// TODO: Add your control notification handler code here
	m_ctrComBox.EnableWindow(FALSE);

	CHelpUARTPin settingDlg(IDB_HELP_EMAC_PIN_BITMAP, _T("Hardware Connection for ISP through EMAC"));

	settingDlg.DoModal();
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     OnBnClickedRadioDevCom                                                                       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �Ŀ�UI�W"COM"�ﶵ�ɪ��^�����                                                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 �L                                                                                */
/* Returns:                                                                                                */
/*               �L                                                                                */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

void CNuvoISPDlg::OnBnClickedRadioDevCom()
{
    // TODO: Add your control notification handler code here
    m_ctrComBox.EnableWindow(TRUE);

    bIsCanInterface = FALSE;
    ((CButton *)GetDlgItem(IDC_CHECK_CAN))->SetCheck(BST_UNCHECKED);
    GetDlgItem(IDC_EDIT_CAN_ID)->EnableWindow(FALSE);
    GetDlgItem(IDC_CHECK_CAN)->EnableWindow(FALSE);

    CHelpUARTPin settingDlg(IDB_HELP_UART_PIN_BITMAP, _T("Hardware Connection for ISP through UART"));

    settingDlg.DoModal();



}