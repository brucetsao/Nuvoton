/*-----------------------------------------------------------------------------
 *  ISP Commands
 *----------------------------------------------------------------------------*/
#define CMD_SET_CAN_ID			0x000000BB
#define CMD_GET_FWVER     		0x000000A6
#define CMD_UPDATE_APROM		0x000000A0
#define CMD_SYNC_PACKNO			0x000000A4
#define CMD_UPDATE_CONFIG   	0x000000A1
#define CMD_UPDATE_DATAFLASH 	0x000000C3
//#define CMD_UPDATE_DATA1		0x000000C2
//#define CMD_UPDATE_DATA2		0x000000C3
#define CMD_READ_CHECKSUM 		0x000000C8
#define CMD_ERASE_ALL 	    	0x000000A3
//#define CMD_GET_APPINFO     	0x000000A8

#define CMD_READ_CONFIG     	0x000000A2
#define CMD_APROM_SIZE      	0x000000AA
#define CMD_GET_DEVICEID    	0x000000B1

#define CMD_WRITE_CHECKSUM  	0x000000C9
#define CMD_GET_FLASHMODE   	0x000000CA
#define CMD_RUN_APROM       	0x000000AB
#define CMD_RUN_LDROM       	0x000000AC

#define CMD_RESEND_PACKET   	0x000000FF
#define CMD_CONNECT         	0x000000AE
//#define CMD_DISCONNECT      	0x000000AF

extern UINT g_packno;

/*
Result = CmdWriteAndReadOne(DevInterface, CMD_GET_DEVICEID);
Result = CmdWriteAndReadOne(DevInterface, CMD_READ_CONFIG);
bResult = CmdWriteAndReadOne(DevInterface, CMD_CONNECT);
Result = CmdWriteAndReadOne(DevInterface, CMD_GET_VERSION);
*/

