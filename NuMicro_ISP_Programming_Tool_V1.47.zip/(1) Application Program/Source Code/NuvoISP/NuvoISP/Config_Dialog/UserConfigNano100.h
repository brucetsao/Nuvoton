#pragma once


// CUserConfigNano100 ��ܤ��

class CUserConfigNano100 : public CDialogEx
{
	DECLARE_DYNAMIC(CUserConfigNano100)

public:
	CUserConfigNano100(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CUserConfigNano100();

// ��ܤ�����
	enum { IDD = IDD_DIALOG_CONFIG_NANO100 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();

	DWORD m_uChipID;
	UINT  m_uFlashSize;
	DWORD m_hexConfig0;
	DWORD m_hexConfig1;

	CEdit m_ctlConfig0;
	CEdit m_ctlConfig1;

	BOOL UpdateConfig();
	BOOL LoadConfig();

	CSpinButtonCtrl m_controlSpinDataSize;
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	BOOL ShowDataSize();

	afx_msg void OnBnClickedRadio12m();
	afx_msg void OnBnClickedRadio22m();
	afx_msg void OnBnClickedRadioBOD17();
	afx_msg void OnBnClickedRadioBOD20();
	afx_msg void OnBnClickedRadioBOD25();
	afx_msg void OnBnClickedRadioBOD_OFF();
	afx_msg void OnBnClickedCheckLock();
	afx_msg void OnBnClickedCheckDfen();
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
