#pragma once


// UserConfigNUC1312AE dialog

class UserConfigNUC1312AE : public CDialog
{
	DECLARE_DYNAMIC(UserConfigNUC1312AE)

public:
	UserConfigNUC1312AE(CWnd* pParent = NULL);   // standard constructor
	virtual ~UserConfigNUC1312AE();

// Dialog Data
	enum { IDD = IDD_DIALOG_CONFIG_NUC131xx2AE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	DWORD m_uChipID;
	UINT  m_uFlashSize;
	DWORD m_hexConfig0;
	DWORD m_hexConfig1;

	CEdit m_ctlConfig0;
	CEdit m_ctlConfig1;
	CSpinButtonCtrl m_controlSpinDataSize;

	BOOL UpdateConfig();
	BOOL LoadConfig();
	afx_msg void OnBnClickedCheckWtdEn();
	afx_msg void OnBnClickedCheckWtdClkPdEn();
	afx_msg void OnBnClickedRadioCgpfmfpGpio();
	afx_msg void OnBnClickedRadioCgpfmfpXtl();
	afx_msg void OnBnClickedRadio12m();
	afx_msg void OnBnClickedRadio22m();
	afx_msg void OnBnClickedRadioIoTriState();
	afx_msg void OnBnClickedRadioIoQuasiBidr();
	afx_msg void OnBnClickedCheckCboden();
	afx_msg void OnBnClickedCheckCborst();
	afx_msg void OnBnClickedRadio45v();
	afx_msg void OnBnClickedRadio38v();
	afx_msg void OnBnClickedRadio26v();
	afx_msg void OnBnClickedRadio22v();
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnBnClickedRadioBootLdrom();
	afx_msg void OnBnClickedRadioBootLdromIap();
	afx_msg void OnBnClickedRadioBootAprom();
	afx_msg void OnBnClickedRadioBootApromIap();
	afx_msg void OnBnClickedCheckLock();
	afx_msg void OnBnClickedCheckDataFlashVarSize();
	afx_msg void OnBnClickedCheckDfen();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};
