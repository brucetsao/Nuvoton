// UserConfigM051.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigM051.h"
//#include "afxdialogex.h"


// CUserConfigM051 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigM051, CDialogEx)

CUserConfigM051::CUserConfigM051(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigM051::IDD, pParent)
{

}

CUserConfigM051::~CUserConfigM051()
{
}

void CUserConfigM051::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
}


BEGIN_MESSAGE_MAP(CUserConfigM051, CDialogEx)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigM051::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigM051::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigM051::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigM051::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigM051::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigM051::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigM051::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigM051::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM, &CUserConfigM051::OnBnClickedRadioBootLdrom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM, &CUserConfigM051::OnBnClickedRadioBootAprom)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigM051::OnBnClickedCheckLock)
	ON_EN_CHANGE(IDC_EDIT_CONFIG0, &CUserConfigM051::OnEnChangeEditConfig0)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigM051::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigM051::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);

	LoadConfig();

	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigM051::LoadConfig()
{
	CString tmpStr;

	if ((m_hexConfig0 & 0x07000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}

	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);
		
	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	if (m_hexConfig0 & 0x80)
	{
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);
	}
	
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigM051::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;
	
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x80;
		
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;
	
	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigM051 �T���B�z�`��


void CUserConfigM051::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadio22m()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedCheckCboden()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigM051::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadioBootLdrom()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedRadioBootAprom()
{
	UpdateConfig();
}


void CUserConfigM051::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigM051::OnEnChangeEditConfig0()
{
	// TODO:  �p�G�o�O RICHEDIT ����A����N���|
	// �ǰe���i���A���D�z�мg CDialogEx::OnInitDialog()
	// �禡�M�I�s CRichEditCtrl().SetEventMask()
	// ���㦳 ENM_CHANGE �X�� ORed �[�J�B�n�C

	// TODO:  �b���[�J����i���B�z�`���{���X
}


void CUserConfigM051::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF3F;
	m_hexConfig1 = 0x1F000;
	LoadConfig();
}

