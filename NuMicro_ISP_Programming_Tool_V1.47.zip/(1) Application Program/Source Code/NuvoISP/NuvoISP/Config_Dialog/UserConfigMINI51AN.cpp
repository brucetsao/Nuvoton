// UserConfigMINI51BN.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigMINI51AN.h"
//#include "afxdialogex.h"


// CUserConfigMINI51AN ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigMINI51AN, CDialogEx)

CUserConfigMINI51AN::CUserConfigMINI51AN(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigMINI51AN::IDD, pParent)
{

}

CUserConfigMINI51AN::~CUserConfigMINI51AN()
{
}

void CUserConfigMINI51AN::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigMINI51AN, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_CKF, &CUserConfigMINI51AN::OnBnClickedCheckCkf)
	ON_BN_CLICKED(IDC_RADIO_BOD_OFF, &CUserConfigMINI51AN::OnBnClickedRadioBOD_OFF)
	ON_BN_CLICKED(IDC_RADIO_BOD38, &CUserConfigMINI51AN::OnBnClickedRadioBOD38)
	ON_BN_CLICKED(IDC_RADIO_BOD27, &CUserConfigMINI51AN::OnBnClickedRadioBOD27)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigMINI51AN::OnBnClickedCheckCborst)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigMINI51AN::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigMINI51AN::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigMINI51AN::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigMINI51AN::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/512) - 1); 	//0.5 Kbytes ~ flash size - 0.5 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigMINI51AN::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<28))
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(FALSE);

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOD_OFF))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOD38))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOD27))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
	{
		((CButton *)GetDlgItem(IDC_RADIO_BOD_OFF))->SetCheck(TRUE);
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
	}

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOD38))->SetCheck(TRUE);

	if ((((m_hexConfig0 >> 21) & 0x3) == 0x1) || (((m_hexConfig0 >> 21) & 0x3) == 0))
		((CButton *)GetDlgItem(IDC_RADIO_BOD27))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (m_hexConfig0 & (1<<7))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);
	
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 512;
		}
		tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigMINI51AN::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;
	
	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CKF))->GetCheck() == BST_CHECKED)
		uConfigBit |= (1<<28);
	else
		uConfigBit &= ~(1<<28);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOD38))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOD27))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((uConfigBit >> 21) & 0x3) == 0x3)
	{
		((CButton *)GetDlgItem(IDC_RADIO_BOD_OFF))->SetCheck(TRUE);
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1<<7);

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"),m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigMINI51AN �T���B�z�`��

void CUserConfigMINI51AN::OnBnClickedCheckCkf()
{
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedRadioBOD_OFF()
{
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedRadioBOD38()
{
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedRadioBOD27()
{
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedCheckDfen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
		
	}
	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigMINI51AN::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF7F;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}

void CUserConfigMINI51AN::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4.1f KB"),(double)nPos/2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 512);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


