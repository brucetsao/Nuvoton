#pragma once


// CUserConfigMT500 ��ܤ��

class CUserConfigMT500 : public CDialogEx
{
	DECLARE_DYNAMIC(CUserConfigMT500)

public:
	CUserConfigMT500(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CUserConfigMT500();

// ��ܤ�����
	enum { IDD = IDD_DIALOG_CONFIG_MT500 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();

	DWORD m_uChipID;
	UINT  m_uFlashSize;
	DWORD m_hexConfig0;
	DWORD m_hexConfig1;

	CEdit m_ctlConfig0;
	CEdit m_ctlConfig1;

	BOOL UpdateConfig();
	BOOL LoadConfig();

	CSpinButtonCtrl m_controlSpinDataSize;
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	BOOL ShowDataSize();

	afx_msg void OnBnClickedCheckWtdEn();
	afx_msg void OnBnClickedCheckWtdClkPdEn();
	afx_msg void OnBnClickedRadio12m();
	afx_msg void OnBnClickedRadio22m();
	afx_msg void OnBnClickedCheckCboden();
	afx_msg void OnBnClickedCheckCborst();
	afx_msg void OnBnClickedRadio45v();
	afx_msg void OnBnClickedRadio38v();
	afx_msg void OnBnClickedRadio26v();
	afx_msg void OnBnClickedRadio22v();
	afx_msg void OnBnClickedRadioBpwmGpio();
	afx_msg void OnBnClickedRadioBpwmTriState();
	afx_msg void OnBnClickedRadioOdd1Gpio();
	afx_msg void OnBnClickedRadioOdd1TriState();
	afx_msg void OnBnClickedRadioEven1Gpio();
	afx_msg void OnBnClickedRadioEven1TriState();
	afx_msg void OnBnClickedRadioOdd0Gpio();
	afx_msg void OnBnClickedRadioOdd0TriState();
	afx_msg void OnBnClickedRadioEven0Gpio();
	afx_msg void OnBnClickedRadioEven0TriState();
	afx_msg void OnBnClickedCheckLock();
	afx_msg void OnBnClickedCheckDfen();
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
