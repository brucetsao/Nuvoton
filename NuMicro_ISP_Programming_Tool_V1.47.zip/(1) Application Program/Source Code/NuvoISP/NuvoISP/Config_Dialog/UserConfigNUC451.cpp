// C:\Users\CFLi0\Documents\Visual Studio 2008\Projects\ISP_1.45_NUC451\NuvoISP\NuvoISP\Config_Dialog\UserConfigNUC451.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigNUC451.h"
//#include "afxdialogex.h"


// CUserConfigNUC451 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigNUC451, CDialogEx)

CUserConfigNUC451::CUserConfigNUC451(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigNUC451::IDD, pParent)
{

}

CUserConfigNUC451::~CUserConfigNUC451()
{
}

void CUserConfigNUC451::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigNUC451, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &CUserConfigNUC451::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_CHECK_WTD_CLK_PD_EN, &CUserConfigNUC451::OnBnClickedCheckWtdClkPdEn)
	ON_BN_CLICKED(IDC_RADIO_CFGXT1_GPIO, &CUserConfigNUC451::OnBnClickedRadioCfgxt1Gpio)
	ON_BN_CLICKED(IDC_RADIO_CFGXT1_XTL, &CUserConfigNUC451::OnBnClickedRadioCfgxt1Xtl)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigNUC451::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigNUC451::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigNUC451::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigNUC451::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigNUC451::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigNUC451::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigNUC451::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigNUC451::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_IO_TRI_STATE, &CUserConfigNUC451::OnBnClickedRadioIoTriState)
	ON_BN_CLICKED(IDC_RADIO_IO_QUASI_BIDR, &CUserConfigNUC451::OnBnClickedRadioIoQuasiBidr)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigNUC451::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigNUC451::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigNUC451::OnBnClickedButtonDefault)
	ON_BN_CLICKED(IDC_RADIO_BLBSEL, &CUserConfigNUC451::OnBnClickedRadioBlbsel)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM, &CUserConfigNUC451::OnBnClickedRadioBootLdrom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM_IAP, &CUserConfigNUC451::OnBnClickedRadioBootLdromIap)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM, &CUserConfigNUC451::OnBnClickedRadioBootAprom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM_IAP, &CUserConfigNUC451::OnBnClickedRadioBootApromIap)
	ON_WM_VSCROLL()
END_MESSAGE_MAP()


// CUserConfigNUC451 �T���B�z�`��


BOOL CUserConfigNUC451::OnInitDialog()
{	
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/2048) - 1); 	//2 Kbytes ~ flash size - 2 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	if ((m_hexConfig0 & 0x1) == 0)
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/2048);


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC451::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/

    //	�p�G�u�ĿWatchdog[31]������N��bit3,4,31�����]��0
    //  �p�G�Ŀ�F��Watchdog[31]�� + ��Watchdog Clock Power-down[30]�� ����N��bit3,4�]��1, bit 30,31�]��0
    if (m_hexConfig0 & (1<<30))
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);		
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
		
	}

	
	if (m_hexConfig0 & (1<<31))
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
	

	/*----------------------------------------------*/
	/*  CFGXT1 - GPF[4:3] Multi-Function Select   */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<27))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_XTL))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_GPIO))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_XTL))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_GPIO))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<26))
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/				
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/	 
	 ((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	 ((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	 ((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	 ((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);
		
	if ((((m_hexConfig0 >> 6) & 0x3) == 0x0) && (m_hexConfig0 & (1<<5)))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if ((((m_hexConfig0 >> 6) & 0x3) == 0x1) && (m_hexConfig0 & (1<<5)))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if ((((m_hexConfig0 >> 6) & 0x3) == 0x2) && (m_hexConfig0 & (1<<5)))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if ((((m_hexConfig0 >> 6) & 0x3) == 0x3) && (m_hexConfig0 & (1<<5)))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);	

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 2048)) || (m_hexConfig1 < 2048))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 2048;
		}
		tmpStr.Format(_T("%4d KB"),  (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC451::UpdateConfig()
{
	UINT uConfigBit = 0xFFFEFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
	{
		uConfigBit &= ~(1 << 31);
        // CWDTEN[2:0] is CONFIG0[31][4][3]
	    uConfigBit &= ~(3 << 3);
	}
	
	if ((((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED) &&
  	    (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED))
	{
	    uConfigBit &= ~(1 << 31);
		uConfigBit &= ~(1 << 30);

	    // CWDTEN[2:0] is CONFIG0[31][4][3]
	    uConfigBit |= (3 << 3);
	}

	/*----------------------------------------------*/
	/*  CFGXT1 - GPF[4:3] Multi-Function Select   */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 27);
		
	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 26);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/		
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	//if (((CButton *)GetDlgItem(IDC_CHECK_BLBSEL))->GetCheck() == BST_CHECKED)
	if (((CButton *)GetDlgItem(IDC_RADIO_BLBSEL))->GetCheck() == BST_CHECKED)	
		uConfigBit &= ~(1 << 5);
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x80;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0xC0;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x40;
	
	
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}

void CUserConfigNUC451::OnBnClickedCheckWtdEn()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() != BST_CHECKED)
	{
		if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
			((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
    }
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedCheckWtdClkPdEn()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);

	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioCfgxt1Gpio()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioCfgxt1Xtl()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadio12m()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadio22m()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedCheckCboden()
{
	// TODO: �b���[�J����i���B�z�`���{���X	
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedCheckCborst()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadio45v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadio38v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadio26v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadio22v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioIoTriState()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioIoQuasiBidr()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedCheckLock()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedCheckDfen()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("2 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
       	m_hexConfig1 = m_uFlashSize - 2048;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedButtonDefault()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	m_hexConfig0 |= 0xFFFEFF7F;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}


void CUserConfigNUC451::OnBnClickedRadioBlbsel()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioBootLdrom()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioBootLdromIap()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioBootAprom()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnBnClickedRadioBootApromIap()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void CUserConfigNUC451::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: �b���[�J�z���T���B�z�`���{���X�M (��) �I�s�w�]��
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4d KB"), nPos*2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 2048);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}