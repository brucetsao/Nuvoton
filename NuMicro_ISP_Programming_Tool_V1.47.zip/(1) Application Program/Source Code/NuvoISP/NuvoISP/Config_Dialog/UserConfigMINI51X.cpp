// C:\Users\CFLi0\Documents\Visual Studio 2008\Projects\ISP code\[1105 0914]NuvoISP\NuvoISP\Config_Dialog\UserConfigMINI51X.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigMINI51X.h"
//#include "afxdialogex.h"


// UserConfigMINI51X ��ܤ��

IMPLEMENT_DYNAMIC(UserConfigMINI51X, CDialogEx)

UserConfigMINI51X::UserConfigMINI51X(CWnd* pParent /*=NULL*/)
	: CDialogEx(UserConfigMINI51X::IDD, pParent)
{

}

UserConfigMINI51X::~UserConfigMINI51X()
{
}

void UserConfigMINI51X::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(UserConfigMINI51X, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &UserConfigMINI51X::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &UserConfigMINI51X::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_17V, &UserConfigMINI51X::OnBnClickedRadio17v)
	ON_BN_CLICKED(IDC_RADIO_20V, &UserConfigMINI51X::OnBnClickedRadio20v)
	ON_BN_CLICKED(IDC_RADIO_22V, &UserConfigMINI51X::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_24V, &UserConfigMINI51X::OnBnClickedRadio24v)
	ON_BN_CLICKED(IDC_RADIO_27V, &UserConfigMINI51X::OnBnClickedRadio27v)
	ON_BN_CLICKED(IDC_RADIO_30V, &UserConfigMINI51X::OnBnClickedRadio30v)
	ON_BN_CLICKED(IDC_RADIO_37V, &UserConfigMINI51X::OnBnClickedRadio37v)
	ON_BN_CLICKED(IDC_RADIO_43V, &UserConfigMINI51X::OnBnClickedRadio43v)
	ON_BN_CLICKED(IDC_RADIO_IO_TRI_STATE, &UserConfigMINI51X::OnBnClickedRadioIoTriState)
	ON_BN_CLICKED(IDC_RADIO_IO_QUASI_BIDR, &UserConfigMINI51X::OnBnClickedRadioIoQuasiBidr)
	ON_BN_CLICKED(IDC_RADIO_RC44M, &UserConfigMINI51X::OnBnClickedRadioRc44m)
	ON_BN_CLICKED(IDC_RADIO_RC48M, &UserConfigMINI51X::OnBnClickedRadioRc48m)
	ON_BN_CLICKED(IDC_CHECK_ENRCDIV2, &UserConfigMINI51X::OnBnClickedCheckEnrcdiv2)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &UserConfigMINI51X::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &UserConfigMINI51X::OnBnClickedCheckDfen)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &UserConfigMINI51X::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


// UserConfigMINI51X �T���B�z�`��





BOOL UserConfigMINI51X::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/512) - 1); 	//0.5 Kbytes ~ flash size - 0.5 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL UserConfigMINI51X::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_17V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_20V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_24V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_30V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_37V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_43V))->SetCheck(FALSE);

	if (m_hexConfig0 & (1<<23))
	{
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);
		if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		{
			((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_37V))->SetCheck(FALSE);
		}
		if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
			((CButton *)GetDlgItem(IDC_RADIO_37V))->SetCheck(TRUE);

		if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
			((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(TRUE);

		if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
			((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(TRUE);
	}
	else    // CBOVEXT
	{
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
		if(((m_hexConfig0 >> 19) & 0x1)) 
		{
			if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
				((CButton *)GetDlgItem(IDC_RADIO_30V))->SetCheck(TRUE);

			if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
				((CButton *)GetDlgItem(IDC_RADIO_24V))->SetCheck(TRUE);

			if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
				((CButton *)GetDlgItem(IDC_RADIO_20V))->SetCheck(TRUE);

			if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
				((CButton *)GetDlgItem(IDC_RADIO_17V))->SetCheck(TRUE);
		}
		else
		{
			if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
				((CButton *)GetDlgItem(IDC_RADIO_43V))->SetCheck(TRUE);

			if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
				((CButton *)GetDlgItem(IDC_RADIO_37V))->SetCheck(TRUE);

			if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
				((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(TRUE);

			if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
				((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);
		}
		
	}

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);


	if (((m_hexConfig0 >> 23) & 0x1))
	{
		//GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_CBODEN)->EnableWindow(TRUE);
		
		GetDlgItem(IDC_RADIO_17V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_20V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_24V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_27V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_30V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_37V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_43V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_17V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_20V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_24V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_30V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_37V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_43V))->SetCheck(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_CBODEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_17V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_20V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_24V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_27V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_30V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_37V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_43V)->EnableWindow(TRUE);
	}

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  RC Oscillator trim bits selection           */
	/*----------------------------------------------*/
	if (((m_hexConfig0 >> 27) & 0x1))
	{
		((CButton *)GetDlgItem(IDC_RADIO_RC44M))->SetCheck(TRUE);
	    ((CButton *)GetDlgItem(IDC_RADIO_RC48M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_RC48M))->SetCheck(TRUE);
	    ((CButton *)GetDlgItem(IDC_RADIO_RC44M))->SetCheck(FALSE);
	}

	if (((m_hexConfig0 >> 15) & 0x1))
		((CButton *)GetDlgItem(IDC_CHECK_ENRCDIV2))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_ENRCDIV2))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 512;
		}
		tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL UserConfigMINI51X::UpdateConfig()
{
	UINT uConfigBit = 0xFFFF7FFF;
	CString tmpStr;
	
	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit |= (1 << 23);
	else
	{
		uConfigBit &= ~(1 << 23);
		if (((CButton *)GetDlgItem(IDC_RADIO_30V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x3 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19)) | (0x1 << 19);
		}

		if (((CButton *)GetDlgItem(IDC_RADIO_24V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19)) | (0x1 << 19);
		}
		if (((CButton *)GetDlgItem(IDC_RADIO_20V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19)) | (0x1 << 19);
		}

		if (((CButton *)GetDlgItem(IDC_RADIO_17V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit &= ~(0x3 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19)) | (0x1 << 19);
		}

		if (((CButton *)GetDlgItem(IDC_RADIO_43V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x3 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19));
		}

		if (((CButton *)GetDlgItem(IDC_RADIO_37V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19));
		}

		if (((CButton *)GetDlgItem(IDC_RADIO_27V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);
			uConfigBit = (uConfigBit & ~(0x1 << 19));
		}
		if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		{
			uConfigBit &= ~(0x3 << 21);
			uConfigBit = (uConfigBit & (~(0x1 << 19)));
		}

		if (((uConfigBit >> 21) & 0x7) == 0x7)
		{
			GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_17V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_20V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_24V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_27V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_30V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_37V)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_43V)->EnableWindow(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_17V))->SetCheck(TRUE);
			((CButton *)GetDlgItem(IDC_RADIO_20V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_24V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_27V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_30V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_37V))->SetCheck(FALSE);
			((CButton *)GetDlgItem(IDC_RADIO_43V))->SetCheck(FALSE);
		}						   
		else
		{
			GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_17V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_20V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_24V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_27V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_30V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_37V)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_43V)->EnableWindow(TRUE);
		}
	}

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x1 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x2 << 6);

	/*----------------------------------------------*/
	/*  RC Oscillator trim bits selection           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_RC44M))->GetCheck() == BST_CHECKED)
		uConfigBit |= (0x1 << 27);
	
	if (((CButton *)GetDlgItem(IDC_RADIO_RC48M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x1 << 27);
	

	if (((CButton *)GetDlgItem(IDC_CHECK_ENRCDIV2))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x1 << 15);
	else
		uConfigBit |= (0x1 << 15);
		

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"),m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}

void UserConfigMINI51X::OnBnClickedCheckCboden()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedCheckCborst()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio17v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio20v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio22v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio24v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio27v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio30v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio37v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadio43v()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadioIoTriState()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadioIoQuasiBidr()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadioRc44m()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedRadioRc48m()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedCheckEnrcdiv2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedCheckLock()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateConfig();
}


void UserConfigMINI51X::OnBnClickedCheckDfen()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
		
	}
	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void UserConfigMINI51X::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: �b���[�J�z���T���B�z�`���{���X�M (��) �I�s�w�]��
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4.1f KB"),(double)nPos/2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 512);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else	
		CDialogEx::OnVScroll(nSBCode, nPos, pScrollBar);
}


void UserConfigMINI51X::OnBnClickedButtonDefault()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	m_hexConfig0 |= 0xFFFFFF7F;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}
