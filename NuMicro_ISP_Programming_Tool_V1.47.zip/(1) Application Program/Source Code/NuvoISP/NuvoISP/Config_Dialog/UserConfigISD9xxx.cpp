// UserConfigISD9xxx.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "../NuvoISPDlg.h"
#include "UserConfigISD9xxx.h"
//#include "afxdialogex.h"


// CUserConfigISD9xxx ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigISD9xxx, CDialogEx)

CUserConfigISD9xxx::CUserConfigISD9xxx(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigISD9xxx::IDD, pParent)
{

}

CUserConfigISD9xxx::~CUserConfigISD9xxx()
{
}

void CUserConfigISD9xxx::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
}


BEGIN_MESSAGE_MAP(CUserConfigISD9xxx, CDialogEx)
	ON_BN_CLICKED(IDOK, &CUserConfigISD9xxx::OnBnClickedOk)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigISD9xxx::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM, &CUserConfigISD9xxx::OnBnClickedRadioBootLdrom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM, &CUserConfigISD9xxx::OnBnClickedRadioBootAprom)
	ON_BN_CLICKED(IDC_RADIO_LDROMEN, &CUserConfigISD9xxx::OnBnClickedRadioLdromEn)
	ON_BN_CLICKED(IDC_RADIO_LDROMDIS, &CUserConfigISD9xxx::OnBnClickedRadioLdromDis)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigISD9xxx::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigISD9xxx::OnBnClickedCheckDfen)
	ON_EN_CHANGE(IDC_EDIT_CONFIG1, &CUserConfigISD9xxx::OnEnChangeEditConfig1)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigISD9xxx::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigISD9xxx::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();

	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);

	LoadConfig();

	return TRUE;

}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ShowDataSize                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*                                          									                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				                                                                                           */
/* Returns:                                                                                                */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigISD9xxx::ShowDataSize()
{

	if (((m_hexConfig1 & 0xFFE00) != m_hexConfig1) || (m_hexConfig1 >= 0x23400))
		return FALSE;

	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigISD9xxx::LoadConfig()
{
	CString tmpStr;
	UINT tmpFlashSize;

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (m_hexConfig0 & (1<<7))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  LDROM EN                                    */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_LDROMEN))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_LDROMDIS))->SetCheck(FALSE);

	if (m_hexConfig0 & (1<<2))
		((CButton *)GetDlgItem(IDC_RADIO_LDROMEN))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_RADIO_LDROMDIS))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	if (((m_hexConfig1 & 0xFFE00) != m_hexConfig1) || (m_hexConfig1 >= 0x23400))
	{
		tmpFlashSize = 0;
		tmpStr.Format(_T("%08X"),tmpFlashSize);
		m_ctlConfig1.SetWindowText(tmpStr);
		SetDlgItemText(IDC_EDIT_CONFIG1_1,tmpStr);
	}
	else
	{
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
		SetDlgItemText(IDC_EDIT_CONFIG1_1,tmpStr);
    }

    ShowDataSize();
	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigISD9xxx::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*   Config0 Set                                */
/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1<<7);

	if (((CButton *)GetDlgItem(IDC_RADIO_LDROMDIS))->GetCheck() == BST_CHECKED)
	uConfigBit &= ~(1<<2);

	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"),m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	SetDlgItemText(IDC_EDIT_CONFIG1_1,tmpStr);

    ShowDataSize();

	return TRUE;
}


// CUserConfigISD9xxx �T���B�z�`��


void CUserConfigISD9xxx::OnBnClickedCheckCboden()
{
	UpdateConfig();
}


void CUserConfigISD9xxx::OnBnClickedRadioBootLdrom()
{
	UpdateConfig();
}


void CUserConfigISD9xxx::OnBnClickedRadioBootAprom()
{
	UpdateConfig();
}

void CUserConfigISD9xxx::OnBnClickedRadioLdromEn()
{
	UpdateConfig();
}

void CUserConfigISD9xxx::OnBnClickedRadioLdromDis()
{
	UpdateConfig();
}

void CUserConfigISD9xxx::OnBnClickedCheckLock()
{
	UpdateConfig();
}

void CUserConfigISD9xxx::OnEnChangeEditConfig1()
{
	CString config1;

	GetDlgItemText(IDC_EDIT_CONFIG1,config1);
	SetDlgItemText(IDC_EDIT_CONFIG1_1,config1);
	for(int index=0;index<8;index++)
	{
		if( (config1[index]>='0' && config1[index] <= '9') || (config1[index] >='a' && config1[index] <= 'f')
			|| (config1[index] >= 'A' && config1[index] <= 'F') || (config1[index] == 0))
		{
			continue;
		}
		else
		{
		  AfxMessageBox(_T("Wrong address"));
		  return;
		}
	}

	m_hexConfig1 = wcstoul(config1, NULL, 16) & 0x000FFFFF;

	if ((m_hexConfig1 % 0x400 != 0) || (m_hexConfig1 >= 0x23400))
	{
		AfxMessageBox(_T("Wrong address"));
		return;
	}
//	UpdateConfig();
}

void CUserConfigISD9xxx::OnBnClickedCheckDfen()
{
	UpdateConfig();
}


void CUserConfigISD9xxx::OnBnClickedButtonDefault()
{
	m_hexConfig0 = 0xFFFFFFFF;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}

void CUserConfigISD9xxx::OnBnClickedOk()
{
	TCHAR buffer[30] = {0};

	UpdateConfig();

	m_ctlConfig0.GetWindowText(buffer, sizeof (buffer) / sizeof (buffer[0]));
	for(int index=0;index<8;index++)
	{
		if( (buffer[index]>='0' && buffer[index] <= '9') || (buffer[index] >='a' && buffer[index] <= 'f')
			|| (buffer[index] >= 'A' && buffer[index] <= 'F') || (buffer[index] == 0))
		{
			continue;
		}
		else
		{
		  AfxMessageBox(_T("Wrong config data"));
		  return;
		}
	}
	m_hexConfig0 = wcstoul(buffer, NULL, 16) | 0xFF7FFF78;


	if (m_hexConfig0 & 1)  //Data flash disable
		goto skip;

	memset(buffer,0,sizeof (buffer) / sizeof (buffer[0]));
	m_ctlConfig1.GetWindowText(buffer, sizeof (buffer) / sizeof (buffer[0]));
//	GetDlgItemText(IDC_EDIT_CONFIG1,buffer1);
	for(int index=0;index<8;index++)
	{
		if( (buffer[index]>='0' && buffer[index] <= '9') || (buffer[index] >='a' && buffer[index] <= 'f')
			|| (buffer[index] >= 'A' && buffer[index] <= 'F') || (buffer[index] == 0))
		{
			continue;
		}
		else
		{
		  AfxMessageBox(_T("Wrong address"));
		  return;
		}
	}

	m_hexConfig1 = wcstoul(buffer, NULL, 16) & 0x000FFFFF;

	if ((m_hexConfig1 % 0x400 != 0) || (m_hexConfig1 >= 0x23400))
	{
		AfxMessageBox(_T("Wrong address"));
		return;
	}

skip:

	OnOK();
}
