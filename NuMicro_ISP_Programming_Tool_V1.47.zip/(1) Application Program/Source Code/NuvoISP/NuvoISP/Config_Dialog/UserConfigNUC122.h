#pragma once


// CUserConfigNUC122 ��ܤ��

class CUserConfigNUC122 : public CDialogEx
{
	DECLARE_DYNAMIC(CUserConfigNUC122)

public:
	CUserConfigNUC122(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CUserConfigNUC122();

// ��ܤ�����
	enum { IDD = IDD_DIALOG_CONFIG_NUC122 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

public:

	virtual BOOL OnInitDialog();

	DWORD m_uChipID;
	DWORD m_hexConfig0;
	DWORD m_hexConfig1;

	CEdit m_ctlConfig0;

	BOOL UpdateConfig();
	BOOL LoadConfig();

	afx_msg void OnBnClickedCheckCkf();
	afx_msg void OnBnClickedRadio12m();
	afx_msg void OnBnClickedRadio22m();
	afx_msg void OnBnClickedCheckCboden();
	afx_msg void OnBnClickedCheckCborst();
	afx_msg void OnBnClickedRadio45v();
	afx_msg void OnBnClickedRadio38v();
	afx_msg void OnBnClickedRadio26v();
	afx_msg void OnBnClickedRadio22v();
	afx_msg void OnBnClickedCheckLock();
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
