// C:\Users\CFLi0\Documents\Visual Studio 2012\Projects\NuvoISP_NUC451[0521 1537]\NuvoISP\Config_Dialog\HelpUARTPin.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "HelpUARTPin.h"
//#include "afxdialogex.h"


// CHelpUARTPin ��ܤ��

IMPLEMENT_DYNAMIC(CHelpUARTPin, CDialogEx)

CHelpUARTPin::CHelpUARTPin(int ID_BMP, CString str, CWnd* pParent /*=NULL*/)
    : CDialogEx(CHelpUARTPin::IDD, pParent), m_iBMP(ID_BMP), m_strCaption(str)
{

}

CHelpUARTPin::~CHelpUARTPin()
{
}

void CHelpUARTPin::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_STATIC_UARTPIN, m_UARTBmp);
}


BEGIN_MESSAGE_MAP(CHelpUARTPin, CDialogEx)
END_MESSAGE_MAP()


// CHelpUARTPin �T���B�z�`��


BOOL CHelpUARTPin::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    SetWindowText(m_strCaption);

    HBITMAP s_hBitmap = NULL;
    s_hBitmap = (HBITMAP)LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(m_iBMP), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE );

    if (s_hBitmap == NULL)
        return TRUE;

    m_UARTBmp.SetBitmap(s_hBitmap);

    RECT rc1, rc2;
    GetWindowRect(&rc1);
    GetClientRect(&rc2);
    int dx = rc1.right - rc1.left - rc2.right;
    int dy = rc1.bottom - rc1.top - rc2.bottom;

    // Get logical coordinates
    BITMAP bitmap = { 0 };
    GetObject(s_hBitmap, sizeof(BITMAP), &bitmap);

    MoveWindow(
        rc1.left, rc1.top,
        bitmap.bmWidth + dx,
        bitmap.bmHeight + dy,
        FALSE);

    return TRUE;  // return TRUE unless you set the focus to a control

    // EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}
