#pragma once
//#include "afxwin.h"
//#include "afxcmn.h"


// CUserConfigISD9xxx ��ܤ��

class CUserConfigISD9xxx : public CDialogEx
{
	DECLARE_DYNAMIC(CUserConfigISD9xxx)

public:
	CUserConfigISD9xxx(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CUserConfigISD9xxx();

// ��ܤ�����
	enum { IDD = IDD_DIALOG_CONFIG_ISD9XXX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();

	DWORD m_uChipID;
	UINT  m_uFlashSize;
	DWORD m_hexConfig0;
	DWORD m_hexConfig1;

	CEdit m_ctlConfig0;
	CEdit m_ctlConfig1;

	BOOL ShowDataSize();
	BOOL UpdateConfig();
	BOOL LoadConfig();

	afx_msg void OnBnClickedCheckCboden();
	afx_msg void OnBnClickedRadioBootLdrom();
	afx_msg void OnBnClickedRadioBootAprom();
	afx_msg void OnBnClickedRadioLdromEn();
	afx_msg void OnBnClickedRadioLdromDis();
	afx_msg void OnEnChangeEditConfig1();
	afx_msg void OnBnClickedCheckLock();
	afx_msg void OnBnClickedCheckDfen();
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnEnChangeEditConfig0();
	afx_msg void OnEnChangeEditConfig11();
};
