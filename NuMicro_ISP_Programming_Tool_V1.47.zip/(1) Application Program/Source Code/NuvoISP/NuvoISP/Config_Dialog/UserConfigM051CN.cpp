// UserConfigM051.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigM051CN.h"
//#include "afxdialogex.h"


// CUserConfigM051CN ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigM051CN, CDialogEx)

CUserConfigM051CN::CUserConfigM051CN(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigM051CN::IDD, pParent)
{

}

CUserConfigM051CN::~CUserConfigM051CN()
{
}

void CUserConfigM051CN::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
}


BEGIN_MESSAGE_MAP(CUserConfigM051CN, CDialogEx)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigM051CN::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigM051CN::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigM051CN::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigM051CN::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigM051CN::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigM051CN::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigM051CN::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigM051CN::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM, &CUserConfigM051CN::OnBnClickedRadioBootLdrom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM, &CUserConfigM051CN::OnBnClickedRadioBootAprom)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigM051CN::OnBnClickedCheckLock)
	ON_EN_CHANGE(IDC_EDIT_CONFIG0, &CUserConfigM051CN::OnEnChangeEditConfig0)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigM051CN::OnBnClickedButtonDefault)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &CUserConfigM051CN::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_CHECK_WTD_CLK_PD_EN, &CUserConfigM051CN::OnBnClickedCheckWtdClkPdEn)
	ON_BN_CLICKED(IDC_RADIO_IO_TRI_STATE, &CUserConfigM051CN::OnBnClickedRadioIoTriState)
	ON_BN_CLICKED(IDC_RADIO_IO_QUASI_BIDR, &CUserConfigM051CN::OnBnClickedRadioIoQuasiBidr)
END_MESSAGE_MAP()


BOOL CUserConfigM051CN::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);

	LoadConfig();

	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigM051CN::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & (1<<30)) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	if ((m_hexConfig0 & 0x80000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
	}

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & 0x07000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);
		
	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
	
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigM051CN::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= 0x7FFFFFFF;

	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 30);
	
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x80;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0xC0;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x40;
		
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;
	
	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigM051CN �T���B�z�`��


void CUserConfigM051CN::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadio22m()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedCheckCboden()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadioBootLdrom()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadioBootAprom()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnEnChangeEditConfig0()
{
	// TODO:  �p�G�o�O RICHEDIT ����A����N���|
	// �ǰe���i���A���D�z�мg CDialogEx::OnInitDialog()
	// �禡�M�I�s CRichEditCtrl().SetEventMask()
	// ���㦳 ENM_CHANGE �X�� ORed �[�J�B�n�C

	// TODO:  �b���[�J����i���B�z�`���{���X
}


void CUserConfigM051CN::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF3F;
	m_hexConfig1 = 0x1F000;
	LoadConfig();
}



void CUserConfigM051CN::OnBnClickedCheckWtdEn()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedCheckWtdClkPdEn()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadioIoTriState()
{
	UpdateConfig();
}


void CUserConfigM051CN::OnBnClickedRadioIoQuasiBidr()
{
	UpdateConfig();
}
