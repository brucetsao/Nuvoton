#pragma once
#include "afxwin.h"


// CHelpUARTPin ��ܤ��

class CHelpUARTPin : public CDialogEx
{
	DECLARE_DYNAMIC(CHelpUARTPin)

public:
	// CHelpUARTPin(CWnd* pParent = NULL);   // �зǫغc�禡
	CHelpUARTPin(int ID_BMP = 0, CString str = _T(""), CWnd* pParent = NULL);
	virtual ~CHelpUARTPin();

// ��ܤ�����
	enum { IDD = IDD_DIALOG_PIN_UART };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	int wNewWidth, wNewHeight;
	CStatic m_UARTBmp;
	int m_iBMP;
	CString m_strCaption;
};
