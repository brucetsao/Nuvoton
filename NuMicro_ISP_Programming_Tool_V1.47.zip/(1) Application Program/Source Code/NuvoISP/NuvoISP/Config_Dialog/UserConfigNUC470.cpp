// UserConfigNUC200.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigNUC470.h"
//#include "afxdialogex.h"


// CUserConfigNUC470 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigNUC470, CDialogEx)

CUserConfigNUC470::CUserConfigNUC470(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigNUC470::IDD, pParent)
{

}

CUserConfigNUC470::~CUserConfigNUC470()
{
}

void CUserConfigNUC470::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_EDIT_CONFIG2, m_ctlConfig2);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigNUC470, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &CUserConfigNUC470::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_CHECK_WTD_CLK_PD_EN, &CUserConfigNUC470::OnBnClickedCheckWtdClkPdEn)
	ON_BN_CLICKED(IDC_CHECK_CKF, &CUserConfigNUC470::OnBnClickedCheckCkf)
	ON_BN_CLICKED(IDC_RADIO_CFGXT1_GPIO, &CUserConfigNUC470::OnBnClickedRadioCfgxt1Gpio)
	ON_BN_CLICKED(IDC_RADIO_CFGXT1_XTL, &CUserConfigNUC470::OnBnClickedRadioCfgxt1Xtl)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigNUC470::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigNUC470::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigNUC470::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigNUC470::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigNUC470::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigNUC470::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigNUC470::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigNUC470::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_EMC_MII, &CUserConfigNUC470::OnBnClickedRadioEmcMii)
	ON_BN_CLICKED(IDC_RADIO_EMC_RMII, &CUserConfigNUC470::OnBnClickedRadioEmcRmii)
	ON_BN_CLICKED(IDC_RADIO_CFG32K_GPIO, &CUserConfigNUC470::OnBnClickedRadioCfg32kGpio)
	ON_BN_CLICKED(IDC_RADIO_CFG32K_LXT, &CUserConfigNUC470::OnBnClickedRadioCfg32kLxt)
	ON_BN_CLICKED(IDC_CHECK_LDWPEN, &CUserConfigNUC470::OnBnClickedLdwpEn)
	ON_BN_CLICKED(IDC_RADIO_IO_TRI_STATE, &CUserConfigNUC470::OnBnClickedRadioIoTriState)
	ON_BN_CLICKED(IDC_RADIO_IO_QUASI_BIDR, &CUserConfigNUC470::OnBnClickedRadioIoQuasiBidr)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigNUC470::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigNUC470::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigNUC470::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigNUC470::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	m_ctlConfig2.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/2048) - 1); 	//2 Kbytes ~ flash size - 2 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	if ((m_hexConfig0 & 0x1) == 0)
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/2048);

	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC470::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & (1<<30)) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	if ((m_hexConfig0 & 0x80000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
	}

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<28))
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(FALSE);

	/*----------------------------------------------*/
	/*  CFGXT1 - GPG[13:12] Multi-Function Select   */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<27))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_XTL))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_GPIO))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_XTL))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_GPIO))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & 0x07000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  EMC Interface Select                        */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<15))
	{
		((CButton *)GetDlgItem(IDC_RADIO_EMC_MII))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_EMC_RMII))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_EMC_MII))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_EMC_RMII))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  CFG32K - GPG[15:14] Multi-Function Select   */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<14))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CFG32K_GPIO))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CFG32K_LXT))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CFG32K_GPIO))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CFG32K_LXT))->SetCheck(FALSE);
	}

	/*-------------------------------------------------*/
	/*  LDWPEN - LDROM Write-Protected Enable Control  */
	/*-------------------------------------------------*/
	if (m_hexConfig0 & (1 << 11))
		((CButton *)GetDlgItem(IDC_CHECK_LDWPEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LDWPEN))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 2048)) || (m_hexConfig1 < 2048))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 2048;
		}
		tmpStr.Format(_T("%4d KB"),  (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC470::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= 0x7FFFFFFF;

	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 30);

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CKF))->GetCheck() == BST_CHECKED)
		uConfigBit |= (1<<28);
	else
		uConfigBit &= ~(1<<28);

	/*----------------------------------------------*/
	/*  CFGXT1 - GPG[13:12] Multi-Function Select   */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CFGXT1_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 27);
		
	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	/*----------------------------------------------*/
	/*  EMC Interface Select                        */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_EMC_MII))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 15);

	/*----------------------------------------------*/
	/*  CFG32K - GPG[15:14] Multi-Function Select   */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CFG32K_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 14);

	/*-------------------------------------------------*/
	/*  LDWPEN - LDROM Write-Protected Enable Control  */
	/*-------------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LDWPEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 11);

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x80;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0xC0;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x40;

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigNUC470 �T���B�z�`��

void CUserConfigNUC470::OnBnClickedCheckWtdEn()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedCheckWtdClkPdEn()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedCheckCkf()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioCfgxt1Gpio()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioCfgxt1Xtl()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadio22m()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedCheckCboden()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioEmcMii()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioEmcRmii()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioCfg32kGpio()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioCfg32kLxt()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedLdwpEn()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioIoTriState()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedRadioIoQuasiBidr()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedCheckDfen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("2 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
       	m_hexConfig1 = m_uFlashSize - 2048;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigNUC470::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF3F;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}

void CUserConfigNUC470::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4d KB"), nPos*2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 2048);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}



