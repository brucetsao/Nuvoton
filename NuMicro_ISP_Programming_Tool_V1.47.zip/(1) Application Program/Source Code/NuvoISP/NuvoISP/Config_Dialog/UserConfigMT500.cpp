// UserConfigNUC200.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigMT500.h"
//#include "afxdialogex.h"


// CUserConfigMT500 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigMT500, CDialogEx)

CUserConfigMT500::CUserConfigMT500(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigMT500::IDD, pParent)
{

}

CUserConfigMT500::~CUserConfigMT500()
{
}

void CUserConfigMT500::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigMT500, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &CUserConfigMT500::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_CHECK_WTD_CLK_PD_EN, &CUserConfigMT500::OnBnClickedCheckWtdClkPdEn)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigMT500::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigMT500::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigMT500::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigMT500::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigMT500::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigMT500::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigMT500::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigMT500::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_CHZ_BPWM_GPIO, &CUserConfigMT500::OnBnClickedRadioBpwmGpio)
	ON_BN_CLICKED(IDC_RADIO_CHZ_BPWM_TriState, &CUserConfigMT500::OnBnClickedRadioBpwmTriState)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Odd1_GPIO, &CUserConfigMT500::OnBnClickedRadioOdd1Gpio)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Odd1_TriState, &CUserConfigMT500::OnBnClickedRadioOdd1TriState)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Even1_GPIO, &CUserConfigMT500::OnBnClickedRadioEven1Gpio)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Even1_TriState, &CUserConfigMT500::OnBnClickedRadioEven1TriState)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Odd0_GPIO, &CUserConfigMT500::OnBnClickedRadioOdd0Gpio)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Odd0_TriState, &CUserConfigMT500::OnBnClickedRadioOdd0TriState)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Even0_GPIO, &CUserConfigMT500::OnBnClickedRadioEven0Gpio)
	ON_BN_CLICKED(IDC_RADIO_CHZ_Even0_TriState, &CUserConfigMT500::OnBnClickedRadioEven0TriState)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigMT500::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigMT500::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigMT500::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigMT500::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/512) - 1); 	//0.5 Kbytes ~ flash size - 0.5 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	if (m_uFlashSize != 0x20000)
	{
		/* If flash size is not 128 KB, data flash size is always 4 KB.  */
		m_hexConfig1 = 0x1F000;
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_HIDE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_HIDE);
	} 

	LoadConfig();
	
	if ((m_hexConfig0 & 0x1) == 0)
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);

	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigMT500::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & (1<<30)) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	if ((m_hexConfig0 & 0x80000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
	}

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & 0x07000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  Basic PWM Ports Tri-state Driving Control   */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<12))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_BPWM_GPIO))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_BPWM_TriState))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_BPWM_GPIO))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_BPWM_TriState))->SetCheck(FALSE);
	}

	/*--------------------------------------------------*/
	/*  PWM Unit1 odd Ports Tri-state Driving Control   */
	/*--------------------------------------------------*/
	if (m_hexConfig0 & (1<<11))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd1_GPIO))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd1_TriState))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd1_GPIO))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd1_TriState))->SetCheck(FALSE);
	}

	/*--------------------------------------------------*/
	/*  PWM Unit1 even Ports Tri-state Driving Control  */
	/*--------------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even1_GPIO))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even1_TriState))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even1_GPIO))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even1_TriState))->SetCheck(FALSE);
	}

	/*--------------------------------------------------*/
	/*  PWM Unit0 odd Ports Tri-state Driving Control   */
	/*--------------------------------------------------*/
	if (m_hexConfig0 & (1<<9))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd0_GPIO))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd0_TriState))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd0_GPIO))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd0_TriState))->SetCheck(FALSE);
	}

	/*--------------------------------------------------*/
	/*  PWM Unit0 even Ports Tri-state Driving Control  */
	/*--------------------------------------------------*/
	if (m_hexConfig0 & (1<<8))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even0_GPIO))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even0_TriState))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even0_GPIO))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even0_TriState))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 512;
		}
		tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
	}

	if (m_uFlashSize != 0x20000)
		m_hexConfig1 = 0x1F000;

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigMT500::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= 0x7FFFFFFF;

	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 30);

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	/*----------------------------------------------*/
	/*  Basic PWM Ports Tri-state Driving Control   */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CHZ_BPWM_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 12);

	/*--------------------------------------------------*/
	/*  PWM Unit1 odd Ports Tri-state Driving Control   */
	/*--------------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd1_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 11);

	/*--------------------------------------------------*/
	/*  PWM Unit1 even Ports Tri-state Driving Control  */
	/*--------------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even1_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	/*--------------------------------------------------*/
	/*  PWM Unit0 odd Ports Tri-state Driving Control   */
	/*--------------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CHZ_Odd0_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 9);

	/*--------------------------------------------------*/
	/*  PWM Unit0 even Ports Tri-state Driving Control  */
	/*--------------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CHZ_Even0_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 8);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x80;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0xC0;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x40;

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigMT500 �T���B�z�`��


void CUserConfigMT500::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadio22m()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedCheckCboden()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedCheckDfen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
       	m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}

	if (m_uFlashSize != 0x20000)
		m_hexConfig1 = 0x1F000;

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF3F;
	if (m_uFlashSize != 0x20000)
		m_hexConfig1 = 0x1F000;
	else
		m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}

void CUserConfigMT500::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4.1f KB"),(double)nPos/2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 512);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


void CUserConfigMT500::OnBnClickedCheckWtdEn()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedCheckWtdClkPdEn()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioBpwmGpio()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioBpwmTriState()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioOdd1Gpio()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioOdd1TriState()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioEven1Gpio()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioEven1TriState()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioOdd0Gpio()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioOdd0TriState()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioEven0Gpio()
{
	UpdateConfig();
}


void CUserConfigMT500::OnBnClickedRadioEven0TriState()
{
	UpdateConfig();
}

