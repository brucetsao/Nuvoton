// UserConfigM051.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigNUC122.h"
//#include "afxdialogex.h"


// CUserConfigNUC122 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigNUC122, CDialogEx)

CUserConfigNUC122::CUserConfigNUC122(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigNUC122::IDD, pParent)
{

}

CUserConfigNUC122::~CUserConfigNUC122()
{
}

void CUserConfigNUC122::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
}


BEGIN_MESSAGE_MAP(CUserConfigNUC122, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_CKF, &CUserConfigNUC122::OnBnClickedCheckCkf)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigNUC122::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigNUC122::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigNUC122::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigNUC122::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigNUC122::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigNUC122::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigNUC122::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigNUC122::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigNUC122::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigNUC122::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigNUC122::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);

	LoadConfig();

	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC122::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<28))
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(FALSE);

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & 0x07000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);
		
	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (m_hexConfig0 & (1<<7))
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);
	
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC122::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CKF))->GetCheck() == BST_CHECKED)
		uConfigBit |= (1<<28);
	else
		uConfigBit &= ~(1<<28);

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1<<7);
		
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;
	
	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigNUC122 �T���B�z�`��

void CUserConfigNUC122::OnBnClickedCheckCkf()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedRadio22m()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedCheckCboden()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigNUC122::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF7F;
	LoadConfig();
}


