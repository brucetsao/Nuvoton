// UserConfigNUC200.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigNUC123.h"
//#include "afxdialogex.h"


// CUserConfigNUC123 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigNUC123, CDialogEx)

CUserConfigNUC123::CUserConfigNUC123(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigNUC123::IDD, pParent)
{

}

CUserConfigNUC123::~CUserConfigNUC123()
{
}

void CUserConfigNUC123::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigNUC123, CDialogEx)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigNUC123::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigNUC123::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &CUserConfigNUC123::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_CHECK_WTD_CLK_PD_EN, &CUserConfigNUC123::OnBnClickedCheckWtdClkPdEn)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigNUC123::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigNUC123::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigNUC123::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigNUC123::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigNUC123::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigNUC123::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_CHECK_CKF, &CUserConfigNUC123::OnBnClickedCheckCkf)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK_DFVSEN, &CUserConfigNUC123::OnBnClickedCheckDfvsen)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigNUC123::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigNUC123::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigNUC123::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigNUC123::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/512) - 1); 	//0.5 Kbytes ~ flash size - 0.5 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC123::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & (1<<30)) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	if ((m_hexConfig0 & 0x80000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
	}

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<28))
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CKF))->SetCheck(FALSE);

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & 0x07000000) == 0)
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  DFVSEN Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x4)
	{
		/* 
		 *  Data Flash is fixed 4 KB size 
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DFVSEN))->SetCheck(FALSE);

		/* If flash size is not 128 KB, data flash size is always 4 KB.  */
		m_hexConfig1 = 0x1F000;
		tmpStr.Format(_T("4 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->EnableWindow(FALSE);
	}
	else
	{
		/* 
		 *  Data Flash size is variable
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DFVSEN))->SetCheck(TRUE);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->EnableWindow(TRUE);

		/*----------------------------------------------*/
		/*  Data Flash Enable Select                    */
		/*----------------------------------------------*/
		if (m_hexConfig0 & 0x1)
		{
			m_hexConfig1 = 0xFFFFFFFF;
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
			((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_HIDE);
			((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);
			((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_HIDE);
		}
		else
		{
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
			((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_SHOW);
			((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_SHOW);
			((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_SHOW);

			m_controlSpinDataSize.EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
			if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
			{
				// force init CONFIG1 value
				m_hexConfig1 = m_uFlashSize - 512;
			}
			tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
			m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
		}
	} 

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);


	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNUC123::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= 0x7FFFFFFF;

	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 30);

	/*----------------------------------------------*/
	/*  XT1 Clock Filter Select                     */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CKF))->GetCheck() == BST_CHECKED)
		uConfigBit |= (1<<28);
	else
		uConfigBit &= ~(1<<28);

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x80;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0xC0;
	else if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x40;

	/*----------------------------------------------*/
	/*  Data Flash Variable Size Enable Select      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFVSEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x4;

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"),m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigNUC123 �T���B�z�`��


void CUserConfigNUC123::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedRadio22m()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckCboden()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckCkf()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckDfvsen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFVSEN))->GetCheck() == BST_CHECKED)
	{
		/* 
		 *  Data Flash size is variable
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DFVSEN))->SetCheck(TRUE);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->EnableWindow(TRUE);

		/*----------------------------------------------*/
		/*  Data Flash Enable Select                    */
		/*----------------------------------------------*/
		if (m_hexConfig0 & 0x1)
		{
			m_hexConfig1 = 0xFFFFFFFF;
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
			((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_HIDE);
			((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);
			((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_HIDE);
		}
		else
		{
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
			((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_SHOW);
			((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_SHOW);
			((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_SHOW);

			m_controlSpinDataSize.EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
			if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
			{
				// force init CONFIG1 value
				m_hexConfig1 = m_uFlashSize - 512;
			}
			tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
			m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
		}
	} 
	else
	{
		/* 
		 *  Data Flash is fixed 4 KB size 
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DFVSEN))->SetCheck(FALSE);

		/* If flash size is not 128 KB, data flash size is always 4 KB.  */
		m_hexConfig1 = 0x1F000;
		tmpStr.Format(_T("4 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->EnableWindow(FALSE);
	}

	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckDfen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_SHOW);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_SHOW);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_SHOW);

		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
       	m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_HIDE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);
		((CWnd *)GetDlgItem(IDC_TEXT_DATA_FLASH_SIZE))->ShowWindow(SW_HIDE);
        m_hexConfig1 = 0xFFFFFFFF;
	}

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF3F;
	m_hexConfig1 = 0x1F000;
	LoadConfig();
}

void CUserConfigNUC123::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4.1f KB"),(double)nPos/2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 512);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


void CUserConfigNUC123::OnBnClickedCheckWtdEn()
{
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	UpdateConfig();
}


void CUserConfigNUC123::OnBnClickedCheckWtdClkPdEn()
{
	UpdateConfig();
}


