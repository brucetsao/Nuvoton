// UserConfigNano112.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigNano112.h"
//#include "afxdialogex.h"


// CUserConfigNano112 ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigNano112, CDialogEx)

CUserConfigNano112::CUserConfigNano112(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigNano112::IDD, pParent)
{

}

CUserConfigNano112::~CUserConfigNano112()
{
}

void CUserConfigNano112::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigNano112, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &CUserConfigNano112::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_RADIO_12M, &CUserConfigNano112::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &CUserConfigNano112::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_RADIO_BOD17, &CUserConfigNano112::OnBnClickedRadioBOD17)
	ON_BN_CLICKED(IDC_RADIO_BOD20, &CUserConfigNano112::OnBnClickedRadioBOD20)
	ON_BN_CLICKED(IDC_RADIO_BOD25, &CUserConfigNano112::OnBnClickedRadioBOD25)
	ON_BN_CLICKED(IDC_RADIO_BOD_OFF, &CUserConfigNano112::OnBnClickedRadioBOD_OFF)
	ON_BN_CLICKED(IDC_RADIO_HXT_GAIN_24M, &CUserConfigNano112::OnBnClickedRadioHxtGain24M)
	ON_BN_CLICKED(IDC_RADIO_HXT_GAIN_16M, &CUserConfigNano112::OnBnClickedRadioHxtGain16M)
	ON_BN_CLICKED(IDC_RADIO_HXT_GAIN_12M, &CUserConfigNano112::OnBnClickedRadioHxtGain12M)
	ON_BN_CLICKED(IDC_RADIO_HXT_GAIN_8M, &CUserConfigNano112::OnBnClickedRadioHxtGain8M)
	ON_BN_CLICKED(IDC_RADIO_HXT_GAIN_4M, &CUserConfigNano112::OnBnClickedRadioHxtGain4M)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigNano112::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigNano112::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigNano112::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigNano112::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/512) - 1); 	//0.5 Kbytes ~ flash size - 0.5 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNano112::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog Timer enable Select                */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & (1<<31)) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1 << 26))
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOD17))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOD20))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOD25))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOD_OFF))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 19) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOD17))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 19) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOD20))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 19) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOD25))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 19) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOD_OFF))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  HXT Gain Select                             */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_24M))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_16M))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_12M))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_8M))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_4M))->SetCheck(FALSE);

	// CFLi 0113 modify
	//if ((m_hexConfig0 & (7 << 13)) == (0 << 13))
	//	((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_24M))->SetCheck(TRUE);
	//else
	
	if ((m_hexConfig0 & (7 << 13)) == (1 << 13))
		((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_16M))->SetCheck(TRUE);
	else if ((m_hexConfig0 & (7 << 13)) == (3 << 13))
		((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_8M))->SetCheck(TRUE);
	else if ((m_hexConfig0 & (7 << 13)) == (4 << 13))
		((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_4M))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_12M))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
	
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 512;
		}
		tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigNano112::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= 0x7FFFFFFF;

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 26);

	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOD17))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 19);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOD20))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 19)) | (0x1 << 19);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOD25))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 19)) | (0x2 << 19);

	/*----------------------------------------------*/
	/*  HXT Gain Select                             */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_24M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 13);

	if (((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_16M))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x7 << 13)) | (1 << 13);

	if (((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_12M))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x7 << 13)) | (7 << 13);

	if (((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_8M))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x7 << 13)) | (3 << 13);

	if (((CButton *)GetDlgItem(IDC_RADIO_HXT_GAIN_4M))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x7 << 13)) | (4 << 13);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x1 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x2 << 6);

	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigNano112 �T���B�z�`��

void CUserConfigNano112::OnBnClickedCheckWtdEn()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadio12m()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadio22m()
{
	UpdateConfig();
}



void CUserConfigNano112::OnBnClickedRadioBOD17()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioBOD20()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioBOD25()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioBOD_OFF()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioHxtGain24M()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioHxtGain16M()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioHxtGain12M()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioHxtGain8M()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedRadioHxtGain4M()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedCheckDfen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
		
	}
	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigNano112::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF3F;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}

void CUserConfigNano112::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4.1f KB"),(double)nPos/2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 512);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


