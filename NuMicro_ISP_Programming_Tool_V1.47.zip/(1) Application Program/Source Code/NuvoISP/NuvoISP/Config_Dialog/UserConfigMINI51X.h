#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// UserConfigMINI51X ��ܤ��

class UserConfigMINI51X : public CDialogEx
{
	DECLARE_DYNAMIC(UserConfigMINI51X)

public:
	UserConfigMINI51X(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~UserConfigMINI51X();

// ��ܤ�����
	enum { IDD = IDD_DIALOG_CONFIG_MINI51X };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_ctlConfig0;
	CEdit m_ctlConfig1;
	CSpinButtonCtrl m_controlSpinDataSize;
	afx_msg void OnBnClickedCheckCboden();
	virtual BOOL OnInitDialog();
	DWORD m_uChipID;
	UINT  m_uFlashSize;
	DWORD m_hexConfig0;
	DWORD m_hexConfig1;


	BOOL UpdateConfig();
	BOOL LoadConfig();
	BOOL ShowDataSize();

	afx_msg void OnBnClickedCheckCborst();
	afx_msg void OnBnClickedRadio17v();
	afx_msg void OnBnClickedRadio20v();
	afx_msg void OnBnClickedRadio22v();
	afx_msg void OnBnClickedRadio24v();
	afx_msg void OnBnClickedRadio27v();
	afx_msg void OnBnClickedRadio30v();
	afx_msg void OnBnClickedRadio37v();
	afx_msg void OnBnClickedRadio43v();
	afx_msg void OnBnClickedRadioIoTriState();
	afx_msg void OnBnClickedRadioIoQuasiBidr();
	afx_msg void OnBnClickedRadioRc44m();
	afx_msg void OnBnClickedRadioRc48m();
	afx_msg void OnBnClickedCheckEnrcdiv2();
	afx_msg void OnBnClickedCheckLock();
	afx_msg void OnBnClickedCheckDfen();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedButtonDefault();
};
