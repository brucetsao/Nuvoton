// UserConfigMINI51DE.cpp : ��@��
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigMINI51DE.h"
//#include "afxdialogex.h"


// CUserConfigMINI51DE ��ܤ��

IMPLEMENT_DYNAMIC(CUserConfigMINI51DE, CDialogEx)

CUserConfigMINI51DE::CUserConfigMINI51DE(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUserConfigMINI51DE::IDD, pParent)
{

}

CUserConfigMINI51DE::~CUserConfigMINI51DE()
{
}

void CUserConfigMINI51DE::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(CUserConfigMINI51DE, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &CUserConfigMINI51DE::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &CUserConfigMINI51DE::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &CUserConfigMINI51DE::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &CUserConfigMINI51DE::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &CUserConfigMINI51DE::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &CUserConfigMINI51DE::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_RADIO_IO_TRI_STATE, &CUserConfigMINI51DE::OnBnClickedRadioIoTriState)
	ON_BN_CLICKED(IDC_RADIO_IO_QUASI_BIDR, &CUserConfigMINI51DE::OnBnClickedRadioIoQuasiBidr)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK_LOCK, &CUserConfigMINI51DE::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &CUserConfigMINI51DE::OnBnClickedCheckDfen)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &CUserConfigMINI51DE::OnBnClickedButtonDefault)
END_MESSAGE_MAP()


BOOL CUserConfigMINI51DE::OnInitDialog()
{
	CString tmpStr;
	CDialog::OnInitDialog();
	
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);
	
	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/512) - 1); 	//0.5 Kbytes ~ flash size - 0.5 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();
	
	return TRUE;

}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigMINI51DE::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/

	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x7) == 0x7)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
		{
			// force init CONFIG1 value
			m_hexConfig1 = m_uFlashSize - 512;
		}
		tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CUserConfigMINI51DE::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;
	
	/*----------------------------------------------*/
	/*  BOD Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit |= (1 << 23);
	else
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	if (((uConfigBit >> 21) & 0x7) == 0x7)
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	}

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x1 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x2 << 6);

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;
	
	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"),m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}


// CUserConfigMINI51DE �T���B�z�`��

void CUserConfigMINI51DE::OnBnClickedCheckCboden()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedCheckCborst()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedRadio45v()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedRadio38v()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedRadio26v()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedRadio22v()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedRadioIoTriState()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedRadioIoQuasiBidr()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedCheckLock()
{
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedCheckDfen()
{
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
		m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
		m_controlSpinDataSize.EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(FALSE);
		tmpStr.Format(_T("0"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
        m_hexConfig1 = 0xFFFFFFFF;
		
	}
	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}


void CUserConfigMINI51DE::OnBnClickedButtonDefault()
{
	m_hexConfig0 |= 0xFFFFFF7F;
	m_hexConfig1 = 0xFFFFFFFF;
	LoadConfig();
}

void CUserConfigMINI51DE::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString  tmpStr;
	
	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
		  	return;
		
		tmpStr.Format(_T("%4.1f KB"),(double)nPos/2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

        m_hexConfig1 = m_uFlashSize - (nPos * 512);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


