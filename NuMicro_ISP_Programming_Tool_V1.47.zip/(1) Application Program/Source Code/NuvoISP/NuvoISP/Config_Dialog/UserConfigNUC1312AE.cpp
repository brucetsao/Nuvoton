// UserConfigNUC1312AE.cpp : implementation file
//

#include "stdafx.h"
#include "../NuvoISP.h"
#include "UserConfigNUC1312AE.h"


// UserConfigNUC1312AE dialog

IMPLEMENT_DYNAMIC(UserConfigNUC1312AE, CDialog)

UserConfigNUC1312AE::UserConfigNUC1312AE(CWnd* pParent /*=NULL*/)
	: CDialog(UserConfigNUC1312AE::IDD, pParent)
{

}

UserConfigNUC1312AE::~UserConfigNUC1312AE()
{
}

void UserConfigNUC1312AE::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CONFIG0, m_ctlConfig0);
	DDX_Control(pDX, IDC_EDIT_CONFIG1, m_ctlConfig1);
	DDX_Control(pDX, IDC_SPIN_DATA_SIZE, m_controlSpinDataSize);
}


BEGIN_MESSAGE_MAP(UserConfigNUC1312AE, CDialog)
	ON_BN_CLICKED(IDC_CHECK_WTD_EN, &UserConfigNUC1312AE::OnBnClickedCheckWtdEn)
	ON_BN_CLICKED(IDC_CHECK_WTD_CLK_PD_EN, &UserConfigNUC1312AE::OnBnClickedCheckWtdClkPdEn)
	ON_BN_CLICKED(IDC_RADIO_CGPFMFP_GPIO, &UserConfigNUC1312AE::OnBnClickedRadioCgpfmfpGpio)
	ON_BN_CLICKED(IDC_RADIO_CGPFMFP_XTL, &UserConfigNUC1312AE::OnBnClickedRadioCgpfmfpXtl)
	ON_BN_CLICKED(IDC_RADIO_12M, &UserConfigNUC1312AE::OnBnClickedRadio12m)
	ON_BN_CLICKED(IDC_RADIO_22M, &UserConfigNUC1312AE::OnBnClickedRadio22m)
	ON_BN_CLICKED(IDC_RADIO_IO_TRI_STATE, &UserConfigNUC1312AE::OnBnClickedRadioIoTriState)
	ON_BN_CLICKED(IDC_RADIO_IO_QUASI_BIDR, &UserConfigNUC1312AE::OnBnClickedRadioIoQuasiBidr)
	ON_BN_CLICKED(IDC_CHECK_CBODEN, &UserConfigNUC1312AE::OnBnClickedCheckCboden)
	ON_BN_CLICKED(IDC_CHECK_CBORST, &UserConfigNUC1312AE::OnBnClickedCheckCborst)
	ON_BN_CLICKED(IDC_RADIO_45V, &UserConfigNUC1312AE::OnBnClickedRadio45v)
	ON_BN_CLICKED(IDC_RADIO_38V, &UserConfigNUC1312AE::OnBnClickedRadio38v)
	ON_BN_CLICKED(IDC_RADIO_26V, &UserConfigNUC1312AE::OnBnClickedRadio26v)
	ON_BN_CLICKED(IDC_RADIO_22V, &UserConfigNUC1312AE::OnBnClickedRadio22v)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, &UserConfigNUC1312AE::OnBnClickedButtonDefault)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM, &UserConfigNUC1312AE::OnBnClickedRadioBootLdrom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_LDROM_IAP, &UserConfigNUC1312AE::OnBnClickedRadioBootLdromIap)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM, &UserConfigNUC1312AE::OnBnClickedRadioBootAprom)
	ON_BN_CLICKED(IDC_RADIO_BOOT_APROM_IAP, &UserConfigNUC1312AE::OnBnClickedRadioBootApromIap)
	ON_BN_CLICKED(IDC_CHECK_LOCK, &UserConfigNUC1312AE::OnBnClickedCheckLock)
	ON_BN_CLICKED(IDC_CHECK_DATA_FLASH_VAR_SIZE, &UserConfigNUC1312AE::OnBnClickedCheckDataFlashVarSize)
	ON_BN_CLICKED(IDC_CHECK_DFEN, &UserConfigNUC1312AE::OnBnClickedCheckDfen)
	ON_WM_VSCROLL()
END_MESSAGE_MAP()


// UserConfigNUC1312AE message handlers

BOOL UserConfigNUC1312AE::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	m_ctlConfig0.SetLimitText(8);
	m_ctlConfig1.SetLimitText(8);

	m_controlSpinDataSize.SetRange(1, (m_uFlashSize/2048) - 1); 	//2 Kbytes ~ flash size - 2 Kbytes
	m_controlSpinDataSize.SetBuddy(GetDlgItem(IDC_EDIT_DATA_SIZE));	

	LoadConfig();

	if ((m_hexConfig0 & 0x1) == 0)
		m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/2048);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     LoadConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Load User Configuration setting                           								   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL UserConfigNUC1312AE::LoadConfig()
{
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if ((m_hexConfig0 & (1<<30)) == 0)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(TRUE);
        ((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	}

	// if ((m_hexConfig0 & 0x80000000) == 0)
	// {
		// ((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
		// GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	// }
	// else
	// {
		// ((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
		// GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
	// }

    if ((m_hexConfig0 & (1<<31)) == 1)
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(FALSE);
	}
    
	/*----------------------------------------------*/
	/*  GPF Multi-Function Select                   */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<27))
	{
		((CButton *)GetDlgItem(IDC_RADIO_CGPFMFP_XTL))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_CGPFMFP_GPIO))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_CGPFMFP_XTL))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_CGPFMFP_GPIO))->SetCheck(TRUE);
	}

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	//if ((m_hexConfig0 & 0x07000000) == 0)
    if (m_hexConfig0 & (1<<24))
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_12M))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_22M))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  BOD Select                                  */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<23))
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	if (m_hexConfig0 & (1<<20))
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(TRUE);

	((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 21) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(TRUE);

	// if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	// {
		// GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	// }
	// else
	// {
		// GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		// ((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		// ((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		// ((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		// ((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		// ((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	// }

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (m_hexConfig0 & (1<<10))
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(FALSE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(TRUE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->SetCheck(TRUE);
		((CButton *)GetDlgItem(IDC_RADIO_IO_QUASI_BIDR))->SetCheck(FALSE);
	}

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(FALSE);
	((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(FALSE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x0)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x1)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x2)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->SetCheck(TRUE);

	if (((m_hexConfig0 >> 6) & 0x3) == 0x3)
		((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  DATA Flash Variable Size Enable             */
	/*----------------------------------------------*/
	//if (m_hexConfig0 & 0xFB)
	// if (m_hexConfig0 & (1<<2))
		// ((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->SetCheck(TRUE);			
	// else
		// ((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->SetCheck(FALSE);
	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (m_hexConfig0 & 0x2)
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(FALSE);
	else
		((CButton *)GetDlgItem(IDC_CHECK_LOCK))->SetCheck(TRUE);

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
    if (m_hexConfig0 & 0x4)
	{
        /* 
		 *  Data Flash is fixed 4 KB size 
		 */
        ((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->SetCheck(FALSE);
        
		/*data flash size is always 4 KB.  */
		m_hexConfig1 = 0x1F000;
		tmpStr.Format(_T("4 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(FALSE);
	}
	else
	{	
		/* 
		 *  Data Flash size is variable
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->SetCheck(TRUE);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(TRUE);

		/*----------------------------------------------*/
		/*  Data Flash Enable Select                    */
		/*----------------------------------------------*/
		if (m_hexConfig0 & 0x1)
		{
			m_hexConfig1 = 0xFFFFFFFF;
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
			//((CWnd *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->ShowWindow(SW_HIDE);
			//((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);
		}
		else
		{
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
			//((CWnd *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->ShowWindow(SW_SHOW);
			//((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_SHOW);

			m_controlSpinDataSize.EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
			if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
			{
				// force init CONFIG1 value
				m_hexConfig1 = m_uFlashSize - 512;
			}
			tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
			m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
		}

	}

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);

	return TRUE;
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               Update User Configuration setting                           							   */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 None                                                                                      */
/* Returns:                                                                                                */
/*               TRUE  : Success                                                                           */
/*               FALSE : Failed                                                                            */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL UserConfigNUC1312AE::UpdateConfig()
{
	UINT uConfigBit = 0xFFFFFFFF;
	CString tmpStr;

	/*----------------------------------------------*/
	/*  Watchdog enable Select                      */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
    {
		uConfigBit &= 0x7FFFFFFF;
        uConfigBit |= (3 << 3);
    }
    
    if (((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 30);

	/*----------------------------------------------*/
	/*  GPF Multi-Function Select                   */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_CGPFMFP_GPIO))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 27);

	/*----------------------------------------------*/
	/*  CFOSC Select                                */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_12M))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x7 << 24);

	/*---------------------------------------------*/
	/*  BOD Select                                 */
	/*---------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 23);

	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 20);
        
    if (((CButton *)GetDlgItem(IDC_RADIO_45V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x3 << 21);    

	if (((CButton *)GetDlgItem(IDC_RADIO_38V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x2 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_26V))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 21)) | (0x1 << 21);

	if (((CButton *)GetDlgItem(IDC_RADIO_22V))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 21);

	/*----------------------------------------------*/
	/*  CIOINI Select                               */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_IO_TRI_STATE))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(1 << 10);

	/*----------------------------------------------*/
	/*  Boot Select                                 */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~(0x3 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_LDROM))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x1 << 6);

	if (((CButton *)GetDlgItem(IDC_RADIO_BOOT_APROM_IAP))->GetCheck() == BST_CHECKED)
		uConfigBit = (uConfigBit & ~(0x3 << 6)) | (0x2 << 6);

	/*----------------------------------------------*/
	/*  DATA Flash Variable Size Enable             */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->GetCheck() == BST_CHECKED)
        uConfigBit &= ~0x4;

	/*----------------------------------------------*/
	/*  Flash Lock Select                           */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_LOCK))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x2;

	/*----------------------------------------------*/
	/*  Data Flash Enable Select                    */
	/*----------------------------------------------*/
	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
		uConfigBit &= ~0x1;

	m_hexConfig0 = uConfigBit;

	tmpStr.Format(_T("%08X"),m_hexConfig0);
	m_ctlConfig0.SetWindowText(tmpStr);
	tmpStr.Format(_T("%08X"),m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	return TRUE;
}

void UserConfigNUC1312AE::OnBnClickedCheckWtdEn()
{
	// TODO: Add your control notification handler code here
	// if (((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->GetCheck() == BST_CHECKED)
	// {
		// GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(TRUE);
	// }
	// else
	// {
		// GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN)->EnableWindow(FALSE);
		// ((CButton *)GetDlgItem(IDC_CHECK_WTD_CLK_PD_EN))->SetCheck(FALSE);
	// }

	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedCheckWtdClkPdEn()
{
	// TODO: Add your control notification handler code here
    ((CButton *)GetDlgItem(IDC_CHECK_WTD_EN))->SetCheck(TRUE);
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioCgpfmfpGpio()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioCgpfmfpXtl()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadio12m()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadio22m()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioIoTriState()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioIoQuasiBidr()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedCheckCboden()
{
	// TODO: Add your control notification handler code here
	// if (((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->GetCheck() == BST_CHECKED)
	// {
		// GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_45V)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_38V)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_26V)->EnableWindow(TRUE);
		// GetDlgItem(IDC_RADIO_22V)->EnableWindow(TRUE);
	// }
	// else
	// {
		// GetDlgItem(IDC_CHECK_CBORST)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_45V)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_38V)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_26V)->EnableWindow(FALSE);
		// GetDlgItem(IDC_RADIO_22V)->EnableWindow(FALSE);
		// ((CButton *)GetDlgItem(IDC_CHECK_CBORST))->SetCheck(FALSE);
		// ((CButton *)GetDlgItem(IDC_RADIO_45V))->SetCheck(TRUE);
		// ((CButton *)GetDlgItem(IDC_RADIO_38V))->SetCheck(FALSE);
		// ((CButton *)GetDlgItem(IDC_RADIO_26V))->SetCheck(FALSE);
		// ((CButton *)GetDlgItem(IDC_RADIO_22V))->SetCheck(FALSE);
	// }

	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedCheckCborst()
{
	// TODO: Add your control notification handler code here
	if (((CButton *)GetDlgItem(IDC_CHECK_CBORST))->GetCheck() == BST_CHECKED)
		((CButton *)GetDlgItem(IDC_CHECK_CBODEN))->SetCheck(TRUE);

	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadio45v()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadio38v()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadio26v()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadio22v()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedButtonDefault()
{
	// TODO: Add your control notification handler code here
	m_hexConfig0 |= 0xFFFFFF3F;
	m_hexConfig1 = 0x1F000;
	LoadConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioBootLdrom()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioBootLdromIap()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioBootAprom()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedRadioBootApromIap()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedCheckLock()
{
	// TODO: Add your control notification handler code here
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedCheckDataFlashVarSize()
{
	// TODO: Add your control notification handler code here
	CString  tmpStr;
    
    if (((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->GetCheck() == BST_CHECKED)
	{
		/* 
		 *  Data Flash size is variable
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->SetCheck(TRUE);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(TRUE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(TRUE);

		/*----------------------------------------------*/
		/*  Data Flash Enable Select                    */
		/*----------------------------------------------*/
		if (m_hexConfig0 & 0x1)
		{
			m_hexConfig1 = 0xFFFFFFFF;
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(FALSE);
			((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_HIDE);
			((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);			
		}
		else
		{
			((CButton *)GetDlgItem(IDC_CHECK_DFEN))->SetCheck(TRUE);
			((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_SHOW);
			((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_SHOW);

			m_controlSpinDataSize.EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
			if ((m_hexConfig1 > (m_uFlashSize - 512)) || (m_hexConfig1 < 512))
			{
				// force init CONFIG1 value
				m_hexConfig1 = m_uFlashSize - 512;
			}
			tmpStr.Format(_T("%4.1f KB"),(double) (m_uFlashSize - m_hexConfig1)/1024);
			GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
			m_controlSpinDataSize.SetPos((m_uFlashSize - m_hexConfig1)/512);
		}
	} 
	else
	{
		/* 
		 *  Data Flash is fixed 4 KB size 
		 */
		((CButton *)GetDlgItem(IDC_CHECK_DATA_FLASH_VAR_SIZE))->SetCheck(FALSE);

		
		m_hexConfig1 = 0x1F000;
		tmpStr.Format(_T("4 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
		((CWnd *)GetDlgItem(IDC_CHECK_DFEN))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->EnableWindow(FALSE);	
	}
    
	UpdateConfig();
}

void UserConfigNUC1312AE::OnBnClickedCheckDfen()
{
	// TODO: Add your control notification handler code here
	CString  tmpStr;

	if (((CButton *)GetDlgItem(IDC_CHECK_DFEN))->GetCheck() == BST_CHECKED)
	{
        ((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_SHOW);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_SHOW);
        
        m_controlSpinDataSize.EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DATA_SIZE)->EnableWindow(TRUE);
		m_controlSpinDataSize.SetPos(1);
		tmpStr.Format(_T("0.5 KB"));
		GetDlgItem(IDC_EDIT_DATA_SIZE)->SetWindowTextW(tmpStr);
       	m_hexConfig1 = m_uFlashSize - 512;
	}
	else
	{
        ((CWnd *)GetDlgItem(IDC_EDIT_DATA_SIZE))->ShowWindow(SW_HIDE);
		((CWnd *)GetDlgItem(IDC_SPIN_DATA_SIZE))->ShowWindow(SW_HIDE);
        m_hexConfig1 = 0xFFFFFFFF;
	}

	tmpStr.Format(_T("%08X"), m_hexConfig1);
	m_ctlConfig1.SetWindowText(tmpStr);
	UpdateConfig();
}

void UserConfigNUC1312AE::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	CString  tmpStr;

	if (pScrollBar->GetDlgCtrlID() == IDC_SPIN_DATA_SIZE)
	{
		if (nSBCode == SB_ENDSCROLL)
			return;

		tmpStr.Format(_T("%4d KB"), nPos*2);
		((CSpinButtonCtrl *)pScrollBar)->GetBuddy()->SetWindowTextW(tmpStr);

		m_hexConfig1 = m_uFlashSize - (nPos * 2048);
		tmpStr.Format(_T("%08X"), m_hexConfig1);
		m_ctlConfig1.SetWindowText(tmpStr);
	}
	else
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}
