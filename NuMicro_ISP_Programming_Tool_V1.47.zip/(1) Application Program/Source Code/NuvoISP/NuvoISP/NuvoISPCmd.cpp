
// NuvoISPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "NuvoISPDlg.h"
#include "NuvoISPCmd.h"

UINT g_packno = 1;

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdSyncPackno                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �V�U����o�eCMD_SYNC_PACKNO�R�O                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 DevInterface	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdSyncPackno(int DevInterface)
{
    BOOL Result;
    unsigned long cmdData;

    //sync send&recv packno
    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_SYNC_PACKNO;
    memcpy(WriteReportBuffer+1, &cmdData, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    memcpy(WriteReportBuffer+9, &g_packno, 4);
    g_packno++;

    Result = WriteData(DevInterface);
    if(Result == FALSE)
        return Result;

    Result = ReadData(DevInterface);

    return Result;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdGetCheckSum                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �q�U���Ū��Checksum��                                                                    */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/*				 start	   	  	  -[in]   �}�l��}                                                         */
/*				 len	   	  	  -[in]   ����                                                             */
/*				 cksum	   	  	  -[out]  Checksum��                                                       */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdGetCheckSum(int DevInterface, int start, int len, unsigned short *cksum)
{
    BOOL Result;
    unsigned long cmdData;
    unsigned short lcksum;

    //sync send&recv packno
    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_READ_CHECKSUM;
    memcpy(WriteReportBuffer+1, &cmdData, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    memcpy(WriteReportBuffer+9, &start, 4);
    memcpy(WriteReportBuffer+13, &len, 4);
    g_packno++;

    Result = WriteData(DevInterface);
    if(Result == FALSE)
        return Result;

    Result = ReadData(DevInterface);
    if(Result) {
        if(DevInterface == PORT_USB)
            memcpy(&lcksum, ReadReportBuffer+9, 2);
        else
            memcpy(&lcksum, ReadReportBuffer+8, 2);

        *cksum = lcksum;
    }

    return Result;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdSetCanId                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �V�U����o�eCMD_SET_CAN_ID�R�O�MCAN identifier                                                           */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdSetCanId(BOOL bUSB)
{
    BOOL Result;
    unsigned long cmdData;
    unsigned long canId = 0;
    CString str;

    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_SET_CAN_ID;
    memcpy(WriteReportBuffer+1, &cmdData, 4);

    GetDlgItemText(IDC_EDIT_CAN_ID, str);
    //canId = _ttoi(str);
    canId = _tcstol(str, NULL, 16);
    memcpy(WriteReportBuffer+5, &canId, 4);

    Result = WriteData(bUSB);

    return Result;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdSetCheckSum                                                              	           */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��Checksum�ȵo�e��U����A�U����i�H�O�sChecksum�Ȩ�S�w��m                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 DevInterface  	  -[in]   �T�{����ظ˸m�����s��: 1(PORT_USB)/2(PORT_COM)/3(PORT_EMAC)   */
/*				 checksum	   	  -[in]   Checksum��                                                  */
/*				 len	   	  	  -[in]   ����                                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                       */
/*               FALSE : ����                                                                       */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdSetCheckSum(int DevInterface, unsigned short checksum, int len)
{
    BOOL Result;
    unsigned long cmdData;

    //sync send&recv packno
    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_WRITE_CHECKSUM;
    memcpy(WriteReportBuffer+1, &cmdData, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    memcpy(WriteReportBuffer+9, &len, 4);
    memcpy(WriteReportBuffer+13, &checksum, 4);
    g_packno++;

    Result = WriteData(DevInterface);
    if(Result == FALSE)
        return Result;

    Result = ReadData(DevInterface);
    return Result;
}
/*---------------------------------------------------------------------------------------------------------*/
/* Function:     CmdWriteAndReadOne                                                              	       */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �o�e�@�өR�O�A�åBŪ���өR�O���^��                                                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/*				 cmd	   	  	  -[in]   �o�e���R�O                                                       */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::CmdWriteAndReadOne(int DevInterface, DWORD cmd)
{
	if(cmd != CMD_RESEND_PACKET)
	    m_curCmd = cmd;

    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    memcpy(WriteReportBuffer+1, &cmd, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    g_packno++;

    if(WriteData(DevInterface) == FALSE)
        return FALSE;

    return ReadData(DevInterface);
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     RunApRom                                                              	                   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �ϤU����qAprom�Ұ�                                                                       */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
void CNuvoISPDlg::RunApRom(int DevInterface)
{
    unsigned long cmdData;

    //CMD_RUN_APROM
    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_RUN_APROM;
    memcpy(WriteReportBuffer+1, &cmdData, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    g_packno++;


    WriteData(DevInterface);

}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     EraseAllChip                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �����U����ҥH���                                                                        */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::EraseAllChip(int DevInterface)
{
    BOOL Result;
    unsigned long cmdData;

    SetDlgItemText(IDC_EDIT_MESSAGE,_T(""));
    AddToInfOut(_T("Erase all..."),1,1);

    m_writeProgress.SetPos(5);
#if 1
    Result = CmdSyncPackno(DevInterface);
    if(Result == FALSE) {
        AddToInfOut(_T("Send sync packno cmd fail"),1,1);
        m_writeProgress.SetPos(0);
        return FALSE;
    }

    m_writeProgress.SetPos(10);
#endif
    /** send updata config command**/
    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_ERASE_ALL;
    memcpy(WriteReportBuffer+1, &cmdData, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    g_packno++;


    Result = WriteData(DevInterface);
    if(Result == FALSE)
        return FALSE;
    m_writeProgress.SetPos(15);

    Result = ReadData(DevInterface);
    if(Result == FALSE)
        return FALSE;

    SaveBurnMode(m_strWindowsAppDataPath + CString(_T("nuvotonISP.lua")));

    return TRUE;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Function:     UpdateConfig                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��s�U���Config�ϰ�                                                                      */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 bUSB	   	  	  -[in]   �O�_��USB�s��: TURE/FALSE                                        */
/* Returns:                                                                                                */
/*               TRUE  : ���\                                                                              */
/*               FALSE : ����                                                                              */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::UpdateConfig(int DevInterface)
{
    BOOL Result;
    unsigned long cmdData;
    DWORD rcvConfig0,rcvConfig1;

    AddToInfOut(_T("Updating..."),1,1);
    m_writeProgress.SetPos(5);

    Result = CmdSyncPackno(DevInterface);
    if(Result == FALSE) {
        AddToInfOut(_T("Send sync packno cmd fail"),1,1);
        m_writeProgress.SetPos(0);
        return FALSE;
    }

    m_writeProgress.SetPos(10);

    /** send updata config command**/
    memset(WriteReportBuffer, 0, MAX_PACKET+1);
    cmdData = CMD_UPDATE_CONFIG;//CMD_UPDATE_CONFIG
    memcpy(WriteReportBuffer+1, &cmdData, 4);
    memcpy(WriteReportBuffer+5, &g_packno, 4);
    g_packno++;


    //config 0
    memcpy(WriteReportBuffer+9, &m_hexConfig0, 4);
    //config 1
    memcpy(WriteReportBuffer+13, &m_hexConfig1, 4);

    TRACE(_T("m_hexConfig1=0x%x\r\n"), m_hexConfig1);

    //send CMD_UPDATE_CONFIG
    Result = WriteData(DevInterface);
    if(Result == FALSE)
        return FALSE;
    m_writeProgress.SetPos(15);

    Result = ReadData(DevInterface);
    if(Result == FALSE)
        return FALSE;


    if(DevInterface == PORT_USB) {
        memcpy(&rcvConfig0,ReadReportBuffer+9,4);
        memcpy(&rcvConfig1,ReadReportBuffer+13,4);
    } else { // PORT_COM / PORT_EMAC
        memcpy(&rcvConfig0,ReadReportBuffer+8,4);
        memcpy(&rcvConfig1,ReadReportBuffer+12,4);
    }
    if( (rcvConfig0!=m_hexConfig0) || (rcvConfig1!=m_hexConfig1) ) {
        AddToInfOut(_T("Recieved Config0:0x")+itos(rcvConfig0,16)+_T(" Config1:0x")+itos(rcvConfig1,16),FALSE,TRUE);
        return FALSE;
    }

    return TRUE;

}
