
// NuvoISPDlg.cpp : implementation file
//

#include "stdafx.h"
#include <strsafe.h>

#include <winsock2.h>
#include <ws2tcpip.h>
#include <conio.h>

#include "NuvoISP.h"
#include "NuvoISPDlg.h"
#include "Config_Dialog/Setting.h"
#include "Config_Dialog/UserConfigM051.h"
#include "Config_Dialog/UserConfigM051CN.h"
#include "Config_Dialog/UserConfigNano100.h"
#include "Config_Dialog/UserConfigNano112.h"
#include "Config_Dialog/UserConfigNUC100.h"
#include "Config_Dialog/UserConfigNUC122.h"
#include "Config_Dialog/UserConfigNUC123.h"
#include "Config_Dialog/UserConfigNUC200.h"
#include "Config_Dialog/UserConfigMT500.h"
#include "Config_Dialog/UserConfigMINI51AN.h"
#include "Config_Dialog/UserConfigMINI51BN.h"
#include "Config_Dialog/UserConfigMINI51DE.h"
#include "Config_Dialog/UserConfigNUC470.h"
#include "Config_Dialog/UserConfigNUC451.h"
#include "Config_Dialog/UserConfigNUC1312AE.h"
#include "Config_Dialog/UserConfigISD9xxx.h"
#include "Config_Dialog/UserConfigMINI51X.h"
#include "Config_Dialog/HelpUARTPin.h"
#include "Config_Dialog/HelpUSBPin.h"
#include "dbt.h"


#ifdef PORJ_SAVE_ALL
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <share.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#endif

#ifdef WINUSB_NUVO_DFU

// Linked libraries
#pragma comment (lib , "setupapi.lib" )
#pragma comment (lib , "winusb.lib" )

// Constant for {AA75740D-F7C8-4417-99D1-28C11E23B70F}
static const GUID DFU_DEVICE_INTERFACE =
{ 0xaa75740d, 0xf7c8, 0x4417, { 0x99, 0xd1, 0x28, 0xc1, 0x1e, 0x23, 0xb7, 0x0f } };

#endif	// WINUSB_NUVO_DFU

extern "C" {
#include "hidsdi.h"
#include "setupapi.h"
}

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace std;

/*
  �Ψӵ��U�]�Ƴq���ƥ�Ϊ��s�������C
  �n�ϥθӵ��c��A�ݭn�bStdAfx.h���N�W�[�y�y#define WINVER 0x0500
*/
DEV_BROADCAST_DEVICEINTERFACE DevBroadcastDeviceInterface;

static UINT g_packno = 1;
static int g_debug = 0;
static DWORD g_ErrorCode = 0;
CString strWhichCom;

CNuvoISPDlg *pDlg;


UCHAR CodeFileBuffer[MAX_BIN_FILE_SIZE];
UCHAR DataFileBuffer[MAX_BIN_FILE_SIZE];


/*---------------------------------------------------------------------------------------------------------*/
/* Function:     ReadData                                                              	                   */
/*                                                                                                         */
/* Description:                                                                                            */
/*               �qUSB/��f/Ethernet Ū����ơAŪ������Ʃ�b�T�w����m:ReadReportBuffer                 */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 DevInterface	   	  	  -[in]   �s���������O���@��                                      */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
BOOL CNuvoISPDlg::ReadData(int DevInterface)
{
    BOOL Result;
    unsigned long nRead;
    UINT LastError, len;
    CString Str;
    unsigned short lcksum;
    HANDLE hRead;
    UCHAR *pBuf;
//	DWORD waitRet;
    static int debugcn;
    UINT uWaitProgress;
    DWORD tick1,tick2,timeout;
    UINT curPacketNo=0;
    int i;
    COMSTAT ComStat;
    DWORD dwErrorFlags;

    g_ErrorCode = 0;

    if (DevInterface == PORT_USB) {
        len = MAX_PACKET+1;
        hRead = hUsbHandle;
    } else {
        len = MAX_PACKET;
        hRead = hCom;
    }
    memset(ReadReportBuffer,0,sizeof(ReadReportBuffer));
    ResetEvent(ReadOverlapped.hEvent);
    ReadOverlapped.Offset = 0;
    ReadOverlapped.OffsetHigh = 0;

#if 0	// ychuang, 2012.12.09 - to shorten time-out
    if (((m_curCmd == CMD_UPDATE_APROM) || (m_curCmd == CMD_UPDATE_DATAFLASH) ||
    (m_curCmd == CMD_ERASE_ALL)) && (g_packno==4))
        timeout = 5500; //ms  (256 * 20ms = 5120 ms)
    else
        timeout = 1000;
#else
    //Time out
    if ((m_curCmd == CMD_UPDATE_DATAFLASH) ||
    (m_curCmd == CMD_UPDATE_APROM) ||
    (m_curCmd == CMD_ERASE_ALL)) 			// need longer time to wait flash erase
        timeout = 20000; //ms
    else
        timeout = 5000;
#endif

    if (bDetectingSaved) {
        timeout = 20;
    }

//Progress
    if (m_curCmd == CMD_UPDATE_CONFIG)
        uWaitProgress = 160;
    else if ((m_curCmd == CMD_UPDATE_APROM) || (m_curCmd == CMD_UPDATE_DATAFLASH) ||
    (m_curCmd == CMD_ERASE_ALL))
        uWaitProgress = 500;

    tick1 = ::GetTickCount();

    if(DevInterface == PORT_EMAC) {
        recvfrom(sclient, (char *)ReadReportBuffer, len, 0, (struct sockaddr*)&Recv_addr, &recv_len);
        //recvfrom(sclient, (char *)pBuf, len, 0, (struct sockaddr*)&Recv_addr, &recv_len);
        g_packno++;
        return TRUE;
    }


    while(1) {
        pBuf = ReadReportBuffer;
        if (DevInterface == PORT_COM)
            ClearCommError(hRead,&dwErrorFlags,&ComStat);

#ifdef WINUSB_NUVO_DFU
        if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
            WINUSB_SETUP_PACKET SetupPacket;

            len = 64;
            ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
            //Create the setup packet
            SetupPacket.RequestType = 0xA1;
            SetupPacket.Request = 0x2;			// DFU_UPLOAD
            SetupPacket.Value = 0;				// wBlockNum
            SetupPacket.Index = 0; 				// Interface
            SetupPacket.Length = 64;
            nRead = 0;
            Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, pBuf+1, 64, &nRead, 0);
            if (nRead != 64)
                Result = FALSE;
        } else {
            Result = ReadFile(hRead,
            pBuf,
            len,
            &nRead,
            &ReadOverlapped);
        }

        if (Result == FALSE) {
            LastError = GetLastError();

            if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE))
                LastError = ERROR_IO_PENDING;

            if (LastError == ERROR_IO_PENDING) {
                ResetEvent(ReadOverlapped.hEvent);

                do {
                    if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
                        WINUSB_SETUP_PACKET SetupPacket;

                        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
                        //Create the setup packet
                        SetupPacket.RequestType = 0xA1;
                        SetupPacket.Request = 0x2;			// DFU_UPLOAD
                        SetupPacket.Value = 0;				// wBlockNum
                        SetupPacket.Index = 0; 				// Interface
                        SetupPacket.Length = 64;
                        nRead = 0;
                        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, pBuf+1, 64, &nRead, 0);
                        if (nRead != 64)
                            Result = FALSE;
                    } else {
                        Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
                    }

                    if (Result)
                        break;
#else
        Result = ReadFile(hRead,
        pBuf,
        len,
        &nRead,
        &ReadOverlapped);
        if (Result == FALSE) {
            LastError = GetLastError();
            if (LastError == ERROR_IO_PENDING) {
                ResetEvent(ReadOverlapped.hEvent);

                do {
                    Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
                    if (Result)
                        break;
#endif
                    //Progress
                    if ((m_curCmd == CMD_UPDATE_CONFIG) && (g_packno == 4)) {
                        //20% - 100%
                        m_writeProgress.SetPos(uWaitProgress/8);
                        uWaitProgress ++;
                        if (uWaitProgress >= 800)
                            uWaitProgress = 800;

                        SleepEx(10,TRUE);
                    } else if (((m_curCmd == CMD_UPDATE_APROM) ||
                    (m_curCmd == CMD_UPDATE_DATAFLASH) ||
                    (m_curCmd == CMD_ERASE_ALL)) &&
                    (g_packno==4)) {
                        if (m_writeProgress.GetPos() != uWaitProgress/30)
                            m_writeProgress.SetPos(uWaitProgress/100); //5% - 20%
                        uWaitProgress ++;
                        if (uWaitProgress >= 2000)
                            uWaitProgress = 2000;

                        SleepEx(10,TRUE);
                    }

                    //Time out
                    tick2 = ::GetTickCount();
                    if ((tick2 - tick1) > timeout) {
                        if (DevInterface == PORT_COM)
                            PurgeComm( hCom, PURGE_RXABORT | PURGE_RXCLEAR );

                        if (!bDetectingSaved) {
                            //if(!bUSB)//clyu
                            //	PurgeComm( hCom, /*PURGE_RXABORT |*/ PURGE_RXCLEAR );
                            AddToInfOut(_T("Time out[Read PENDING]"),1,1);
                            MessageBox(_T("Time out!"),_T("Error"),MB_OK);
                        }
                        g_ErrorCode = ERR_CODE_TIME_OUT;
                        return FALSE;
                    }

                } while (Result == FALSE);
#if 0
                if( (m_curCmd == CMD_GET_VERSION) || (m_curCmd == CMD_SYNC_PACKNO) )
                    waitRet = WaitForSingleObject(ReadOverlapped.hEvent,  2000);//unit ms//INFINITE
                else
                    waitRet = WaitForSingleObject(ReadOverlapped.hEvent,  20000);//unit ms//INFINITE
                ResetEvent(ReadOverlapped.hEvent);
                //clear the error
                SetLastError(0);
                if(waitRet == WAIT_TIMEOUT) {
                    pDlg->AddToInfOut(_T("Device no response"),1,1);
                    return FALSE;
                }
#endif

            } else if (LastError != 0) {
                pDlg->AddToInfOut(pDlg->itos(debugcn,10)+_T("Failed to read data,error code:")+pDlg->itos(LastError,10),1,1);
                if (DevInterface == PORT_COM) { //Reset
                    if(!OpenDeviceCom(strWhichCom)) {
                        g_ErrorCode = ERR_CODE_COM_ERROR_OPEN;
                        SetLastError(0);
                        return FALSE;
                    }

                }
                return FALSE;
            }
        }


#ifdef WINUSB_NUVO_DFU
        if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
            nRead = 64;
        } else {
            ResetEvent(ReadOverlapped.hEvent);
            Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
        }
#else
        ResetEvent(ReadOverlapped.hEvent);
        Result = GetOverlappedResult(hRead, &ReadOverlapped, &nRead, FALSE);
#endif

        // 2013.08.11 - Y.C.Huang
        // May read zero bytes data
        if ((Result == TRUE) && (nRead == 0))
            continue;

        if (Result == TRUE) {
            if (nRead < len) {
                pDlg->AddToInfOut(_T("Wrong size:")+pDlg->itos(nRead,10) + _T(" ") + pDlg->itos(len,10),1,1);//ReadOverlapped.InternalHigh
                g_ErrorCode = ERR_CODE_LOST_PACKET;
                g_packno++;
                return FALSE;

                //test
                //ResetEvent(ReadOverlapped.hEvent);
                //pBuf += nRead;
                //len -= nRead;
                //continue;

            }
        } else {
            LastError=GetLastError();
            pDlg->AddToInfOut(_T("GetOverlappedResult error")+pDlg->itos(LastError,10),1,1);
            return FALSE;
        }

        //pBuf = ReadReportBuffer;//test

        //if(bDetecting)
        //	return TRUE;

        if (DevInterface == PORT_USB) {
            //len = MAX_PACKET+1;//test
            memcpy(&lcksum, pBuf+1, 2);
            pBuf += 5;
        } else {
            //len = MAX_PACKET; //test
            memcpy(&lcksum, pBuf, 2);
            pBuf += 4;
        }

        memcpy(&curPacketNo, pBuf, 4);
        if (curPacketNo != g_packno) {
//Progress
            if ( (( m_curCmd == CMD_UPDATE_CONFIG)||( m_curCmd == CMD_ERASE_ALL)) && (g_packno == 4) ) {
                //20% - 100%
                m_writeProgress.SetPos(uWaitProgress/8);
                uWaitProgress ++;
                if(uWaitProgress >= 800)
                    uWaitProgress = 800;

            } else if ( (( m_curCmd == CMD_UPDATE_APROM) || (m_curCmd == CMD_UPDATE_DATAFLASH)) && (g_packno==4) ) {
                if (m_writeProgress.GetPos() != uWaitProgress/30)
                    m_writeProgress.SetPos(uWaitProgress/100); //5% - 20%
                uWaitProgress ++;
                if (uWaitProgress >= 2000)
                    uWaitProgress = 2000;

            }

            tick2 = ::GetTickCount();
            if( (tick2 - tick1) > timeout ) {
                if (DevInterface == PORT_COM)
                    PurgeComm( hCom, PURGE_RXABORT | PURGE_RXCLEAR );

                if (!bDetectingSaved) {
                    AddToInfOut(_T("Time out[Read]"),1,1);
                    MessageBox(_T("Time out!"),_T("Error"),MB_OK);
                }
                g_ErrorCode = ERR_CODE_TIME_OUT;
                return FALSE;
            } else
                continue;
        } else {
            if(lcksum != gcksum) {
                Str=_T("Checksum error:");
                for(i=len-1; i>=0; i--) {
                    Str+=pDlg->itos(ReadReportBuffer[i],16).Right(2)+_T(" ");
                }
                Str+=_T("gcksum=")+pDlg->itos(gcksum,16).Right(4)+_T(" ");

                pDlg->AddToInfOut(Str,FALSE,TRUE);
                g_ErrorCode = ERR_CODE_CHECKSUM_ERROR;
                g_packno++;
                return FALSE;
            }

            if( ( m_curCmd == CMD_UPDATE_APROM) && (g_packno==4) )
                AddToInfOut(_T("Erase success,sending next packet..."),1,1);



            g_packno++;
            break;
        }
    }
    debugcn++;

    return TRUE;
}



/*---------------------------------------------------------------------------------------------------------*/
/* Function:     WriteData                                                              	               */
/*                                                                                                         */
/* Description:                                                                                            */
/*               ��USB/��f/Ethernet�g�J��ơA�ݼg�J��Ʀ�m��:WriteReportBuffer                          */
/*                                                                                                         */
/* Parameter:                                                                                              */
/*				 DevInterface	   	  	  -[in]   �s���������O���@��                                      */
/* Returns:                                                                                                */
/*               �L                                                                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

BOOL CNuvoISPDlg::WriteData(int DevInterface)
{
    BOOL Result;
    unsigned long written;
    UINT LastError, len;
    CString Str;
    HANDLE hWrite;
    UCHAR	*pBuf;
    DWORD waitRet;
    COMSTAT ComStat;
    DWORD dwErrorFlags;

    ResetEvent(WriteOverlapped.hEvent);
    WriteOverlapped.Offset = 0;
    WriteOverlapped.OffsetHigh = 0;
    g_ErrorCode = 0;

    if (DevInterface == PORT_USB) {
        pBuf = WriteReportBuffer;
        len = MAX_PACKET+1;
        hWrite = hUsbHandle;
    } else {
        pBuf = WriteReportBuffer + 1;
        len = MAX_PACKET;
        hWrite = hCom;
    }

    gcksum = Checksum(WriteReportBuffer+1, MAX_PACKET);

    if (DevInterface == PORT_COM)
        ClearCommError(hWrite,&dwErrorFlags,&ComStat);

    if(DevInterface == PORT_EMAC) {
        sendto(sclient, (const char*)pBuf, len,0,(struct sockaddr*)&sin, len);
        return TRUE;
    }

#ifdef WINUSB_NUVO_DFU
    if ((DevInterface == PORT_USB) && (hWinUSBHandle != INVALID_HANDLE_VALUE)) {
        WINUSB_SETUP_PACKET SetupPacket;
        UCHAR	status_buff[6];
        ULONG 	cbSent = 0;

        pBuf = WriteReportBuffer+1;
        len = MAX_PACKET;

        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
        //Create the setup packet
        SetupPacket.RequestType = 0x21;
        SetupPacket.Request = 0x1;			// DFU_DNLOAD
        SetupPacket.Value = 0;				// wBlockNum
        SetupPacket.Index = 0; 				// Interface
        SetupPacket.Length = len;
        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, pBuf, len, &cbSent, 0);
        if (!Result)
            return FALSE;

        /*
         *  DFU_GETSTATUS to make DFU device enter dfuDNLOAD_IDLE state
         */
        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
        //Create the setup packet
        SetupPacket.RequestType = 0xA1;
        SetupPacket.Request = 0x3;			// DFU_GETSTATUS
        SetupPacket.Value = 0;
        SetupPacket.Index = 0; 				// Interface
        SetupPacket.Length = 6;
        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, &status_buff[0], 6, &cbSent, 0);
        if (!Result)
            return FALSE;

        /*
         *  Send 0 bytes DFU_DNLOAD to complete it.
         */
        ZeroMemory(&SetupPacket, sizeof(WINUSB_SETUP_PACKET));
        //Create the setup packet
        SetupPacket.RequestType = 0x21;
        SetupPacket.Request = 0x1;			// DFU_DNLOAD
        SetupPacket.Value = 1;				// wBlockNum
        SetupPacket.Index = 0; 				// Interface
        SetupPacket.Length = 0;
        Result = WinUsb_ControlTransfer(hWinUSBHandle, SetupPacket, NULL, 0, NULL, 0);
        if (!Result)
            return FALSE;

        return TRUE;
    } else
#endif	// WINUSB_NUVO_DFU

        Result=WriteFile(hWrite,
        pBuf,
        len,
        &written,
        &WriteOverlapped);
    if (Result == 0) {
        LastError=GetLastError();
        if (LastError==ERROR_IO_PENDING) {
            waitRet = WaitForSingleObject(WriteOverlapped.hEvent, 1000 ); // 1sec
            if(waitRet == WAIT_TIMEOUT) {
                AddToInfOut(_T("Timeout[Write PENDING]"),1,1);
                if (DevInterface == PORT_COM)
                    PurgeComm( hCom, PURGE_TXABORT | PURGE_TXCLEAR );

                return FALSE;
            }

            ResetEvent(WriteOverlapped.hEvent);
            //clear the error
            SetLastError(0);
        } else if (LastError != 0) {
            pDlg->AddToInfOut(pDlg->itos(g_debug,10)+_T("Failed to write data,error code:")+pDlg->itos(LastError,10),1,1);
            if (DevInterface == PORT_COM) { //Reset COM
                //PurgeComm( hCom, PURGE_TXABORT | PURGE_TXCLEAR );
                if(!OpenDeviceCom(strWhichCom)) {
                    g_ErrorCode = ERR_CODE_COM_ERROR_OPEN;
                    SetLastError(0);
                    return FALSE;
                }

            }
            //ExceptionHandle(wndHandle, LastError);
            return FALSE;
        }
    }
    //FlushFileBuffers(hWrite);

    //pDlg->AddToInfOut(pDlg->itos(g_debug,10) + _T(" write success"),1,1);
    g_debug++;

    return TRUE;
}
